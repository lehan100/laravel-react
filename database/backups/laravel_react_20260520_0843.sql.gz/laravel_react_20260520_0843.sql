/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: laravel_react
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES
(1,'Acme Corporation','2026-03-04 02:28:32','2026-03-04 02:28:32');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `administrative_regions`
--

DROP TABLE IF EXISTS `administrative_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrative_regions` (
  `id` tinyint(3) unsigned NOT NULL,
  `name` varchar(535) NOT NULL,
  `name_en` varchar(535) NOT NULL,
  `code_name` varchar(535) DEFAULT NULL,
  `code_name_en` varchar(535) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrative_regions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `administrative_regions` WRITE;
/*!40000 ALTER TABLE `administrative_regions` DISABLE KEYS */;
INSERT INTO `administrative_regions` VALUES
(1,'Đông Bắc Bộ','Northeast','dong_bac_bo','northest'),
(2,'Tây Bắc Bộ','Northwest','tay_bac_bo','northwest'),
(3,'Đồng bằng sông Hồng','Red River Delta','dong_bang_song_hong','red_river_delta'),
(4,'Bắc Trung Bộ','North Central Coast','bac_trung_bo','north_central_coast'),
(5,'Duyên hải Nam Trung Bộ','South Central Coast','duyen_hai_nam_trung_bo','south_central_coast'),
(6,'Tây Nguyên','Central Highlands','tay_nguyen','central_highlands'),
(7,'Đông Nam Bộ','Southeast','dong_nam_bo','southeast'),
(8,'Đồng bằng sông Cửu Long','Mekong River Delta','dong_bang_song_cuu_long','southwest');
/*!40000 ALTER TABLE `administrative_regions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `administrative_units`
--

DROP TABLE IF EXISTS `administrative_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrative_units` (
  `id` tinyint(3) unsigned NOT NULL,
  `full_name` varchar(535) DEFAULT NULL,
  `full_name_en` varchar(535) DEFAULT NULL,
  `short_name` varchar(535) DEFAULT NULL,
  `short_name_en` varchar(535) DEFAULT NULL,
  `code_name` varchar(535) DEFAULT NULL,
  `code_name_en` varchar(535) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrative_units`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `administrative_units` WRITE;
/*!40000 ALTER TABLE `administrative_units` DISABLE KEYS */;
INSERT INTO `administrative_units` VALUES
(1,'Thành phố trực thuộc trung ương','Municipality','Thành phố','City','thanh_pho_truc_thuoc_trung_uong','municipality'),
(2,'Tỉnh','Province','Tỉnh','Province','tinh','province'),
(3,'Phường','Ward','Phường','Ward','phuong','ward'),
(4,'Xã','Commune','Xã','Commune','xa','commune'),
(5,'Đặc khu tại hải đảo','Special administrative region','Đặc khu','Special administrative region','dac_khu','special_administrative_region');
/*!40000 ALTER TABLE `administrative_units` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `agent_conversation_messages`
--

DROP TABLE IF EXISTS `agent_conversation_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_conversation_messages` (
  `id` varchar(36) NOT NULL,
  `conversation_id` varchar(36) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `agent` varchar(535) NOT NULL,
  `role` varchar(25) NOT NULL,
  `content` text NOT NULL,
  `attachments` text NOT NULL,
  `tool_calls` text NOT NULL,
  `tool_results` text NOT NULL,
  `usage` text NOT NULL,
  `meta` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_index` (`conversation_id`,`user_id`,`updated_at`),
  KEY `agent_conversation_messages_user_id_index` (`user_id`),
  KEY `agent_conversation_messages_conversation_id_index` (`conversation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_conversation_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agent_conversation_messages` WRITE;
/*!40000 ALTER TABLE `agent_conversation_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_conversation_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `agent_conversations`
--

DROP TABLE IF EXISTS `agent_conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_conversations` (
  `id` varchar(36) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(535) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_conversations_user_id_updated_at_index` (`user_id`,`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_conversations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `agent_conversations` WRITE;
/*!40000 ALTER TABLE `agent_conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_conversations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `attribute_translations`
--

DROP TABLE IF EXISTS `attribute_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `name` varchar(535) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_translations_attribute_id_locale_unique` (`attribute_id`,`locale`),
  KEY `attribute_translations_locale_name_index` (`locale`,`name`),
  CONSTRAINT `attribute_translations_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `attribute_translations` WRITE;
/*!40000 ALTER TABLE `attribute_translations` DISABLE KEYS */;
INSERT INTO `attribute_translations` VALUES
(1,1,'0','Thương hiệu','2026-05-05 04:54:29','2026-05-05 05:08:55'),
(2,1,'1','Brand','2026-05-05 04:54:29','2026-05-05 04:54:29'),
(3,1,'2','ブランド','2026-05-05 04:54:29','2026-05-05 04:54:29'),
(4,2,'0','Màu sắc','2026-05-05 07:22:07','2026-05-05 07:22:07'),
(5,2,'1','Color','2026-05-05 07:22:07','2026-05-05 07:22:07'),
(6,2,'2','色','2026-05-05 07:22:07','2026-05-05 07:22:07');
/*!40000 ALTER TABLE `attribute_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `attribute_value_translations`
--

DROP TABLE IF EXISTS `attribute_value_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_value_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_value_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `value` varchar(535) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_value_translations_attribute_value_id_locale_unique` (`attribute_value_id`,`locale`),
  KEY `attribute_value_translations_locale_value_index` (`locale`,`value`),
  CONSTRAINT `attribute_value_translations_attribute_value_id_foreign` FOREIGN KEY (`attribute_value_id`) REFERENCES `attribute_values` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_value_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `attribute_value_translations` WRITE;
/*!40000 ALTER TABLE `attribute_value_translations` DISABLE KEYS */;
INSERT INTO `attribute_value_translations` VALUES
(1,1,'0','Hương Thị','2026-05-05 04:54:29','2026-05-05 04:54:29'),
(2,1,'1','Huong Thi','2026-05-05 04:54:29','2026-05-05 04:54:29'),
(3,1,'2','Huong Thi','2026-05-05 04:54:29','2026-05-05 04:54:29'),
(4,2,'0','Trung Nguyên','2026-05-05 05:19:41','2026-05-05 05:19:41'),
(5,2,'1','Trung Nguyen','2026-05-05 05:19:41','2026-05-05 05:19:41'),
(6,2,'2','Trung Nguyen','2026-05-05 05:19:41','2026-05-05 05:19:41'),
(7,3,'0','Ohlins','2026-05-05 06:34:45','2026-05-05 06:34:45'),
(8,3,'1','Ohlins','2026-05-05 06:34:45','2026-05-05 06:34:45'),
(9,3,'2','Ohlins','2026-05-05 06:34:45','2026-05-05 06:34:45'),
(10,4,'0','Jw Speaker','2026-05-05 06:37:46','2026-05-05 06:37:46'),
(11,4,'1','Jw Speaker','2026-05-05 06:37:46','2026-05-05 06:37:46'),
(12,4,'2','Jw Speaker','2026-05-05 06:37:46','2026-05-05 06:37:46'),
(13,18,'0','Đỏ','2026-05-05 07:22:07','2026-05-05 07:22:07'),
(14,18,'1','Red','2026-05-05 07:22:07','2026-05-05 07:22:07'),
(15,18,'2','赤','2026-05-05 07:22:07','2026-05-05 07:22:07'),
(16,19,'0','Xanh Lá','2026-05-05 07:43:57','2026-05-05 07:43:57'),
(17,19,'1','Green','2026-05-05 07:43:57','2026-05-05 07:43:57'),
(18,19,'2','グリーン','2026-05-05 07:43:57','2026-05-08 08:11:31');
/*!40000 ALTER TABLE `attribute_value_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `attribute_values`
--

DROP TABLE IF EXISTS `attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_id` bigint(20) unsigned NOT NULL,
  `value` varchar(535) NOT NULL,
  `image` varchar(535) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_values_attribute_id_value_unique` (`attribute_id`,`value`),
  CONSTRAINT `attribute_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_values`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `attribute_values` WRITE;
/*!40000 ALTER TABLE `attribute_values` DISABLE KEYS */;
INSERT INTO `attribute_values` VALUES
(1,1,'Hương Thị','/media/editor/sachs-logo-9905-1778210684.png','#9F2D2D',0,'2026-05-05 04:54:29','2026-05-08 03:24:47',NULL),
(2,1,'Trung Nguyên','/media/editor/attributes/remus-7689-1778210240.png','#A22F2F',1,'2026-05-05 05:19:41','2026-05-08 03:17:48',NULL),
(3,1,'Ohlins','/media/editor/attributes/ohlins-5723-1778210250.png','#000000',2,'2026-05-05 06:34:45','2026-05-08 03:17:48',NULL),
(4,1,'Jw Speaker','/media/editor/attributes/jw-2-1708-1778210264.png','#000000',3,'2026-05-05 06:37:46','2026-05-08 03:17:48',NULL),
(18,2,'Đỏ',NULL,'#F70202',0,'2026-05-05 07:22:07','2026-05-05 07:22:44',NULL),
(19,2,'Xanh Lá',NULL,'#2F9E00',1,'2026-05-05 07:43:57','2026-05-05 07:43:57',NULL),
(20,3,'Red',NULL,NULL,0,'2026-05-13 03:54:58','2026-05-13 03:54:58',NULL),
(21,4,'XL',NULL,NULL,0,'2026-05-13 03:54:58','2026-05-13 03:54:58',NULL);
/*!40000 ALTER TABLE `attribute_values` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `attributes`
--

DROP TABLE IF EXISTS `attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attributes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(535) NOT NULL,
  `code` varchar(150) DEFAULT NULL,
  `type` varchar(535) NOT NULL DEFAULT 'text',
  `status` int(10) unsigned NOT NULL DEFAULT 1,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attributes_name_unique` (`name`),
  UNIQUE KEY `attributes_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attributes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `attributes` WRITE;
/*!40000 ALTER TABLE `attributes` DISABLE KEYS */;
INSERT INTO `attributes` VALUES
(1,'Thương hiệu','brand','image',1,0,'2026-05-05 04:54:29','2026-05-05 05:58:36',NULL),
(2,'Màu sắc','color','color',1,0,'2026-05-05 07:22:07','2026-05-05 07:22:07',NULL),
(3,'Color',NULL,'text',1,0,'2026-05-13 03:54:58','2026-05-13 03:54:58',NULL),
(4,'Size',NULL,'text',1,0,'2026-05-13 03:54:58','2026-05-13 03:54:58',NULL);
/*!40000 ALTER TABLE `attributes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'product',
  `photo` varchar(535) DEFAULT NULL,
  `page_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_status_order_index` (`status`,`order`),
  KEY `categories_parent_id_index` (`parent_id`),
  KEY `categories_type_index` (`type`),
  KEY `categories_page_id_foreign` (`page_id`),
  CONSTRAINT `categories_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(4,1,0,23,'product','xoong-noi-1678432362-1773908924.webp',NULL,'2026-03-18 14:57:29','2026-04-29 09:16:43',NULL),
(13,1,0,4,'product','ban-ui-1678432743-1773890792.webp',NULL,'2026-03-19 03:29:59','2026-04-29 09:16:43',NULL),
(14,1,1,4,'product','chao-chong-dinh-1675405144-1678346906-1773891158.webp',NULL,'2026-03-19 03:34:27','2026-04-29 09:16:43',NULL),
(15,1,1,23,'product','duong-da-1675404411-1678087283-1773908824.webp',NULL,'2026-03-19 03:40:43','2026-04-29 09:16:43',NULL),
(19,1,2,4,'product',NULL,NULL,'2026-03-20 04:17:41','2026-04-29 09:16:43',NULL),
(20,1,2,NULL,'news','/media/editor/posts/duong-da-1675404411-1678087283-1778213582.png',NULL,'2026-04-08 08:03:08','2026-05-08 04:13:07',NULL),
(21,1,3,NULL,'contact',NULL,3,'2026-04-08 08:18:41','2026-05-06 08:52:58',NULL),
(22,1,0,NULL,'page',NULL,2,'2026-04-08 08:20:07','2026-05-06 08:48:59',NULL),
(23,1,1,NULL,'product','/media/editor/categories/gia-dung-khac-1678432821-1778211340.jpg',NULL,'2026-04-08 08:29:06','2026-05-08 03:35:48',NULL),
(51,1,1,78,'product',NULL,NULL,'2026-04-29 02:42:41','2026-04-29 09:16:43',NULL),
(54,1,0,78,'product',NULL,NULL,'2026-04-29 02:42:41','2026-04-29 09:16:43',NULL),
(56,1,1,78,'product',NULL,NULL,'2026-04-29 02:42:41','2026-04-29 09:16:43',NULL),
(78,1,2,23,'product',NULL,NULL,'2026-04-29 02:51:05','2026-04-29 09:16:43',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `category_post`
--

DROP TABLE IF EXISTS `category_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_post` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_post_category_id_post_id_unique` (`category_id`,`post_id`),
  KEY `category_post_post_id_foreign` (`post_id`),
  CONSTRAINT `category_post_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_post_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_post`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `category_post` WRITE;
/*!40000 ALTER TABLE `category_post` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_post` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `category_product`
--

DROP TABLE IF EXISTS `category_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_product` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_product_product_id_category_id_unique` (`product_id`,`category_id`),
  KEY `category_product_category_id_foreign` (`category_id`),
  CONSTRAINT `category_product_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_product`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `category_product` WRITE;
/*!40000 ALTER TABLE `category_product` DISABLE KEYS */;
INSERT INTO `category_product` VALUES
(4,7,15),
(111,44,56),
(113,45,51),
(112,45,54),
(92,45,56),
(114,46,51),
(110,46,54),
(105,50,56),
(106,55,56),
(107,56,56),
(109,57,51),
(108,57,56);
/*!40000 ALTER TABLE `category_product` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `category_translations`
--

DROP TABLE IF EXISTS `category_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `name` varchar(535) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `seo_title` varchar(535) DEFAULT NULL,
  `seo_keyword` varchar(535) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_locale_unique` (`category_id`,`locale`),
  KEY `category_translations_locale_index` (`locale`),
  CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `category_translations` WRITE;
/*!40000 ALTER TABLE `category_translations` DISABLE KEYS */;
INSERT INTO `category_translations` VALUES
(2,4,'vi','Đồ gia dụng',NULL,NULL,'Đồ gia dụng chính hãng, giá tốt, giao hàng nhanh toàn quốc',NULL,'Chuyên cung cấp đồ gia dụng thông minh, thiết bị nhà bếp và điện gia dụng chính hãng. Sản phẩm đa dạng, giá ưu đãi, bảo hành uy tín, giao hàng nhanh tận nơi.','2026-03-18 14:57:29','2026-04-29 09:02:00',NULL),
(3,4,'en','Household appliances',NULL,NULL,'Household Appliances: Shop Quality Home Essentials Online',NULL,'Browse our wide selection of household appliances for every room. From kitchen essentials to laundry solutions, find top-quality products at great prices.','2026-03-18 14:57:29','2026-04-29 09:02:00',NULL),
(4,4,'ja','家庭用電化製品',NULL,NULL,'家庭用電化製品（生活家電）の通販・最新おすすめ商品一覧',NULL,'キッチン家電から掃除機、生活必需品まで、人気の家庭用電化製品を豊富に取り揃えています。最新モデルの機能比較や売れ筋ランキングなど、毎日の暮らしを豊かにする家電選','2026-03-18 14:57:29','2026-04-29 09:02:00',NULL),
(23,13,'vi','Bàn ủi',NULL,NULL,'Bàn ủi','Bàn ủi','Bàn ủi','2026-03-19 03:29:59','2026-04-29 02:46:11',NULL),
(24,13,'en','Ironing board',NULL,NULL,'Ironing board','Bàn ủi','Bàn ủi','2026-03-19 03:29:59','2026-04-29 04:50:54',NULL),
(25,13,'ja','アイロン台',NULL,NULL,'アイロン台','JP Bàn ủi','JP Bàn ủi','2026-03-19 03:29:59','2026-04-29 04:50:54',NULL),
(26,14,'vi','Chảo chống dính',NULL,NULL,'Chảo chống dính','Chảo chống dính','Chảo chống dính','2026-03-19 03:34:27','2026-04-29 02:46:11',NULL),
(27,14,'en','Non-stick pan',NULL,NULL,'Non-stick pan','Chảo chống dính','Chảo chống dính','2026-03-19 03:34:27','2026-04-29 04:52:08',NULL),
(28,14,'ja','焦げ付き防止パン',NULL,NULL,'焦げ付き防止パン','JP Chảo chống dính','JP Chảo chống dính','2026-03-19 03:34:27','2026-04-29 04:52:08',NULL),
(29,15,'vi','Làm đẹp',NULL,NULL,'Bí quyết Làm đẹp: Chăm sóc da, Trang điểm & Xu hướng mới',NULL,'Khám phá các bí quyết làm đẹp, hướng dẫn chăm sóc da, mẹo trang điểm và xu hướng mới nhất. Cập nhật thông tin hữu ích giúp bạn luôn tự tin và tỏa sáng mỗi ngày.','2026-03-19 03:40:43','2026-04-29 09:03:33',NULL),
(30,15,'en','Beautify',NULL,NULL,'Beautify: Essential Tips and Tools for Better Results',NULL,'Explore our Beautify collection for expert advice, high-quality products, and innovative techniques designed to enhance your personal style and appearance.','2026-03-19 03:40:44','2026-04-29 09:03:33',NULL),
(31,15,'ja','美しくする',NULL,NULL,'自分を磨き、毎日を美しくするヒントと美容情報',NULL,'「美しくする」をテーマに、外見の磨き方から内面の整え方、心地よい暮らしのアイデアまで幅広くご紹介します。自分をより輝かせるための最新美容情報やお手入れのコツ、ラ','2026-03-19 03:40:44','2026-04-29 09:03:33',NULL),
(41,19,'vi','Bàn ủi hơi nước',NULL,NULL,'Bàn ủi hơi nước','Bàn ủi hơi nước','Bàn ủi hơi nước','2026-03-20 04:17:41','2026-04-29 02:46:11',NULL),
(42,19,'en','Steam iron',NULL,NULL,'Steam iron','Bàn ủi hơi nước','Bàn ủi hơi nước','2026-03-20 04:17:41','2026-04-29 04:51:36',NULL),
(43,19,'ja','スチームアイロン',NULL,NULL,'スチームアイロン','JP Bàn ủi hơi nước','JP Bàn ủi hơi nước','2026-03-20 04:17:41','2026-04-29 04:51:36',NULL),
(44,20,'vi','Tin tức',NULL,NULL,'Tin tức mới nhất hôm nay | Cập nhật tin nóng 24h',NULL,'Cập nhật tin tức mới nhất, nóng hổi trong ngày về các lĩnh vực đời sống, xã hội và công nghệ. Thông tin nhanh chóng, chính xác và được cập nhật liên tục.','2026-04-08 08:03:08','2026-04-29 09:04:21',NULL),
(45,20,'en','News',NULL,NULL,'Latest News, Updates and Breaking Stories',NULL,'Stay up to date with the latest news, breaking stories, and in-depth reports. Explore our comprehensive archive of current events and trending topics.','2026-04-08 08:03:08','2026-04-29 09:04:21',NULL),
(46,20,'ja','ニュース',NULL,NULL,'最新ニュース・新着情報一覧',NULL,'当サイトの最新ニュースや新着情報を一覧でご覧いただけます。プレスリリース、イベント情報、重要なお知らせなど、皆様に役立つ最新トピックスを随時更新してお届けします','2026-04-08 08:03:08','2026-04-29 09:04:21',NULL),
(47,21,'vi','Liên hệ',NULL,NULL,'Liên hệ - Thông tin tư vấn và hỗ trợ khách hàng','Liên hệ','Liên hệ ngay với chúng tôi để được tư vấn và hỗ trợ nhanh nhất. Cung cấp đầy đủ thông tin về hotline, email và địa chỉ văn phòng làm việc chính thức.','2026-04-08 08:18:41','2026-04-29 09:05:04',NULL),
(48,21,'en','Contact Us',NULL,NULL,'Contact Us | Get in Touch with Our Team',NULL,'Have questions or need support? Contact us today via phone, email, or our online form. Our team is ready to help with all your inquiries and feedback.','2026-04-08 08:18:41','2026-04-29 09:05:04',NULL),
(49,21,'ja','接触',NULL,NULL,'接触（せっしょく）に関する記事一覧｜解説・最新情報まとめ',NULL,'接触に関する最新情報や基礎知識を網羅したカテゴリーページです。物理的な接触の仕組みや技術的な解説、実生活に関連するトピックなど、多角的な視点で執筆された記事を一','2026-04-08 08:18:41','2026-04-29 09:04:43',NULL),
(50,22,'vi','Giới thiệu',NULL,NULL,'Giới thiệu về chúng tôi | Câu chuyện & Sứ mệnh phát triển','Giới thiệu','Tìm hiểu chi tiết về quá trình hình thành, sứ mệnh và tầm nhìn của chúng tôi. Khám phá những giá trị cốt lõi mang lại niềm tin và sự hài lòng cho khách hàng.','2026-04-08 08:20:07','2026-05-03 07:23:46',NULL),
(51,22,'en','About Us',NULL,NULL,'About Us: Our Story, Mission, and Core Values',NULL,'Learn more about our company\'s history, mission, and core values. Meet the dedicated team behind our brand and discover how we work to serve our customers.','2026-04-08 08:20:07','2026-05-03 07:23:46',NULL),
(52,22,'ja','導入',NULL,NULL,'導入方法・手順・事例の解説記事一覧｜スムーズな導入のためのガ',NULL,'導入に関する最新情報や、具体的な導入手順、成功事例をまとめた記事一覧ページです。スムーズに導入を進めるためのポイントや、導入後の活用方法、注意点など、実務に役立','2026-04-08 08:20:07','2026-05-03 07:23:46',NULL),
(53,23,'vi','Sản phẩm',NULL,NULL,'Danh sách Sản phẩm Chính hãng, Giá tốt & Đa dạng Mẫu mã',NULL,'Khám phá các dòng sản phẩm chính hãng, đa dạng mẫu mã với giá thành cực tốt. Cam kết chất lượng uy tín, bảo hành đầy đủ, đáp ứng mọi nhu cầu mua sắm của bạn.','2026-04-08 08:29:06','2026-05-04 08:36:01',NULL),
(54,23,'en','Products',NULL,NULL,'Genuine Product List: Best Prices & Diverse Models',NULL,'Explore our collection of genuine products with diverse models at the best prices. Guaranteed quality, full warranty, and perfect for all your shopping needs.','2026-04-08 08:29:06','2026-05-08 07:50:05',NULL),
(55,23,'ja','商品一覧',NULL,NULL,'正規品・本物製品一覧 | お得な価格と豊富なラインナップ',NULL,'多彩なデザインと手頃な価格の正規品・本物をチェック。信頼の品質と充実の保証で、あらゆるショッピングニーズにお応えします。','2026-04-08 08:29:06','2026-05-08 07:50:05',NULL),
(83,51,'vi','Heo Thắng',NULL,NULL,'Heo Thắng Xe Máy Chính Hãng, Độ Bền Cao, Giá Tốt Nhất','Heo Thắng','Chuyên heo thắng xe máy chính hãng, độ bền cao và an toàn vượt trội. Đầy đủ mẫu mã cho mọi dòng xe với giá cực tốt. Giao hàng nhanh toàn quốc, kiểm tra tận nơi.','2026-04-29 02:42:41','2026-04-29 02:55:06',NULL),
(84,51,'en','Brake Caliper',NULL,NULL,'Brake Calipers: Shop Replacement Front & Rear Calipers','Brake Caliper','Browse our selection of high-quality brake calipers for all makes and models. Shop durable replacement parts and performance calipers to ensure safe braking.','2026-04-29 02:42:41','2026-04-29 02:58:02',NULL),
(85,51,'ja','ブレーキキャリパー',NULL,NULL,'ブレーキキャリパーの通販・販売 | 人気メーカーから純正品まで',NULL,'ブレーキキャリパーの商品一覧です。高い制動力を誇るスポーツモデルからドレスアップに最適なカラーキャリパー、補修用の純正品まで幅広く取り揃えています。人気ブランド','2026-04-29 02:42:41','2026-04-29 02:58:18',NULL),
(92,54,'vi','Tay Thắng',NULL,NULL,'Tay Thắng Xe Máy Chính Hãng, Giá Tốt | Mẫu Mã Đa Dạng','Tay Thắng','Chuyên cung cấp các loại tay thắng xe máy chính hãng, tay thắng độ kiểng đẹp, bền bỉ. Đa dạng mẫu mã cho mọi dòng xe, giá tốt nhất thị trường. Mua ngay tại đây!','2026-04-29 02:42:41','2026-04-29 02:55:25',NULL),
(93,54,'en','Brake Lever',NULL,NULL,'High-Quality Brake Levers for Bicycles & Motorcycles','Brake Lever','Explore our range of durable brake levers for bicycles and motorcycles. Find high-performance upgrades and reliable replacement parts for better stopping power.','2026-04-29 02:42:41','2026-04-29 02:59:07',NULL),
(94,54,'ja','ブレーキレバー',NULL,NULL,'ブレーキレバーの通販・商品一覧 | 人気ブランドやおすすめアイ',NULL,'ロードバイク、クロスバイク、MTBなど、各種自転車に最適なブレーキレバーを豊富に取り揃えています。シマノをはじめとする人気ブランドの商品から、軽量モデル、カラーバ','2026-04-29 02:42:41','2026-04-29 02:59:07',NULL),
(98,56,'vi','Bao Tay',NULL,NULL,'Bao Tay Cao Cấp, Chính Hãng, Mẫu Mã Đa Dạng & Giá Tốt','Bao Tay','Tổng hợp các loại bao tay cao cấp, bền đẹp, mẫu mã đa dạng phù hợp mọi nhu cầu. Mua bao tay chính hãng, giá tốt, hỗ trợ giao hàng nhanh toàn quốc tại đây.','2026-04-29 02:42:41','2026-04-29 02:55:43',NULL),
(99,56,'en','Glove',NULL,NULL,'Shop Premium Gloves | Protective, Stylish & Durable',NULL,'Explore our extensive collection of high-quality gloves. From protective work gear to stylish seasonal accessories, find the perfect pair for any need today.','2026-04-29 02:42:41','2026-04-29 03:01:13',NULL),
(100,56,'ja','グローブ',NULL,NULL,'グローブの商品一覧｜人気のおすすめアイテムを通販で探す',NULL,'グローブの商品一覧ページです。定番の人気アイテムから機能性に優れたモデルまで、幅広いラインナップを豊富に取り揃えています。用途やデザイン、好みに合わせたおすすめ','2026-04-29 02:42:41','2026-04-29 03:01:13',NULL),
(218,78,'vi','Đồ chơi xe',NULL,NULL,'Đồ Chơi Xe - Phụ Kiện Xe Cao Cấp, Chính Hãng, Giá Tốt',NULL,'Tổng hợp đồ chơi xe, phụ kiện trang trí nội ngoại thất chính hãng cho ô tô và xe máy. Sản phẩm chất lượng, giá ưu đãi, bảo hành uy tín. Xem ngay tại đây!','2026-04-29 02:51:05','2026-04-29 02:56:58',NULL),
(219,78,'en','Car toys',NULL,NULL,'Car Toys & Vehicle Playsets for Kids | Shop Online',NULL,'Explore a wide range of car toys for kids. Shop racing sets, diecast models, and remote control vehicles for all ages. Quality fun at great prices. Shop now!','2026-04-29 02:51:05','2026-04-29 02:56:58',NULL),
(220,78,'ja','車のおもちゃ',NULL,NULL,'車のおもちゃの通販・人気ランキング | ミニカーやラジコン、知',NULL,'人気の車のおもちゃを豊富にラインナップ。トミカなどのミニカーから、迫力のラジコン、はたらく車、小さなお子様でも安心の木製玩具まで、年齢や好みに合わせて選べます。','2026-04-29 02:51:05','2026-04-29 02:56:58',NULL);
/*!40000 ALTER TABLE `category_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `coupon_categories`
--

DROP TABLE IF EXISTS `coupon_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_coupon_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupon_categories_unique` (`promotion_coupon_id`,`category_id`),
  KEY `coupon_categories_category_id_index` (`category_id`),
  CONSTRAINT `coupon_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_categories_promotion_coupon_id_foreign` FOREIGN KEY (`promotion_coupon_id`) REFERENCES `promotion_coupons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `coupon_categories` WRITE;
/*!40000 ALTER TABLE `coupon_categories` DISABLE KEYS */;
INSERT INTO `coupon_categories` VALUES
(1,1,15,'2026-04-09 08:22:14','2026-04-09 08:22:14'),
(2,1,56,'2026-04-29 04:38:32','2026-04-29 04:38:32');
/*!40000 ALTER TABLE `coupon_categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `coupon_products`
--

DROP TABLE IF EXISTS `coupon_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_coupon_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupon_products_unique` (`promotion_coupon_id`,`product_id`),
  KEY `coupon_products_product_id_index` (`product_id`),
  CONSTRAINT `coupon_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_products_promotion_coupon_id_foreign` FOREIGN KEY (`promotion_coupon_id`) REFERENCES `promotion_coupons` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_products`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `coupon_products` WRITE;
/*!40000 ALTER TABLE `coupon_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(535) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `field_groups`
--

DROP TABLE IF EXISTS `field_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `field_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(535) NOT NULL,
  `fields_schema` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields_schema`)),
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `field_groups` WRITE;
/*!40000 ALTER TABLE `field_groups` DISABLE KEYS */;
INSERT INTO `field_groups` VALUES
(1,'Homepage','[{\"key\":\"title\",\"label\":\"Ti\\u00eau \\u0111\\u1ec1\",\"type\":\"text\",\"translatable\":true,\"required\":true},{\"key\":\"banner\",\"label\":\"Banner\",\"type\":\"image\",\"translatable\":false,\"required\":true},{\"key\":\"products\",\"label\":\"Product News\",\"type\":\"product\",\"translatable\":false,\"required\":true},{\"key\":\"post_lasts\",\"label\":\"Post News\",\"type\":\"relation_new\",\"translatable\":false,\"required\":true}]',1,'2026-05-06 04:40:16','2026-05-06 07:57:23'),
(2,'Single Page','[{\"key\":\"title\",\"label\":\"Title\",\"type\":\"text\",\"translatable\":true,\"required\":true}]',1,'2026-05-06 07:25:16','2026-05-08 08:20:54');
/*!40000 ALTER TABLE `field_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `inventory_adjustment_histories`
--

DROP TABLE IF EXISTS `inventory_adjustment_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_adjustment_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL DEFAULT 'set',
  `old_quantity` int(11) NOT NULL DEFAULT 0,
  `new_quantity` int(11) NOT NULL DEFAULT 0,
  `delta` int(11) NOT NULL DEFAULT 0,
  `reason` varchar(500) DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_adjustment_histories_product_id_created_at_index` (`product_id`,`created_at`),
  CONSTRAINT `inventory_adjustment_histories_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_adjustment_histories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `inventory_adjustment_histories` WRITE;
/*!40000 ALTER TABLE `inventory_adjustment_histories` DISABLE KEYS */;
INSERT INTO `inventory_adjustment_histories` VALUES
(1,7,1,'adjust',1000,1900,900,'điều chỉnh','{\"channel\":\"website\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-28 07:33:28','2026-04-28 07:33:28'),
(2,7,1,'adjust',1900,900,-1000,'điều chỉnh','{\"channel\":\"website\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-28 07:33:41','2026-04-28 07:33:41'),
(3,7,1,'set',900,900,0,'Cập nhật trạng thái còn hàng/hết hàng từ danh sách kho','{\"channel\":\"website\",\"type\":\"toggle_stock\",\"old_is_stock\":true,\"new_is_stock\":false,\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-28 07:52:36','2026-04-28 07:52:36'),
(4,7,1,'set',900,900,0,'Cập nhật trạng thái còn hàng/hết hàng từ danh sách kho','{\"channel\":\"website\",\"type\":\"toggle_stock\",\"old_is_stock\":false,\"new_is_stock\":true,\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-28 07:52:37','2026-04-28 07:52:37'),
(5,7,1,'set',900,900,0,'Cập nhật trạng thái còn hàng/hết hàng từ danh sách kho','{\"channel\":\"website\",\"type\":\"toggle_stock\",\"old_is_stock\":true,\"new_is_stock\":false,\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-28 07:53:18','2026-04-28 07:53:18'),
(6,7,1,'set',900,900,0,'Cập nhật trạng thái còn hàng/hết hàng từ danh sách kho','{\"channel\":\"website\",\"type\":\"toggle_stock\",\"old_is_stock\":false,\"new_is_stock\":true,\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-28 07:54:35','2026-04-28 07:54:35'),
(7,7,1,'set',900,900,0,'Cập nhật trạng thái còn hàng/hết hàng từ danh sách kho','{\"channel\":\"website\",\"type\":\"toggle_stock\",\"old_is_stock\":true,\"new_is_stock\":false,\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-28 07:54:41','2026-04-28 07:54:41'),
(8,22,1,'set',0,100,100,NULL,'{\"channel\":\"website\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-29 08:55:05','2026-04-29 08:55:05'),
(9,55,1,'set',4,5,1,NULL,'{\"channel\":\"website\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-04 08:50:25','2026-05-04 08:50:25'),
(10,55,1,'adjust',5,9,4,NULL,'{\"channel\":\"website\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-04 08:50:35','2026-05-04 08:50:35'),
(11,25,1,'set',0,0,0,'Cập nhật trạng thái kho từ trang quản lý kho.','{\"channel\":\"website\",\"type\":\"toggle_stock\",\"old_is_stock\":true,\"new_is_stock\":false,\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-04 08:53:49','2026-05-04 08:53:49'),
(12,7,1,'order_deduct',898,896,-2,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":7,\"order_number\":\"B004\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":898,\"new_quantity\":896}','2026-05-05 07:38:49','2026-05-05 07:38:49'),
(13,55,1,'order_deduct',9,8,-1,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":7,\"order_number\":\"B004\",\"channel\":\"order\",\"delta\":-1,\"old_quantity\":9,\"new_quantity\":8}','2026-05-05 07:38:49','2026-05-05 07:38:49'),
(14,22,1,'order_deduct',100,99,-1,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":8,\"order_number\":\"B002\",\"channel\":\"order\",\"delta\":-1,\"old_quantity\":100,\"new_quantity\":99}','2026-05-05 07:51:36','2026-05-05 07:51:36'),
(15,7,1,'set',10,896,886,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-08 09:08:02','2026-05-08 09:08:02'),
(16,25,1,'set',0,102,102,NULL,'{\"channel\":\"website\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 03:22:41','2026-05-11 03:22:41'),
(17,7,1,'promotion_buytogift_reserve',696,596,-100,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":100}','2026-05-11 03:44:06','2026-05-11 03:44:06'),
(18,7,1,'promotion_buytogift_reserve',596,586,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":10,\"allocated_quantity\":10}','2026-05-11 03:52:50','2026-05-11 03:52:50'),
(19,7,1,'promotion_buytogift_reserve',586,546,-40,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":50,\"allocated_quantity\":50}','2026-05-11 04:04:16','2026-05-11 04:04:16'),
(20,7,1,'promotion_buytogift_reserve',546,526,-20,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":70,\"allocated_quantity\":70}','2026-05-11 04:09:08','2026-05-11 04:09:08'),
(21,7,1,'promotion_buytogift_release',526,566,40,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":60}','2026-05-11 04:10:10','2026-05-11 04:10:10'),
(22,7,1,'promotion_buytogift_release',566,586,20,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":50,\"allocated_quantity\":50}','2026-05-11 04:41:47','2026-05-11 04:41:47'),
(23,7,1,'promotion_buytogift_reserve',586,576,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":60}','2026-05-11 04:43:24','2026-05-11 04:43:24'),
(24,7,1,'promotion_buytogift_reserve',576,575,-1,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":61,\"allocated_quantity\":61}','2026-05-11 04:46:13','2026-05-11 04:46:13'),
(25,25,1,'promotion_buytogift_reserve',102,42,-60,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":61,\"allocated_quantity\":60}','2026-05-11 05:28:20','2026-05-11 05:28:20'),
(26,7,1,'promotion_buytogift_release',575,616,41,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":61,\"allocated_quantity\":20}','2026-05-11 05:28:20','2026-05-11 05:28:20'),
(27,25,1,'promotion_buytogift_release',42,60,18,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":61,\"allocated_quantity\":42}','2026-05-11 05:41:54','2026-05-11 05:41:54'),
(28,7,1,'promotion_buytogift_release',616,622,6,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":61,\"allocated_quantity\":14}','2026-05-11 05:41:54','2026-05-11 05:41:54'),
(29,25,1,'promotion_buytogift_reserve',60,57,-3,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":61,\"allocated_quantity\":45}','2026-05-11 06:08:28','2026-05-11 06:08:28'),
(30,7,1,'promotion_buytogift_reserve',622,621,-1,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":61,\"allocated_quantity\":15}','2026-05-11 06:08:28','2026-05-11 06:08:28'),
(31,25,1,'promotion_buytogift_reserve',57,45,-12,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":89,\"allocated_quantity\":57}','2026-05-11 06:18:00','2026-05-11 06:18:00'),
(32,7,1,'promotion_buytogift_reserve',621,617,-4,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":89,\"allocated_quantity\":19}','2026-05-11 06:18:00','2026-05-11 06:18:00'),
(33,25,1,'promotion_buytogift_release',45,57,12,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":63,\"allocated_quantity\":45}','2026-05-11 06:18:10','2026-05-11 06:18:10'),
(34,7,1,'promotion_buytogift_release',617,621,4,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":63,\"allocated_quantity\":15}','2026-05-11 06:18:10','2026-05-11 06:18:10'),
(35,25,1,'promotion_buytogift_reserve',57,51,-6,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":70,\"allocated_quantity\":51}','2026-05-11 06:18:34','2026-05-11 06:18:34'),
(36,7,1,'promotion_buytogift_reserve',621,619,-2,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":70,\"allocated_quantity\":17}','2026-05-11 06:18:34','2026-05-11 06:18:34'),
(37,25,1,'promotion_buytogift_release',51,96,45,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":11,\"allocated_quantity\":6}','2026-05-11 06:19:57','2026-05-11 06:19:57'),
(38,7,1,'promotion_buytogift_release',619,634,15,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":11,\"allocated_quantity\":2}','2026-05-11 06:19:57','2026-05-11 06:19:57'),
(39,25,1,'promotion_buytogift_reserve',96,27,-69,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:20:07','2026-05-11 06:20:07'),
(40,7,1,'promotion_buytogift_reserve',634,611,-23,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:20:07','2026-05-11 06:20:07'),
(41,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:20:24','2026-05-11 06:20:24'),
(42,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:20:24','2026-05-11 06:20:24'),
(43,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:20:31','2026-05-11 06:20:31'),
(44,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:20:31','2026-05-11 06:20:31'),
(45,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:20:41','2026-05-11 06:20:41'),
(46,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:20:41','2026-05-11 06:20:41'),
(47,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:20:53','2026-05-11 06:20:53'),
(48,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:20:53','2026-05-11 06:20:53'),
(49,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:21:22','2026-05-11 06:21:22'),
(50,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:21:22','2026-05-11 06:21:22'),
(51,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:21:36','2026-05-11 06:21:36'),
(52,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:21:36','2026-05-11 06:21:36'),
(53,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:21:57','2026-05-11 06:21:57'),
(54,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:21:57','2026-05-11 06:21:57'),
(55,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:22:43','2026-05-11 06:22:43'),
(56,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:22:43','2026-05-11 06:22:43'),
(57,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:27:50','2026-05-11 06:27:50'),
(58,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:27:50','2026-05-11 06:27:50'),
(59,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:27:56','2026-05-11 06:27:56'),
(60,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:27:56','2026-05-11 06:27:56'),
(61,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:28:02','2026-05-11 06:28:02'),
(62,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:28:02','2026-05-11 06:28:02'),
(63,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:29:05','2026-05-11 06:29:05'),
(64,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:29:05','2026-05-11 06:29:05'),
(65,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:29:13','2026-05-11 06:29:13'),
(66,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:29:13','2026-05-11 06:29:13'),
(67,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:29:23','2026-05-11 06:29:23'),
(68,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:29:23','2026-05-11 06:29:23'),
(69,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:29:40','2026-05-11 06:29:40'),
(70,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:29:40','2026-05-11 06:29:40'),
(71,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:29:46','2026-05-11 06:29:46'),
(72,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:29:46','2026-05-11 06:29:46'),
(73,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:31:31','2026-05-11 06:31:31'),
(74,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:31:31','2026-05-11 06:31:31'),
(75,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:32:26','2026-05-11 06:32:26'),
(76,7,1,'promotion_buytogift_reserve',627,611,-16,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:32:26','2026-05-11 06:32:26'),
(77,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:33:37','2026-05-11 06:33:37'),
(78,7,1,'promotion_buytogift_release',611,627,16,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":9}','2026-05-11 06:33:37','2026-05-11 06:33:37'),
(79,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:37:41','2026-05-11 06:37:41'),
(80,7,1,'promotion_buytogift_reserve',627,616,-11,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":20}','2026-05-11 06:37:41','2026-05-11 06:37:41'),
(81,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:37:47','2026-05-11 06:37:47'),
(82,7,1,'promotion_buytogift_reserve',616,611,-5,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:37:47','2026-05-11 06:37:47'),
(83,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:37:55','2026-05-11 06:37:55'),
(84,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:39:20','2026-05-11 06:39:20'),
(85,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:39:32','2026-05-11 06:39:32'),
(86,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:39:45','2026-05-11 06:39:45'),
(87,7,1,'promotion_buytogift_release',611,631,20,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":5}','2026-05-11 06:39:45','2026-05-11 06:39:45'),
(88,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:39:51','2026-05-11 06:39:51'),
(89,7,1,'promotion_buytogift_reserve',631,626,-5,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":10}','2026-05-11 06:39:51','2026-05-11 06:39:51'),
(90,25,1,'promotion_buytogift_release',27,75,48,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":27}','2026-05-11 06:40:06','2026-05-11 06:40:06'),
(91,7,1,'promotion_buytogift_reserve',626,616,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":20}','2026-05-11 06:40:06','2026-05-11 06:40:06'),
(92,25,1,'promotion_buytogift_reserve',75,27,-48,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:40:11','2026-05-11 06:40:11'),
(93,7,1,'promotion_buytogift_reserve',616,611,-5,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":25}','2026-05-11 06:40:11','2026-05-11 06:40:11'),
(94,25,1,'promotion_buytogift_release',27,66,39,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":50,\"allocated_quantity\":36}','2026-05-11 06:44:53','2026-05-11 06:44:53'),
(95,7,1,'promotion_buytogift_release',611,624,13,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":50,\"allocated_quantity\":12}','2026-05-11 06:44:53','2026-05-11 06:44:53'),
(96,25,1,'promotion_buytogift_reserve',66,63,-3,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":52,\"allocated_quantity\":39}','2026-05-11 06:49:57','2026-05-11 06:49:57'),
(97,7,1,'promotion_buytogift_reserve',624,623,-1,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":52,\"allocated_quantity\":13}','2026-05-11 06:49:57','2026-05-11 06:49:57'),
(98,25,1,'promotion_buytogift_reserve',63,27,-36,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":75}','2026-05-11 06:50:53','2026-05-11 06:50:53'),
(99,7,1,'promotion_buytogift_reserve',623,621,-2,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":15}','2026-05-11 06:50:53','2026-05-11 06:50:53'),
(100,7,1,'promotion_buytogift_reserve',621,616,-5,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":20}','2026-05-11 06:51:16','2026-05-11 06:51:16'),
(101,25,NULL,'promotion_buytogift_release',27,42,15,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":60}','2026-05-11 06:57:50','2026-05-11 06:57:50'),
(102,25,1,'promotion_buytogift_reserve',42,39,-3,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":63}','2026-05-11 06:59:55','2026-05-11 06:59:55'),
(103,7,1,'promotion_buytogift_reserve',616,615,-1,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":21}','2026-05-11 06:59:55','2026-05-11 06:59:55'),
(104,25,1,'promotion_buytogift_release',39,42,3,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":60}','2026-05-11 07:00:00','2026-05-11 07:00:00'),
(105,7,1,'promotion_buytogift_release',615,616,1,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":100,\"allocated_quantity\":20}','2026-05-11 07:00:00','2026-05-11 07:00:00'),
(106,7,1,'set',896,20,-876,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 07:16:10','2026-05-11 07:16:10'),
(107,7,1,'set',20,16,-4,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 07:16:24','2026-05-11 07:16:24'),
(108,25,1,'promotion_buytogift_release',42,102,60,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":25,\"stock_scope\":\"all\",\"stock_limit\":null,\"allocated_quantity\":0}','2026-05-11 07:38:06','2026-05-11 07:38:06'),
(109,7,1,'set',616,900,284,NULL,'{\"channel\":\"website\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 07:45:27','2026-05-11 07:45:27'),
(110,7,1,'set',16,300,284,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 07:45:36','2026-05-11 07:45:36'),
(111,7,1,'set',300,400,100,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 07:45:44','2026-05-11 07:45:44'),
(112,7,1,'order_deduct',900,898,-2,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":10,\"order_number\":\"B0012\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":900,\"new_quantity\":898}','2026-05-11 08:01:11','2026-05-11 08:01:11'),
(113,25,1,'order_deduct',102,99,-3,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":10,\"order_number\":\"B0012\",\"channel\":\"order\",\"delta\":-3,\"old_quantity\":102,\"new_quantity\":99}','2026-05-11 08:01:11','2026-05-11 08:01:11'),
(114,7,1,'order_deduct',898,897,-1,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":10,\"order_number\":\"B0012\",\"channel\":\"order\",\"delta\":-1,\"old_quantity\":898,\"new_quantity\":897}','2026-05-11 08:31:19','2026-05-11 08:31:19'),
(115,7,1,'order_rollback',897,898,1,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":10,\"order_number\":\"B0012\",\"channel\":\"order\",\"delta\":1,\"old_quantity\":897,\"new_quantity\":898}','2026-05-11 08:34:07','2026-05-11 08:34:07'),
(116,46,1,'order_rollback',1,2,1,'Order cancelled/returned (stock rollback)','{\"type\":\"order_delivery_rollback\",\"order_id\":9,\"order_number\":\"A004\",\"channel\":\"order\",\"delta\":1,\"old_quantity\":1,\"new_quantity\":2}','2026-05-11 08:44:53','2026-05-11 08:44:53'),
(117,7,1,'order_deduct',898,896,-2,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":11,\"order_number\":\"B0002\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":898,\"new_quantity\":896}','2026-05-11 08:52:16','2026-05-11 08:52:16'),
(118,25,1,'order_deduct',99,96,-3,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":11,\"order_number\":\"B0002\",\"channel\":\"order\",\"delta\":-3,\"old_quantity\":99,\"new_quantity\":96}','2026-05-11 08:52:16','2026-05-11 08:52:16'),
(119,7,1,'set',400,400,0,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 02:38:00','2026-05-12 02:38:00'),
(120,7,1,'set',500,500,0,NULL,'{\"channel\":\"website\",\"variant_id\":2,\"variant_sku\":\"A001-2\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 02:38:02','2026-05-12 02:38:02'),
(121,7,1,'set',400,500,100,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 02:38:13','2026-05-12 02:38:13'),
(122,7,1,'set',500,500,0,NULL,'{\"channel\":\"website\",\"variant_id\":2,\"variant_sku\":\"A001-2\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 02:41:20','2026-05-12 02:41:20'),
(123,7,1,'set',500,499,-1,NULL,'{\"channel\":\"website\",\"variant_id\":1,\"variant_sku\":\"A001-Blue\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 02:42:19','2026-05-12 02:42:19'),
(124,7,1,'promotion_buytogift_release',999,1005,6,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":54}','2026-05-12 04:12:59','2026-05-12 04:12:59'),
(125,7,1,'promotion_buytogift_reserve',499,479,-20,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":20,\"variant_stock\":true}','2026-05-12 04:12:59','2026-05-12 04:12:59'),
(126,7,1,'promotion_buytogift_reserve',500,480,-20,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":20,\"variant_stock\":true}','2026-05-12 04:12:59','2026-05-12 04:12:59'),
(127,7,1,'promotion_buytogift_release',1005,1023,18,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0}','2026-05-12 04:12:59','2026-05-12 04:12:59'),
(128,7,1,'promotion_buytogift_release',479,489,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 04:14:51','2026-05-12 04:14:51'),
(129,7,1,'promotion_buytogift_release',480,490,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 04:14:51','2026-05-12 04:14:51'),
(130,7,1,'promotion_buytogift_reserve',489,479,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 04:21:39','2026-05-12 04:21:39'),
(131,7,1,'promotion_buytogift_reserve',490,480,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 04:21:39','2026-05-12 04:21:39'),
(132,7,1,'promotion_buytogift_release',979,1033,54,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0}','2026-05-12 04:21:39','2026-05-12 04:21:39'),
(133,45,1,'order_deduct',39,37,-2,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":12,\"order_number\":\"T001\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":39,\"new_quantity\":37}','2026-05-12 04:59:30','2026-05-12 04:59:30'),
(134,7,1,'promotion_buytogift_release',477,487,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:12:39','2026-05-12 05:12:39'),
(135,7,1,'promotion_buytogift_release',480,489,9,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:12:39','2026-05-12 05:12:39'),
(136,7,1,'promotion_buytogift_release',487,497,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:12:39','2026-05-12 05:12:39'),
(137,7,1,'promotion_buytogift_release',489,499,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:12:39','2026-05-12 05:12:39'),
(138,7,1,'promotion_buytogift_reserve',497,487,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:12:47','2026-05-12 05:12:47'),
(139,7,1,'promotion_buytogift_reserve',499,489,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:12:47','2026-05-12 05:12:47'),
(140,7,1,'promotion_buytogift_reserve',487,477,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:12:47','2026-05-12 05:12:47'),
(141,7,1,'promotion_buytogift_reserve',489,479,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:12:47','2026-05-12 05:12:47'),
(142,7,1,'promotion_buytogift_release',477,487,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:13:20','2026-05-12 05:13:20'),
(143,7,1,'promotion_buytogift_release',479,489,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:13:20','2026-05-12 05:13:20'),
(144,7,1,'promotion_buytogift_release',487,497,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:13:20','2026-05-12 05:13:20'),
(145,7,1,'promotion_buytogift_release',489,499,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 05:13:20','2026-05-12 05:13:20'),
(146,7,1,'promotion_buytogift_reserve',497,487,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:13:28','2026-05-12 05:13:28'),
(147,7,1,'promotion_buytogift_reserve',499,489,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:13:28','2026-05-12 05:13:28'),
(148,7,1,'promotion_buytogift_reserve',487,477,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:13:28','2026-05-12 05:13:28'),
(149,7,1,'promotion_buytogift_reserve',489,479,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 05:13:28','2026-05-12 05:13:28'),
(150,45,1,'order_rollback',37,39,2,'Order deleted (stock rollback)','{\"type\":\"order_delete_rollback\",\"order_id\":12,\"order_number\":\"T001\",\"channel\":\"order\",\"delta\":2,\"old_quantity\":37,\"new_quantity\":39}','2026-05-12 06:22:19','2026-05-12 06:22:19'),
(151,7,1,'promotion_buytogift_release',477,487,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:22:43','2026-05-12 06:22:43'),
(152,7,1,'promotion_buytogift_release',480,491,11,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:22:43','2026-05-12 06:22:43'),
(153,7,1,'promotion_buytogift_release',487,497,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:22:43','2026-05-12 06:22:43'),
(154,7,1,'promotion_buytogift_release',491,501,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:22:43','2026-05-12 06:22:43'),
(155,7,1,'promotion_buytogift_reserve',497,487,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:22:45','2026-05-12 06:22:45'),
(156,7,1,'promotion_buytogift_reserve',501,491,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:22:45','2026-05-12 06:22:45'),
(157,7,1,'promotion_buytogift_reserve',487,477,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:22:45','2026-05-12 06:22:45'),
(158,7,1,'promotion_buytogift_reserve',491,481,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:22:45','2026-05-12 06:22:45'),
(159,45,1,'order_deduct',39,37,-2,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":13,\"order_number\":\"T0011\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":39,\"new_quantity\":37}','2026-05-12 06:24:23','2026-05-12 06:24:23'),
(160,7,1,'promotion_buytogift_release',477,486,9,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:24:51','2026-05-12 06:24:51'),
(161,7,1,'promotion_buytogift_release',481,491,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:24:51','2026-05-12 06:24:51'),
(162,7,1,'promotion_buytogift_release',486,496,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:24:51','2026-05-12 06:24:51'),
(163,7,1,'promotion_buytogift_release',491,501,10,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":0,\"variant_stock\":true}','2026-05-12 06:24:51','2026-05-12 06:24:51'),
(164,7,1,'promotion_buytogift_reserve',496,486,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:24:53','2026-05-12 06:24:53'),
(165,7,1,'promotion_buytogift_reserve',501,491,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:24:53','2026-05-12 06:24:53'),
(166,7,1,'promotion_buytogift_reserve',486,476,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:24:53','2026-05-12 06:24:53'),
(167,7,1,'promotion_buytogift_reserve',491,481,-10,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 06:24:53','2026-05-12 06:24:53'),
(168,45,1,'order_rollback',37,39,2,'Order deleted (stock rollback)','{\"type\":\"order_delete_rollback\",\"order_id\":13,\"order_number\":\"T0011\",\"channel\":\"order\",\"delta\":2,\"old_quantity\":37,\"new_quantity\":39}','2026-05-12 07:06:03','2026-05-12 07:06:03'),
(169,45,1,'order_deduct',39,37,-2,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":14,\"order_number\":\"H0003\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":39,\"new_quantity\":37}','2026-05-12 07:07:18','2026-05-12 07:07:18'),
(170,45,1,'order_deduct',37,35,-2,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":37,\"new_quantity\":35}','2026-05-12 07:08:53','2026-05-12 07:08:53'),
(171,45,1,'order_rollback',35,37,2,'Order cancelled/returned (stock rollback)','{\"type\":\"order_delivery_rollback\",\"order_id\":14,\"order_number\":\"H0003\",\"channel\":\"order\",\"delta\":2,\"old_quantity\":35,\"new_quantity\":37}','2026-05-12 07:09:55','2026-05-12 07:09:55'),
(172,45,1,'order_deduct',37,36,-1,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":-1,\"old_quantity\":37,\"new_quantity\":36}','2026-05-12 07:19:48','2026-05-12 07:19:48'),
(173,45,1,'order_deduct',36,26,-10,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":-10,\"old_quantity\":36,\"new_quantity\":26}','2026-05-12 07:20:16','2026-05-12 07:20:16'),
(174,45,1,'order_rollback',26,37,11,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":11,\"old_quantity\":26,\"new_quantity\":37}','2026-05-12 07:22:00','2026-05-12 07:22:00'),
(175,25,1,'order_deduct',96,93,-3,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":-3,\"old_quantity\":96,\"new_quantity\":93}','2026-05-12 07:56:32','2026-05-12 07:56:32'),
(176,45,1,'order_deduct',37,23,-14,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":-14,\"old_quantity\":37,\"new_quantity\":23}','2026-05-12 07:56:32','2026-05-12 07:56:32'),
(177,25,1,'order_rollback',93,96,3,'Order cancelled/returned (stock rollback)','{\"type\":\"order_delivery_rollback\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":3,\"old_quantity\":93,\"new_quantity\":96}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(178,45,1,'order_rollback',23,39,16,'Order cancelled/returned (stock rollback)','{\"type\":\"order_delivery_rollback\",\"order_id\":15,\"order_number\":\"J0001\",\"channel\":\"order\",\"delta\":16,\"old_quantity\":23,\"new_quantity\":39}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(179,7,1,'promotion_buytogift_release',562,570,8,'Release stock from buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":2,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":60,\"allocated_quantity\":10,\"variant_stock\":true}','2026-05-12 08:25:22','2026-05-12 08:25:22'),
(180,7,1,'promotion_buytogift_reserve',570,565,-5,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":1,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":15,\"variant_stock\":true}','2026-05-12 08:26:34','2026-05-12 08:26:34'),
(181,7,1,'promotion_buytogift_reserve',537,532,-5,'Reserve stock for buy x get y promotion','{\"promotion_buytogift_offer_rule_id\":3,\"promotion_buytogift_offer_id\":1,\"product_id\":7,\"variant_id\":2,\"stock_scope\":\"limited\",\"stock_limit\":62,\"allocated_quantity\":15,\"variant_stock\":true}','2026-05-12 08:26:34','2026-05-12 08:26:34'),
(182,25,1,'order_deduct',96,95,-1,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":16,\"order_number\":\"L0001\",\"channel\":\"order\",\"delta\":-1,\"old_quantity\":96,\"new_quantity\":95}','2026-05-12 09:05:58','2026-05-12 09:05:58'),
(183,45,1,'order_deduct',39,37,-2,'Order created (initial stock deduction)','{\"type\":\"order_delivery\",\"order_id\":16,\"order_number\":\"L0001\",\"channel\":\"order\",\"delta\":-2,\"old_quantity\":39,\"new_quantity\":37}','2026-05-12 09:05:58','2026-05-12 09:05:58'),
(184,45,1,'order_deduct',37,36,-1,'Order items changed while delivered/completed (stock sync)','{\"type\":\"order_delivery_sync\",\"order_id\":16,\"order_number\":\"L0001\",\"channel\":\"order\",\"delta\":-1,\"old_quantity\":37,\"new_quantity\":36}','2026-05-12 09:14:04','2026-05-12 09:14:04');
/*!40000 ALTER TABLE `inventory_adjustment_histories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `code` varchar(10) NOT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `photo` varchar(50) NOT NULL,
  `status` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES
(1,'Tiếng Việt','vi',NULL,'vi-1772204431-1772682777.webp',1,'2026-03-04 02:53:30','2026-03-05 03:52:57',NULL),
(2,'English','en',NULL,'en-1772204447-1772682765.webp',1,'2026-03-04 02:53:48','2026-05-15 03:19:44',NULL),
(3,'日本','ja',NULL,'ja-1772204497-1772682754.webp',1,'2026-03-04 02:54:18','2026-05-15 03:19:40',NULL),
(4,'1','2',NULL,'',0,'2026-03-06 02:49:06','2026-03-06 02:49:28','2026-03-06 02:49:28');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `mail_template_translations`
--

DROP TABLE IF EXISTS `mail_template_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mail_template_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mail_template_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `name` varchar(535) NOT NULL,
  `subject` varchar(535) NOT NULL,
  `body_html` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail_template_locale_unique` (`mail_template_id`,`locale`),
  KEY `mail_template_translations_locale_index` (`locale`),
  CONSTRAINT `mail_template_translations_mail_template_id_foreign` FOREIGN KEY (`mail_template_id`) REFERENCES `mail_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_template_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `mail_template_translations` WRITE;
/*!40000 ALTER TABLE `mail_template_translations` DISABLE KEYS */;
INSERT INTO `mail_template_translations` VALUES
(1,1,'vi','Đơn hàng mới','Đơn hàng #{{order_code}} đã được tạo','<tr>\n    <td style=\"padding:32px;\">\n        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;border:1px solid #e2e8f0;border-radius:20px;overflow:hidden;\">\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Mã đơn hàng</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_code}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Khách hàng</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{customer_name}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Phương thức thanh toán</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{payment_method}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Phương thức vận chuyển</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{shipping_method}}</td></tr>\n            <tr><td style=\"padding:14px 18px;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Tổng thanh toán</td><td style=\"padding:14px 18px;font-size:14px;color:#0f172a;font-weight:700;\">{{order_total}}</td></tr>\n        </table>\n        <div style=\"margin-top:24px;border:1px solid #dbeafe;border-radius:20px;background:#eff6ff;padding:20px;\">\n            <div style=\"margin-bottom:14px;font-size:14px;font-weight:800;color:#1d4ed8;\">Sản phẩm đã mua</div>\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\n                <thead>\n                    <tr>\n                        <th align=\"left\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Sản phẩm</th>\n                        <th align=\"center\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">SL</th>\n                        <th align=\"right\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Thành tiền</th>\n                    </tr>\n                </thead>\n                <tbody>{{items_html}}</tbody>\n            </table>\n        </div>\n        <div style=\"margin-top:28px;text-align:center;\">\n            <a href=\"{{order_url}}\" style=\"display:inline-block;background:linear-gradient(135deg,#0f172a 0%,#0b5f6b 100%);color:#fff;text-decoration:none;padding:14px 24px;border-radius:999px;font-weight:700;\">Xem đơn hàng</a>\n        </div>\n    </td>\n</tr>','2026-05-14 03:32:30','2026-05-14 03:41:40'),
(2,1,'en','New Order','Order #{{order_code}} has been created','<tr>\n    <td style=\"padding:32px;\">\n        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;border:1px solid #e2e8f0;border-radius:20px;overflow:hidden;\">\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Order code</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_code}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Customer</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{customer_name}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Payment method</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{payment_method}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Shipping method</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{shipping_method}}</td></tr>\n            <tr><td style=\"padding:14px 18px;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Order total</td><td style=\"padding:14px 18px;font-size:14px;color:#0f172a;font-weight:700;\">{{order_total}}</td></tr>\n        </table>\n        <div style=\"margin-top:24px;border:1px solid #dbeafe;border-radius:20px;background:#eff6ff;padding:20px;\">\n            <div style=\"margin-bottom:14px;font-size:14px;font-weight:800;color:#1d4ed8;\">Purchased items</div>\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\n                <thead>\n                    <tr>\n                        <th align=\"left\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Item</th>\n                        <th align=\"center\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Qty</th>\n                        <th align=\"right\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Amount</th>\n                    </tr>\n                </thead>\n                <tbody>{{items_html}}</tbody>\n            </table>\n        </div>\n        <div style=\"margin-top:28px;text-align:center;\">\n            <a href=\"{{order_url}}\" style=\"display:inline-block;background:linear-gradient(135deg,#0f172a 0%,#0b5f6b 100%);color:#fff;text-decoration:none;padding:14px 24px;border-radius:999px;font-weight:700;\">View order</a>\n        </div>\n    </td>\n</tr>','2026-05-14 03:32:30','2026-05-14 03:41:40'),
(3,1,'ja','新しい注文','注文 #{{order_code}} が作成されました','<tr>\n    <td style=\"padding:32px;\">\n        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;border:1px solid #e2e8f0;border-radius:20px;overflow:hidden;\">\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">注文番号</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_code}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">顧客名</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{customer_name}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">支払い方法</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{payment_method}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">配送方法</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{shipping_method}}</td></tr>\n            <tr><td style=\"padding:14px 18px;font-size:13px;color:#64748b;font-weight:700;width:40%;\">合計金額</td><td style=\"padding:14px 18px;font-size:14px;color:#0f172a;font-weight:700;\">{{order_total}}</td></tr>\n        </table>\n        <div style=\"margin-top:24px;border:1px solid #dbeafe;border-radius:20px;background:#eff6ff;padding:20px;\">\n            <div style=\"margin-bottom:14px;font-size:14px;font-weight:800;color:#1d4ed8;\">購入商品</div>\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\n                <thead>\n                    <tr>\n                        <th align=\"left\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">商品</th>\n                        <th align=\"center\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">数量</th>\n                        <th align=\"right\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">金額</th>\n                    </tr>\n                </thead>\n                <tbody>{{items_html}}</tbody>\n            </table>\n        </div>\n        <div style=\"margin-top:28px;text-align:center;\">\n            <a href=\"{{order_url}}\" style=\"display:inline-block;background:linear-gradient(135deg,#0f172a 0%,#0b5f6b 100%);color:#fff;text-decoration:none;padding:14px 24px;border-radius:999px;font-weight:700;\">注文を見る</a>\n        </div>\n    </td>\n</tr>','2026-05-14 03:32:30','2026-05-14 03:41:40'),
(4,2,'vi','Cập nhật đơn hàng','Đơn hàng #{{order_code}} đã được cập nhật','<tr>\n    <td style=\"padding:32px;\">\n        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;border:1px solid #e2e8f0;border-radius:20px;overflow:hidden;\">\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Mã đơn hàng</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_code}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Khách hàng</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{customer_name}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Trạng thái mới</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_status}}</td></tr>\n            <tr><td style=\"padding:14px 18px;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Tổng thanh toán</td><td style=\"padding:14px 18px;font-size:14px;color:#0f172a;font-weight:700;\">{{order_total}}</td></tr>\n        </table>\n        <div style=\"margin-top:24px;border:1px solid #dbeafe;border-radius:20px;background:#eff6ff;padding:20px;\">\n            <div style=\"margin-bottom:14px;font-size:14px;font-weight:800;color:#1d4ed8;\">Sản phẩm đã mua</div>\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\n                <thead><tr><th align=\"left\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Sản phẩm</th><th align=\"center\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">SL</th><th align=\"right\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Thành tiền</th></tr></thead>\n                <tbody>{{items_html}}</tbody>\n            </table>\n        </div>\n        <div style=\"margin-top:28px;text-align:center;\"><a href=\"{{order_url}}\" style=\"display:inline-block;background:linear-gradient(135deg,#0f172a 0%,#0b5f6b 100%);color:#fff;text-decoration:none;padding:14px 24px;border-radius:999px;font-weight:700;\">Xem cập nhật</a></div>\n    </td>\n</tr>','2026-05-15 04:27:18','2026-05-15 04:27:18'),
(5,2,'en','Order Updated','Order #{{order_code}} has been updated','<tr>\n    <td style=\"padding:32px;\">\n        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;border:1px solid #e2e8f0;border-radius:20px;overflow:hidden;\">\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Order code</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_code}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Customer</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{customer_name}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">New status</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_status}}</td></tr>\n            <tr><td style=\"padding:14px 18px;font-size:13px;color:#64748b;font-weight:700;width:40%;\">Order total</td><td style=\"padding:14px 18px;font-size:14px;color:#0f172a;font-weight:700;\">{{order_total}}</td></tr>\n        </table>\n        <div style=\"margin-top:24px;border:1px solid #dbeafe;border-radius:20px;background:#eff6ff;padding:20px;\">\n            <div style=\"margin-bottom:14px;font-size:14px;font-weight:800;color:#1d4ed8;\">Purchased items</div>\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\n                <thead><tr><th align=\"left\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Item</th><th align=\"center\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Qty</th><th align=\"right\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">Amount</th></tr></thead>\n                <tbody>{{items_html}}</tbody>\n            </table>\n        </div>\n        <div style=\"margin-top:28px;text-align:center;\"><a href=\"{{order_url}}\" style=\"display:inline-block;background:linear-gradient(135deg,#0f172a 0%,#0b5f6b 100%);color:#fff;text-decoration:none;padding:14px 24px;border-radius:999px;font-weight:700;\">View update</a></div>\n    </td>\n</tr>','2026-05-15 04:27:18','2026-05-15 04:27:18'),
(6,2,'ja','注文更新','注文 #{{order_code}} が更新されました','<tr>\n    <td style=\"padding:32px;\">\n        <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;border:1px solid #e2e8f0;border-radius:20px;overflow:hidden;\">\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">注文番号</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_code}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">顧客名</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{customer_name}}</td></tr>\n            <tr><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:13px;color:#64748b;font-weight:700;width:40%;\">新しい状態</td><td style=\"padding:14px 18px;border-bottom:1px solid #e2e8f0;font-size:14px;color:#0f172a;font-weight:700;\">{{order_status}}</td></tr>\n            <tr><td style=\"padding:14px 18px;font-size:13px;color:#64748b;font-weight:700;width:40%;\">合計金額</td><td style=\"padding:14px 18px;font-size:14px;color:#0f172a;font-weight:700;\">{{order_total}}</td></tr>\n        </table>\n        <div style=\"margin-top:24px;border:1px solid #dbeafe;border-radius:20px;background:#eff6ff;padding:20px;\">\n            <div style=\"margin-bottom:14px;font-size:14px;font-weight:800;color:#1d4ed8;\">購入商品</div>\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse:collapse;\">\n                <thead><tr><th align=\"left\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">商品</th><th align=\"center\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">数量</th><th align=\"right\" style=\"padding:10px 0;border-bottom:1px solid #bfdbfe;color:#1e3a8a;font-size:13px;\">金額</th></tr></thead>\n                <tbody>{{items_html}}</tbody>\n            </table>\n        </div>\n        <div style=\"margin-top:28px;text-align:center;\"><a href=\"{{order_url}}\" style=\"display:inline-block;background:linear-gradient(135deg,#0f172a 0%,#0b5f6b 100%);color:#fff;text-decoration:none;padding:14px 24px;border-radius:999px;font-weight:700;\">更新を見る</a></div>\n    </td>\n</tr>','2026-05-15 04:27:18','2026-05-15 04:27:18');
/*!40000 ALTER TABLE `mail_template_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `mail_templates`
--

DROP TABLE IF EXISTS `mail_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mail_templates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(535) NOT NULL,
  `module` varchar(535) DEFAULT NULL,
  `fallback_locale` varchar(10) DEFAULT NULL,
  `variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`variables`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail_templates_key_unique` (`key`),
  KEY `mail_templates_module_index` (`module`),
  KEY `mail_templates_fallback_locale_index` (`fallback_locale`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_templates`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `mail_templates` WRITE;
/*!40000 ALTER TABLE `mail_templates` DISABLE KEYS */;
INSERT INTO `mail_templates` VALUES
(1,'order_created','sales','en','[\"brand_company\",\"brand_phone\",\"brand_address\",\"brand_logo_url\",\"brand_copyright\",\"order_code\",\"customer_name\",\"order_total\",\"payment_method\",\"shipping_method\",\"order_url\",\"items_html\",\"items_text\",\"items_count\"]',1,'2026-05-14 03:32:30','2026-05-14 04:28:28',NULL),
(2,'order_updated','sales','en','[\"brand_company\",\"brand_phone\",\"brand_address\",\"brand_logo_url\",\"brand_copyright\",\"order_code\",\"customer_name\",\"order_status\",\"order_total\",\"order_url\",\"items_html\",\"items_text\",\"items_count\"]',1,'2026-05-15 04:27:18','2026-05-16 11:55:04',NULL);
/*!40000 ALTER TABLE `mail_templates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `media_banner_position`
--

DROP TABLE IF EXISTS `media_banner_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_banner_position` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `position_id` bigint(20) unsigned NOT NULL,
  `banner_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_banner_position_position_id_foreign` (`position_id`),
  KEY `media_banner_position_banner_id_foreign` (`banner_id`),
  CONSTRAINT `media_banner_position_banner_id_foreign` FOREIGN KEY (`banner_id`) REFERENCES `media_banners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `media_banner_position_position_id_foreign` FOREIGN KEY (`position_id`) REFERENCES `media_positions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_banner_position`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `media_banner_position` WRITE;
/*!40000 ALTER TABLE `media_banner_position` DISABLE KEYS */;
INSERT INTO `media_banner_position` VALUES
(23,2,22,'2026-03-20 04:27:03','2026-03-20 04:27:03',NULL);
/*!40000 ALTER TABLE `media_banner_position` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `media_banner_translations`
--

DROP TABLE IF EXISTS `media_banner_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_banner_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `media_banner_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `alias_link` varchar(535) DEFAULT NULL,
  `name` varchar(535) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `photo` varchar(535) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `banner_id_locale_unique` (`media_banner_id`,`locale`),
  KEY `media_banner_translations_locale_index` (`locale`),
  CONSTRAINT `media_banner_translations_media_banner_id_foreign` FOREIGN KEY (`media_banner_id`) REFERENCES `media_banners` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_banner_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `media_banner_translations` WRITE;
/*!40000 ALTER TABLE `media_banner_translations` DISABLE KEYS */;
INSERT INTO `media_banner_translations` VALUES
(18,22,'ja',NULL,'家庭用品',NULL,NULL,'banner01-907x422-1672907779-1678087545-1773477777.webp','2026-03-14 08:43:11','2026-03-14 08:43:11',NULL),
(19,22,'en',NULL,'Household goods',NULL,NULL,'banner01-907x422-1672907779-1678087545-1773477782.webp','2026-03-14 08:43:11','2026-03-14 08:43:11',NULL),
(20,22,'vi',NULL,'Gia dụng',NULL,NULL,'banner01-907x422-1672907779-1678087545-1773477785.webp','2026-03-14 08:43:11','2026-03-18 08:20:28',NULL);
/*!40000 ALTER TABLE `media_banner_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `media_banners`
--

DROP TABLE IF EXISTS `media_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_banners_status_order_index` (`status`,`order`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_banners`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `media_banners` WRITE;
/*!40000 ALTER TABLE `media_banners` DISABLE KEYS */;
INSERT INTO `media_banners` VALUES
(22,1,0,'2026-03-14 08:43:11','2026-03-14 08:43:11',NULL);
/*!40000 ALTER TABLE `media_banners` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `media_positions`
--

DROP TABLE IF EXISTS `media_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_positions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(535) DEFAULT NULL,
  `code` varchar(535) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_positions_code_unique` (`code`),
  KEY `media_positions_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media_positions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `media_positions` WRITE;
/*!40000 ALTER TABLE `media_positions` DISABLE KEYS */;
INSERT INTO `media_positions` VALUES
(1,'SlideShow','slidehome',1,'2026-03-12 04:56:42','2026-03-12 04:56:42',NULL),
(2,'Banner Footer','bannerfooter',1,'2026-03-12 04:57:05','2026-03-12 04:57:05',NULL);
/*!40000 ALTER TABLE `media_positions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(535) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2019_12_14_000001_create_personal_access_tokens_table',1),
(2,'2020_01_01_000001_create_password_resets_table',1),
(3,'2020_01_01_000002_create_failed_jobs_table',1),
(4,'2020_01_01_000003_create_accounts_table',1),
(5,'2020_01_01_000004_create_users_table',1),
(6,'2024_04_02_000000_add_expires_at_to_personal_access_tokens_table',1),
(7,'2024_04_02_000000_rename_password_resets_table',1),
(8,'2026_01_14_052506_create_permission_tables',1),
(9,'2026_01_30_021755_create_language_table',1),
(11,'2026_02_23_064526_create_categories_table',1),
(12,'2026_02_12_051755_create_media_table',2),
(13,'2026_01_11_000001_create_agent_conversations_table',3),
(14,'2026_03_17_070654_create_slugs_table',4),
(15,'2026_03_17_071752_create_category_table',5),
(18,'2026_03_20_022259_create_product_table',6),
(19,'2026_03_20_080044_add_soft_deletes_to_media_banner_translations_table',7),
(20,'2026_03_20_080230_add_soft_deletes_to_category_translations_table',8),
(21,'2026_04_07_000001_add_soft_deletes_to_products_tables',9),
(22,'2026_04_07_000002_add_currency_to_languages_table',10),
(23,'2026_04_07_000003_add_soft_deletes_to_product_translations_table',11),
(24,'2026_04_07_000004_add_order_to_products_tables',12),
(25,'2026_04_08_000001_add_type_to_categories_table',13),
(26,'2026_04_08_100219_create_post_table',14),
(27,'2026_04_09_065346_create_promotion_coupon_table',15),
(28,'2026_04_09_082528_create_promotion_saleoffer_table',16),
(30,'2026_04_09_094719_create_promotion_buytogift_table',17),
(31,'2026_04_28_071500_create_inventory_adjustment_histories_table',18),
(32,'2026_04_28_090000_add_stock_scope_to_buytogift_rules_table',19),
(33,'2026_04_28_160000_create_payment_methods_table',20),
(34,'2026_04_28_170000_add_gateway_fields_to_payment_methods_table',21),
(35,'2026_04_28_085321_create_order_items_table',22),
(36,'2026_04_28_085321_create_orders_table',23),
(37,'2026_04_28_171000_create_order_timelines_table',24),
(38,'2026_04_28_230000_add_order_items_order_id_foreign_key',25),
(39,'2026_04_29_095900_create_field_groups_table',26),
(40,'2026_04_29_100000_create_pages_table',26),
(41,'2026_04_29_100100_create_custom_fields_table',26),
(42,'2026_04_29_100200_create_page_field_values_table',26),
(43,'2026_04_29_120000_create_page_translations_table',27),
(44,'2026_04_29_121000_add_locale_to_page_field_values_table',27),
(45,'2026_04_29_210000_add_currency_fields_to_orders_table',28),
(46,'2026_04_30_000000_backfill_order_price_snapshots',29),
(47,'2026_04_30_010000_add_deleted_at_to_orders_table',30),
(48,'2026_04_30_020000_create_shipping_methods_table',31),
(49,'2026_04_30_030000_add_deleted_at_to_shipping_methods_table',32),
(50,'2026_05_01_000000_create_administrative_location_tables',32),
(51,'2026_05_02_000000_add_location_fields_to_orders_table',33),
(52,'2026_05_04_000001_create_field_groups_table',34),
(53,'2026_05_04_000002_create_pages_table',34),
(54,'2026_05_05_022430_create_attributes_table',35),
(55,'2026_05_05_022431_create_attribute_values_table',35),
(56,'2026_05_05_022432_create_product_variants_table',35),
(57,'2026_05_05_022507_create_variant_attribute_values_table',35),
(58,'2026_05_05_022548_add_brand_and_base_price_to_products_table',35),
(59,'2026_05_05_025458_add_images_to_product_variants_table',36),
(60,'2026_05_05_030000_add_name_translations_to_product_variants_table',37),
(61,'2026_05_05_031000_create_variant_translations_table',38),
(62,'2026_05_05_035617_add_type_to_attributes_and_media_fields_to_attribute_values_table',39),
(63,'2026_05_05_035617_create_attribute_value_translations_table',39),
(64,'2026_05_05_035618_create_attribute_translations_table',39),
(65,'2026_05_05_041000_add_code_to_attributes_table',40),
(66,'2026_05_05_060000_add_deleted_at_to_attributes_tables',41),
(67,'2026_05_05_022430_create_product_attribute_variant_schema',42),
(68,'2026_05_06_032933_create_pages_table',43),
(69,'2026_05_06_032934_create_field_groups_table',43),
(70,'2026_05_06_072352_add_page_id_to_categories_table',44),
(71,'2026_05_06_235900_create_page_translations_table',45),
(72,'2026_05_06_240000_make_pages_title_nullable',46),
(73,'2026_05_07_000001_create_category_post_table',47),
(74,'2026_05_07_061314_create_promotion_campaigns_table',48),
(75,'2026_05_07_061331_create_promotion_campaign_product_table',49),
(76,'2026_05_07_063846_create_promotion_campaign_translations_table',50),
(77,'2026_05_07_065956_add_description_to_promotion_campaign_translations_table',51),
(78,'2026_05_07_070000_add_campaign_id_to_promotion_modules_table',52),
(79,'2026_05_07_074241_make_promotion_campaigns_name_slug_nullable',53),
(80,'2026_05_07_083152_drop_name_and_slug_from_promotion_campaigns_table',54),
(81,'2026_05_11_000000_create_promotion_buytogift_rule_stock_allocations_table',55),
(82,'2026_05_11_000001_add_max_gift_qty_to_promotion_buytogift_offer_rules_table',56),
(83,'2026_05_11_033440_add_priority_to_promotion_coupons_table',57),
(84,'2026_05_11_034318_alter_inventory_adjustment_histories_action_column',58),
(85,'2026_05_11_040800_add_sold_quantity_to_products_table',59),
(86,'2026_05_11_080430_add_promotion_fields_to_orders_table',60),
(87,'2026_05_12_000000_add_variant_id_to_buytogift_pivots',61),
(88,'2026_05_12_010000_create_promotion_buytogift_rule_gift_variant_options_table',62),
(89,'2026_05_13_052812_create_mail_templates_table',63),
(90,'2026_05_14_020222_drop_body_text_from_mail_template_translations_table',64),
(91,'2026_05_14_054217_create_product_attribute_values_table',64);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(535) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES
(297,'App\\Models\\Users\\User',1),
(298,'App\\Models\\Users\\User',1),
(308,'App\\Models\\Users\\User',1),
(309,'App\\Models\\Users\\User',1),
(310,'App\\Models\\Users\\User',1),
(311,'App\\Models\\Users\\User',1),
(312,'App\\Models\\Users\\User',1),
(313,'App\\Models\\Users\\User',1),
(314,'App\\Models\\Users\\User',1),
(315,'App\\Models\\Users\\User',1),
(316,'App\\Models\\Users\\User',1);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(535) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\Users\\User',1),
(3,'App\\Models\\Users\\User',2),
(4,'App\\Models\\Users\\User',6);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned DEFAULT NULL,
  `product_name` varchar(535) NOT NULL,
  `product_sku` varchar(535) DEFAULT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 1,
  `unit_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=234 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES
(9,5,45,'JP Grip Domino A250 - Đen','VAR-1136',1,620000.00,620000.00,'{\"available_quantity\":39,\"price_source\":\"manual\"}','2026-04-29 07:30:43','2026-04-29 07:30:43'),
(10,6,26,'Mâm BST Rapid Tek Ducati Panigale V4 2018-23','VAR-1058',1,89999987.00,89999987.00,'{\"available_quantity\":0,\"price_source\":\"manual\"}','2026-04-29 07:50:47','2026-04-29 07:50:47'),
(25,7,7,'Nước hoa Charme Cool Water - Màu xanh','A001-Blue',2,500000.00,1000000.00,'{\"available_quantity\":10,\"price_source\":\"manual\",\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"M\\u00e0u xanh\",\"label\":\"M\\u00e0u xanh\",\"stock\":10,\"attribute_values\":[]}}','2026-05-05 07:38:49','2026-05-05 07:38:49'),
(26,7,55,'Rear Shock Nitron R1 Honda Wave 125i','VAR-1473',1,25500000.00,25500000.00,'{\"available_quantity\":9,\"price_source\":\"manual\",\"variant\":null}','2026-05-05 07:38:49','2026-05-05 07:38:49'),
(27,8,22,'Nắp Xăng Accossato Yamaha FC124','VAR-2490',1,1990000.00,1990000.00,'{\"available_quantity\":100,\"price_source\":\"manual\",\"variant\":null}','2026-05-05 07:51:36','2026-05-05 07:51:36'),
(55,9,46,'Tay Côn CRG','VAR-1109',1,5900000.00,5900000.00,'{\"available_quantity\":1,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-11 08:44:53','2026-05-11 08:44:53'),
(56,10,7,'Nước hoa Charme Cool Water - Xanh dương','A001-Blue',1,500000.00,500000.00,'{\"available_quantity\":400,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"Xanh d\\u01b0\\u01a1ng\",\"label\":\"Xanh d\\u01b0\\u01a1ng\",\"stock\":400,\"attribute_values\":[]}}','2026-05-11 08:50:51','2026-05-11 08:50:51'),
(57,10,25,'Mâm BST Rapid Tek Ducati Hypermotard 950 2019-23','VAR-1042',3,90000000.00,270000000.00,'{\"available_quantity\":99,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-11 08:50:51','2026-05-11 08:50:51'),
(58,10,7,'Nước hoa Charme Cool Water - Màu tím','A001-2',1,0.00,0.00,'{\"available_quantity\":500,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":{\"id\":2,\"sku\":\"A001-2\",\"name\":\"M\\u00e0u t\\u00edm\",\"label\":\"M\\u00e0u t\\u00edm\",\"stock\":500,\"attribute_values\":[]}}','2026-05-11 08:50:51','2026-05-11 08:50:51'),
(72,11,7,'Nước hoa Charme Cool Water - Xanh dương','A001-Blue',2,500000.00,1000000.00,'{\"available_quantity\":479,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"Xanh d\\u01b0\\u01a1ng\",\"label\":\"Xanh d\\u01b0\\u01a1ng\",\"stock\":479,\"attribute_values\":[]}}','2026-05-12 04:44:57','2026-05-12 04:44:57'),
(73,11,7,'Nước hoa Charme Cool Water - Xanh dương','A001-Blue',1,0.00,0.00,'{\"available_quantity\":479,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":2,\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"Xanh d\\u01b0\\u01a1ng\",\"label\":\"Xanh d\\u01b0\\u01a1ng\",\"stock\":479,\"attribute_values\":[]}}','2026-05-12 04:44:57','2026-05-12 04:44:57'),
(74,12,45,'Grip Domino A250 - Đen','VAR-1136',2,620000.00,1240000.00,'{\"available_quantity\":39,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-12 04:59:30','2026-05-12 04:59:30'),
(75,12,7,'Nước hoa Charme Cool Water - Màu tím','A001-2',1,0.00,0.00,'{\"available_quantity\":480,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":2,\"variant\":{\"id\":2,\"sku\":\"A001-2\",\"name\":\"M\\u00e0u t\\u00edm\",\"label\":\"M\\u00e0u t\\u00edm\",\"stock\":480,\"attribute_values\":[]}}','2026-05-12 04:59:30','2026-05-12 04:59:30'),
(76,13,45,'Grip Domino A250 - Đen','VAR-1136',2,620000.00,1240000.00,'{\"available_quantity\":39,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-12 06:24:23','2026-05-12 06:24:23'),
(77,13,7,'Nước hoa Charme Cool Water - Xanh dương','A001-Blue',1,0.00,0.00,'{\"available_quantity\":477,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":2,\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"Xanh d\\u01b0\\u01a1ng\",\"label\":\"Xanh d\\u01b0\\u01a1ng\",\"stock\":477,\"attribute_values\":[]}}','2026-05-12 06:24:23','2026-05-12 06:24:23'),
(82,14,45,'Grip Domino A250 - Đen','VAR-1136',2,620000.00,1240000.00,'{\"available_quantity\":35,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-12 07:09:55','2026-05-12 07:09:55'),
(83,14,7,'Nước hoa Charme Cool Water - Màu tím','A001-2',1,0.00,0.00,'{\"available_quantity\":481,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":2,\"variant\":{\"id\":2,\"sku\":\"A001-2\",\"name\":\"M\\u00e0u t\\u00edm\",\"label\":\"M\\u00e0u t\\u00edm\",\"stock\":481,\"attribute_values\":[]}}','2026-05-12 07:09:55','2026-05-12 07:09:55'),
(125,15,45,'Grip Domino A250 - Đen','VAR-1136',16,620000.00,9920000.00,'{\"available_quantity\":23,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(126,15,25,'Mâm BST Rapid Tek Ducati Hypermotard 950 2019-23','VAR-1042',3,90000000.00,270000000.00,'{\"available_quantity\":93,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(127,15,7,'Nước hoa Charme Cool Water - Màu tím','A001-2',1,0.00,0.00,'{\"available_quantity\":528,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":3,\"variant\":{\"id\":2,\"sku\":\"A001-2\",\"name\":\"M\\u00e0u t\\u00edm\",\"label\":\"M\\u00e0u t\\u00edm\",\"stock\":528,\"attribute_values\":[]}}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(128,15,7,'Nước hoa Charme Cool Water - Xanh dương','A001-Blue',10,0.00,0.00,'{\"available_quantity\":552,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":2,\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"Xanh d\\u01b0\\u01a1ng\",\"label\":\"Xanh d\\u01b0\\u01a1ng\",\"stock\":552,\"attribute_values\":[]}}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(129,15,7,'Nước hoa Charme Cool Water - Màu tím','A001-2',8,0.00,0.00,'{\"available_quantity\":528,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":2,\"variant\":{\"id\":2,\"sku\":\"A001-2\",\"name\":\"M\\u00e0u t\\u00edm\",\"label\":\"M\\u00e0u t\\u00edm\",\"stock\":528,\"attribute_values\":[]}}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(230,16,25,'Mâm BST Rapid Tek Ducati Hypermotard 950 2019-23','VAR-1042',1,90000000.00,90000000.00,'{\"available_quantity\":95,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-19 08:11:23','2026-05-19 08:11:23'),
(231,16,45,'Grip Domino A250 - Đen','VAR-1136',3,620000.00,1860000.00,'{\"available_quantity\":36,\"price_source\":\"manual\",\"is_gift\":false,\"rule_id\":null,\"variant\":null}','2026-05-19 08:11:23','2026-05-19 08:11:23'),
(232,16,7,'Nước Hoa Charme Cool Water Hương Thơm Nam Tính 100ml - Xanh dương','A001-Blue',2,0.00,0.00,'{\"available_quantity\":604,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":3,\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"Xanh d\\u01b0\\u01a1ng\",\"label\":\"Xanh d\\u01b0\\u01a1ng\",\"stock\":604,\"attribute_values\":[]}}','2026-05-19 08:11:23','2026-05-19 08:11:23'),
(233,16,7,'Nước Hoa Charme Cool Water Hương Thơm Nam Tính 100ml - Xanh dương','A001-Blue',2,0.00,0.00,'{\"available_quantity\":604,\"price_source\":\"manual\",\"is_gift\":true,\"rule_id\":2,\"variant\":{\"id\":1,\"sku\":\"A001-Blue\",\"name\":\"Xanh d\\u01b0\\u01a1ng\",\"label\":\"Xanh d\\u01b0\\u01a1ng\",\"stock\":604,\"attribute_values\":[]}}','2026-05-19 08:11:23','2026-05-19 08:11:23');
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `order_timelines`
--

DROP TABLE IF EXISTS `order_timelines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_timelines` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `event_type` varchar(50) NOT NULL,
  `title` varchar(535) NOT NULL,
  `description` text DEFAULT NULL,
  `old_value` varchar(535) DEFAULT NULL,
  `new_value` varchar(535) DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_timelines_order_id_foreign` (`order_id`),
  KEY `order_timelines_user_id_index` (`user_id`),
  KEY `order_timelines_event_type_index` (`event_type`),
  CONSTRAINT `order_timelines_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_timelines`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `order_timelines` WRITE;
/*!40000 ALTER TABLE `order_timelines` DISABLE KEYS */;
INSERT INTO `order_timelines` VALUES
(5,7,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Đã xác nhận sang Chờ xử lý.','confirmed','pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-29 08:44:33','2026-04-29 08:44:33'),
(6,7,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Chờ xử lý sang Đã xác nhận.','pending','confirmed','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-04-29 08:44:38','2026-04-29 08:44:38'),
(7,7,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"total_quantity\":1,\"grand_total\":89900000}','2026-04-29 10:13:55','2026-04-29 10:13:55'),
(8,7,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"confirmed\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":1,\"grand_total\":490000}','2026-05-04 07:24:32','2026-05-04 07:24:32'),
(9,7,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"confirmed\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":3,\"grand_total\":26580000}','2026-05-04 07:24:53','2026-05-04 07:24:53'),
(10,7,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Đã xác nhận sang Hoàn thành.','confirmed','completed','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-04 07:34:32','2026-05-04 07:34:32'),
(11,7,1,'payment_status_changed','Cập nhật thanh toán','Trạng thái thanh toán đã đổi từ Chưa thanh toán sang Đã thanh toán.','unpaid','paid','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-04 07:34:32','2026-05-04 07:34:32'),
(12,7,1,'shipping_status_changed','Cập nhật giao hàng','Trạng thái giao hàng đã đổi từ Chờ giao sang Đã giao.','pending','delivered','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"192.168.65.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-04 07:34:32','2026-05-04 07:34:32'),
(13,8,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-05 02:07:37','2026-05-05 02:07:37'),
(14,7,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"completed\",\"payment_status\":\"paid\",\"shipping_status\":\"delivered\",\"total_quantity\":3,\"grand_total\":26400000}','2026-05-05 07:38:49','2026-05-05 07:38:49'),
(15,8,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Chờ xử lý sang Hoàn thành.','pending','completed','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-05 07:51:36','2026-05-05 07:51:36'),
(16,8,1,'payment_status_changed','Cập nhật thanh toán','Trạng thái thanh toán đã đổi từ Chưa thanh toán sang Đã thanh toán.','unpaid','paid','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-05 07:51:36','2026-05-05 07:51:36'),
(17,8,1,'shipping_status_changed','Cập nhật giao hàng','Trạng thái giao hàng đã đổi từ Chờ giao sang Đang giao.','pending','shipping','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-05 07:51:36','2026-05-05 07:51:36'),
(18,9,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-05 08:10:09','2026-05-05 08:10:09'),
(19,10,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-11 08:01:11','2026-05-11 08:01:11'),
(20,10,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":5,\"grand_total\":270450000}','2026-05-11 08:19:27','2026-05-11 08:19:27'),
(21,10,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":5,\"grand_total\":270440000}','2026-05-11 08:19:44','2026-05-11 08:19:44'),
(22,10,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":6,\"grand_total\":270450000}','2026-05-11 08:31:19','2026-05-11 08:31:19'),
(23,10,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":6,\"grand_total\":270440000}','2026-05-11 08:31:22','2026-05-11 08:31:22'),
(24,10,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":5,\"grand_total\":270450000}','2026-05-11 08:34:07','2026-05-11 08:34:07'),
(25,10,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":5,\"grand_total\":270440000}','2026-05-11 08:43:12','2026-05-11 08:43:12'),
(26,9,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Chờ xử lý sang Đã hủy.','pending','cancelled','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 08:44:53','2026-05-11 08:44:53'),
(27,9,1,'payment_status_changed','Cập nhật thanh toán','Trạng thái thanh toán đã đổi từ Chưa thanh toán sang Thất bại.','unpaid','failed','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 08:44:53','2026-05-11 08:44:53'),
(28,9,1,'shipping_status_changed','Cập nhật giao hàng','Trạng thái giao hàng đã đổi từ Chờ giao sang Đã trả hàng.','pending','returned','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-11 08:44:53','2026-05-11 08:44:53'),
(29,9,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"cancelled\",\"payment_status\":\"failed\",\"shipping_status\":\"returned\",\"total_quantity\":1,\"grand_total\":5310000}','2026-05-11 08:44:53','2026-05-11 08:44:53'),
(30,11,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-11 08:52:16','2026-05-11 08:52:16'),
(31,11,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":3,\"grand_total\":890000}','2026-05-12 04:31:07','2026-05-12 04:31:07'),
(32,11,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Chờ xử lý sang Hoàn thành.','pending','completed','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 04:44:57','2026-05-12 04:44:57'),
(33,11,1,'payment_status_changed','Cập nhật thanh toán','Trạng thái thanh toán đã đổi từ Chưa thanh toán sang Đã thanh toán.','unpaid','paid','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 04:44:57','2026-05-12 04:44:57'),
(34,11,1,'shipping_status_changed','Cập nhật giao hàng','Trạng thái giao hàng đã đổi từ Chờ giao sang Đã giao.','pending','delivered','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 04:44:57','2026-05-12 04:44:57'),
(35,11,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"completed\",\"payment_status\":\"paid\",\"shipping_status\":\"delivered\",\"total_quantity\":3,\"grand_total\":890000}','2026-05-12 04:44:57','2026-05-12 04:44:57'),
(36,12,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-12 04:59:30','2026-05-12 04:59:30'),
(37,13,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-12 06:24:23','2026-05-12 06:24:23'),
(38,14,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-12 07:07:18','2026-05-12 07:07:18'),
(39,15,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-12 07:08:53','2026-05-12 07:08:53'),
(40,14,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Chờ xử lý sang Đã hủy.','pending','cancelled','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 07:09:55','2026-05-12 07:09:55'),
(41,14,1,'payment_status_changed','Cập nhật thanh toán','Trạng thái thanh toán đã đổi từ Chưa thanh toán sang Thất bại.','unpaid','failed','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 07:09:55','2026-05-12 07:09:55'),
(42,14,1,'shipping_status_changed','Cập nhật giao hàng','Trạng thái giao hàng đã đổi từ Chờ giao sang Đã trả hàng.','pending','returned','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 07:09:55','2026-05-12 07:09:55'),
(43,14,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"cancelled\",\"payment_status\":\"failed\",\"shipping_status\":\"returned\",\"total_quantity\":3,\"grand_total\":1116000}','2026-05-12 07:09:55','2026-05-12 07:09:55'),
(44,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":5,\"grand_total\":1674000}','2026-05-12 07:19:49','2026-05-12 07:19:49'),
(45,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":24,\"grand_total\":7254000}','2026-05-12 07:20:16','2026-05-12 07:20:16'),
(46,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":3,\"grand_total\":1116000}','2026-05-12 07:22:00','2026-05-12 07:22:00'),
(47,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":38,\"grand_total\":278928000}','2026-05-12 07:56:32','2026-05-12 07:56:32'),
(48,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":36,\"grand_total\":278928000}','2026-05-12 08:22:18','2026-05-12 08:22:18'),
(49,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":38,\"grand_total\":278928000}','2026-05-12 08:22:37','2026-05-12 08:22:37'),
(50,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":34,\"grand_total\":278928000}','2026-05-12 08:22:58','2026-05-12 08:22:58'),
(51,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":36,\"grand_total\":278928000}','2026-05-12 08:23:11','2026-05-12 08:23:11'),
(52,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":38,\"grand_total\":278928000}','2026-05-12 08:23:21','2026-05-12 08:23:21'),
(53,15,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Chờ xử lý sang Đã hủy.','pending','cancelled','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\"}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(54,15,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"cancelled\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":38,\"grand_total\":278928000}','2026-05-12 08:24:49','2026-05-12 08:24:49'),
(55,16,1,'created','Thêm đơn hàng','Đã tạo đơn hàng với trạng thái Chờ xử lý, thanh toán Chưa thanh toán và giao hàng Chờ giao.',NULL,'pending','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\"}','2026-05-12 09:05:58','2026-05-12 09:05:58'),
(56,16,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/147.0.0.0 Safari\\/537.36\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":8,\"grand_total\":91674000}','2026-05-12 09:14:04','2026-05-12 09:14:04'),
(57,16,NULL,'payment_method_changed','Đổi phương thức thanh toán','Phương thức thanh toán đã đổi từ Thanh toán khi nhận hàng (COD) sang -.','Thanh toán khi nhận hàng (COD)','-','{\"user_name\":\"H\\u1ec7 th\\u1ed1ng\",\"user_email\":null,\"ip\":\"127.0.0.1\",\"user_agent\":\"Symfony\"}','2026-05-12 10:00:17','2026-05-12 10:00:17'),
(58,16,NULL,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"H\\u1ec7 th\\u1ed1ng\",\"user_email\":null,\"ip\":\"127.0.0.1\",\"user_agent\":\"Symfony\",\"order_status\":\"pending\",\"payment_status\":\"unpaid\",\"shipping_status\":\"pending\",\"total_quantity\":8,\"grand_total\":91674000}','2026-05-12 10:00:17','2026-05-12 10:00:17'),
(59,16,1,'order_status_changed','Đổi trạng thái đơn','Trạng thái đơn đã đổi từ Chờ xử lý sang Hoàn thành.','pending','completed','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/148.0.0.0 Safari\\/537.36\"}','2026-05-14 05:58:59','2026-05-14 05:58:59'),
(60,16,1,'payment_status_changed','Cập nhật thanh toán','Trạng thái thanh toán đã đổi từ Chưa thanh toán sang Đã thanh toán.','unpaid','paid','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/148.0.0.0 Safari\\/537.36\"}','2026-05-14 05:58:59','2026-05-14 05:58:59'),
(61,16,1,'shipping_status_changed','Cập nhật giao hàng','Trạng thái giao hàng đã đổi từ Chờ giao sang Đã giao.','pending','delivered','{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.21.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/148.0.0.0 Safari\\/537.36\"}','2026-05-14 05:58:59','2026-05-14 05:58:59'),
(62,16,1,'updated','Cập nhật đơn hàng','Đã cập nhật thông tin đơn hàng.',NULL,NULL,'{\"user_name\":\"L\\u00ea H\\u00e2n\",\"user_email\":\"lehan100@gmail.com\",\"ip\":\"172.18.0.1\",\"user_agent\":\"Mozilla\\/5.0 (X11; Linux x86_64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/148.0.0.0 Safari\\/537.36\",\"order_status\":\"completed\",\"payment_status\":\"paid\",\"shipping_status\":\"delivered\",\"total_quantity\":8,\"grand_total\":91674000}','2026-05-19 08:05:45','2026-05-19 08:05:45');
/*!40000 ALTER TABLE `order_timelines` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `payment_method_id` bigint(20) unsigned DEFAULT NULL,
  `price_snapshot` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`price_snapshot`)),
  `customer_name` varchar(535) NOT NULL,
  `customer_email` varchar(535) DEFAULT NULL,
  `customer_phone` varchar(50) DEFAULT NULL,
  `customer_address` varchar(1000) DEFAULT NULL,
  `province_code` varchar(20) DEFAULT NULL,
  `ward_code` varchar(20) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `coupon_code` varchar(535) DEFAULT NULL,
  `order_status` varchar(30) NOT NULL DEFAULT 'pending',
  `payment_status` varchar(30) NOT NULL DEFAULT 'unpaid',
  `shipping_status` varchar(30) NOT NULL DEFAULT 'pending',
  `total_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `subtotal` decimal(15,2) NOT NULL DEFAULT 0.00,
  `discount_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `applied_promotions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`applied_promotions`)),
  `shipping_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(15,2) NOT NULL DEFAULT 0.00,
  `placed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_province_code_foreign` (`province_code`),
  KEY `orders_ward_code_foreign` (`ward_code`),
  CONSTRAINT `orders_province_code_foreign` FOREIGN KEY (`province_code`) REFERENCES `provinces` (`code`) ON DELETE SET NULL,
  CONSTRAINT `orders_ward_code_foreign` FOREIGN KEY (`ward_code`) REFERENCES `wards` (`code`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(5,'A001',NULL,1,'{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":165.07381959,\"captured_at\":\"2026-04-29T07:30:43+00:00\",\"base\":{\"subtotal\":620000,\"discount_total\":0,\"shipping_total\":0,\"grand_total\":620000,\"currency_symbol\":\"\\u00a5\",\"items\":[{\"product_id\":45,\"quantity\":1,\"unit_price\":620000,\"line_total\":620000}]},\"display\":{\"subtotal\":3755.895,\"discount_total\":0,\"shipping_total\":0,\"grand_total\":3755.895,\"currency_symbol\":\"\\u00a5\",\"items\":[{\"product_id\":45,\"quantity\":1,\"unit_price\":3755.895,\"line_total\":3755.895}]}}','Lê Ngọc Hân','lehan@canhcam.com','0347970971','Thu Duc',NULL,NULL,NULL,NULL,'pending','unpaid','pending',1,620000.00,0.00,NULL,0.00,620000.00,'2026-04-29 07:30:00','2026-04-29 07:30:43','2026-04-29 07:42:54','2026-04-29 07:42:54'),
(6,'B001',NULL,1,'{\"locale\":\"en\",\"active_locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26348.99926553,\"captured_at\":\"2026-04-29T07:50:47+00:00\",\"currencies\":{\"en\":{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26348.99926553,\"subtotal\":3415.689,\"discount_total\":0,\"shipping_total\":0,\"grand_total\":3415.689,\"items\":[{\"product_id\":26,\"quantity\":1,\"unit_price\":3415.689,\"line_total\":3415.689}]}},\"base\":{\"subtotal\":89999987,\"discount_total\":0,\"shipping_total\":0,\"grand_total\":89999987,\"currency_symbol\":\"$\",\"items\":[{\"product_id\":26,\"quantity\":1,\"unit_price\":89999987,\"line_total\":89999987}]},\"display\":{\"subtotal\":3415.689,\"discount_total\":0,\"shipping_total\":0,\"grand_total\":3415.689,\"currency_symbol\":\"$\",\"items\":[{\"product_id\":26,\"quantity\":1,\"unit_price\":3415.689,\"line_total\":3415.689}]}}','Hân Lê Ngọc','lehan@canhcam.com','0347970971',NULL,NULL,NULL,NULL,NULL,'pending','unpaid','pending',1,89999987.00,0.00,NULL,0.00,89999987.00,'2026-04-29 07:50:00','2026-04-29 07:50:47','2026-04-29 07:56:56','2026-04-29 07:56:56'),
(7,'B004',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26348.99926553},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":165.07381959}]','Lê Ngọc Hân','lehan@canhcam.com','0347970971','38/11/3 đường số 3,','79','26824','Gọi trươc khi giao hàng',NULL,'completed','paid','delivered',3,26500000.00,100000.00,NULL,0.00,26400000.00,'2026-04-29 08:02:00','2026-04-29 08:03:26','2026-05-05 07:38:49',NULL),
(8,'B002',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26345.00125534},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.55122064}]','Lê Ngọc Hân','lehan100@gmail.com','0347970971','38/11/3','79','26824',NULL,NULL,'completed','paid','shipping',1,1990000.00,0.00,NULL,0.00,1990000.00,'2026-05-05 02:06:00','2026-05-05 02:07:37','2026-05-05 07:51:36',NULL),
(9,'A004',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26333.48964187},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.48447559}]','lê Ngọc Hân','lehan100@gmail.com','0347970971','38/11/3','79','26824',NULL,NULL,'cancelled','failed','returned',1,5900000.00,590000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":590000}]',0.00,5310000.00,'2026-05-05 08:09:00','2026-05-05 08:10:09','2026-05-11 08:44:53',NULL),
(10,'B0012',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26308.00774261},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.91071719}]','Lê Ngọc Hân','lehan100@gmail.com','0347970971','38/11/3','79','26824',NULL,'A0001','pending','unpaid','pending',5,270500000.00,60000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":50000},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":3,\"name\":\"May A0001\",\"gift_quantity\":1},{\"type\":\"coupon\",\"id\":1,\"code\":\"A0001\",\"name\":\"Coupon A0001 Discount 10%\",\"discount_amount\":10000}]',0.00,270440000.00,'2026-05-11 07:56:00','2026-05-11 08:01:11','2026-05-11 08:51:05','2026-05-11 08:51:05'),
(11,'B0002',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26308.00774261},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.91071719}]','lê Ngọc hân','lehan10@gmail.com','034797971','38','79','26824',NULL,'A0001','completed','paid','delivered',3,1000000.00,110000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":100000},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":2,\"name\":\"May A0001\",\"gift_quantity\":1},{\"type\":\"coupon\",\"id\":1,\"code\":\"A0001\",\"name\":\"Coupon A0001 Discount 10%\",\"discount_amount\":10000}]',0.00,890000.00,'2026-05-11 08:51:00','2026-05-11 08:52:16','2026-05-12 04:44:57',NULL),
(12,'T001',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26326.50579657},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.51559414}]','Lê Ngọc Hân','lehan100@gmail.com','0347970971','38/11/3','79','26824',NULL,NULL,'pending','unpaid','pending',3,1240000.00,124000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":124000},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":2,\"name\":\"May A0001\",\"gift_quantity\":1}]',0.00,1116000.00,'2026-05-12 04:49:00','2026-05-12 04:59:30','2026-05-12 06:22:19','2026-05-12 06:22:19'),
(13,'T0011',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26326.50579657},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.51559414}]','Lê Ngọc Hân','lehan100@gmail.com','0347970971','38/11/3','79','26824',NULL,NULL,'pending','unpaid','pending',3,1240000.00,124000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":124000},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":2,\"name\":\"May A0001\",\"gift_quantity\":1}]',0.00,1116000.00,'2026-05-12 06:23:00','2026-05-12 06:24:23','2026-05-12 07:06:03','2026-05-12 07:06:03'),
(14,'H0003',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26326.50579657},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.51559414}]','Lê Ngọc hân','lehan100@gmail.com','0347970971','38/11/3','79','26824',NULL,NULL,'cancelled','failed','returned',3,1240000.00,124000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":124000},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":2,\"name\":\"May A0001\",\"gift_quantity\":1}]',0.00,1116000.00,'2026-05-12 07:06:00','2026-05-12 07:07:18','2026-05-12 07:09:55',NULL),
(15,'J0001',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26326.50579657},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.51559414}]','Lê Ngọc Hân','lehan@gmail.com','0707795588','38/11/3','79','26824',NULL,NULL,'cancelled','unpaid','pending',38,279920000.00,992000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":992000},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":3,\"name\":\"May A0001\",\"gift_quantity\":1},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":2,\"name\":\"May A0001\",\"gift_quantity\":18}]',0.00,278928000.00,'2026-05-12 07:07:00','2026-05-12 07:08:53','2026-05-12 08:24:49',NULL),
(16,'L0001',NULL,1,'[{\"locale\":\"vi\",\"currency_code\":\"VND\",\"currency_symbol\":\"\\u20ab\",\"exchange_rate_to_vnd\":1},{\"locale\":\"en\",\"currency_code\":\"USD\",\"currency_symbol\":\"$\",\"exchange_rate_to_vnd\":26326.50579657},{\"locale\":\"ja\",\"currency_code\":\"JPY\",\"currency_symbol\":\"\\u00a5\",\"exchange_rate_to_vnd\":167.51559414}]','lê Ngọc hân','lehan100@gmail.com','0347970971','38/11/3','79','26824',NULL,NULL,'completed','paid','delivered',8,91860000.00,186000.00,'[{\"type\":\"sale_offer\",\"id\":1,\"name\":\"Discount 10%\",\"discount_amount\":186000},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":3,\"name\":\"May A0001\",\"gift_quantity\":2},{\"type\":\"buy_to_gift\",\"id\":1,\"rule_id\":2,\"name\":\"May A0001\",\"gift_quantity\":2}]',0.00,91674000.00,'2026-05-12 08:55:00','2026-05-12 09:05:58','2026-05-19 08:11:23',NULL);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `page_translations`
--

DROP TABLE IF EXISTS `page_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `page_translations_page_id_locale_unique` (`page_id`,`locale`),
  KEY `page_translations_locale_index` (`locale`),
  CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `page_translations` WRITE;
/*!40000 ALTER TABLE `page_translations` DISABLE KEYS */;
INSERT INTO `page_translations` VALUES
(1,1,'vi','Trang chủ','2026-05-06 08:10:55','2026-05-06 08:20:37'),
(2,1,'en','Homepage','2026-05-06 08:10:55','2026-05-06 08:29:47'),
(3,1,'ja','ホームページ','2026-05-06 08:10:55','2026-05-06 08:29:47'),
(4,2,'vi','Giới thiệu','2026-05-06 08:33:35','2026-05-06 08:33:35'),
(5,2,'en','About Us Company','2026-05-06 08:33:35','2026-05-06 08:33:35'),
(6,2,'ja','私たちについて 会社概要','2026-05-06 08:33:35','2026-05-06 08:33:35'),
(7,3,'vi','Liên hệ','2026-05-06 08:52:56','2026-05-06 08:52:56'),
(8,3,'en','Contact Us','2026-05-06 08:52:56','2026-05-06 08:52:56'),
(9,3,'ja','お問い合わせ','2026-05-06 08:52:56','2026-05-06 08:52:56');
/*!40000 ALTER TABLE `page_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `field_group_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(535) DEFAULT NULL,
  `slug` varchar(535) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `acf_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`acf_data`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`),
  KEY `pages_field_group_id_foreign` (`field_group_id`),
  CONSTRAINT `pages_field_group_id_foreign` FOREIGN KEY (`field_group_id`) REFERENCES `field_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,1,'Home Page','trang-chu',1,'{\"vi\":{\"title\":\"Ti\\u00eau \\u0111\\u1ec1 trang ch\\u1ee7\",\"banner\":\"\\/media\\/editor\\/banner01-907x422-1672907779-1678087545-1778222562.jpg\",\"products\":[22,25,7],\"post_lasts\":[5,4]},\"en\":{\"title\":\"Homepage title\",\"banner\":\"\\/media\\/editor\\/banner01-907x422-1672907779-1678087545-1778222562.jpg\",\"products\":[],\"post_lasts\":[5,4]},\"ja\":{\"title\":\"\\u30db\\u30fc\\u30e0\\u30da\\u30fc\\u30b8\\u306e\\u30bf\\u30a4\\u30c8\\u30eb\",\"banner\":\"\\/media\\/editor\\/banner01-907x422-1672907779-1678087545-1778222562.jpg\",\"products\":[],\"post_lasts\":[5,4]}}','2026-05-06 04:53:47','2026-05-08 07:37:36'),
(2,2,NULL,'gioi-thieu-2',1,'{\"vi\":{\"title\":null},\"en\":{\"title\":null},\"ja\":{\"title\":null}}','2026-05-06 08:33:35','2026-05-06 08:33:35'),
(3,2,NULL,'lien-he-2',1,'{\"vi\":{\"title\":null},\"en\":{\"title\":null},\"ja\":{\"title\":null}}','2026-05-06 08:52:56','2026-05-13 04:18:33');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(535) NOT NULL,
  `token` varchar(535) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `provider` varchar(50) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_system` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_methods_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES
(1,'cash_on_delivery','cash_on_delivery','Thanh toán khi nhận hàng (COD)','Khách thanh toán khi nhận hàng','[]',1,1,0,'2026-04-28 08:11:50','2026-04-28 08:11:50'),
(2,'momo','momo','MoMo','Ví điện tử MoMo','[]',0,1,1,'2026-04-28 08:11:50','2026-05-04 07:00:26'),
(3,'zalopay','zalopay','ZaloPay','Ví điện tử ZaloPay','[]',0,1,2,'2026-04-28 08:11:50','2026-04-29 08:52:08'),
(4,'vnpay','vnpay','VNPay','Cổng thanh toán VNPay','[]',0,1,3,'2026-04-28 08:11:50','2026-04-28 08:12:48'),
(5,'paypal','paypal','PayPal','Thanh toán PayPal','[]',0,1,4,'2026-04-28 08:11:50','2026-04-28 08:12:42');
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `guard_name` varchar(250) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'login','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(2,'login.store','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(3,'logout','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(4,'password.request','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(5,'password.reset','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(6,'password.email','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(7,'password.update','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(8,'register','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(9,'register.store','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(10,'verification.notice','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(11,'verification.verify','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(12,'verification.send','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(13,'user-profile-information.update','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(14,'user-password.update','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(15,'password.confirm','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(16,'password.confirmation','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(17,'password.confirm.store','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(18,'two-factor.login','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(19,'two-factor.login.store','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(20,'two-factor.enable','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(21,'two-factor.confirm','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(22,'two-factor.disable','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(23,'two-factor.qr-code','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(24,'two-factor.secret-key','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(25,'two-factor.recovery-codes','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(26,'two-factor.regenerate-recovery-codes','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(27,'sanctum.csrf-cookie','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(28,'ignition.healthCheck','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(29,'ignition.executeSolution','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(30,'ignition.updateConfig','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(31,'photo.upload','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(32,'lang.switch','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(33,'auth.login','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(34,'auth.post-login','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(35,'auth.logout','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(36,'dashboard','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(37,'roles.permissions','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(38,'layout.index','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(39,'layout.store','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(40,'media-position.destroy-many','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(41,'media-position.index','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(42,'media-position.create','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(43,'media-position.store','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(44,'media-position.show','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(45,'media-position.edit','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(46,'media-position.update','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(47,'media-position.destroy','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(48,'media-banner.destroy-many','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(49,'media-banner.index','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(50,'media-banner.create','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(51,'media-banner.store','web','2026-03-04 02:29:07','2026-03-04 02:29:07'),
(52,'media-banner.show','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(53,'media-banner.edit','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(54,'media-banner.update','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(55,'media-banner.destroy','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(56,'languages.destroy-many','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(57,'languages.index','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(58,'languages.create','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(59,'languages.store','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(60,'languages.show','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(61,'languages.edit','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(62,'languages.update','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(63,'languages.destroy','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(64,'labels.destroy-many','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(65,'labels.index','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(66,'labels.create','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(67,'labels.store','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(68,'labels.show','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(69,'labels.edit','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(70,'labels.update','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(71,'labels.destroy','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(72,'users.destroy-many','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(73,'users.index','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(74,'users.create','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(75,'users.store','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(76,'users.show','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(77,'users.edit','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(78,'users.update','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(79,'users.destroy','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(80,'roles.destroy-many','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(81,'roles.index','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(82,'roles.create','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(83,'roles.store','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(84,'roles.show','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(85,'roles.edit','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(86,'roles.update','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(87,'roles.destroy','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(88,'category.destroy-many','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(89,'category.index','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(90,'category.create','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(91,'category.store','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(92,'category.show','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(93,'category.edit','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(94,'category.update','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(95,'category.destroy','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(96,'product.destroy-many','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(97,'product.index','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(98,'product.create','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(99,'product.store','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(100,'product.show','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(101,'product.edit','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(102,'product.update','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(103,'product.destroy','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(104,'storage.local','web','2026-03-04 02:29:08','2026-03-04 02:29:08'),
(105,'media.upload.tinymce','web','2026-03-09 03:30:57','2026-03-09 03:30:57'),
(106,'media.get.images','web','2026-03-09 03:58:50','2026-03-09 03:58:50'),
(107,'media.reate.folder','web','2026-03-11 03:45:19','2026-03-11 03:45:19'),
(108,'media.create.folder','web','2026-03-11 04:21:32','2026-03-11 04:21:32'),
(109,'media.move.file','web','2026-03-11 04:21:32','2026-03-11 04:21:32'),
(110,'media.rename','web','2026-03-11 07:48:11','2026-03-11 07:48:11'),
(111,'media.delete','web','2026-03-11 07:48:11','2026-03-11 07:48:11'),
(112,'api.login','web','2026-03-18 04:07:36','2026-03-18 04:07:36'),
(113,'api.logout','web','2026-03-18 04:07:36','2026-03-18 04:07:36'),
(114,'api.login','api','2026-03-18 04:14:46','2026-03-18 04:14:46'),
(115,'api.logout','api','2026-03-18 04:14:46','2026-03-18 04:14:46'),
(116,'category.upload','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(117,'product.upload','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(118,'category.reorder','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(119,'exchange-rates.show','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(120,'product.ai.suggest-content','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(121,'product.ai.suggest-seo','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(122,'post.destroy-many','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(123,'post.index','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(124,'post.create','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(125,'post.store','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(126,'post.show','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(127,'post.edit','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(128,'post.update','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(129,'post.destroy','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(130,'storage.local.upload','web','2026-04-08 10:54:06','2026-04-08 10:54:06'),
(131,'saleoffer.destroy-many','web','2026-04-09 04:49:59','2026-04-09 04:49:59'),
(132,'saleoffer.index','web','2026-04-09 04:49:59','2026-04-09 04:49:59'),
(133,'saleoffer.create','web','2026-04-09 04:49:59','2026-04-09 04:49:59'),
(134,'saleoffer.store','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(135,'saleoffer.show','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(136,'saleoffer.edit','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(137,'saleoffer.update','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(138,'saleoffer.destroy','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(139,'coupon.destroy-many','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(140,'coupon.index','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(141,'coupon.create','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(142,'coupon.store','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(143,'coupon.show','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(144,'coupon.edit','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(145,'coupon.update','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(146,'coupon.destroy','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(147,'promotion.destroy-many','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(148,'promotion.index','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(149,'promotion.create','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(150,'promotion.store','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(151,'promotion.show','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(152,'promotion.edit','web','2026-04-09 04:50:00','2026-04-09 04:50:00'),
(153,'promotion.update','web','2026-04-09 04:50:01','2026-04-09 04:50:01'),
(154,'promotion.destroy','web','2026-04-09 04:50:01','2026-04-09 04:50:01'),
(155,'warehouse.destroy-many','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(156,'warehouse.index','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(157,'warehouse.create','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(158,'warehouse.store','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(159,'warehouse.show','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(160,'warehouse.edit','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(161,'warehouse.update','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(162,'warehouse.destroy','web','2026-04-09 04:57:27','2026-04-09 04:57:27'),
(163,'orders.destroy-many','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(164,'orders.index','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(165,'orders.create','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(166,'orders.store','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(167,'orders.show','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(168,'orders.edit','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(169,'orders.update','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(170,'orders.destroy','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(171,'payment-methods.destroy-many','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(172,'payment-methods.index','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(173,'payment-methods.create','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(174,'payment-methods.store','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(175,'payment-methods.show','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(176,'payment-methods.edit','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(177,'payment-methods.update','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(178,'payment-methods.destroy','web','2026-04-09 04:57:28','2026-04-09 04:57:28'),
(179,'report-revenue.destroy-many','web','2026-04-09 06:47:11','2026-04-09 06:47:11'),
(180,'report-revenue.index','web','2026-04-09 06:47:11','2026-04-09 06:47:11'),
(181,'report-revenue.create','web','2026-04-09 06:47:11','2026-04-09 06:47:11'),
(182,'report-revenue.store','web','2026-04-09 06:47:11','2026-04-09 06:47:11'),
(183,'report-revenue.show','web','2026-04-09 06:47:11','2026-04-09 06:47:11'),
(184,'report-revenue.edit','web','2026-04-09 06:47:11','2026-04-09 06:47:11'),
(185,'report-revenue.update','web','2026-04-09 06:47:11','2026-04-09 06:47:11'),
(186,'report-revenue.destroy','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(187,'report-product.destroy-many','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(188,'report-product.index','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(189,'report-product.create','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(190,'report-product.store','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(191,'report-product.show','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(192,'report-product.edit','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(193,'report-product.update','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(194,'report-product.destroy','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(195,'report-inventory.destroy-many','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(196,'report-inventory.index','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(197,'report-inventory.create','web','2026-04-09 06:47:12','2026-04-09 06:47:12'),
(198,'report-inventory.store','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(199,'report-inventory.show','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(200,'report-inventory.edit','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(201,'report-inventory.update','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(202,'report-inventory.destroy','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(203,'report-promotion.destroy-many','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(204,'report-promotion.index','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(205,'report-promotion.create','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(206,'report-promotion.store','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(207,'report-promotion.show','web','2026-04-09 06:47:13','2026-04-09 06:47:13'),
(208,'report-promotion.edit','web','2026-04-09 06:47:14','2026-04-09 06:47:14'),
(209,'report-promotion.update','web','2026-04-09 06:47:14','2026-04-09 06:47:14'),
(210,'report-promotion.destroy','web','2026-04-09 06:47:14','2026-04-09 06:47:14'),
(211,'saleoffer.products-picker','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(212,'coupon.products-picker','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(213,'buytogift.products-picker','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(214,'buytogift.destroy-many','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(215,'buytogift.index','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(216,'buytogift.create','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(217,'buytogift.store','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(218,'buytogift.show','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(219,'buytogift.edit','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(220,'buytogift.update','web','2026-04-09 10:02:14','2026-04-09 10:02:14'),
(221,'buytogift.destroy','web','2026-04-09 10:02:15','2026-04-09 10:02:15'),
(222,'boost.browser-logs','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(223,'pages.destroy-many','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(224,'pages.index','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(225,'pages.create','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(226,'pages.store','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(227,'pages.show','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(228,'pages.edit','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(229,'pages.update','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(230,'pages.destroy','web','2026-04-29 01:55:47','2026-04-29 01:55:47'),
(231,'warehouse.toggle-stock','web','2026-04-29 01:55:48','2026-04-29 01:55:48'),
(232,'payment-methods.toggle-status','web','2026-04-29 01:55:48','2026-04-29 01:55:48'),
(233,'category.ai.suggest-seo','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(234,'category.products-picker','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(235,'media-position.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(236,'media-banner.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(237,'languages.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(238,'labels.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(239,'users.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(240,'roles.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(241,'category.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(242,'product.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(243,'post.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(244,'saleoffer.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(245,'coupon.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(246,'buytogift.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(247,'warehouse.toggle-status','web','2026-04-29 09:24:30','2026-04-29 09:24:30'),
(248,'orders.toggle-status','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(249,'shipping-methods.destroy-many','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(250,'shipping-methods.toggle-status','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(251,'shipping-methods.index','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(252,'shipping-methods.create','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(253,'shipping-methods.store','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(254,'shipping-methods.show','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(255,'shipping-methods.edit','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(256,'shipping-methods.update','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(257,'shipping-methods.destroy','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(258,'report-revenue.toggle-status','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(259,'report-product.toggle-status','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(260,'report-inventory.toggle-status','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(261,'report-promotion.toggle-status','web','2026-04-29 09:24:31','2026-04-29 09:24:31'),
(262,'locations.index','web','2026-04-29 09:49:43','2026-04-29 09:49:43'),
(263,'locations.show','web','2026-04-29 09:49:43','2026-04-29 09:49:43'),
(264,'hancms-translations.index','web','2026-04-29 10:31:52','2026-04-29 10:31:52'),
(265,'hancms-translations.store','web','2026-04-29 10:31:52','2026-04-29 10:31:52'),
(266,'report-revenue.analyze','web','2026-05-04 04:31:36','2026-05-04 04:31:36'),
(267,'report-product.analyze','web','2026-05-04 04:31:37','2026-05-04 04:31:37'),
(268,'report-inventory.analyze','web','2026-05-04 04:31:37','2026-05-04 04:31:37'),
(269,'report-promotion.analyze','web','2026-05-04 04:31:37','2026-05-04 04:31:37'),
(270,'pages.toggle-status','web','2026-05-04 04:31:37','2026-05-04 04:31:37'),
(271,'attribute.upload','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(272,'attribute.destroy-many','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(273,'attribute.toggle-status','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(274,'attribute.index','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(275,'attribute.create','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(276,'attribute.store','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(277,'attribute.show','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(278,'attribute.edit','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(279,'attribute.update','web','2026-05-05 04:17:29','2026-05-05 04:17:29'),
(280,'attribute.destroy','web','2026-05-05 04:17:30','2026-05-05 04:17:30'),
(281,'attribute.quick-save','web','2026-05-05 07:07:43','2026-05-05 07:07:43'),
(282,'warehouse.variants.edit','web','2026-05-06 03:43:53','2026-05-06 03:43:53'),
(283,'warehouse.variants.update','web','2026-05-06 03:43:54','2026-05-06 03:43:54'),
(284,'warehouse.variants.toggle-stock','web','2026-05-06 03:43:54','2026-05-06 03:43:54'),
(285,'field-groups.destroy-many','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(286,'field-groups.toggle-status','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(287,'field-groups.index','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(288,'field-groups.create','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(289,'field-groups.store','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(290,'field-groups.show','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(291,'field-groups.edit','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(292,'field-groups.update','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(293,'field-groups.destroy','web','2026-05-06 04:22:58','2026-05-06 04:22:58'),
(294,'page-schemas.index','web','2026-05-06 04:51:28','2026-05-06 04:51:28'),
(295,'page-values.index','web','2026-05-06 04:51:28','2026-05-06 04:51:28'),
(296,'home','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(297,'promotion-campaign.public','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(298,'promotion-campaign.products-picker','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(299,'pages.quick-store','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(300,'page-schemas.destroy-many','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(301,'page-schemas.toggle-status','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(302,'page-schemas.create','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(303,'page-schemas.store','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(304,'page-schemas.show','web','2026-05-07 06:26:36','2026-05-07 06:26:36'),
(305,'page-schemas.edit','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(306,'page-schemas.update','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(307,'page-schemas.destroy','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(308,'promotion-campaign.destroy-many','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(309,'promotion-campaign.toggle-status','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(310,'promotion-campaign.index','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(311,'promotion-campaign.create','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(312,'promotion-campaign.store','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(313,'promotion-campaign.show','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(314,'promotion-campaign.edit','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(315,'promotion-campaign.update','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(316,'promotion-campaign.destroy','web','2026-05-07 06:26:37','2026-05-07 06:26:37'),
(317,'ai.translate','web','2026-05-08 06:22:33','2026-05-08 06:22:33'),
(318,'post.ai.translate','web','2026-05-08 06:22:33','2026-05-08 06:22:33'),
(319,'post.ai.suggest-content','web','2026-05-08 06:23:31','2026-05-08 06:23:31'),
(320,'post.ai.suggest-seo','web','2026-05-08 06:23:31','2026-05-08 06:23:31'),
(321,'orders.calculate-promotions','web','2026-05-13 05:58:05','2026-05-13 05:58:05'),
(322,'mail-templates.destroy-many','web','2026-05-13 05:58:05','2026-05-13 05:58:05'),
(323,'mail-templates.toggle-status','web','2026-05-13 05:58:05','2026-05-13 05:58:05'),
(324,'mail-templates.index','web','2026-05-13 05:58:05','2026-05-13 05:58:05'),
(325,'mail-templates.create','web','2026-05-13 05:58:05','2026-05-13 05:58:05'),
(326,'mail-templates.store','web','2026-05-13 05:58:06','2026-05-13 05:58:06'),
(327,'mail-templates.show','web','2026-05-13 05:58:06','2026-05-13 05:58:06'),
(328,'mail-templates.edit','web','2026-05-13 05:58:06','2026-05-13 05:58:06'),
(329,'mail-templates.update','web','2026-05-13 05:58:06','2026-05-13 05:58:06'),
(330,'mail-templates.destroy','web','2026-05-13 05:58:06','2026-05-13 05:58:06');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(535) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(535) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES
(17,'App\\Models\\User',2,'cmd_test','0ac49d63f3ac37b20fa22872fb41ca0ea89d167d7f216f790bd29e2984310084','[\"*\"]',NULL,NULL,'2026-03-15 07:45:32','2026-03-15 07:45:32');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `post_translations`
--

DROP TABLE IF EXISTS `post_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `name` varchar(535) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `seo_title` varchar(535) DEFAULT NULL,
  `seo_keyword` varchar(535) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_locale_unique` (`post_id`,`locale`),
  KEY `post_translations_locale_index` (`locale`),
  CONSTRAINT `post_translations_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `post_translations` WRITE;
/*!40000 ALTER TABLE `post_translations` DISABLE KEYS */;
INSERT INTO `post_translations` VALUES
(1,1,'vi','Những lưu ý cần phải biết trước khi đi mua lò nướng bánh','Lò nướng bánh là dụng cụ làm bánh quan trọng hàng đầu trong công cuộc chinh phục con đường bánh trái ngọt ngào. Chọn một chiếc lò nướng bánh không chỉ vì nó giúp bánh chín, mà còn có thể giúp bạn tránh được nhiều thất bại trong khi làm bánh. Chắc hẳn khi bạn quyết định đi mua bạn rất băn khoăn trong việc chọn lựa. Đừng lo, hãy để chúng tôi tư vấn giúp bạn lựa chọn được lò nướng bánh phù hợp nhu cầu và ví tiền của bạn.','<h2>B&iacute; quyết chọn mua l&ograve; nướng b&aacute;nh ho&agrave;n hảo cho người mới bắt đầu</h2>\n<p>Đối với những người đam m&ecirc; l&agrave;m b&aacute;nh, chiếc <strong>l&ograve; nướng b&aacute;nh</strong> kh&ocirc;ng chỉ đơn thuần l&agrave; một thiết bị gia dụng m&agrave; c&ograve;n l&agrave; \"người bạn đồng h&agrave;nh\" quyết định sự th&agrave;nh bại của từng mẻ b&aacute;nh. Một chiếc l&ograve; chất lượng sẽ gi&uacute;p nhiệt độ lan tỏa đều, gi&uacute;p b&aacute;nh nở phồng, ch&iacute;n đều từ trong ra ngo&agrave;i v&agrave; c&oacute; m&agrave;u sắc bắt mắt. Việc hiểu r&otilde; c&aacute;c th&ocirc;ng số kỹ thuật trước khi quyết định mua sắm sẽ gi&uacute;p bạn tiết kiệm chi ph&iacute;, đồng thời hạn chế tối đa những thất bại thường gặp trong qu&aacute; tr&igrave;nh nướng b&aacute;nh như b&aacute;nh bị xẹp, ch&aacute;y mặt hoặc sống b&ecirc;n trong.</p>\n<blockquote><strong>Mẹo nhỏ từ chuy&ecirc;n gia:</strong> Đừng bao giờ chỉ nh&igrave;n v&agrave;o thiết kế b&ecirc;n ngo&agrave;i của l&ograve;. H&atilde;y ưu ti&ecirc;n kiểm tra độ d&agrave;y của th&agrave;nh l&ograve; v&agrave; khả năng giữ nhiệt, v&igrave; nhiệt độ ổn định l&agrave; yếu tố ti&ecirc;n quyết để l&agrave;m ra những ổ b&aacute;nh m&igrave; hay b&aacute;nh b&ocirc;ng lan ho&agrave;n hảo.</blockquote>\n<h3>C&aacute;c ti&ecirc;u chuẩn kỹ thuật cần lưu &yacute; khi chọn l&ograve; nướng b&aacute;nh</h3>\n<p>Để chọn được một chiếc l&ograve; ph&ugrave; hợp với nhu cầu v&agrave; t&uacute;i tiền, bạn n&ecirc;n b&aacute;m s&aacute;t c&aacute;c ti&ecirc;u ch&iacute; dưới đ&acirc;y:</p>\n<ul>\n<li><strong>Dung t&iacute;ch ph&ugrave; hợp:</strong> Nếu bạn c&oacute; &yacute; định nướng b&aacute;nh b&ocirc;ng lan, b&aacute;nh m&igrave; hoặc c&aacute;c loại b&aacute;nh k&iacute;ch cỡ lớn, h&atilde;y chọn l&ograve; c&oacute; dung t&iacute;ch từ <strong>35 l&iacute;t đến 50 l&iacute;t</strong>. Khoang l&ograve; rộng gi&uacute;p luồng kh&iacute; n&oacute;ng lưu th&ocirc;ng tốt hơn, tr&aacute;nh việc b&aacute;nh qu&aacute; gần thanh nhiệt g&acirc;y ch&aacute;y mặt.</li>\n<li><strong>Chế độ hai lửa độc lập:</strong> Một chiếc <strong>l&ograve; nướng b&aacute;nh</strong> ti&ecirc;u chuẩn phải c&oacute; thanh nhiệt tr&ecirc;n v&agrave; thanh nhiệt dưới. Khả năng điều chỉnh nhiệt độ ri&ecirc;ng biệt cho từng thanh nhiệt sẽ gi&uacute;p bạn linh hoạt hơn với c&aacute;c c&ocirc;ng thức b&aacute;nh phức tạp.</li>\n<li><strong>Quạt đối lưu (Convection):</strong> Đ&acirc;y l&agrave; t&iacute;nh năng gi&uacute;p ph&acirc;n t&aacute;n nhiệt đều khắp khoang l&ograve;. N&oacute; đặc biệt quan trọng khi bạn muốn nướng nhiều khay b&aacute;nh c&ugrave;ng l&uacute;c hoặc cần lớp vỏ b&aacute;nh v&agrave;ng gi&ograve;n đều m&agrave;u.</li>\n<li><strong>Cửa k&iacute;nh hai lớp v&agrave; đ&egrave;n:</strong> Lớp k&iacute;nh d&agrave;y gi&uacute;p giữ nhiệt tốt v&agrave; tiết kiệm điện, trong khi đ&egrave;n chiếu s&aacute;ng gi&uacute;p bạn dễ d&agrave;ng quan s&aacute;t qu&aacute; tr&igrave;nh b&aacute;nh nở b&ecirc;n trong m&agrave; kh&ocirc;ng cần mở cửa l&ograve; g&acirc;y mất nhiệt.</li>\n</ul>\n<h3>So s&aacute;nh c&aacute;c d&ograve;ng l&ograve; nướng b&aacute;nh phổ biến hiện nay</h3>\n<p>T&ugrave;y v&agrave;o mục đ&iacute;ch sử dụng, bạn c&oacute; thể lựa chọn một trong c&aacute;c d&ograve;ng l&ograve; dưới đ&acirc;y để tối ưu h&oacute;a hiệu quả l&agrave;m b&aacute;nh:</p>\n<table>\n<thead>\n<tr>\n<th>Loại l&ograve; nướng</th>\n<th>Ưu điểm nổi bật</th>\n<th>Đối tượng ph&ugrave; hợp</th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<td><strong>L&ograve; nướng th&ugrave;ng</strong></td>\n<td>Gi&aacute; th&agrave;nh phải chăng, đa năng, dễ d&agrave;ng di chuyển v&agrave; lắp đặt.</td>\n<td>Người mới bắt đầu, l&agrave;m b&aacute;nh tại gia đ&igrave;nh.</td>\n</tr>\n<tr>\n<td><strong>L&ograve; nướng &acirc;m tủ</strong></td>\n<td>Dung t&iacute;ch lớn, nhiệt độ cực kỳ ổn định, thiết kế sang trọng.</td>\n<td>Người l&agrave;m b&aacute;nh chuy&ecirc;n nghiệp, gian bếp hiện đại.</td>\n</tr>\n<tr>\n<td><strong>L&ograve; đối lưu chuy&ecirc;n dụng</strong></td>\n<td>Nhiệt đều tuyệt đối, nướng được nhiều khay c&ugrave;ng l&uacute;c.</td>\n<td>Kinh doanh b&aacute;nh nhỏ, tiệm b&aacute;nh online.</td>\n</tr>\n</tbody>\n</table>\n<p>Hy vọng những chia sẻ tr&ecirc;n đ&atilde; gi&uacute;p bạn c&oacute; c&aacute;i nh&igrave;n tổng quan v&agrave; tự tin hơn khi chọn mua chiếc <strong>l&ograve; nướng b&aacute;nh</strong> ưng &yacute; nhất cho m&igrave;nh. H&atilde;y c&acirc;n nhắc kỹ nhu cầu thực tế v&agrave; ng&acirc;n s&aacute;ch để đầu tư một c&aacute;ch xứng đ&aacute;ng. Nếu bạn vẫn c&ograve;n băn khoăn, h&atilde;y li&ecirc;n hệ ngay với c&aacute;c trung t&acirc;m uy t&iacute;n để được trải nghiệm thực tế sản phẩm v&agrave; bắt đầu h&agrave;nh tr&igrave;nh s&aacute;ng tạo những mẻ b&aacute;nh thơm ngon cho người th&acirc;n y&ecirc;u ngay h&ocirc;m nay!</p>','Những lưu ý quan trọng khi chọn mua lò nướng bánh','lò nướng bánh','Tổng hợp kinh nghiệm và lưu ý cần biết khi mua lò nướng bánh giúp bạn sở hữu thiết bị bền đẹp, phù hợp với nhu cầu sử dụng và túi tiền của gia đình.','2026-05-06 05:31:28','2026-05-15 04:08:06',NULL),
(2,1,'en','Essential Tips to Know Before Buying a Baking Oven','A baking oven is the most important tool in conquering the sweet path of pastry making. Choosing an oven isn\'t just about cooking the cake; it also helps you avoid many baking failures. You might feel hesitant when deciding to buy. Don\'t worry, let us advise you on choosing the right oven for your needs and budget.','<p>A baking oven is the most important tool in conquering the sweet path of pastry making. Choosing an oven isn\'t just about cooking the cake; it also helps you avoid many baking failures. You might feel hesitant when deciding to buy. Don\'t worry, let us advise you on choosing the right oven for your needs and budget.</p>\n<p>To ensure you buy a <strong>baking oven</strong> that satisfies you most, you need to determine the following points before \"bringing\" it home.</p>\n<p>The first important step is to determine your needs, purpose, and budget.</p>\n<ul>\n<li>What kind of cakes am I <strong>buying a baking oven</strong> for? Each type of oven has its own pros and cons for different types of cakes.</li>\n<li>How often will I use it? Frequently, or only when I have free time?</li>\n<li>Is the space where the oven will be placed large enough? You need to measure the dimensions where you want to place it to find an oven that fits those measurements.</li>\n<li>What is the voltage at the place of use? <strong>Baking ovens</strong> come in types that use 220V and some that use 380V voltage.</li>\n<li>What is the maximum budget I will spend to buy the oven?</li>\n<li>If possible, you should research details online and call for advice beforehand.</li>\n</ul>\n<p>After clearly understanding the issues mentioned above, go directly to stores or showrooms to see and test the products.</p>\n<ul>\n<li>You should carefully consult and explore technical specifications, manufacturers, and product functions through the sales consultants.</li>\n<li>Ask specifically about the temperature, main functions, power, and warranty policy of each baking oven.</li>\n<li>Are the temperature control knobs easy to use and accurate?</li>\n<li>Does the baking oven have wheels for convenient movement?</li>\n<li>Is it easy to clean after use?</li>\n<li>Is the rack or baking tray system easy to install and remove?</li>\n<li>Does the lighting system meet your needs? Is the material used to make the oven of good quality?</li>\n<li>Compare prices and find out about the shipping process.</li>\n</ul>','Important Notes When Choosing to Buy a Baking Oven',NULL,'A compilation of experiences and notes to know when buying a baking oven to help you own a durable, beautiful device that fits your family\'s needs and budget.','2026-05-06 05:31:28','2026-05-08 06:26:47',NULL),
(3,1,'ja','製菓用オーブンを購入する前に知っておくべき注意点','オーブンは、甘いお菓子の道を極める上で最も重要な製菓道具です。オーブン選びは単に生地を焼くためだけでなく、お菓子作りの失敗を避けることにも繋がります。購入を決めた際、どれを選ぶべきか迷うこともあるでしょう。ご安心ください。あなたのニーズと予算に合ったオーブン選びをアドバイスいたします。','<p>オーブンは、甘いお菓子の道を極める上で最も重要な製菓道具です。オーブン選びは単に生地を焼くためだけでなく、お菓子作りの失敗を避けることにも繋がります。購入を決めた際、どれを選ぶべきか迷うこともあるでしょう。ご安心ください。あなたのニーズと予算に合ったオーブン選びをアドバイスいたします。</p>\n<p>最も満足のいく<strong>オーブン</strong>を購入するためには、持ち帰る前に以下の点を確認しておく必要があります。</p>\n<p>まず最も重要なのは、自分のニーズ、目的、そして予算を明確にすることです。</p>\n<ul>\n<li>どのようなお菓子を焼くために<strong>オーブンを購入</strong>するのか？ オーブンのタイプによって、お菓子の種類ごとに長所と短所があります。</li>\n<li>使用頻度はどのくらいか？ 頻繁に使うのか、それとも暇な時だけ使うのか。</li>\n<li>オーブンを置くスペースは十分にありますか？ 設置したい場所の寸法を正確に測り、そのサイズに合うオーブンを探す必要があります。</li>\n<li>使用場所の電圧はどうなっていますか？ <strong>オーブン</strong>には220Vを使用するものと、380Vの電圧を使用するものがあります。</li>\n<li>オーブン購入にかけられる最大予算はいくらですか？</li>\n<li>可能であれば、事前にインターネットで詳細を調べたり、電話で相談したりすることをお勧めします。</li>\n</ul>\n<p>上記の事項を把握した上で、実物を確認・テストするために店舗やショールームへ直接足を運びましょう。</p>\n<ul>\n<li>販売スタッフを通じて、技術仕様、メーカー、製品の機能を詳しく聞き出し、参考にしてください。</li>\n<li>各オーブンの温度、主な機能、出力、保証制度について詳しく尋ねてください。</li>\n<li>温度調節ダイヤルは使いやすく、正確ですか？</li>\n<li>移動に便利なキャスターは付いていますか？</li>\n<li>使用後のお手入れは簡単ですか？</li>\n<li>棚やベーキングトレイの着脱はスムーズですか？</li>\n<li>照明システムは十分ですか？ オーブンの材質は高品質ですか？</li>\n<li>価格を比較し、配送プロセスがどのようになっているかを確認してください。</li>\n</ul>','製菓用オーブン選びの重要な注意点',NULL,'家族のニーズと予算に合った、耐久性が高く美しいオーブンを手に入れるために知っておきたい、購入時の経験と注意点をまとめました。','2026-05-06 05:31:28','2026-05-08 06:26:47',NULL),
(4,2,'vi','Bai mau 2','Bai mau 2 description','Bai mau 2 content','Bai mau 2 SEO title','Bai mau 2 SEO keyword','Bai mau 2 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(5,2,'en','Sample Post 2','Sample Post 2 description','Sample Post 2 content','Sample Post 2 SEO title','Sample Post 2 SEO keyword','Sample Post 2 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(6,2,'ja','サンプル記事2','サンプル記事2 description','サンプル記事2 content','サンプル記事2 SEO title','サンプル記事2 SEO keyword','サンプル記事2 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(7,3,'vi','Bai mau 3','Bai mau 3 description','Bai mau 3 content','Bai mau 3 SEO title','Bai mau 3 SEO keyword','Bai mau 3 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(8,3,'en','Sample Post 3','Sample Post 3 description','Sample Post 3 content','Sample Post 3 SEO title','Sample Post 3 SEO keyword','Sample Post 3 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(9,3,'ja','サンプル記事3','サンプル記事3 description','サンプル記事3 content','サンプル記事3 SEO title','サンプル記事3 SEO keyword','サンプル記事3 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(10,4,'vi','Bai mau 4','Bai mau 4 description','Bai mau 4 content','Bai mau 4 SEO title','Bai mau 4 SEO keyword','Bai mau 4 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(11,4,'en','Sample Post 4','Sample Post 4 description','Sample Post 4 content','Sample Post 4 SEO title','Sample Post 4 SEO keyword','Sample Post 4 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(12,4,'ja','サンプル記事4','サンプル記事4 description','サンプル記事4 content','サンプル記事4 SEO title','サンプル記事4 SEO keyword','サンプル記事4 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(13,5,'vi','Bai mau 5','Bai mau 5 description','Bai mau 5 content','Bai mau 5 SEO title','Bai mau 5 SEO keyword','Bai mau 5 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(14,5,'en','Sample Post 5','Sample Post 5 description','Sample Post 5 content','Sample Post 5 SEO title','Sample Post 5 SEO keyword','Sample Post 5 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL),
(15,5,'ja','サンプル記事5','サンプル記事5 description','サンプル記事5 content','サンプル記事5 SEO title','サンプル記事5 SEO keyword','サンプル記事5 SEO description','2026-05-06 05:31:28','2026-05-06 05:31:28',NULL);
/*!40000 ALTER TABLE `post_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint(20) unsigned NOT NULL,
  `photo` varchar(535) DEFAULT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'primary',
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `hit_viewer` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_category_id_foreign` (`category_id`),
  KEY `posts_status_order_index` (`status`,`order`),
  KEY `posts_type_index` (`type`),
  CONSTRAINT `posts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES
(1,20,NULL,'primary',1,1,0,'2026-05-06 05:31:28','2026-05-07 03:11:24',NULL),
(2,20,NULL,'primary',1,2,0,'2026-05-06 05:31:28','2026-05-07 03:11:53',NULL),
(3,20,NULL,'primary',1,3,0,'2026-05-06 05:31:28','2026-05-07 03:11:58',NULL),
(4,20,NULL,'primary',1,4,0,'2026-05-06 05:31:28','2026-05-07 03:12:03',NULL),
(5,20,NULL,'primary',1,5,0,'2026-05-06 05:31:28','2026-05-07 03:12:08',NULL);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `product_attribute_values`
--

DROP TABLE IF EXISTS `product_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attribute_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `attribute_value_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_attribute_value_unique` (`product_id`,`attribute_value_id`),
  KEY `product_attribute_values_attribute_value_id_foreign` (`attribute_value_id`),
  CONSTRAINT `product_attribute_values_attribute_value_id_foreign` FOREIGN KEY (`attribute_value_id`) REFERENCES `attribute_values` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_attribute_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attribute_values`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `product_attribute_values` WRITE;
/*!40000 ALTER TABLE `product_attribute_values` DISABLE KEYS */;
INSERT INTO `product_attribute_values` VALUES
(1,7,1,'2026-05-14 05:48:12','2026-05-14 05:48:12'),
(3,7,18,'2026-05-14 05:55:14','2026-05-14 05:55:14');
/*!40000 ALTER TABLE `product_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `product_photos`
--

DROP TABLE IF EXISTS `product_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_photos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `filename` varchar(535) NOT NULL,
  `disk` varchar(535) NOT NULL DEFAULT 'public',
  `alt` varchar(535) DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_photos_product_id_foreign` (`product_id`),
  CONSTRAINT `product_photos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_photos`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `product_photos` WRITE;
/*!40000 ALTER TABLE `product_photos` DISABLE KEYS */;
INSERT INTO `product_photos` VALUES
(2,7,'baseus-1-210723-111431-1775621113.webp','public',NULL,0,0,1,'2026-04-08 04:06:17','2026-05-15 04:10:04',NULL),
(3,7,'baseus-4-210723-134327-1775621113.webp','public',NULL,1,0,0,'2026-04-08 04:06:17','2026-04-08 07:52:33','2026-04-08 07:52:33'),
(4,7,'baseus-5-210723-134346-1775621112.webp','public',NULL,1,0,0,'2026-04-08 04:06:17','2026-05-15 04:10:04',NULL);
/*!40000 ALTER TABLE `product_photos` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `product_translations`
--

DROP TABLE IF EXISTS `product_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `name` varchar(535) NOT NULL,
  `description` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `seo_title` varchar(535) DEFAULT NULL,
  `seo_keyword` varchar(535) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_locale_unique` (`product_id`,`locale`),
  KEY `product_translations_locale_index` (`locale`),
  CONSTRAINT `product_translations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `product_translations` WRITE;
/*!40000 ALTER TABLE `product_translations` DISABLE KEYS */;
INSERT INTO `product_translations` VALUES
(4,7,'vi','Nước Hoa Charme Cool Water Hương Thơm Nam Tính 100ml','Charme Cool Water mở đầu bằng một sự bùng nổ tức thì của các nốt hương làm mát, chuyển dần sang tầng hương giữa tinh tế, cân bằng giữa sức mạnh và sự thanh lịch. Cho dù bạn đang tham gia một cuộc họp kinh doanh quan trọng hay một chuyến đi chơi cuối tuần bình thường, mùi hương linh hoạt này phù hợp với mọi dịp, để lại một dấu ấn tinh tế nhưng đầy nam tính.','<h2>Charme Cool Water &ndash; Nước Hoa Nam Đẳng Cấp Mang Hơi Thở Đại Dương</h2>\r\n<p>Charme Cool Water l&agrave; d&ograve;ng nước hoa nam biểu tượng cho sự ph&oacute;ng kho&aacute;ng v&agrave; mạnh mẽ. Với hương thơm lấy cảm hứng từ sự bao la của biển cả, nước hoa Charme mang đến cảm gi&aacute;c sảng kho&aacute;i tức th&igrave;, gi&uacute;p qu&yacute; &ocirc;ng tự tin khẳng định bản lĩnh trong mọi t&igrave;nh huống. Từ những nốt hương đầu b&ugrave;ng nổ cho đến sự lắng đọng ấm &aacute;p ở nốt hương cuối, sản phẩm n&agrave;y kiến tạo một phong c&aacute;ch nam t&iacute;nh, lịch l&atilde;m v&agrave; kh&ocirc;ng k&eacute;m phần cuốn h&uacute;t. Đ&acirc;y ch&iacute;nh l&agrave; lựa chọn ho&agrave;n hảo cho những người đ&agrave;n &ocirc;ng hiện đại đang t&igrave;m kiếm một dấu ấn ri&ecirc;ng biệt giữa đ&aacute;m đ&ocirc;ng.</p>\r\n<h3>Đặc Điểm Nổi Bật Của Nước Hoa Charme Cool Water</h3>\r\n<ul>\r\n<li><strong>Hương biển tươi m&aacute;t v&agrave; bền bỉ:</strong> Được chiết xuất từ những tinh chất hương liệu cao cấp, Charme Cool Water đảm bảo khả năng lưu hương ấn tượng, gi&uacute;p bạn lu&ocirc;n duy tr&igrave; sự tươi mới v&agrave; phong độ suốt cả ng&agrave;y d&agrave;i năng động m&agrave; kh&ocirc;ng cần xịt lại nhiều lần.</li>\r\n<li><strong>Sự kết hợp tầng hương tinh tế:</strong> Mở đầu với sự b&ugrave;ng nổ của bạc h&agrave; v&agrave; hương xanh m&aacute;t lạnh, sau đ&oacute; chuyển dần sang tầng hương giữa thanh khiết. Cuối c&ugrave;ng, nốt hương gỗ đ&agrave;n hương v&agrave; r&ecirc;u sồi mang lại một kết th&uacute;c mộc mạc, vững ch&atilde;i v&agrave; đầy l&ocirc;i cuốn.</li>\r\n<li><strong>Độ tỏa hương l&yacute; tưởng:</strong> Sản phẩm c&oacute; khả năng tỏa hương vừa phải, tạo ra một v&ugrave;ng kh&ocirc;ng gian dễ chịu xung quanh người sử dụng, đủ để g&acirc;y ấn tượng tinh tế m&agrave; kh&ocirc;ng g&acirc;y nồng gắt cho người đối diện.</li>\r\n<li><strong>Phong c&aacute;ch linh hoạt:</strong> Với m&ugrave;i hương Aromatic Aquatic đặc trưng, đ&acirc;y l&agrave; d&ograve;ng nước hoa nam cực kỳ đa năng. Bạn c&oacute; thể sử dụng h&agrave;ng ng&agrave;y khi đi l&agrave;m, tham gia c&aacute;c buổi họp quan trọng hoặc diện trong những chuyến d&atilde; ngoại cuối tuần.</li>\r\n<li><strong>Chất lượng đạt chuẩn quốc tế:</strong> Nước hoa Charme được sản xuất tr&ecirc;n d&acirc;y chuyền c&ocirc;ng nghệ hiện đại, đảm bảo độ an to&agrave;n cho l&agrave;n da v&agrave; giữ được nguy&ecirc;n bản m&ugrave;i hương sang trọng như c&aacute;c d&ograve;ng nước hoa ngoại nhập đắt tiền.</li>\r\n</ul>\r\n<h3>Th&ocirc;ng Số Kỹ Thuật Chi Tiết</h3>\r\n<table>\r\n<thead>\r\n<tr>\r\n<th>Th&ocirc;ng số</th>\r\n<th>Chi tiết sản phẩm</th>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr>\r\n<td>Dung t&iacute;ch</td>\r\n<td>100ml</td>\r\n</tr>\r\n<tr>\r\n<td>Nh&oacute;m hương</td>\r\n<td>Hương thơm biển (Aromatic Aquatic)</td>\r\n</tr>\r\n<tr>\r\n<td>Độ lưu hương</td>\r\n<td>Từ 7 giờ đến 12 giờ (T&ugrave;y cơ địa)</td>\r\n</tr>\r\n<tr>\r\n<td>Phong c&aacute;ch</td>\r\n<td>Nam t&iacute;nh, Tươi m&aacute;t, Hiện đại</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>H&atilde;y n&acirc;ng tầm đẳng cấp c&aacute; nh&acirc;n v&agrave; khơi dậy nguồn năng lượng tr&agrave;n đầy với Charme Cool Water ngay h&ocirc;m nay. Đ&acirc;y kh&ocirc;ng chỉ l&agrave; một chai nước hoa, m&agrave; c&ograve;n l&agrave; người bạn đồng h&agrave;nh gi&uacute;p bạn chinh phục mọi thử th&aacute;ch với vẻ ngo&agrave;i tự tin nhất. Đừng bỏ lỡ cơ hội sở hữu m&ugrave;i hương huyền thoại n&agrave;y để biến mỗi khoảnh khắc thường nhật trở n&ecirc;n ấn tượng v&agrave; đ&aacute;ng nhớ hơn bao giờ hết!</p>','Nước Hoa Charme Cool Water Hương Thơm Nam Tính 100ml','Charme Cool Water, nước hoa Charme, nước hoa nam','Trải nghiệm hương thơm tươi mát và nam tính của nước hoa Charme Cool Water, được lấy cảm hứng từ sự mát lạnh của đại dương.',0,'2026-04-08 04:06:16','2026-05-15 04:10:04',NULL),
(5,7,'en','Charme Cool Water Perfume',NULL,'<h2>Charme Cool Water: The Ultimate Breath of Freshness</h2>\r\n<p>Experience the invigorating power of the ocean with Charme Cool Water. Designed for the modern individual who values confidence and clarity, this fragrance captures the essence of crisp sea air and deep blue waves. It is more than just a perfume; it is a daily dose of energy that keeps you feeling revitalized from morning to night.</p>\r\n<p>Charme Cool Water opens with an immediate burst of cooling notes, transitioning into a sophisticated heart that balances strength and elegance. Whether you are heading to a high-stakes business meeting or a casual weekend outing, this versatile scent adapts to every occasion, leaving a memorable yet subtle trail of sophistication.</p>\r\n<ul>\r\n<li><strong>Long-Lasting Aquatic Scent:</strong> Formulated with high-quality essences to ensure your fragrance stays fresh for hours.</li>\r\n<li><strong>Invigorating Top Notes:</strong> A sharp, clean blend of peppermint and green nuances for an instant cooling sensation.</li>\r\n<li><strong>Sophisticated Heart:</strong> Earthy notes of oakmoss and sandalwood provide a masculine, grounded finish.</li>\r\n<li><strong>Versatile Appeal:</strong> The perfect signature scent for daytime wear, sports, or professional environments.</li>\r\n<li><strong>Premium Quality:</strong> Expertly crafted to be gentle on the skin while delivering a powerful aromatic profile.</li>\r\n</ul>\r\n<p>Elevate your grooming routine with a timeless fragrance that never goes out of style. Discover the refreshing confidence of Charme Cool Water today and make every moment feel like a coastal escape. Add it to your collection and experience the difference of a truly premium aquatic perfume.</p>','Charme Cool Water Perfume','Charme Cool Water, Charme perfume, men\'s fragrance','Experience the refreshing and masculine scent of Charme Cool Water Perfume, inspired by the coolness of the ocean.',0,'2026-04-08 04:06:16','2026-05-08 06:39:20',NULL),
(6,7,'ja','シャルム クール ウォーター パフューム',NULL,'<h2>Charme Cool Water: 究極のフレッシュな息吹</h2>\r\n<p>Charme Cool Waterで、海が持つ爽快なパワーを体験してください。自信と明晰さを大切にする現代の人々のためにデザインされたこのフレグランスは、清々しい潮風と深い青い波のエッセンスを捉えています。これは単なる香水ではありません。朝から晩まであなたをリフレッシュさせ続ける、毎日のエネルギーの源です。</p>\r\n<p>Charme Cool Waterは、瞬時に広がるクールな香りのバーストで始まり、強さとエレガンスを兼ね備えた洗練されたミドルノートへと移行します。重要なビジネスミーティングでも、カジュアルな週末のお出かけでも、この多用途な香りはあらゆるシーンに馴染み、洗練された控えめな余韻を残します。</p>\r\n<ul>\r\n<li><strong>持続性のあるアクアティックな香り:</strong> 高品質なエッセンスを配合し、爽やかな香りが何時間も持続するように作られています。</li>\r\n<li><strong>爽快なトップノート:</strong> ペパーミントとグリーンニュアンスのシャープでクリーンなブレンドが、瞬時に清涼感を与えます。</li>\r\n<li><strong>洗練されたハートノート:</strong> オークモスとサンダルウッドのアーシーな香りが、男性らしく落ち着いた仕上がりをもたらします。</li>\r\n<li><strong>幅広いシーンに対応:</strong> 日中の使用、スポーツ、またはプロフェッショナルな環境に最適なシグネチャーセントです。</li>\r\n<li><strong>プレミアム品質:</strong> 強力な香りのプロファイルを提供しながら、肌に優しいように専門的に作られています。</li>\r\n</ul>\r\n<p>時代に左右されないタイムレスなフレグランスで、グルーミングルーチンを格上げしましょう。今すぐCharme Cool Waterの爽快な自信を体感し、あらゆる瞬間を海岸へのエスケープのように感じてください。あなたのコレクションに加えて、真にプレミアムなアクアティックパフュームの違いを実感してください。</p>','シャルム クール ウォーター パフューム｜爽快なアクアティック',NULL,'シャルム クール ウォーターは、海の爽快さを凝縮したアクアティックな香水です。ペパーミントの清涼感とサンダルウッドの洗練された香りが長時間持続し、ビジネスからカジ',0,'2026-04-08 04:06:16','2026-05-08 06:41:13',NULL),
(21,22,'en','Accossato Fuel Cap for Yamaha FC124',NULL,NULL,'Accossato Fuel Cap for Yamaha FC124','Accossato Fuel Cap, Yamaha FC124, Accossato Yamaha, Gas Cap','High-quality Accossato fuel cap designed for Yamaha FC124. Performance fuel tank cap with Italian design for motorcycles.',0,'2026-04-29 02:38:38','2026-05-08 07:50:44',NULL),
(24,25,'en','BST Rapid Tek Wheels for Ducati Hypermotard 950 2019-23',NULL,NULL,'BST Rapid Tek Wheels for Ducati Hypermotard 950 2019-23','BST Rapid Tek, Ducati Hypermotard 950, carbon fiber wheels, Ducati rims','High-performance BST Rapid Tek carbon fiber wheels for Ducati Hypermotard 950 (2019-2023). Engineered for lightweight handling and superior speed.',0,'2026-04-29 02:38:38','2026-05-08 07:51:33',NULL),
(25,26,'en','Mâm BST Rapid Tek Ducati Panigale V4 2018-23',NULL,NULL,'Mâm BST Rapid Tek Ducati Panigale V4 2018-23','Mâm BST Rapid Tek Ducati Panigale V4 2018-23','Mâm BST Rapid Tek Ducati Panigale V4 2018-23',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(41,42,'en','Mâm OZ Racing Aprilia RSV4 R 2009-23',NULL,NULL,'Mâm OZ Racing Aprilia RSV4 R 2009-23','Mâm OZ Racing Aprilia RSV4 R 2009-23','Mâm OZ Racing Aprilia RSV4 R 2009-23',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(42,43,'en','Mâm OZ Racing BMW S1000 RR 2010-18',NULL,NULL,'Mâm OZ Racing BMW S1000 RR 2010-18','Mâm OZ Racing BMW S1000 RR 2010-18','Mâm OZ Racing BMW S1000 RR 2010-18',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(43,44,'en','Mâm OZ Racing BMW S1000 RR 2019-23',NULL,NULL,'Mâm OZ Racing BMW S1000 RR 2019-23','Mâm OZ Racing BMW S1000 RR 2019-23','Mâm OZ Racing BMW S1000 RR 2019-23',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(44,45,'en','Domino A250 Grips - Black',NULL,'<h2>Elevate Your Riding Experience with Genuine Domino A250 Grips - Black</h2>\r\n<p>Domino A250 Grips - Black is a premium line of hand grips from the renowned Italian brand Domino, specifically designed for bikers who want the perfect combination of aesthetics and performance. With a mysterious black color and modern style, this product not only enhances the look of your bike but also provides a firm grip, helping you fully master the handlebars on every road, from crowded city streets to long-distance tours.</p>\r\n<h3>Key Features and Outstanding Benefits</h3>\r\n<ul>\r\n<li><strong>Ergonomic Design:</strong> Domino A250 Grips - Black feature a distinctive textured surface with smart water and dirt drainage channels, ensuring optimal grip even when riding in the rain or for those with sweaty hands.</li>\r\n<li><strong>Thermoplastic Rubber Material:</strong> The product is made from a special rubber compound, providing excellent softness while remaining durable. This material helps dampen shocks and eliminate vibrations transmitted from the engine to the handlebars, minimizing hand fatigue during long rides.</li>\r\n<li><strong>Time-Defying Durability:</strong> Unlike low-quality grips, Domino A250 has good heat resistance and does not suffer from \"melting\" or deformation after long-term direct exposure to sunlight and harsh weather conditions.</li>\r\n<li><strong>Easy Installation:</strong> With standard dimensions, the product can be quickly installed on most motorcycles, manual clutch bikes, and big bikes using 22mm handlebars currently on the market.</li>\r\n</ul>\r\n<h3>Detailed Technical Specifications</h3>\r\n<table>\r\n<thead>\r\n<tr>\r\n<th>Technical Specifications</th>\r\n<th>Product Details</th>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr>\r\n<td>Brand</td>\r\n<td>Domino (Made in Italy)</td>\r\n</tr>\r\n<tr>\r\n<td>Model</td>\r\n<td>Domino A250 Grip - Black</td>\r\n</tr>\r\n<tr>\r\n<td>Length</td>\r\n<td>120 mm</td>\r\n</tr>\r\n<tr>\r\n<td>Handlebar Diameter</td>\r\n<td>22 mm (Standard)</td>\r\n</tr>\r\n<tr>\r\n<td>Color</td>\r\n<td>Black</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>If you are looking for an affordable accessory that offers high utility value and class for your beloved bike, Domino A250 Grips - Black is an unmissable choice. Don\'t let old, slippery grips affect your safety and riding inspiration. Order today to own this top-quality genuine accessory and receive the most attractive offers!</p>','Genuine Domino A250 Grips - Black (Made in Italy) | Premium Motorcycle Grips','Domino A250 Grips Black','Genuine Italian Domino A250 Grips in Black. High-quality rubber material for anti-slip and reduced hand fatigue. Durable design for all motorcycle types.',0,'2026-04-29 02:38:38','2026-05-16 12:14:47',NULL),
(45,46,'en','Tay Côn CRG',NULL,NULL,'Tay Côn CRG','Tay Côn CRG','Tay Côn CRG',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(48,49,'en','Mâm Kineo BMW R9T Scrambler',NULL,NULL,'Mâm Kineo BMW R9T Scrambler','Mâm Kineo BMW R9T Scrambler','Mâm Kineo BMW R9T Scrambler',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(49,50,'en','Ghi Đông IMA Ducati Panigale V4',NULL,NULL,'Ghi Đông IMA Ducati Panigale V4','Ghi Đông IMA Ducati Panigale V4','Ghi Đông IMA Ducati Panigale V4',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(54,55,'en','Rear Shock Nitron R1 Honda Wave 125i',NULL,NULL,'Rear Shock Nitron R1 Honda Wave 125i','Rear Shock Nitron R1 Honda Wave 125i','Rear Shock Nitron R1 Honda Wave 125i',0,'2026-04-29 02:38:38','2026-04-29 02:42:41',NULL),
(55,56,'en','Pát Tăng Sên TWM YAMAHA R1 2020-25',NULL,NULL,'Pát Tăng Sên TWM YAMAHA R1 2020-25','Pát Tăng Sên TWM YAMAHA R1 2020-25','Pát Tăng Sên TWM YAMAHA R1 2020-25',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(56,57,'en','Bố Thắng Brembo Heo P2.34 (2 Piston)',NULL,NULL,'Bố Thắng Brembo Heo P2.34 (2 Piston)','Bố Thắng Brembo Heo P2.34 (2 Piston)','Bố Thắng Brembo Heo P2.34 (2 Piston)',0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(85,22,'vi','Nắp Xăng Accossato Yamaha FC124',NULL,NULL,'Nắp Xăng Accossato Yamaha FC124','Nắp Xăng Accossato Yamaha FC124','Nắp Xăng Accossato Yamaha FC124',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(86,22,'ja','Accossato ヤマハ用 フューエルキャップ FC124',NULL,NULL,'Accossato ヤマハ用 フューエルキャップ FC124','Accossato, フューエルキャップ, ヤマハ, FC124, タンクキャップ','ヤマハ FC124用のアコサット製フューエルキャップ。イタリアンデザインの高品質なバイク用燃料タンクキャップです。',0,'2026-04-29 02:42:41','2026-05-08 07:50:44',NULL),
(91,25,'vi','Mâm BST Rapid Tek Ducati Hypermotard 950 2019-23',NULL,NULL,'Mâm BST Rapid Tek Ducati Hypermotard 950 2019-23','Mâm BST Rapid Tek Ducati Hypermotard 950 2019-23','Mâm BST Rapid Tek Ducati Hypermotard 950 2019-23',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(92,25,'ja','BST Rapid Tek ホイール Ducati Hypermotard 950 2019-23',NULL,NULL,'BST Rapid Tek ホイール Ducati Hypermotard 950 2019-23','BST Rapid Tek, Ducati Hypermotard 950, ドゥカティ, カーボンホイール','Ducati Hypermotard 950 (2019-2023) 用の BST Rapid Tek カーボンファイバーホイール。軽量化により走行性能とハンドリングを大幅に向上させます。',0,'2026-04-29 02:42:41','2026-05-08 07:51:33',NULL),
(93,26,'vi','Mâm BST Rapid Tek Ducati Panigale V4 2018-23',NULL,NULL,'Mâm BST Rapid Tek Ducati Panigale V4 2018-23','Mâm BST Rapid Tek Ducati Panigale V4 2018-23','Mâm BST Rapid Tek Ducati Panigale V4 2018-23',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(94,26,'ja','JP Mâm BST Rapid Tek Ducati Panigale V4 2018-23',NULL,NULL,'JP Mâm BST Rapid Tek Ducati Panigale V4 2018-23','JP Mâm BST Rapid Tek Ducati Panigale V4 2018-23','JP Mâm BST Rapid Tek Ducati Panigale V4 2018-23',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(125,42,'vi','Mâm OZ Racing Aprilia RSV4 R 2009-23',NULL,NULL,'Mâm OZ Racing Aprilia RSV4 R 2009-23','Mâm OZ Racing Aprilia RSV4 R 2009-23','Mâm OZ Racing Aprilia RSV4 R 2009-23',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(126,42,'ja','JP Mâm OZ Racing Aprilia RSV4 R 2009-23',NULL,NULL,'JP Mâm OZ Racing Aprilia RSV4 R 2009-23','JP Mâm OZ Racing Aprilia RSV4 R 2009-23','JP Mâm OZ Racing Aprilia RSV4 R 2009-23',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(127,43,'vi','Mâm OZ Racing BMW S1000 RR 2010-18',NULL,NULL,'Mâm OZ Racing BMW S1000 RR 2010-18','Mâm OZ Racing BMW S1000 RR 2010-18','Mâm OZ Racing BMW S1000 RR 2010-18',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(128,43,'ja','JP Mâm OZ Racing BMW S1000 RR 2010-18',NULL,NULL,'JP Mâm OZ Racing BMW S1000 RR 2010-18','JP Mâm OZ Racing BMW S1000 RR 2010-18','JP Mâm OZ Racing BMW S1000 RR 2010-18',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(129,44,'vi','Mâm OZ Racing BMW S1000 RR 2019-23',NULL,NULL,'Mâm OZ Racing BMW S1000 RR 2019-23','Mâm OZ Racing BMW S1000 RR 2019-23','Mâm OZ Racing BMW S1000 RR 2019-23',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(130,44,'ja','JP Mâm OZ Racing BMW S1000 RR 2019-23',NULL,NULL,'JP Mâm OZ Racing BMW S1000 RR 2019-23','JP Mâm OZ Racing BMW S1000 RR 2019-23','JP Mâm OZ Racing BMW S1000 RR 2019-23',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(131,45,'vi','Grip Domino A250 - Đen',NULL,'<h2>N&acirc;ng tầm trải nghiệm l&aacute;i xe với Grip Domino A250 - Đen ch&iacute;nh h&atilde;ng</h2>\r\n<p>Grip Domino A250 - Đen l&agrave; d&ograve;ng bao tay cao cấp đến từ thương hiệu Domino danh tiếng của &Yacute;, được thiết kế chuy&ecirc;n biệt cho những biker mong muốn sự kết hợp ho&agrave;n hảo giữa t&iacute;nh thẩm mỹ v&agrave; hiệu suất vận h&agrave;nh. Với sắc đen huyền b&iacute; v&agrave; phong c&aacute;ch hiện đại, sản phẩm kh&ocirc;ng chỉ l&agrave;m nổi bật vẻ ngo&agrave;i của chiếc xe m&agrave; c&ograve;n mang lại cảm gi&aacute;c cầm nắm chắc chắn, gi&uacute;p bạn ho&agrave;n to&agrave;n l&agrave;m chủ tay l&aacute;i tr&ecirc;n mọi cung đường, từ phố thị đ&ocirc;ng đ&uacute;c đến những h&agrave;nh tr&igrave;nh tour d&agrave;i ng&agrave;y.</p>\r\n<h3>Đặc điểm nổi bật v&agrave; lợi &iacute;ch vượt trội</h3>\r\n<ul>\r\n<li><strong>Thiết kế c&ocirc;ng th&aacute;i học:</strong> Grip Domino A250 - Đen sở hữu bề mặt v&acirc;n nổi đặc trưng với c&aacute;c r&atilde;nh tho&aacute;t nước v&agrave; bụi bẩn th&ocirc;ng minh, đảm bảo độ b&aacute;m tối ưu ngay cả khi di chuyển dưới trời mưa hay đối với những người hay ra mồ h&ocirc;i tay.</li>\r\n<li><strong>Chất liệu cao su nhiệt dẻo:</strong> Sản phẩm được chế tạo từ hợp chất cao su đặc biệt, mang lại độ mềm mại tuyệt vời nhưng vẫn giữ được sự bền bỉ. Chất liệu n&agrave;y gi&uacute;p giảm chấn v&agrave; triệt ti&ecirc;u rung động từ động cơ truyền l&ecirc;n tay l&aacute;i, hạn chế tối đa t&igrave;nh trạng t&ecirc; mỏi tay khi l&aacute;i xe l&acirc;u.</li>\r\n<li><strong>Độ bền bỉ th&aacute;ch thức thời gian:</strong> Kh&aacute;c với c&aacute;c d&ograve;ng bao tay k&eacute;m chất lượng, Domino A250 c&oacute; khả năng chịu nhiệt tốt, kh&ocirc;ng bị t&igrave;nh trạng \"chảy nhựa\" hay biến dạng sau thời gian d&agrave;i tiếp x&uacute;c trực tiếp với &aacute;nh nắng mặt trời v&agrave; điều kiện thời tiết khắc nghiệt.</li>\r\n<li><strong>Lắp đặt dễ d&agrave;ng:</strong> Với k&iacute;ch thước ti&ecirc;u chuẩn, sản phẩm c&oacute; thể lắp đặt nhanh ch&oacute;ng cho hầu hết c&aacute;c d&ograve;ng xe m&aacute;y, xe c&ocirc;n tay v&agrave; xe ph&acirc;n khối lớn sử dụng ghi đ&ocirc;ng 22mm hiện nay tr&ecirc;n thị trường.</li>\r\n</ul>\r\n<h3>Th&ocirc;ng số kỹ thuật chi tiết</h3>\r\n<table>\r\n<thead>\r\n<tr>\r\n<th>Th&ocirc;ng số kỹ thuật</th>\r\n<th>Chi tiết sản phẩm</th>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr>\r\n<td>Thương hiệu</td>\r\n<td>Domino (Made in Italy)</td>\r\n</tr>\r\n<tr>\r\n<td>Model</td>\r\n<td>Grip Domino A250 - Đen</td>\r\n</tr>\r\n<tr>\r\n<td>Chiều d&agrave;i</td>\r\n<td>120 mm</td>\r\n</tr>\r\n<tr>\r\n<td>Đường k&iacute;nh ghi đ&ocirc;ng</td>\r\n<td>22 mm (Ti&ecirc;u chuẩn)</td>\r\n</tr>\r\n<tr>\r\n<td>M&agrave;u sắc</td>\r\n<td>Đen (Black)</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Nếu bạn đang t&igrave;m kiếm một m&oacute;n phụ kiện vừa t&uacute;i tiền nhưng mang lại gi&aacute; trị sử dụng cao v&agrave; đẳng cấp cho xế cưng, Grip Domino A250 - Đen ch&iacute;nh l&agrave; sự lựa chọn kh&ocirc;ng thể bỏ qua. Đừng để những chiếc bao tay cũ kỹ, trơn trượt l&agrave;m ảnh hưởng đến sự an to&agrave;n v&agrave; cảm hứng cầm l&aacute;i của bạn. H&atilde;y đặt h&agrave;ng ngay h&ocirc;m nay để sở hữu m&oacute;n phụ kiện ch&iacute;nh h&atilde;ng chất lượng đỉnh cao v&agrave; nhận những ưu đ&atilde;i hấp dẫn nhất!</p>','Grip Domino A250 - Đen Chính Hãng Ý | Bao Tay Cao Cấp','Grip Domino A250 - Đen','Grip Domino A250 - Đen chính hãng Ý với chất liệu cao su cao cấp, giúp chống trượt và giảm tê mỏi tay hiệu quả. Thiết kế bền bỉ, phù hợp mọi dòng xe máy.',0,'2026-04-29 02:42:41','2026-05-16 12:14:47',NULL),
(132,45,'ja','ドミノ A250 グリップ - ブラック',NULL,'<h2>正規品 ドミノ A250 グリップ - ブラックでライディング体験を向上</h2>\r\n<p>ドミノ A250 グリップ - ブラックは、イタリアの有名ブランド Domino によるプレミアムなハンドルグリップです。美しさと走行性能の完璧な組み合わせを求めるライダーのために特別に設計されました。神秘的なブラックカラーとモダンなスタイルで、バイクの外観を際立たせるだけでなく、しっかりとした握り心地を提供し、混雑した市街地から長距離ツーリングまで、あらゆる道でハンドルバーを完全にコントロールするのに役立ちます。</p>\r\n<h3>主な特徴と優れたメリット</h3>\r\n<ul>\r\n<li><strong>人間工学に基づいたデザイン:</strong> ドミノ A250 グリップ - ブラックは、スマートな排水・防汚溝を備えた特徴的な表面テクスチャを採用しており、雨天時の走行や手汗をかきやすい方でも最適なグリップ力を確保します。</li>\r\n<li><strong>サーモプラスチックラバー素材:</strong> 本製品は特殊なラバーコンパウンドで作られており、優れた柔軟性と耐久性を両立しています。この素材は衝撃を和らげ、エンジンからハンドルに伝わる振動を吸収し、長時間の運転による手のしびれや疲労を最小限に抑えます。</li>\r\n<li><strong>時間を超越する耐久性:</strong> 低品質なグリップとは異なり、ドミノ A250 は耐熱性に優れ、長期間の直射日光や過酷な天候にさらされても「ベタつき」や変形が起こりにくくなっています。</li>\r\n<li><strong>簡単な取り付け:</strong> 標準的なサイズ設計により、現在市場に出回っている 22mm ハンドルバーを使用するほとんどのオートバイ、マニュアル車、大型バイクに素早く取り付けることができます。</li>\r\n</ul>\r\n<h3>詳細な技術仕様</h3>\r\n<table>\r\n<thead>\r\n<tr>\r\n<th>技術仕様</th>\r\n<th>製品詳細</th>\r\n</tr>\r\n</thead>\r\n<tbody>\r\n<tr>\r\n<td>ブランド</td>\r\n<td>Domino（イタリア製）</td>\r\n</tr>\r\n<tr>\r\n<td>モデル</td>\r\n<td>ドミノ A250 グリップ - ブラック</td>\r\n</tr>\r\n<tr>\r\n<td>長さ</td>\r\n<td>120 mm</td>\r\n</tr>\r\n<tr>\r\n<td>ハンドル径</td>\r\n<td>22 mm（標準）</td>\r\n</tr>\r\n<tr>\r\n<td>カラー</td>\r\n<td>ブラック</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>愛車に高い実用性と高級感をもたらす、手頃な価格のアクセサリーをお探しなら、ドミノ A250 グリップ - ブラックは見逃せない選択肢です。古くて滑りやすいグリップが、あなたの安全やライディングの楽しさを損なわないようにしましょう。今すぐ注文して、最高品質の純正アクセサリーを手に入れ、魅力的な特典を受け取りましょう！</p>','正規品 ドミノ A250 グリップ - ブラック (イタリア製) | 高級バイク用グリップ','ドミノ A250 グリップ ブラック','イタリア製正規品ドミノ A250 グリップ（ブラック）。高品質ラバー素材で滑り止めと手の疲労軽減を実現。耐久性に優れ、あらゆるバイクに適合。',0,'2026-04-29 02:42:41','2026-05-16 12:14:47',NULL),
(133,46,'vi','Tay Côn CRG',NULL,NULL,'Tay Côn CRG','Tay Côn CRG','Tay Côn CRG',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(134,46,'ja','JP Tay Côn CRG',NULL,NULL,'JP Tay Côn CRG','JP Tay Côn CRG','JP Tay Côn CRG',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(139,49,'vi','Mâm Kineo BMW R9T Scrambler',NULL,NULL,'Mâm Kineo BMW R9T Scrambler','Mâm Kineo BMW R9T Scrambler','Mâm Kineo BMW R9T Scrambler',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(140,49,'ja','JP Mâm Kineo BMW R9T Scrambler',NULL,NULL,'JP Mâm Kineo BMW R9T Scrambler','JP Mâm Kineo BMW R9T Scrambler','JP Mâm Kineo BMW R9T Scrambler',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(141,50,'vi','Ghi Đông IMA Ducati Panigale V4',NULL,NULL,'Ghi Đông IMA Ducati Panigale V4','Ghi Đông IMA Ducati Panigale V4','Ghi Đông IMA Ducati Panigale V4',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(142,50,'ja','JP Ghi Đông IMA Ducati Panigale V4',NULL,NULL,'JP Ghi Đông IMA Ducati Panigale V4','JP Ghi Đông IMA Ducati Panigale V4','JP Ghi Đông IMA Ducati Panigale V4',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(151,55,'vi','Rear Shock Nitron R1 Honda Wave 125i',NULL,NULL,'Rear Shock Nitron R1 Honda Wave 125i','Rear Shock Nitron R1 Honda Wave 125i','Rear Shock Nitron R1 Honda Wave 125i',0,'2026-04-29 02:42:41','2026-04-29 02:46:11',NULL),
(152,55,'ja','JP Rear Shock Nitron R1 Honda Wave 125i',NULL,NULL,'JP Rear Shock Nitron R1 Honda Wave 125i','JP Rear Shock Nitron R1 Honda Wave 125i','JP Rear Shock Nitron R1 Honda Wave 125i',0,'2026-04-29 02:42:41','2026-04-29 02:42:41',NULL),
(153,56,'vi','Pát Tăng Sên TWM YAMAHA R1 2020-25',NULL,NULL,'Pát Tăng Sên TWM YAMAHA R1 2020-25','Pát Tăng Sên TWM YAMAHA R1 2020-25','Pát Tăng Sên TWM YAMAHA R1 2020-25',0,'2026-04-29 02:42:42','2026-04-29 02:42:42',NULL),
(154,56,'ja','JP Pát Tăng Sên TWM YAMAHA R1 2020-25',NULL,NULL,'JP Pát Tăng Sên TWM YAMAHA R1 2020-25','JP Pát Tăng Sên TWM YAMAHA R1 2020-25','JP Pát Tăng Sên TWM YAMAHA R1 2020-25',0,'2026-04-29 02:42:42','2026-04-29 02:42:42',NULL),
(155,57,'vi','Bố Thắng Brembo Heo P2.34 (2 Piston)',NULL,NULL,'Bố Thắng Brembo Heo P2.34 (2 Piston)','Bố Thắng Brembo Heo P2.34 (2 Piston)','Bố Thắng Brembo Heo P2.34 (2 Piston)',0,'2026-04-29 02:42:42','2026-04-29 02:42:42',NULL),
(156,57,'ja','JP Bố Thắng Brembo Heo P2.34 (2 Piston)',NULL,NULL,'JP Bố Thắng Brembo Heo P2.34 (2 Piston)','JP Bố Thắng Brembo Heo P2.34 (2 Piston)','JP Bố Thắng Brembo Heo P2.34 (2 Piston)',0,'2026-04-29 02:42:42','2026-04-29 02:42:42',NULL);
/*!40000 ALTER TABLE `product_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `product_variants`
--

DROP TABLE IF EXISTS `product_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_variants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) unsigned NOT NULL,
  `sku` varchar(535) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `stock` int(10) unsigned NOT NULL DEFAULT 0,
  `image` varchar(535) DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_variants_sku_unique` (`sku`),
  KEY `product_variants_product_id_stock_index` (`product_id`,`stock`),
  CONSTRAINT `product_variants_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_variants`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `product_variants` WRITE;
/*!40000 ALTER TABLE `product_variants` DISABLE KEYS */;
INSERT INTO `product_variants` VALUES
(1,7,'A001-Blue',500000.00,604,'kem-duong-trang-tuyet-toan-than-huong-thi-snow-body-whitening-1-1684824054-1777952506.webp','[\"kem-duong-trang-tuyet-toan-than-huong-thi-snow-body-whitening-1-1684824054-1777952506.webp\",\"kem-duong-trang-tuyet-huong-thi-snow-body-whitening-1684824057-1777952506.webp\"]','2026-05-05 03:33:29','2026-05-19 08:05:45'),
(2,7,'A001-2',590000.00,554,'gel-tay-te-bao-chet-da-mat-huong-thi-exfoliating-face-scrub-1684824422-1778733745.webp','[\"gel-tay-te-bao-chet-da-mat-huong-thi-exfoliating-face-scrub-1684824422-1778733745.webp\"]','2026-05-11 07:18:14','2026-05-19 08:05:45');
/*!40000 ALTER TABLE `product_variants` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sku` varchar(535) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `sold_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `weight` int(11) DEFAULT 0,
  `brand` varchar(535) DEFAULT NULL,
  `base_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `is_coupon` tinyint(1) NOT NULL DEFAULT 0,
  `is_stock` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `hit_viewer` int(10) unsigned DEFAULT 0,
  `hit_order` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_status_order_index` (`status`,`order`),
  KEY `products_sku_index` (`sku`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(7,'A001',1158,13,10,NULL,0.00,590000.00,1,1,1,0,0,2,'2026-04-08 04:06:16','2026-05-19 08:05:45',NULL),
(22,'VAR-2490',99,0,0,NULL,0.00,1990000.00,0,1,1,15,0,0,'2026-04-29 02:38:38','2026-05-05 07:51:36',NULL),
(25,'VAR-1042',95,7,0,NULL,0.00,90000000.00,0,1,1,18,0,1,'2026-04-29 02:38:38','2026-05-14 05:58:59',NULL),
(26,'VAR-1058',0,0,0,NULL,0.00,90000000.00,0,1,1,19,0,0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(42,'VAR-1227',0,0,0,NULL,0.00,80190000.00,0,1,1,35,0,0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(43,'VAR-1230',0,0,0,NULL,0.00,85770000.00,0,1,1,36,0,0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(44,'VAR-1242',0,0,0,NULL,0.00,85770000.00,0,1,1,37,0,0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(45,'VAR-1136',36,3,0,NULL,0.00,620000.00,0,1,1,38,0,1,'2026-04-29 02:38:38','2026-05-14 05:58:59',NULL),
(46,'VAR-1109',2,0,0,NULL,0.00,5900000.00,0,1,1,39,0,0,'2026-04-29 02:38:38','2026-05-11 08:44:53',NULL),
(49,'VAR-1308',0,0,0,NULL,0.00,89940000.00,0,1,1,42,0,0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(50,'VAR-1352',2,0,0,NULL,0.00,13370000.00,0,1,1,43,0,0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL),
(55,'VAR-1473',8,0,0,NULL,0.00,25500000.00,0,1,1,48,0,0,'2026-04-29 02:38:38','2026-05-05 07:38:49',NULL),
(56,'VAR-2689',10,0,0,NULL,0.00,5150000.00,0,1,1,49,0,0,'2026-04-29 02:38:38','2026-05-04 06:55:33',NULL),
(57,'VAR-1675',11,0,0,NULL,0.00,1520000.00,0,1,1,50,0,0,'2026-04-29 02:38:38','2026-04-29 02:38:38',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_buytogift_offer_rules`
--

DROP TABLE IF EXISTS `promotion_buytogift_offer_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_buytogift_offer_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_buytogift_offer_id` bigint(20) unsigned NOT NULL,
  `condition_type` enum('order_amount','buy_product') NOT NULL DEFAULT 'buy_product',
  `min_order_amount` decimal(12,2) DEFAULT NULL,
  `max_sets_per_order` int(10) unsigned DEFAULT NULL,
  `max_gift_qty` int(10) unsigned DEFAULT NULL,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `stackable` tinyint(1) NOT NULL DEFAULT 0,
  `stock_scope` enum('all','limited') NOT NULL DEFAULT 'all',
  `stock_limit` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `buytogift_rules_offer_active_idx` (`promotion_buytogift_offer_id`,`is_active`),
  KEY `buytogift_rules_priority_active_idx` (`priority`,`is_active`),
  KEY `buytogift_rules_condition_active_idx` (`condition_type`,`is_active`),
  CONSTRAINT `buytogift_rules_offer_fk` FOREIGN KEY (`promotion_buytogift_offer_id`) REFERENCES `promotion_buytogift_offers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_buytogift_offer_rules`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_buytogift_offer_rules` WRITE;
/*!40000 ALTER TABLE `promotion_buytogift_offer_rules` DISABLE KEYS */;
INSERT INTO `promotion_buytogift_offer_rules` VALUES
(1,1,'buy_product',NULL,NULL,NULL,100,1,0,'all',NULL,'2026-04-28 07:21:30','2026-04-28 07:34:38','2026-04-28 07:34:38'),
(2,1,'order_amount',700000.00,NULL,20,102,1,0,'limited',60,'2026-04-28 07:23:13','2026-05-12 04:22:44',NULL),
(3,1,'buy_product',NULL,NULL,30,101,1,0,'limited',62,'2026-05-04 05:44:40','2026-05-12 08:26:34',NULL);
/*!40000 ALTER TABLE `promotion_buytogift_offer_rules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_buytogift_offers`
--

DROP TABLE IF EXISTS `promotion_buytogift_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_buytogift_offers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(535) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `campaign_id` bigint(20) unsigned DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `stackable` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_buytogift_offers_code_unique` (`code`),
  KEY `promotion_buytogift_offers_code_index` (`code`),
  KEY `promotion_buytogift_offers_is_active_starts_at_ends_at_index` (`is_active`,`starts_at`,`ends_at`),
  KEY `promotion_buytogift_offers_priority_is_active_index` (`priority`,`is_active`),
  KEY `promotion_buytogift_offers_campaign_id_foreign` (`campaign_id`),
  CONSTRAINT `promotion_buytogift_offers_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `promotion_campaigns` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_buytogift_offers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_buytogift_offers` WRITE;
/*!40000 ALTER TABLE `promotion_buytogift_offers` DISABLE KEYS */;
INSERT INTO `promotion_buytogift_offers` VALUES
(1,'A001','May A0001',NULL,1,'2026-05-08 10:00:00','2026-05-31 14:47:00',100,1,0,'2026-04-28 07:21:30','2026-05-19 07:30:16',NULL),
(2,'GIFT-1','Gift 1',NULL,NULL,'2026-05-06 07:36:23','2026-05-08 07:36:23',1,1,0,'2026-05-07 07:36:23','2026-05-07 07:53:38','2026-05-07 07:53:38'),
(3,'GIFT-2','Gift 2',NULL,1,'2026-05-06 07:41:10','2026-05-08 07:41:10',1,1,0,'2026-05-07 07:41:10','2026-05-07 07:53:38','2026-05-07 07:53:38');
/*!40000 ALTER TABLE `promotion_buytogift_offers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_buytogift_rule_buy_items`
--

DROP TABLE IF EXISTS `promotion_buytogift_rule_buy_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_buytogift_rule_buy_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_buytogift_rule_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variant_id` bigint(20) unsigned DEFAULT NULL,
  `buy_qty` int(10) unsigned NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_buytogift_rule_buy_items_variant_unique` (`promotion_buytogift_rule_id`,`product_id`,`variant_id`),
  KEY `promotion_buytogift_rule_buy_items_product_id_index` (`product_id`),
  KEY `promotion_buytogift_rule_buy_items_variant_id_foreign` (`variant_id`),
  CONSTRAINT `buytogift_buy_items_rule_fk` FOREIGN KEY (`promotion_buytogift_rule_id`) REFERENCES `promotion_buytogift_offer_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `promotion_buytogift_rule_buy_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `promotion_buytogift_rule_buy_items_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_buytogift_rule_buy_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_buytogift_rule_buy_items` WRITE;
/*!40000 ALTER TABLE `promotion_buytogift_rule_buy_items` DISABLE KEYS */;
INSERT INTO `promotion_buytogift_rule_buy_items` VALUES
(1,1,7,NULL,2,'2026-04-28 07:21:30','2026-04-28 07:23:13'),
(3,3,25,NULL,1,'2026-05-04 08:14:27','2026-05-12 08:48:51');
/*!40000 ALTER TABLE `promotion_buytogift_rule_buy_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_buytogift_rule_gift_items`
--

DROP TABLE IF EXISTS `promotion_buytogift_rule_gift_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_buytogift_rule_gift_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_buytogift_rule_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variant_id` bigint(20) unsigned DEFAULT NULL,
  `gift_qty` int(10) unsigned NOT NULL DEFAULT 1,
  `is_auto_add` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_buytogift_rule_gift_items_variant_unique` (`promotion_buytogift_rule_id`,`product_id`,`variant_id`),
  KEY `promotion_buytogift_rule_gift_items_product_id_index` (`product_id`),
  KEY `promotion_buytogift_rule_gift_items_variant_id_foreign` (`variant_id`),
  CONSTRAINT `buytogift_gift_items_rule_fk` FOREIGN KEY (`promotion_buytogift_rule_id`) REFERENCES `promotion_buytogift_offer_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `promotion_buytogift_rule_gift_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `promotion_buytogift_rule_gift_items_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_buytogift_rule_gift_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_buytogift_rule_gift_items` WRITE;
/*!40000 ALTER TABLE `promotion_buytogift_rule_gift_items` DISABLE KEYS */;
INSERT INTO `promotion_buytogift_rule_gift_items` VALUES
(1,1,7,NULL,1,1,'2026-04-28 07:21:30','2026-04-28 07:23:13'),
(2,2,7,NULL,1,1,'2026-04-28 07:23:13','2026-05-12 08:48:51'),
(4,3,7,NULL,2,1,'2026-05-04 08:14:27','2026-05-12 08:48:51');
/*!40000 ALTER TABLE `promotion_buytogift_rule_gift_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_buytogift_rule_gift_variant_options`
--

DROP TABLE IF EXISTS `promotion_buytogift_rule_gift_variant_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_buytogift_rule_gift_variant_options` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_buytogift_offer_rule_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variant_id` bigint(20) unsigned NOT NULL,
  `reserve_qty` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_buytogift_rule_gift_variant_options`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_buytogift_rule_gift_variant_options` WRITE;
/*!40000 ALTER TABLE `promotion_buytogift_rule_gift_variant_options` DISABLE KEYS */;
INSERT INTO `promotion_buytogift_rule_gift_variant_options` VALUES
(1,3,7,1,13,'2026-05-12 04:12:59','2026-05-12 09:05:58'),
(2,3,7,2,15,'2026-05-12 04:12:59','2026-05-12 08:26:34'),
(3,2,7,1,8,'2026-05-12 04:21:39','2026-05-19 08:05:45'),
(4,2,7,2,10,'2026-05-12 04:21:39','2026-05-19 08:05:45');
/*!40000 ALTER TABLE `promotion_buytogift_rule_gift_variant_options` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_buytogift_rule_stock_allocations`
--

DROP TABLE IF EXISTS `promotion_buytogift_rule_stock_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_buytogift_rule_stock_allocations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_buytogift_offer_rule_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variant_id` bigint(20) unsigned DEFAULT NULL,
  `allocated_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `buytogift_rule_stock_allocations_variant_unique` (`promotion_buytogift_offer_rule_id`,`product_id`,`variant_id`),
  KEY `promotion_buytogift_rule_stock_allocations_product_id_index` (`product_id`),
  KEY `promotion_buytogift_rule_stock_allocations_variant_id_foreign` (`variant_id`),
  CONSTRAINT `buytogift_rule_stock_allocations_rule_fk` FOREIGN KEY (`promotion_buytogift_offer_rule_id`) REFERENCES `promotion_buytogift_offer_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `promotion_buytogift_rule_stock_allocations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `promotion_buytogift_rule_stock_allocations_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_buytogift_rule_stock_allocations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_buytogift_rule_stock_allocations` WRITE;
/*!40000 ALTER TABLE `promotion_buytogift_rule_stock_allocations` DISABLE KEYS */;
INSERT INTO `promotion_buytogift_rule_stock_allocations` VALUES
(20,2,7,1,8,'2026-05-12 06:24:53','2026-05-19 08:05:45'),
(21,2,7,2,10,'2026-05-12 06:24:53','2026-05-19 08:05:45'),
(22,3,7,1,13,'2026-05-12 06:24:53','2026-05-12 09:05:58'),
(23,3,7,2,15,'2026-05-12 06:24:53','2026-05-12 08:26:34');
/*!40000 ALTER TABLE `promotion_buytogift_rule_stock_allocations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_campaign_products`
--

DROP TABLE IF EXISTS `promotion_campaign_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_campaign_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_campaign_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pcp_campaign_product_unique` (`promotion_campaign_id`,`product_id`),
  KEY `promotion_campaign_products_product_id_foreign` (`product_id`),
  CONSTRAINT `promotion_campaign_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `promotion_campaign_products_promotion_campaign_id_foreign` FOREIGN KEY (`promotion_campaign_id`) REFERENCES `promotion_campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_campaign_products`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_campaign_products` WRITE;
/*!40000 ALTER TABLE `promotion_campaign_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotion_campaign_products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_campaign_translations`
--

DROP TABLE IF EXISTS `promotion_campaign_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_campaign_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_campaign_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `name` varchar(535) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `slug` varchar(535) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_campaign_locale_unique` (`promotion_campaign_id`,`locale`),
  UNIQUE KEY `promotion_campaign_slug_locale_unique` (`slug`,`locale`),
  KEY `promotion_campaign_translations_locale_index` (`locale`),
  CONSTRAINT `promotion_campaign_translations_promotion_campaign_id_foreign` FOREIGN KEY (`promotion_campaign_id`) REFERENCES `promotion_campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_campaign_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_campaign_translations` WRITE;
/*!40000 ALTER TABLE `promotion_campaign_translations` DISABLE KEYS */;
INSERT INTO `promotion_campaign_translations` VALUES
(1,1,'vi','Giảm giá tháng 5',NULL,NULL,'2026-05-07 07:47:08','2026-05-07 08:03:43',NULL),
(2,1,'en','May Sale',NULL,NULL,'2026-05-07 07:47:08','2026-05-07 08:03:43',NULL),
(3,1,'ja','5月のセール',NULL,NULL,'2026-05-07 07:47:08','2026-05-07 08:03:43',NULL);
/*!40000 ALTER TABLE `promotion_campaign_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_campaigns`
--

DROP TABLE IF EXISTS `promotion_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_campaigns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_campaigns`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_campaigns` WRITE;
/*!40000 ALTER TABLE `promotion_campaigns` DISABLE KEYS */;
INSERT INTO `promotion_campaigns` VALUES
(1,'2026-05-08 10:00:00','2026-05-31 14:47:00',100,1,'2026-05-07 07:47:08','2026-05-12 06:24:53',NULL);
/*!40000 ALTER TABLE `promotion_campaigns` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_coupons`
--

DROP TABLE IF EXISTS `promotion_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(535) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `campaign_id` bigint(20) unsigned DEFAULT NULL,
  `discount_type` enum('percent','fixed') NOT NULL,
  `discount_value` decimal(12,2) NOT NULL,
  `max_discount_amount` decimal(12,2) DEFAULT NULL,
  `min_order_amount` decimal(12,2) DEFAULT NULL,
  `max_order_amount` decimal(12,2) DEFAULT NULL,
  `first_order_only` tinyint(1) NOT NULL DEFAULT 0,
  `usage_limit_total` int(10) unsigned DEFAULT NULL,
  `usage_limit_per_user` int(10) unsigned DEFAULT NULL,
  `used_count` int(10) unsigned NOT NULL DEFAULT 0,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `stackable` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_coupons_code_unique` (`code`),
  KEY `promotion_coupons_code_index` (`code`),
  KEY `promotion_coupons_is_active_starts_at_ends_at_index` (`is_active`,`starts_at`,`ends_at`),
  KEY `promotion_coupons_campaign_id_foreign` (`campaign_id`),
  KEY `promotion_coupons_priority_active_idx` (`priority`,`is_active`),
  CONSTRAINT `promotion_coupons_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `promotion_campaigns` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_coupons`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_coupons` WRITE;
/*!40000 ALTER TABLE `promotion_coupons` DISABLE KEYS */;
INSERT INTO `promotion_coupons` VALUES
(1,'A0001','Coupon A0001 Discount 10%',NULL,1,'percent',10.00,10000.00,NULL,NULL,0,1000,1,0,'2026-05-08 10:00:00','2026-05-31 14:47:00',100,1,1,0,'2026-04-09 08:22:14','2026-05-19 07:30:16',NULL),
(2,'COUPON-1','Coupon 1',NULL,NULL,'fixed',100.00,NULL,NULL,NULL,0,NULL,NULL,0,'2026-05-06 07:36:23','2026-05-08 07:36:23',100,1,1,0,'2026-05-07 07:36:23','2026-05-07 07:53:46','2026-05-07 07:53:46'),
(3,'COUPON-2','Coupon 2',NULL,1,'fixed',100.00,NULL,NULL,NULL,0,NULL,NULL,0,'2026-05-06 07:41:10','2026-05-08 07:41:10',100,1,1,0,'2026-05-07 07:41:10','2026-05-07 07:53:46','2026-05-07 07:53:46');
/*!40000 ALTER TABLE `promotion_coupons` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `promotion_saleoffers`
--

DROP TABLE IF EXISTS `promotion_saleoffers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `promotion_saleoffers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(535) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `campaign_id` bigint(20) unsigned DEFAULT NULL,
  `discount_type` enum('percent','fixed') NOT NULL,
  `discount_value` decimal(12,2) NOT NULL,
  `max_discount_amount` decimal(12,2) DEFAULT NULL,
  `starts_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `stackable` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `promotion_saleoffers_code_unique` (`code`),
  KEY `promotion_saleoffers_is_active_starts_at_ends_at_index` (`is_active`,`starts_at`,`ends_at`),
  KEY `promotion_saleoffers_priority_is_active_index` (`priority`,`is_active`),
  KEY `promotion_saleoffers_campaign_id_foreign` (`campaign_id`),
  CONSTRAINT `promotion_saleoffers_campaign_id_foreign` FOREIGN KEY (`campaign_id`) REFERENCES `promotion_campaigns` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promotion_saleoffers`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `promotion_saleoffers` WRITE;
/*!40000 ALTER TABLE `promotion_saleoffers` DISABLE KEYS */;
INSERT INTO `promotion_saleoffers` VALUES
(1,'LDA001','Discount 10%',NULL,1,'percent',10.00,NULL,'2026-05-08 10:00:00','2026-05-31 14:47:00',90,1,0,'2026-04-09 09:06:54','2026-05-19 07:30:16',NULL),
(2,'SALE-1','Sale 1',NULL,NULL,'percent',10.00,NULL,'2026-05-06 07:36:23','2026-05-08 07:36:23',1,1,1,'2026-05-07 07:36:23','2026-05-07 07:49:20','2026-05-07 07:49:20'),
(3,'SALE-2','Sale 2',NULL,1,'percent',10.00,NULL,'2026-05-06 07:41:10','2026-05-08 07:41:10',1,1,1,'2026-05-07 07:41:10','2026-05-07 07:49:20','2026-05-07 07:49:20');
/*!40000 ALTER TABLE `promotion_saleoffers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `provinces`
--

DROP TABLE IF EXISTS `provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `provinces` (
  `code` varchar(20) NOT NULL,
  `name` varchar(535) NOT NULL,
  `name_en` varchar(535) DEFAULT NULL,
  `full_name` varchar(535) NOT NULL,
  `full_name_en` varchar(535) DEFAULT NULL,
  `code_name` varchar(535) DEFAULT NULL,
  `administrative_unit_id` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`code`),
  KEY `idx_provinces_unit` (`administrative_unit_id`),
  CONSTRAINT `provinces_administrative_unit_id_foreign` FOREIGN KEY (`administrative_unit_id`) REFERENCES `administrative_units` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provinces`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;
INSERT INTO `provinces` VALUES
('01','Hà Nội','Ha Noi','Thành phố Hà Nội','Ha Noi City','ha_noi',1),
('04','Cao Bằng','Cao Bang','Tỉnh Cao Bằng','Cao Bang Province','cao_bang',2),
('08','Tuyên Quang','Tuyen Quang','Tỉnh Tuyên Quang','Tuyen Quang Province','tuyen_quang',2),
('11','Điện Biên','Dien Bien','Tỉnh Điện Biên','Dien Bien Province','dien_bien',2),
('12','Lai Châu','Lai Chau','Tỉnh Lai Châu','Lai Chau Province','lai_chau',2),
('14','Sơn La','Son La','Tỉnh Sơn La','Son La Province','son_la',2),
('15','Lào Cai','Lao Cai','Tỉnh Lào Cai','Lao Cai Province','lao_cai',2),
('19','Thái Nguyên','Thai Nguyen','Tỉnh Thái Nguyên','Thai Nguyen Province','thai_nguyen',2),
('20','Lạng Sơn','Lang Son','Tỉnh Lạng Sơn','Lang Son Province','lang_son',2),
('22','Quảng Ninh','Quang Ninh','Tỉnh Quảng Ninh','Quang Ninh Province','quang_ninh',2),
('24','Bắc Ninh','Bac Ninh','Tỉnh Bắc Ninh','Bac Ninh Province','bac_ninh',2),
('25','Phú Thọ','Phu Tho','Tỉnh Phú Thọ','Phu Tho Province','phu_tho',2),
('31','Hải Phòng','Hai Phong','Thành phố Hải Phòng','Hai Phong City','hai_phong',1),
('33','Hưng Yên','Hung Yen','Tỉnh Hưng Yên','Hung Yen Province','hung_yen',2),
('37','Ninh Bình','Ninh Binh','Tỉnh Ninh Bình','Ninh Binh Province','ninh_binh',2),
('38','Thanh Hóa','Thanh Hoa','Tỉnh Thanh Hóa','Thanh Hoa Province','thanh_hoa',2),
('40','Nghệ An','Nghe An','Tỉnh Nghệ An','Nghe An Province','nghe_an',2),
('42','Hà Tĩnh','Ha Tinh','Tỉnh Hà Tĩnh','Ha Tinh Province','ha_tinh',2),
('44','Quảng Trị','Quang Tri','Tỉnh Quảng Trị','Quang Tri Province','quang_tri',2),
('46','Huế','Hue','Thành phố Huế','Hue City','hue',1),
('48','Đà Nẵng','Da Nang','Thành phố Đà Nẵng','Da Nang City','da_nang',1),
('51','Quảng Ngãi','Quang Ngai','Tỉnh Quảng Ngãi','Quang Ngai Province','quang_ngai',2),
('52','Gia Lai','Gia Lai','Tỉnh Gia Lai','Gia Lai Province','gia_lai',2),
('56','Khánh Hòa','Khanh Hoa','Tỉnh Khánh Hòa','Khanh Hoa Province','khanh_hoa',2),
('66','Đắk Lắk','Dak Lak','Tỉnh Đắk Lắk','Dak Lak Province','dak_lak',2),
('68','Lâm Đồng','Lam Dong','Tỉnh Lâm Đồng','Lam Dong Province','lam_dong',2),
('75','Đồng Nai','Dong Nai','Tỉnh Đồng Nai','Dong Nai Province','dong_nai',2),
('79','Hồ Chí Minh','Ho Chi Minh','Thành phố Hồ Chí Minh','Ho Chi Minh City','ho_chi_minh',1),
('80','Tây Ninh','Tay Ninh','Tỉnh Tây Ninh','Tay Ninh Province','tay_ninh',2),
('82','Đồng Tháp','Dong Thap','Tỉnh Đồng Tháp','Dong Thap Province','dong_thap',2),
('86','Vĩnh Long','Vinh Long','Tỉnh Vĩnh Long','Vinh Long Province','vinh_long',2),
('91','An Giang','An Giang','Tỉnh An Giang','An Giang Province','an_giang',2),
('92','Cần Thơ','Can Tho','Thành phố Cần Thơ','Can Tho City','can_tho',1),
('96','Cà Mau','Ca Mau','Tỉnh Cà Mau','Ca Mau Province','ca_mau',2);
/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES
(1,1),
(2,1),
(3,1),
(4,1),
(5,1),
(6,1),
(7,1),
(8,1),
(9,1),
(10,1),
(11,1),
(12,1),
(13,1),
(14,1),
(15,1),
(16,1),
(17,1),
(18,1),
(19,1),
(20,1),
(21,1),
(22,1),
(23,1),
(24,1),
(25,1),
(26,1),
(27,1),
(28,1),
(29,1),
(30,1),
(31,1),
(32,1),
(33,1),
(34,1),
(35,1),
(36,1),
(37,1),
(38,1),
(39,1),
(40,1),
(41,1),
(42,1),
(43,1),
(44,1),
(45,1),
(46,1),
(47,1),
(48,1),
(49,1),
(50,1),
(51,1),
(52,1),
(53,1),
(54,1),
(55,1),
(56,1),
(57,1),
(58,1),
(59,1),
(60,1),
(61,1),
(62,1),
(63,1),
(64,1),
(65,1),
(66,1),
(67,1),
(68,1),
(69,1),
(70,1),
(71,1),
(72,1),
(73,1),
(74,1),
(75,1),
(76,1),
(77,1),
(78,1),
(79,1),
(80,1),
(81,1),
(82,1),
(83,1),
(84,1),
(85,1),
(86,1),
(87,1),
(88,1),
(89,1),
(90,1),
(91,1),
(92,1),
(93,1),
(94,1),
(95,1),
(96,1),
(97,1),
(98,1),
(99,1),
(100,1),
(101,1),
(102,1),
(103,1),
(104,1),
(105,1),
(106,1),
(107,1),
(108,1),
(109,1),
(110,1),
(111,1),
(112,1),
(113,1),
(116,1),
(117,1),
(118,1),
(119,1),
(120,1),
(121,1),
(122,1),
(123,1),
(124,1),
(125,1),
(126,1),
(127,1),
(128,1),
(129,1),
(130,1),
(131,1),
(132,1),
(133,1),
(134,1),
(135,1),
(136,1),
(137,1),
(138,1),
(139,1),
(140,1),
(141,1),
(142,1),
(143,1),
(144,1),
(145,1),
(146,1),
(147,1),
(148,1),
(149,1),
(150,1),
(151,1),
(152,1),
(153,1),
(154,1),
(155,1),
(156,1),
(157,1),
(158,1),
(159,1),
(160,1),
(161,1),
(162,1),
(163,1),
(164,1),
(165,1),
(166,1),
(167,1),
(168,1),
(169,1),
(170,1),
(171,1),
(172,1),
(173,1),
(174,1),
(175,1),
(176,1),
(177,1),
(178,1),
(179,1),
(180,1),
(181,1),
(182,1),
(183,1),
(184,1),
(185,1),
(186,1),
(187,1),
(188,1),
(189,1),
(190,1),
(191,1),
(192,1),
(193,1),
(194,1),
(195,1),
(196,1),
(197,1),
(198,1),
(199,1),
(200,1),
(201,1),
(202,1),
(203,1),
(204,1),
(205,1),
(206,1),
(207,1),
(208,1),
(209,1),
(210,1),
(211,1),
(212,1),
(213,1),
(214,1),
(215,1),
(216,1),
(217,1),
(218,1),
(219,1),
(220,1),
(221,1),
(222,1),
(223,1),
(224,1),
(225,1),
(226,1),
(227,1),
(228,1),
(229,1),
(230,1),
(231,1),
(232,1),
(233,1),
(234,1),
(235,1),
(236,1),
(237,1),
(238,1),
(239,1),
(240,1),
(241,1),
(242,1),
(243,1),
(244,1),
(245,1),
(246,1),
(247,1),
(248,1),
(249,1),
(250,1),
(251,1),
(252,1),
(253,1),
(254,1),
(255,1),
(256,1),
(257,1),
(258,1),
(259,1),
(260,1),
(261,1),
(262,1),
(263,1),
(264,1),
(265,1),
(266,1),
(267,1),
(268,1),
(269,1),
(270,1),
(271,1),
(272,1),
(273,1),
(274,1),
(275,1),
(276,1),
(277,1),
(278,1),
(279,1),
(280,1),
(281,1),
(282,1),
(283,1),
(284,1),
(285,1),
(286,1),
(287,1),
(288,1),
(289,1),
(290,1),
(291,1),
(292,1),
(293,1),
(294,1),
(295,1),
(296,1),
(297,1),
(298,1),
(299,1),
(300,1),
(301,1),
(302,1),
(303,1),
(304,1),
(305,1),
(306,1),
(307,1),
(308,1),
(309,1),
(310,1),
(311,1),
(312,1),
(313,1),
(314,1),
(315,1),
(316,1),
(317,1),
(318,1),
(319,1),
(320,1),
(321,1),
(322,1),
(323,1),
(324,1),
(325,1),
(326,1),
(327,1),
(328,1),
(329,1),
(330,1),
(114,3),
(115,3);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `guard_name` varchar(250) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Aministrators','web','2026-03-04 02:52:07','2026-03-04 02:52:07'),
(3,'Api','api','2026-03-15 06:46:54','2026-03-15 06:46:54'),
(4,'Not Access','web','2026-03-15 07:49:52','2026-03-15 07:49:52');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `saleoffer_products`
--

DROP TABLE IF EXISTS `saleoffer_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `saleoffer_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `promotion_saleoffer_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `saleoffer_products_unique` (`promotion_saleoffer_id`,`product_id`),
  KEY `saleoffer_products_product_id_index` (`product_id`),
  CONSTRAINT `saleoffer_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `saleoffer_products_promotion_saleoffer_id_foreign` FOREIGN KEY (`promotion_saleoffer_id`) REFERENCES `promotion_saleoffers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saleoffer_products`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `saleoffer_products` WRITE;
/*!40000 ALTER TABLE `saleoffer_products` DISABLE KEYS */;
INSERT INTO `saleoffer_products` VALUES
(1,1,7,'2026-04-09 09:06:54','2026-04-09 09:06:54'),
(2,1,22,'2026-05-04 08:37:54','2026-05-04 08:37:54'),
(3,1,45,'2026-05-04 08:37:54','2026-05-04 08:37:54'),
(4,1,46,'2026-05-04 08:37:54','2026-05-04 08:37:54');
/*!40000 ALTER TABLE `saleoffer_products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `shipping_methods`
--

DROP TABLE IF EXISTS `shipping_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipping_methods` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `provider` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `sort_order` int(10) unsigned NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `shipping_methods_code_unique` (`code`),
  KEY `shipping_methods_provider_index` (`provider`),
  KEY `shipping_methods_is_active_index` (`is_active`),
  KEY `shipping_methods_is_system_index` (`is_system`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_methods`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `shipping_methods` WRITE;
/*!40000 ALTER TABLE `shipping_methods` DISABLE KEYS */;
INSERT INTO `shipping_methods` VALUES
(1,'ghn','ghn','GHN','Giao Hàng Nhanh','[]',0,0,1,'2026-04-29 09:25:35','2026-04-29 09:26:00',NULL),
(2,'ghtk','ghtk','GHTK','Giao Hàng Tiết Kiệm','[]',1,1,1,'2026-04-29 09:25:35','2026-05-04 07:00:15',NULL),
(3,'viettel_post','viettel_post','Viettel Post','Viettel Post shipping API','[]',2,0,1,'2026-04-29 09:25:35','2026-04-29 09:26:01',NULL),
(4,'jnt','jnt','J&T Express','J&T Express shipping API','[]',3,0,1,'2026-04-29 09:25:35','2026-04-29 09:26:02',NULL),
(5,'ninja_van','ninja_van','Ninja Van','Ninja Van shipping API','[]',4,0,1,'2026-04-29 09:25:35','2026-04-29 09:26:04',NULL);
/*!40000 ALTER TABLE `shipping_methods` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `slugs`
--

DROP TABLE IF EXISTS `slugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `slugs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `locale` varchar(10) NOT NULL,
  `sluggable_id` bigint(20) unsigned NOT NULL,
  `sluggable_type` varchar(535) NOT NULL,
  `redirect_to` varchar(535) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `is_default` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slugs_slug_locale_unique` (`slug`,`locale`),
  KEY `sluggable_locale_index` (`sluggable_id`,`sluggable_type`,`locale`),
  KEY `slugs_slug_index` (`slug`),
  KEY `slugs_locale_index` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=451 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slugs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `slugs` WRITE;
/*!40000 ALTER TABLE `slugs` DISABLE KEYS */;
INSERT INTO `slugs` VALUES
(1,'do-gia-dung','vi',4,'App\\Models\\Category',NULL,1,1,'2026-03-18 14:57:29','2026-03-18 14:57:29'),
(2,'household-appliances','en',4,'App\\Models\\Category',NULL,1,1,'2026-03-18 14:57:29','2026-03-18 14:57:29'),
(3,'家電','ja',4,'App\\Models\\Category',NULL,1,1,'2026-03-18 14:57:29','2026-03-18 14:57:29'),
(22,'ban-ui','vi',13,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:29:59','2026-03-19 04:32:51'),
(23,'to-iron','en',13,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:29:59','2026-03-19 04:32:51'),
(24,'','ja',13,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:29:59','2026-03-19 08:19:22'),
(25,'chao-chong-dinh','vi',14,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:34:27','2026-03-19 04:40:01'),
(26,'non-stick-frying-pan-non-stick-skillet','en',14,'App\\Models\\Category','non-stick-skillet',1,0,'2026-03-19 03:34:27','2026-03-20 03:34:18'),
(27,'フライハン','ja',14,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:34:27','2026-03-19 04:40:01'),
(28,'lam-dep','vi',15,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:40:43','2026-03-19 04:32:55'),
(29,'health-beauty','en',15,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:40:44','2026-03-19 04:32:55'),
(30,'美容-ヒューティー','ja',15,'App\\Models\\Category',NULL,1,1,'2026-03-19 03:40:44','2026-03-19 04:32:55'),
(41,'non-stick-skillet','en',14,'App\\Models\\Category',NULL,1,1,'2026-03-20 03:23:36','2026-03-20 03:34:18'),
(42,'non-stick-skillets','en',14,'App\\Models\\Category','non-stick-skillet',1,0,'2026-03-20 03:34:06','2026-03-20 03:34:18'),
(43,'ban-ui-hoi-nuoc','vi',19,'App\\Models\\Category',NULL,1,1,'2026-03-20 04:17:41','2026-03-20 04:17:41'),
(44,'steam-iron','en',19,'App\\Models\\Category',NULL,1,1,'2026-03-20 04:17:41','2026-03-20 04:17:41'),
(45,'スチームアイロン','ja',19,'App\\Models\\Category',NULL,1,1,'2026-03-20 04:17:41','2026-03-20 04:17:41'),
(46,'ten-viet','vi',6,'App\\Models\\Product',NULL,0,1,'2026-04-07 10:24:09','2026-04-07 10:25:50'),
(47,'ten-anh','en',6,'App\\Models\\Product',NULL,0,1,'2026-04-07 10:24:09','2026-04-07 10:25:50'),
(48,'ten-nhat','ja',6,'App\\Models\\Product',NULL,0,1,'2026-04-07 10:24:10','2026-04-07 10:25:50'),
(49,'a','vi',7,'App\\Models\\Product','nuoc-hoa-charme-cool-water',1,0,'2026-04-08 04:06:17','2026-04-08 08:49:52'),
(50,'b','en',7,'App\\Models\\Product','charme-cool-water-perfume',1,0,'2026-04-08 04:06:17','2026-04-08 08:49:52'),
(51,'c','ja',7,'App\\Models\\Product','チャーム-クールウォーター-ハフューム',1,0,'2026-04-08 04:06:17','2026-04-08 08:49:52'),
(52,'tin-tuc','vi',20,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:03:08','2026-04-08 08:03:08'),
(53,'posts','en',20,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:03:08','2026-04-08 08:03:08'),
(54,'投稿','ja',20,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:03:08','2026-04-08 08:03:08'),
(55,'lien-he','vi',21,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:18:41','2026-04-08 08:18:41'),
(56,'contact-us','en',21,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:18:41','2026-04-08 08:18:41'),
(57,'お問い合わせ','ja',21,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:18:41','2026-04-08 08:18:41'),
(58,'gioi-thieu','vi',22,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:20:07','2026-04-08 08:20:07'),
(59,'about-us','en',22,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:20:07','2026-04-08 08:20:07'),
(60,'私たちについて','ja',22,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:20:07','2026-04-08 08:20:07'),
(62,'shops','en',23,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:29:06','2026-04-08 08:29:06'),
(63,'ショッフ','ja',23,'App\\Models\\Category',NULL,1,1,'2026-04-08 08:29:06','2026-04-08 08:29:06'),
(64,'nuoc-hoa-charme-cool-water','vi',7,'App\\Models\\Product',NULL,1,1,'2026-04-08 08:49:52','2026-04-08 08:49:52'),
(65,'charme-cool-water-perfume','en',7,'App\\Models\\Product',NULL,1,1,'2026-04-08 08:49:52','2026-04-08 08:49:52'),
(66,'チャーム-クールウォーター-ハフューム','ja',7,'App\\Models\\Product',NULL,1,1,'2026-04-08 08:49:52','2026-04-08 08:49:52'),
(89,'napxangaccossatoyamahafc124xanhduong-22','en',22,'App\\Models\\Catalog\\Product','accossato-fuel-cap-for-yamaha-fc124',1,0,'2026-04-29 02:46:10','2026-05-08 07:50:44'),
(94,'mambstrapidtekducatihypermotard950201923denbong-25','en',25,'App\\Models\\Catalog\\Product','bst-rapid-tek-wheels-for-ducati-hypermotard-950-2019-23',1,0,'2026-04-29 02:46:10','2026-05-08 07:51:33'),
(95,'mambstrapidtekducatipanigalev4201823denbong-26','en',26,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(118,'mamozracingapriliarsv4r200923vang-42','en',42,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(119,'mamozracingbmws1000rr201018vang-43','en',43,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(120,'mamozracingbmws1000rr201923titan-44','en',44,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(121,'baotaydominoa250dencam-45','en',45,'App\\Models\\Catalog\\Product','domino-a250-grips-black',1,0,'2026-04-29 02:46:10','2026-05-16 12:14:47'),
(123,'tayconcrgracelinexam-46','en',46,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(130,'mamkineobmwr9tscramblerdenvang-49','en',49,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(132,'ghidongimaducatipanigalev4titan-50','en',50,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(139,'phuocsaunitronr1hondawave125ixanh-55','en',55,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(141,'pattangsentwmyamahar1202025den-56','en',56,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(143,'bothangbremboheop2342pistonheatshield-57','en',57,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(144,'heo-thang-51','vi',51,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:42:41','2026-04-29 02:42:41'),
(145,'brake-caliper-51','en',51,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:42:41','2026-04-29 02:42:41'),
(146,'jp-brake-caliper-51','ja',51,'App\\Models\\Catalog\\Category','フレーキキャリハー',1,0,'2026-04-29 02:42:41','2026-04-29 02:58:02'),
(157,'tay-thang-54','vi',54,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:42:41','2026-04-29 02:42:41'),
(158,'brake-lever-54','en',54,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:42:41','2026-04-29 02:42:41'),
(159,'jp-brake-lever-54','ja',54,'App\\Models\\Catalog\\Category','フレーキレハー',1,0,'2026-04-29 02:42:41','2026-04-29 02:58:38'),
(165,'bao-tay-56','vi',56,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:42:41','2026-04-29 02:42:41'),
(166,'grip-56','en',56,'App\\Models\\Catalog\\Category','glove',1,0,'2026-04-29 02:42:41','2026-04-29 03:00:33'),
(167,'jp-grip-56','ja',56,'App\\Models\\Catalog\\Category','クローフ',1,0,'2026-04-29 02:42:41','2026-04-29 03:00:33'),
(196,'napxangaccossatoyamahafc124xanhduong-22','vi',22,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(197,'napxangaccossatoyamahafc124xanhduong-22','ja',22,'App\\Models\\Catalog\\Product','accossato-ヤマハ用-フューエルキャッフ-fc124',1,0,'2026-04-29 02:46:10','2026-05-08 07:50:44'),
(208,'mambstrapidtekducatihypermotard950201923denbong-25','vi',25,'App\\Models\\Catalog\\Product','mam-bst-rapid-tek-ducati-hypermotard-950-2019-23',1,0,'2026-04-29 02:46:10','2026-04-29 04:49:39'),
(209,'mambstrapidtekducatihypermotard950201923denbong-25','ja',25,'App\\Models\\Catalog\\Product','bst-rapid-tek-ホイール-ducati-hypermotard-950-2019-23',1,0,'2026-04-29 02:46:10','2026-05-08 07:51:33'),
(210,'mambstrapidtekducatipanigalev4201823denbong-26','vi',26,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(211,'mambstrapidtekducatipanigalev4201823denbong-26','ja',26,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(263,'mamozracingapriliarsv4r200923vang-42','vi',42,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(264,'mamozracingapriliarsv4r200923vang-42','ja',42,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(265,'mamozracingbmws1000rr201018vang-43','vi',43,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(266,'mamozracingbmws1000rr201018vang-43','ja',43,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(267,'mamozracingbmws1000rr201923titan-44','vi',44,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(268,'mamozracingbmws1000rr201923titan-44','ja',44,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:10','2026-04-29 02:46:10'),
(269,'baotaydominoa250dencam-45','vi',45,'App\\Models\\Catalog\\Product','grip-domino-a250-den',1,0,'2026-04-29 02:46:10','2026-05-16 12:14:47'),
(270,'baotaydominoa250dencam-45','ja',45,'App\\Models\\Catalog\\Product','トミノ-a250-クリッフ-フラック',1,0,'2026-04-29 02:46:10','2026-05-16 12:14:47'),
(274,'tayconcrgracelinexam-46','vi',46,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(275,'tayconcrgracelinexam-46','ja',46,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(292,'mamkineobmwr9tscramblerdenvang-49','vi',49,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(293,'mamkineobmwr9tscramblerdenvang-49','ja',49,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(297,'ghidongimaducatipanigalev4titan-50','vi',50,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(298,'ghidongimaducatipanigalev4titan-50','ja',50,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(313,'phuocsaunitronr1hondawave125ixanh-55','vi',55,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(314,'phuocsaunitronr1hondawave125ixanh-55','ja',55,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(318,'pattangsentwmyamahar1202025den-56','vi',56,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(319,'pattangsentwmyamahar1202025den-56','ja',56,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(323,'bothangbremboheop2342pistonheatshield-57','vi',57,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(324,'bothangbremboheop2342pistonheatshield-57','ja',57,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 02:46:11','2026-04-29 02:46:11'),
(379,'do-choi-xe','vi',78,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:51:05','2026-04-29 02:51:05'),
(380,'car-toys','en',78,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:51:05','2026-04-29 02:51:05'),
(381,'車のおもちゃ','ja',78,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:51:05','2026-04-29 02:51:05'),
(382,'フレーキキャリハー','ja',51,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:58:02','2026-04-29 02:58:02'),
(383,'フレーキレハー','ja',54,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 02:58:38','2026-04-29 02:58:38'),
(384,'glove','en',56,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 03:00:33','2026-04-29 03:00:33'),
(385,'クローフ','ja',56,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 03:00:33','2026-04-29 03:00:33'),
(386,'san-pham-1','vi',23,'App\\Models\\Catalog\\Category','san-pham',1,0,'2026-04-29 03:13:44','2026-04-29 03:30:53'),
(387,'products','en',23,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 03:13:44','2026-04-29 03:13:44'),
(388,'製品','ja',23,'App\\Models\\Catalog\\Category','商品一覧',1,0,'2026-04-29 03:13:44','2026-05-08 07:50:05'),
(389,'san-pham','vi',23,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 03:30:53','2026-04-29 03:30:53'),
(390,'lam-dep-1','vi',15,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:07:09','2026-04-29 04:07:09'),
(391,'beautify','en',15,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:07:09','2026-04-29 04:07:09'),
(392,'美しくする','ja',15,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:07:09','2026-04-29 04:07:09'),
(393,'do-gia-dung-1','vi',4,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:07:45','2026-04-29 04:07:45'),
(394,'household-appliances-1','en',4,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:07:45','2026-04-29 04:07:45'),
(395,'家庭用電化製品','ja',4,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:07:45','2026-04-29 04:07:45'),
(396,'tin-tuc-1','vi',20,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:08:23','2026-04-29 04:08:23'),
(397,'news','en',20,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:08:23','2026-04-29 04:08:23'),
(398,'ニュース','ja',20,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:08:23','2026-04-29 04:08:23'),
(399,'lien-he-1','vi',21,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:09:02','2026-04-29 04:09:02'),
(400,'contact-us-1','en',21,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:09:02','2026-04-29 04:09:02'),
(401,'接触','ja',21,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:09:02','2026-04-29 04:09:02'),
(402,'gioi-thieu-1','vi',22,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:09:28','2026-04-29 04:09:28'),
(403,'about-us-1','en',22,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:09:28','2026-04-29 04:09:28'),
(404,'導入','ja',22,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:09:28','2026-04-29 04:09:28'),
(405,'mam-bst-rapid-tek-ducati-hypermotard-950-2019-23','vi',25,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-04-29 04:49:39','2026-04-29 04:49:39'),
(406,'mam-bst-rapid-tek-ducati-hypermotard-950-2019-23','en',25,'App\\Models\\Catalog\\Product','bst-rapid-tek-wheels-for-ducati-hypermotard-950-2019-23',1,0,'2026-04-29 04:49:39','2026-05-08 07:51:33'),
(407,'jp-mam-bst-rapid-tek-ducati-hypermotard-950-2019-23','ja',25,'App\\Models\\Catalog\\Product','bst-rapid-tek-ホイール-ducati-hypermotard-950-2019-23',1,0,'2026-04-29 04:49:39','2026-05-08 07:51:33'),
(408,'ban-ui-1','vi',13,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:50:54','2026-04-29 04:50:54'),
(409,'ironing-board','en',13,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:50:54','2026-04-29 04:50:54'),
(410,'アイロン台','ja',13,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:50:54','2026-04-29 04:50:54'),
(411,'ban-ui-hoi-nuoc-1','vi',19,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:51:36','2026-04-29 04:51:36'),
(412,'steam-iron-1','en',19,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:51:36','2026-04-29 04:51:36'),
(413,'スチームアイロン-1','ja',19,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:51:36','2026-04-29 04:51:36'),
(414,'chao-chong-dinh-1','vi',14,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:52:08','2026-04-29 04:52:08'),
(415,'non-stick-pan','en',14,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:52:08','2026-04-29 04:52:08'),
(416,'焦け付き防止ハン','ja',14,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-04-29 04:52:08','2026-04-29 04:52:08'),
(417,'charme-cool-water-perfume-1','en',7,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-05 08:15:58','2026-05-05 08:15:58'),
(418,'チャーム-クールウォーター-ハフューム-1','ja',7,'App\\Models\\Catalog\\Product','シャルム-クール-ウォーター-ハフューム',1,0,'2026-05-05 08:15:58','2026-05-08 06:39:20'),
(419,'homepage','vi',1,'App\\Models\\Page','trang-chu',1,0,'2026-05-06 08:10:55','2026-05-08 07:37:36'),
(420,'homepage','en',1,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:10:55','2026-05-06 08:29:47'),
(421,'homepage','ja',1,'App\\Models\\Page','ホームヘーシ',1,0,'2026-05-06 08:10:55','2026-05-08 07:37:36'),
(422,'trang-chủ','vi',1,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:20:37','2026-05-08 07:37:36'),
(423,'ホームページ','en',1,'App\\Models\\Page','homepage',1,0,'2026-05-06 08:20:37','2026-05-06 08:29:47'),
(424,'ホームページ','ja',1,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:29:47','2026-05-08 07:37:36'),
(425,'gioi-thieu-2','vi',2,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:33:35','2026-05-06 08:33:35'),
(426,'about-us-company','en',2,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:33:35','2026-05-06 08:33:35'),
(427,'私たちについて-会社概要','ja',2,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:33:35','2026-05-06 08:33:35'),
(428,'lien-he-2','vi',3,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:52:56','2026-05-06 08:52:56'),
(429,'contact-us-2','en',3,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:52:56','2026-05-06 08:52:56'),
(430,'お問い合わせ-1','ja',3,'App\\Models\\Page',NULL,1,1,'2026-05-06 08:52:56','2026-05-06 08:52:56'),
(431,'a-1','vi',1,'App\\Models\\Promotion\\PromotionCampaign','giam-gia-thang-5',1,0,'2026-05-07 07:47:08','2026-05-07 08:03:43'),
(432,'b-1','en',1,'App\\Models\\Promotion\\PromotionCampaign','may-sale',1,0,'2026-05-07 07:47:08','2026-05-07 08:03:43'),
(433,'c-1','ja',1,'App\\Models\\Promotion\\PromotionCampaign','5月のセール',1,0,'2026-05-07 07:47:08','2026-05-07 08:03:43'),
(434,'giam-gia-thang-5','vi',1,'App\\Models\\Promotion\\PromotionCampaign',NULL,1,1,'2026-05-07 08:03:43','2026-05-07 08:03:43'),
(435,'may-sale','en',1,'App\\Models\\Promotion\\PromotionCampaign',NULL,1,1,'2026-05-07 08:03:43','2026-05-07 08:03:43'),
(436,'5月のセール','ja',1,'App\\Models\\Promotion\\PromotionCampaign',NULL,1,1,'2026-05-07 08:03:43','2026-05-07 08:03:43'),
(437,'nhung-luu-y-can-phai-biet-truoc-khi-di-mua-lo-nuong-banh','vi',1,'App\\Models\\Catalog\\Post',NULL,1,1,'2026-05-08 06:10:03','2026-05-08 06:10:03'),
(438,'essential-tips-to-know-before-buying-a-baking-oven','en',1,'App\\Models\\Catalog\\Post',NULL,1,1,'2026-05-08 06:26:47','2026-05-08 06:26:47'),
(439,'製菓用オーフンを購入する前に知っておくへき注意点','ja',1,'App\\Models\\Catalog\\Post',NULL,1,1,'2026-05-08 06:26:47','2026-05-08 06:26:47'),
(440,'nuoc-hoa-charme-cool-water-1','vi',7,'App\\Models\\Catalog\\Product','nuoc-hoa-charme-cool-water-huong-thom-nam-tinh-100ml',1,0,'2026-05-08 06:39:20','2026-05-14 04:52:52'),
(441,'シャルム-クール-ウォーター-ハフューム','ja',7,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-08 06:39:20','2026-05-08 06:39:20'),
(442,'商品一覧','ja',23,'App\\Models\\Catalog\\Category',NULL,1,1,'2026-05-08 07:50:05','2026-05-08 07:50:05'),
(443,'accossato-fuel-cap-for-yamaha-fc124','en',22,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-08 07:50:44','2026-05-08 07:50:44'),
(444,'accossato-ヤマハ用-フューエルキャッフ-fc124','ja',22,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-08 07:50:44','2026-05-08 07:50:44'),
(445,'bst-rapid-tek-wheels-for-ducati-hypermotard-950-2019-23','en',25,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-08 07:51:33','2026-05-08 07:51:33'),
(446,'bst-rapid-tek-ホイール-ducati-hypermotard-950-2019-23','ja',25,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-08 07:51:33','2026-05-08 07:51:33'),
(447,'nuoc-hoa-charme-cool-water-huong-thom-nam-tinh-100ml','vi',7,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-14 04:52:52','2026-05-14 04:52:52'),
(448,'grip-domino-a250-den','vi',45,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-16 12:14:47','2026-05-16 12:14:47'),
(449,'domino-a250-grips-black','en',45,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-16 12:14:47','2026-05-16 12:14:47'),
(450,'トミノ-a250-クリッフ-フラック','ja',45,'App\\Models\\Catalog\\Product',NULL,1,1,'2026-05-16 12:14:47','2026-05-16 12:14:47');
/*!40000 ALTER TABLE `slugs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(535) DEFAULT NULL,
  `owner` tinyint(1) NOT NULL DEFAULT 0,
  `photo` varchar(100) DEFAULT NULL,
  `group` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_account_id_index` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,1,'Lê','Hân','lehan100@gmail.com','2026-03-04 02:28:32','$2y$12$a.y1Wq9gDTIJEAaHX8W7zOjR/2wbZIV8ERFU1g2MSfgfF0wVAfpPi',1,NULL,1,1,'nHYO3DzFRlLoVe1D7NofbkTx664ko1gNaOlRQ9pLbmvcJNDmgw4JFj5tzyQ8','2026-03-04 02:28:32','2026-05-07 06:31:21',NULL),
(2,1,'Le','Han','api@gmail.com','2026-03-04 02:28:32','$2y$12$.6We1lX84vgIvYlzO9xafOnuoK0J5pFDYwXjikdIdgEqLfOqbzkty',0,NULL,4,1,'BjDsH1qMK5','2026-03-04 02:28:32','2026-03-15 06:38:07',NULL),
(3,1,'Felipe','Koelpin','kozey.cassidy@example.net','2026-03-04 02:28:32','$2y$12$oarnmGtSpmx2rU.b/soVyOs1TcOyKzUoLa46AJGGsOVlS8KcsAumC',0,NULL,0,0,'20MnftWzjU','2026-03-04 02:28:32','2026-03-04 02:28:32',NULL),
(4,1,'Durward','Goodwin','vhauck@example.org','2026-03-04 02:28:32','$2y$12$oarnmGtSpmx2rU.b/soVyOs1TcOyKzUoLa46AJGGsOVlS8KcsAumC',0,NULL,0,0,'ldYBKU8ugQ','2026-03-04 02:28:32','2026-03-04 02:28:32',NULL),
(5,1,'Mary','Aufderhar','wilfrid.corwin@example.com','2026-03-04 02:28:32','$2y$12$oarnmGtSpmx2rU.b/soVyOs1TcOyKzUoLa46AJGGsOVlS8KcsAumC',0,NULL,0,0,'1gQBCGiwex','2026-03-04 02:28:32','2026-03-04 02:28:32',NULL),
(6,1,'Braulio','Braun','haag.henderson@example.net','2026-03-04 02:28:32','$2y$12$oarnmGtSpmx2rU.b/soVyOs1TcOyKzUoLa46AJGGsOVlS8KcsAumC',0,NULL,0,0,'xd912WNSn0','2026-03-04 02:28:32','2026-03-04 02:28:32',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `variant_attribute_values`
--

DROP TABLE IF EXISTS `variant_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `variant_attribute_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_variant_id` bigint(20) unsigned NOT NULL,
  `attribute_value_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `variant_attribute_value_unique` (`product_variant_id`,`attribute_value_id`),
  KEY `variant_attribute_values_attribute_value_id_foreign` (`attribute_value_id`),
  CONSTRAINT `variant_attribute_values_attribute_value_id_foreign` FOREIGN KEY (`attribute_value_id`) REFERENCES `attribute_values` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variant_attribute_values_product_variant_id_foreign` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variant_attribute_values`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `variant_attribute_values` WRITE;
/*!40000 ALTER TABLE `variant_attribute_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `variant_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `variant_translations`
--

DROP TABLE IF EXISTS `variant_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `variant_translations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `product_variant_id` bigint(20) unsigned NOT NULL,
  `locale` varchar(10) NOT NULL,
  `name` varchar(535) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `variant_translations_product_variant_id_locale_unique` (`product_variant_id`,`locale`),
  CONSTRAINT `variant_translations_product_variant_id_foreign` FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variant_translations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `variant_translations` WRITE;
/*!40000 ALTER TABLE `variant_translations` DISABLE KEYS */;
INSERT INTO `variant_translations` VALUES
(1,1,'vi','Xanh dương','2026-05-05 03:33:29','2026-05-05 08:13:56'),
(2,1,'en','Blue','2026-05-05 03:33:29','2026-05-05 03:33:29'),
(3,1,'ja','ブルー','2026-05-05 03:33:29','2026-05-12 07:17:58'),
(4,2,'vi','Màu tím','2026-05-11 07:18:14','2026-05-11 07:18:14'),
(5,2,'en','Purple','2026-05-11 07:18:14','2026-05-11 07:18:14'),
(6,2,'ja','紫','2026-05-11 07:18:14','2026-05-11 07:18:14');
/*!40000 ALTER TABLE `variant_translations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `wards`
--

DROP TABLE IF EXISTS `wards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wards` (
  `code` varchar(20) NOT NULL,
  `name` varchar(535) NOT NULL,
  `name_en` varchar(535) DEFAULT NULL,
  `full_name` varchar(535) DEFAULT NULL,
  `full_name_en` varchar(535) DEFAULT NULL,
  `code_name` varchar(535) DEFAULT NULL,
  `province_code` varchar(20) DEFAULT NULL,
  `administrative_unit_id` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`code`),
  KEY `idx_wards_province` (`province_code`),
  KEY `idx_wards_unit` (`administrative_unit_id`),
  CONSTRAINT `wards_administrative_unit_id_foreign` FOREIGN KEY (`administrative_unit_id`) REFERENCES `administrative_units` (`id`) ON DELETE SET NULL,
  CONSTRAINT `wards_province_code_foreign` FOREIGN KEY (`province_code`) REFERENCES `provinces` (`code`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `wards` WRITE;
/*!40000 ALTER TABLE `wards` DISABLE KEYS */;
INSERT INTO `wards` VALUES
('00004','Ba Đình','Ba Dinh','Phường Ba Đình','Ba Dinh Ward','ba_dinh','01',3),
('00008','Ngọc Hà','Ngoc Ha','Phường Ngọc Hà','Ngoc Ha Ward','ngoc_ha','01',3),
('00025','Giảng Võ','Giang Vo','Phường Giảng Võ','Giang Vo Ward','giang_vo','01',3),
('00070','Hoàn Kiếm','Hoan Kiem','Phường Hoàn Kiếm','Hoan Kiem Ward','hoan_kiem','01',3),
('00082','Cửa Nam','Cua Nam','Phường Cửa Nam','Cua Nam Ward','cua_nam','01',3),
('00091','Phú Thượng','Phu Thuong','Phường Phú Thượng','Phu Thuong Ward','phu_thuong','01',3),
('00097','Hồng Hà','Hong Ha','Phường Hồng Hà','Hong Ha Ward','hong_ha','01',3),
('00103','Tây Hồ','Tay Ho','Phường Tây Hồ','Tay Ho Ward','tay_ho','01',3),
('00118','Bồ Đề','Bo De','Phường Bồ Đề','Bo De Ward','bo_de','01',3),
('00127','Việt Hưng','Viet Hung','Phường Việt Hưng','Viet Hung Ward','viet_hung','01',3),
('00136','Phúc Lợi','Phuc Loi','Phường Phúc Lợi','Phuc Loi Ward','phuc_loi','01',3),
('00145','Long Biên','Long Bien','Phường Long Biên','Long Bien Ward','long_bien','01',3),
('00160','Nghĩa Đô','Nghia Do','Phường Nghĩa Đô','Nghia Do Ward','nghia_do','01',3),
('00166','Cầu Giấy','Cau Giay','Phường Cầu Giấy','Cau Giay Ward','cau_giay','01',3),
('00175','Yên Hòa','Yen Hoa','Phường Yên Hòa','Yen Hoa Ward','yen_hoa','01',3),
('00190','Ô Chợ Dừa','O Cho Dua','Phường Ô Chợ Dừa','O Cho Dua Ward','o_cho_dua','01',3),
('00199','Láng','Lang','Phường Láng','Lang Ward','lang','01',3),
('00226','Văn Miếu - Quốc Tử Giám','Van Mieu - Quoc Tu Giam','Phường Văn Miếu - Quốc Tử Giám','Van Mieu - Quoc Tu Giam Ward','van_mieu_quoc_tu_giam','01',3),
('00229','Kim Liên','Kim Lien','Phường Kim Liên','Kim Lien Ward','kim_lien','01',3),
('00235','Đống Đa','Dong Da','Phường Đống Đa','Dong Da Ward','dong_da','01',3),
('00256','Hai Bà Trưng','Hai Ba Trung','Phường Hai Bà Trưng','Hai Ba Trung Ward','hai_ba_trung','01',3),
('00283','Vĩnh Tuy','Vinh Tuy','Phường Vĩnh Tuy','Vinh Tuy Ward','vinh_tuy','01',3),
('00292','Bạch Mai','Bach Mai','Phường Bạch Mai','Bach Mai Ward','bach_mai','01',3),
('00301','Vĩnh Hưng','Vinh Hung','Phường Vĩnh Hưng','Vinh Hung Ward','vinh_hung','01',3),
('00316','Định Công','Dinh Cong','Phường Định Công','Dinh Cong Ward','dinh_cong','01',3),
('00322','Tương Mai','Tuong Mai','Phường Tương Mai','Tuong Mai Ward','tuong_mai','01',3),
('00328','Lĩnh Nam','Linh Nam','Phường Lĩnh Nam','Linh Nam Ward','linh_nam','01',3),
('00331','Hoàng Mai','Hoang Mai','Phường Hoàng Mai','Hoang Mai Ward','hoang_mai','01',3),
('00337','Hoàng Liệt','Hoang Liet','Phường Hoàng Liệt','Hoang Liet Ward','hoang_liet','01',3),
('00340','Yên Sở','Yen So','Phường Yên Sở','Yen So Ward','yen_so','01',3),
('00352','Phương Liệt','Phuong Liet','Phường Phương Liệt','Phuong Liet Ward','phuong_liet','01',3),
('00364','Khương Đình','Khuong Dinh','Phường Khương Đình','Khuong Dinh Ward','khuong_dinh','01',3),
('00367','Thanh Xuân','Thanh Xuan','Phường Thanh Xuân','Thanh Xuan Ward','thanh_xuan','01',3),
('00376','Sóc Sơn','Soc Son','Xã Sóc Sơn','Soc Son Commune','soc_son','01',4),
('00382','Kim Anh','Kim Anh','Xã Kim Anh','Kim Anh Commune','kim_anh','01',4),
('00385','Trung Giã','Trung Gia','Xã Trung Giã','Trung Gia Commune','trung_gia','01',4),
('00430','Đa Phúc','Da Phuc','Xã Đa Phúc','Da Phuc Commune','da_phuc','01',4),
('00433','Nội Bài','Noi Bai','Xã Nội Bài','Noi Bai Commune','noi_bai','01',4),
('00454','Đông Anh','Dong Anh','Xã Đông Anh','Dong Anh Commune','dong_anh','01',4),
('00466','Phúc Thịnh','Phuc Thinh','Xã Phúc Thịnh','Phuc Thinh Commune','phuc_thinh','01',4),
('00475','Thư Lâm','Thu Lam','Xã Thư Lâm','Thu Lam Commune','thu_lam','01',4),
('00493','Thiên Lộc','Thien Loc','Xã Thiên Lộc','Thien Loc Commune','thien_loc','01',4),
('00508','Vĩnh Thanh','Vinh Thanh','Xã Vĩnh Thanh','Vinh Thanh Commune','vinh_thanh','01',4),
('00541','Phù Đổng','Phu Dong','Xã Phù Đổng','Phu Dong Commune','phu_dong','01',4),
('00562','Thuận An','Thuan An','Xã Thuận An','Thuan An Commune','thuan_an','01',4),
('00565','Gia Lâm','Gia Lam','Xã Gia Lâm','Gia Lam Commune','gia_lam','01',4),
('00577','Bát Tràng','Bat Trang','Xã Bát Tràng','Bat Trang Commune','bat_trang','01',4),
('00592','Từ Liêm','Tu Liem','Phường Từ Liêm','Tu Liem Ward','tu_liem','01',3),
('00598','Thượng Cát','Thuong Cat','Phường Thượng Cát','Thuong Cat Ward','thuong_cat','01',3),
('00602','Đông Ngạc','Dong Ngac','Phường Đông Ngạc','Dong Ngac Ward','dong_ngac','01',3),
('00611','Xuân Đỉnh','Xuan Dinh','Phường Xuân Đỉnh','Xuan Dinh Ward','xuan_dinh','01',3),
('00613','Tây Tựu','Tay Tuu','Phường Tây Tựu','Tay Tuu Ward','tay_tuu','01',3),
('00619','Phú Diễn','Phu Dien','Phường Phú Diễn','Phu Dien Ward','phu_dien','01',3),
('00622','Xuân Phương','Xuan Phuong','Phường Xuân Phương','Xuan Phuong Ward','xuan_phuong','01',3),
('00634','Tây Mỗ','Tay Mo','Phường Tây Mỗ','Tay Mo Ward','tay_mo','01',3),
('00637','Đại Mỗ','Dai Mo','Phường Đại Mỗ','Dai Mo Ward','dai_mo','01',3),
('00640','Thanh Trì','Thanh Tri','Xã Thanh Trì','Thanh Tri Commune','thanh_tri','01',4),
('00643','Thanh Liệt','Thanh Liet','Phường Thanh Liệt','Thanh Liet Ward','thanh_liet','01',3),
('00664','Đại Thanh','Dai Thanh','Xã Đại Thanh','Dai Thanh Commune','dai_thanh','01',4),
('00679','Ngọc Hồi','Ngoc Hoi','Xã Ngọc Hồi','Ngoc Hoi Commune','ngoc_hoi','01',4),
('00685','Nam Phù','Nam Phu','Xã Nam Phù','Nam Phu Commune','nam_phu','01',4),
('00691','Hà Giang 2','Ha Giang 2','Phường Hà Giang 2','Ha Giang 2 Ward','ha_giang_2','08',3),
('00694','Hà Giang 1','Ha Giang 1','Phường Hà Giang 1','Ha Giang 1 Ward','ha_giang_1','08',3),
('00700','Ngọc Đường','Ngoc Duong','Xã Ngọc Đường','Ngoc Duong Commune','ngoc_duong','08',4),
('00706','Phú Linh','Phu Linh','Xã Phú Linh','Phu Linh Commune','phu_linh','08',4),
('00715','Lũng Cú','Lung Cu','Xã Lũng Cú','Lung Cu Commune','lung_cu','08',4),
('00721','Đồng Văn','Dong Van','Xã Đồng Văn','Dong Van Commune','dong_van','08',4),
('00733','Sà Phìn','Sa Phin','Xã Sà Phìn','Sa Phin Commune','sa_phin','08',4),
('00745','Phó Bảng','Pho Bang','Xã Phó Bảng','Pho Bang Commune','pho_bang','08',4),
('00763','Lũng Phìn','Lung Phin','Xã Lũng Phìn','Lung Phin Commune','lung_phin','08',4),
('00769','Mèo Vạc','Meo Vac','Xã Mèo Vạc','Meo Vac Commune','meo_vac','08',4),
('00778','Sơn Vĩ','Son Vi','Xã Sơn Vĩ','Son Vi Commune','son_vi','08',4),
('00787','Sủng Máng','Sung Mang','Xã Sủng Máng','Sung Mang Commune','sung_mang','08',4),
('00802','Khâu Vai','Khau Vai','Xã Khâu Vai','Khau Vai Commune','khau_vai','08',4),
('00808','Tát Ngà','Tat Nga','Xã Tát Ngà','Tat Nga Commune','tat_nga','08',4),
('00817','Niêm Sơn','Niem Son','Xã Niêm Sơn','Niem Son Commune','niem_son','08',4),
('00820','Yên Minh','Yen Minh','Xã Yên Minh','Yen Minh Commune','yen_minh','08',4),
('00829','Thắng Mố','Thang Mo','Xã Thắng Mố','Thang Mo Commune','thang_mo','08',4),
('00832','Bạch Đích','Bach Dich','Xã Bạch Đích','Bach Dich Commune','bach_dich','08',4),
('00847','Mậu Duệ','Mau Due','Xã Mậu Duệ','Mau Due Commune','mau_due','08',4),
('00859','Ngọc Long','Ngoc Long','Xã Ngọc Long','Ngoc Long Commune','ngoc_long','08',4),
('00865','Đường Thượng','Duong Thuong','Xã Đường Thượng','Duong Thuong Commune','duong_thuong','08',4),
('00871','Du Già','Du Gia','Xã Du Già','Du Gia Commune','du_gia','08',4),
('00874','Quản Bạ','Quan Ba','Xã Quản Bạ','Quan Ba Commune','quan_ba','08',4),
('00883','Cán Tỷ','Can Ty','Xã Cán Tỷ','Can Ty Commune','can_ty','08',4),
('00889','Nghĩa Thuận','Nghia Thuan','Xã Nghĩa Thuận','Nghia Thuan Commune','nghia_thuan','08',4),
('00892','Tùng Vài','Tung Vai','Xã Tùng Vài','Tung Vai Commune','tung_vai','08',4),
('00901','Lùng Tám','Lung Tam','Xã Lùng Tám','Lung Tam Commune','lung_tam','08',4),
('00913','Vị Xuyên','Vi Xuyen','Xã Vị Xuyên','Vi Xuyen Commune','vi_xuyen','08',4),
('00919','Minh Tân','Minh Tan','Xã Minh Tân','Minh Tan Commune','minh_tan','08',4),
('00922','Thuận Hòa','Thuan Hoa','Xã Thuận Hòa','Thuan Hoa Commune','thuan_hoa','08',4),
('00925','Tùng Bá','Tung Ba','Xã Tùng Bá','Tung Ba Commune','tung_ba','08',4),
('00928','Thanh Thủy','Thanh Thuy','Xã Thanh Thủy','Thanh Thuy Commune','thanh_thuy','08',4),
('00937','Lao Chải','Lao Chai','Xã Lao Chải','Lao Chai Commune','lao_chai','08',4),
('00952','Cao Bồ','Cao Bo','Xã Cao Bồ','Cao Bo Commune','cao_bo','08',4),
('00958','Thượng Sơn','Thuong Son','Xã Thượng Sơn','Thuong Son Commune','thuong_son','08',4),
('00967','Việt Lâm','Viet Lam','Xã Việt Lâm','Viet Lam Commune','viet_lam','08',4),
('00970','Linh Hồ','Linh Ho','Xã Linh Hồ','Linh Ho Commune','linh_ho','08',4),
('00976','Bạch Ngọc','Bach Ngoc','Xã Bạch Ngọc','Bach Ngoc Commune','bach_ngoc','08',4),
('00982','Minh Sơn','Minh Son','Xã Minh Sơn','Minh Son Commune','minh_son','08',4),
('00985','Giáp Trung','Giap Trung','Xã Giáp Trung','Giap Trung Commune','giap_trung','08',4),
('00991','Bắc Mê','Bac Me','Xã Bắc Mê','Bac Me Commune','bac_me','08',4),
('00994','Minh Ngọc','Minh Ngoc','Xã Minh Ngọc','Minh Ngoc Commune','minh_ngoc','08',4),
('01006','Yên Cường','Yen Cuong','Xã Yên Cường','Yen Cuong Commune','yen_cuong','08',4),
('01012','Đường Hồng','Duong Hong','Xã Đường Hồng','Duong Hong Commune','duong_hong','08',4),
('01021','Hoàng Su Phì','Hoang Su Phi','Xã Hoàng Su Phì','Hoang Su Phi Commune','hoang_su_phi','08',4),
('01024','Bản Máy','Ban May','Xã Bản Máy','Ban May Commune','ban_may','08',4),
('01033','Thàng Tín','Thang Tin','Xã Thàng Tín','Thang Tin Commune','thang_tin','08',4),
('01051','Tân Tiến','Tan Tien','Xã Tân Tiến','Tan Tien Commune','tan_tien','08',4),
('01057','Pờ Ly Ngài','Po Ly Ngai','Xã Pờ Ly Ngài','Po Ly Ngai Commune','po_ly_ngai','08',4),
('01075','Nậm Dịch','Nam Dich','Xã Nậm Dịch','Nam Dich Commune','nam_dich','08',4),
('01084','Hồ Thầu','Ho Thau','Xã Hồ Thầu','Ho Thau Commune','ho_thau','08',4),
('01090','Thông Nguyên','Thong Nguyen','Xã Thông Nguyên','Thong Nguyen Commune','thong_nguyen','08',4),
('01096','Pà Vầy Sủ','Pa Vay Su','Xã Pà Vầy Sủ','Pa Vay Su Commune','pa_vay_su','08',4),
('01108','Xín Mần','Xin Man','Xã Xín Mần','Xin Man Commune','xin_man','08',4),
('01117','Trung Thịnh','Trung Thinh','Xã Trung Thịnh','Trung Thinh Commune','trung_thinh','08',4),
('01141','Nấm Dẩn','Nam Dan','Xã Nấm Dẩn','Nam Dan Commune','nam_dan','08',4),
('01144','Quảng Nguyên','Quang Nguyen','Xã Quảng Nguyên','Quang Nguyen Commune','quang_nguyen','08',4),
('01147','Khuôn Lùng','Khuon Lung','Xã Khuôn Lùng','Khuon Lung Commune','khuon_lung','08',4),
('01153','Bắc Quang','Bac Quang','Xã Bắc Quang','Bac Quang Commune','bac_quang','08',4),
('01156','Vĩnh Tuy','Vinh Tuy','Xã Vĩnh Tuy','Vinh Tuy Commune','vinh_tuy','08',4),
('01165','Đồng Tâm','Dong Tam','Xã Đồng Tâm','Dong Tam Commune','dong_tam','08',4),
('01171','Tân Quang','Tan Quang','Xã Tân Quang','Tan Quang Commune','tan_quang','08',4),
('01180','Bằng Hành','Bang Hanh','Xã Bằng Hành','Bang Hanh Commune','bang_hanh','08',4),
('01192','Liên Hiệp','Lien Hiep','Xã Liên Hiệp','Lien Hiep Commune','lien_hiep','08',4),
('01201','Hùng An','Hung An','Xã Hùng An','Hung An Commune','hung_an','08',4),
('01216','Đồng Yên','Dong Yen','Xã Đồng Yên','Dong Yen Commune','dong_yen','08',4),
('01225','Tiên Nguyên','Tien Nguyen','Xã Tiên Nguyên','Tien Nguyen Commune','tien_nguyen','08',4),
('01234','Yên Thành','Yen Thanh','Xã Yên Thành','Yen Thanh Commune','yen_thanh','08',4),
('01237','Quang Bình','Quang Binh','Xã Quang Bình','Quang Binh Commune','quang_binh','08',4),
('01243','Tân Trịnh','Tan Trinh','Xã Tân Trịnh','Tan Trinh Commune','tan_trinh','08',4),
('01246','Bằng Lang','Bang Lang','Xã Bằng Lang','Bang Lang Commune','bang_lang','08',4),
('01255','Xuân Giang','Xuan Giang','Xã Xuân Giang','Xuan Giang Commune','xuan_giang','08',4),
('01261','Tiên Yên','Tien Yen','Xã Tiên Yên','Tien Yen Commune','tien_yen','08',4),
('01273','Thục Phán','Thuc Phan','Phường Thục Phán','Thuc Phan Ward','thuc_phan','04',3),
('01279','Nùng Trí Cao','Nung Tri Cao','Phường Nùng Trí Cao','Nung Tri Cao Ward','nung_tri_cao','04',3),
('01288','Tân Giang','Tan Giang','Phường Tân Giang','Tan Giang Ward','tan_giang','04',3),
('01290','Bảo Lâm','Bao Lam','Xã Bảo Lâm','Bao Lam Commune','bao_lam','04',4),
('01294','Lý Bôn','Ly Bon','Xã Lý Bôn','Ly Bon Commune','ly_bon','04',4),
('01297','Nam Quang','Nam Quang','Xã Nam Quang','Nam Quang Commune','nam_quang','04',4),
('01304','Quảng Lâm','Quang Lam','Xã Quảng Lâm','Quang Lam Commune','quang_lam','04',4),
('01318','Yên Thổ','Yen Tho','Xã Yên Thổ','Yen Tho Commune','yen_tho','04',4),
('01321','Bảo Lạc','Bao Lac','Xã Bảo Lạc','Bao Lac Commune','bao_lac','04',4),
('01324','Cốc Pàng','Coc Pang','Xã Cốc Pàng','Coc Pang Commune','coc_pang','04',4),
('01327','Cô Ba','Co Ba','Xã Cô Ba','Co Ba Commune','co_ba','04',4),
('01336','Khánh Xuân','Khanh Xuan','Xã Khánh Xuân','Khanh Xuan Commune','khanh_xuan','04',4),
('01339','Xuân Trường','Xuan Truong','Xã Xuân Trường','Xuan Truong Commune','xuan_truong','04',4),
('01351','Hưng Đạo','Hung Dao','Xã Hưng Đạo','Hung Dao Commune','hung_dao','04',4),
('01354','Huy Giáp','Huy Giap','Xã Huy Giáp','Huy Giap Commune','huy_giap','04',4),
('01360','Sơn Lộ','Son Lo','Xã Sơn Lộ','Son Lo Commune','son_lo','04',4),
('01363','Thông Nông','Thong Nong','Xã Thông Nông','Thong Nong Commune','thong_nong','04',4),
('01366','Cần Yên','Can Yen','Xã Cần Yên','Can Yen Commune','can_yen','04',4),
('01387','Thanh Long','Thanh Long','Xã Thanh Long','Thanh Long Commune','thanh_long','04',4),
('01392','Trường Hà','Truong Ha','Xã Trường Hà','Truong Ha Commune','truong_ha','04',4),
('01393','Lũng Nặm','Lung Nam','Xã Lũng Nặm','Lung Nam Commune','lung_nam','04',4),
('01414','Tổng Cọt','Tong Cot','Xã Tổng Cọt','Tong Cot Commune','tong_cot','04',4),
('01438','Hà Quảng','Ha Quang','Xã Hà Quảng','Ha Quang Commune','ha_quang','04',4),
('01447','Trà Lĩnh','Tra Linh','Xã Trà Lĩnh','Tra Linh Commune','tra_linh','04',4),
('01456','Quang Hán','Quang Han','Xã Quang Hán','Quang Han Commune','quang_han','04',4),
('01465','Quang Trung','Quang Trung','Xã Quang Trung','Quang Trung Commune','quang_trung','04',4),
('01477','Trùng Khánh','Trung Khanh','Xã Trùng Khánh','Trung Khanh Commune','trung_khanh','04',4),
('01489','Đình Phong','Dinh Phong','Xã Đình Phong','Dinh Phong Commune','dinh_phong','04',4),
('01501','Đàm Thủy','Dam Thuy','Xã Đàm Thủy','Dam Thuy Commune','dam_thuy','04',4),
('01525','Đoài Dương','Doai Duong','Xã Đoài Dương','Doai Duong Commune','doai_duong','04',4),
('01537','Lý Quốc','Ly Quoc','Xã Lý Quốc','Ly Quoc Commune','ly_quoc','04',4),
('01552','Quang Long','Quang Long','Xã Quang Long','Quang Long Commune','quang_long','04',4),
('01558','Hạ Lang','Ha Lang','Xã Hạ Lang','Ha Lang Commune','ha_lang','04',4),
('01561','Vinh Quý','Vinh Quy','Xã Vinh Quý','Vinh Quy Commune','vinh_quy','04',4),
('01576','Quảng Uyên','Quang Uyen','Xã Quảng Uyên','Quang Uyen Commune','quang_uyen','04',4),
('01594','Độc Lập','Doc Lap','Xã Độc Lập','Doc Lap Commune','doc_lap','04',4),
('01618','Hạnh Phúc','Hanh Phuc','Xã Hạnh Phúc','Hanh Phuc Commune','hanh_phuc','04',4),
('01636','Bế Văn Đàn','Be Van Dan','Xã Bế Văn Đàn','Be Van Dan Commune','be_van_dan','04',4),
('01648','Phục Hòa','Phuc Hoa','Xã Phục Hòa','Phuc Hoa Commune','phuc_hoa','04',4),
('01654','Hòa An','Hoa An','Xã Hòa An','Hoa An Commune','hoa_an','04',4),
('01660','Nam Tuấn','Nam Tuan','Xã Nam Tuấn','Nam Tuan Commune','nam_tuan','04',4),
('01699','Nguyễn Huệ','Nguyen Hue','Xã Nguyễn Huệ','Nguyen Hue Commune','nguyen_hue','04',4),
('01708','Bạch Đằng','Bach Dang','Xã Bạch Đằng','Bach Dang Commune','bach_dang','04',4),
('01726','Nguyên Bình','Nguyen Binh','Xã Nguyên Bình','Nguyen Binh Commune','nguyen_binh','04',4),
('01729','Tĩnh Túc','Tinh Tuc','Xã Tĩnh Túc','Tinh Tuc Commune','tinh_tuc','04',4),
('01738','Ca Thành','Ca Thanh','Xã Ca Thành','Ca Thanh Commune','ca_thanh','04',4),
('01747','Minh Tâm','Minh Tam','Xã Minh Tâm','Minh Tam Commune','minh_tam','04',4),
('01768','Phan Thanh','Phan Thanh','Xã Phan Thanh','Phan Thanh Commune','phan_thanh','04',4),
('01774','Tam Kim','Tam Kim','Xã Tam Kim','Tam Kim Commune','tam_kim','04',4),
('01777','Thành Công','Thanh Cong','Xã Thành Công','Thanh Cong Commune','thanh_cong','04',4),
('01786','Đông Khê','Dong Khe','Xã Đông Khê','Dong Khe Commune','dong_khe','04',4),
('01789','Canh Tân','Canh Tan','Xã Canh Tân','Canh Tan Commune','canh_tan','04',4),
('01792','Kim Đồng','Kim Dong','Xã Kim Đồng','Kim Dong Commune','kim_dong','04',4),
('01795','Minh Khai','Minh Khai','Xã Minh Khai','Minh Khai Commune','minh_khai','04',4),
('01807','Thạch An','Thach An','Xã Thạch An','Thach An Commune','thach_an','04',4),
('01822','Đức Long','Duc Long','Xã Đức Long','Duc Long Commune','duc_long','04',4),
('01840','Đức Xuân','Duc Xuan','Phường Đức Xuân','Duc Xuan Ward','duc_xuan','19',3),
('01843','Bắc Kạn','Bac Kan','Phường Bắc Kạn','Bac Kan Ward','bac_kan','19',3),
('01849','Phong Quang','Phong Quang','Xã Phong Quang','Phong Quang Commune','phong_quang','19',4),
('01864','Bằng Thành','Bang Thanh','Xã Bằng Thành','Bang Thanh Commune','bang_thanh','19',4),
('01879','Cao Minh','Cao Minh','Xã Cao Minh','Cao Minh Commune','cao_minh','19',4),
('01882','Nghiên Loan','Nghien Loan','Xã Nghiên Loan','Nghien Loan Commune','nghien_loan','19',4),
('01894','Phúc Lộc','Phuc Loc','Xã Phúc Lộc','Phuc Loc Commune','phuc_loc','19',4),
('01906','Ba Bể','Ba Be','Xã Ba Bể','Ba Be Commune','ba_be','19',4),
('01912','Chợ Rã','Cho Ra','Xã Chợ Rã','Cho Ra Commune','cho_ra','19',4),
('01921','Thượng Minh','Thuong Minh','Xã Thượng Minh','Thuong Minh Commune','thuong_minh','19',4),
('01933','Đồng Phúc','Dong Phuc','Xã Đồng Phúc','Dong Phuc Commune','dong_phuc','19',4),
('01936','Nà Phặc','Na Phac','Xã Nà Phặc','Na Phac Commune','na_phac','19',4),
('01942','Bằng Vân','Bang Van','Xã Bằng Vân','Bang Van Commune','bang_van','19',4),
('01954','Ngân Sơn','Ngan Son','Xã Ngân Sơn','Ngan Son Commune','ngan_son','19',4),
('01957','Thượng Quan','Thuong Quan','Xã Thượng Quan','Thuong Quan Commune','thuong_quan','19',4),
('01960','Hiệp Lực','Hiep Luc','Xã Hiệp Lực','Hiep Luc Commune','hiep_luc','19',4),
('01969','Phủ Thông','Phu Thong','Xã Phủ Thông','Phu Thong Commune','phu_thong','19',4),
('01981','Vĩnh Thông','Vinh Thong','Xã Vĩnh Thông','Vinh Thong Commune','vinh_thong','19',4),
('02008','Cẩm Giàng','Cam Giang','Xã Cẩm Giàng','Cam Giang Commune','cam_giang','19',4),
('02014','Bạch Thông','Bach Thong','Xã Bạch Thông','Bach Thong Commune','bach_thong','19',4),
('02020','Chợ Đồn','Cho Don','Xã Chợ Đồn','Cho Don Commune','cho_don','19',4),
('02026','Nam Cường','Nam Cuong','Xã Nam Cường','Nam Cuong Commune','nam_cuong','19',4),
('02038','Quảng Bạch','Quang Bach','Xã Quảng Bạch','Quang Bach Commune','quang_bach','19',4),
('02044','Yên Thịnh','Yen Thinh','Xã Yên Thịnh','Yen Thinh Commune','yen_thinh','19',4),
('02071','Nghĩa Tá','Nghia Ta','Xã Nghĩa Tá','Nghia Ta Commune','nghia_ta','19',4),
('02083','Yên Phong','Yen Phong','Xã Yên Phong','Yen Phong Commune','yen_phong','19',4),
('02086','Chợ Mới','Cho Moi','Xã Chợ Mới','Cho Moi Commune','cho_moi','19',4),
('02101','Thanh Mai','Thanh Mai','Xã Thanh Mai','Thanh Mai Commune','thanh_mai','19',4),
('02104','Tân Kỳ','Tan Ky','Xã Tân Kỳ','Tan Ky Commune','tan_ky','19',4),
('02107','Thanh Thịnh','Thanh Thinh','Xã Thanh Thịnh','Thanh Thinh Commune','thanh_thinh','19',4),
('02116','Yên Bình','Yen Binh','Xã Yên Bình','Yen Binh Commune','yen_binh','19',4),
('02143','Văn Lang','Van Lang','Xã Văn Lang','Van Lang Commune','van_lang','19',4),
('02152','Cường Lợi','Cuong Loi','Xã Cường Lợi','Cuong Loi Commune','cuong_loi','19',4),
('02155','Na Rì','Na Ri','Xã Na Rì','Na Ri Commune','na_ri','19',4),
('02176','Trần Phú','Tran Phu','Xã Trần Phú','Tran Phu Commune','tran_phu','19',4),
('02185','Côn Minh','Con Minh','Xã Côn Minh','Con Minh Commune','con_minh','19',4),
('02191','Xuân Dương','Xuan Duong','Xã Xuân Dương','Xuan Duong Commune','xuan_duong','19',4),
('02212','Nông Tiến','Nong Tien','Phường Nông Tiến','Nong Tien Ward','nong_tien','08',3),
('02215','Minh Xuân','Minh Xuan','Phường Minh Xuân','Minh Xuan Ward','minh_xuan','08',3),
('02221','Nà Hang','Na Hang','Xã Nà Hang','Na Hang Commune','na_hang','08',4),
('02239','Thượng Nông','Thuong Nong','Xã Thượng Nông','Thuong Nong Commune','thuong_nong','08',4),
('02245','Côn Lôn','Con Lon','Xã Côn Lôn','Con Lon Commune','con_lon','08',4),
('02248','Yên Hoa','Yen Hoa','Xã Yên Hoa','Yen Hoa Commune','yen_hoa','08',4),
('02260','Hồng Thái','Hong Thai','Xã Hồng Thái','Hong Thai Commune','hong_thai','08',4),
('02266','Lâm Bình','Lam Binh','Xã Lâm Bình','Lam Binh Commune','lam_binh','08',4),
('02269','Thượng Lâm','Thuong Lam','Xã Thượng Lâm','Thuong Lam Commune','thuong_lam','08',4),
('02287','Chiêm Hóa','Chiem Hoa','Xã Chiêm Hóa','Chiem Hoa Commune','chiem_hoa','08',4),
('02296','Bình An','Binh An','Xã Bình An','Binh An Commune','binh_an','08',4),
('02302','Minh Quang','Minh Quang','Xã Minh Quang','Minh Quang Commune','minh_quang','08',4),
('02305','Trung Hà','Trung Ha','Xã Trung Hà','Trung Ha Commune','trung_ha','08',4),
('02308','Tân Mỹ','Tan My','Xã Tân Mỹ','Tan My Commune','tan_my','08',4),
('02317','Yên Lập','Yen Lap','Xã Yên Lập','Yen Lap Commune','yen_lap','08',4),
('02320','Tân An','Tan An','Xã Tân An','Tan An Commune','tan_an','08',4),
('02332','Kiên Đài','Kien Dai','Xã Kiên Đài','Kien Dai Commune','kien_dai','08',4),
('02350','Kim Bình','Kim Binh','Xã Kim Bình','Kim Binh Commune','kim_binh','08',4),
('02353','Hòa An','Hoa An','Xã Hòa An','Hoa An Commune','hoa_an','08',4),
('02359','Tri Phú','Tri Phu','Xã Tri Phú','Tri Phu Commune','tri_phu','08',4),
('02365','Yên Nguyên','Yen Nguyen','Xã Yên Nguyên','Yen Nguyen Commune','yen_nguyen','08',4),
('02374','Hàm Yên','Ham Yen','Xã Hàm Yên','Ham Yen Commune','ham_yen','08',4),
('02380','Bạch Xa','Bach Xa','Xã Bạch Xa','Bach Xa Commune','bach_xa','08',4),
('02392','Phù Lưu','Phu Luu','Xã Phù Lưu','Phu Luu Commune','phu_luu','08',4),
('02398','Yên Phú','Yen Phu','Xã Yên Phú','Yen Phu Commune','yen_phu','08',4),
('02404','Bình Xa','Binh Xa','Xã Bình Xa','Binh Xa Commune','binh_xa','08',4),
('02407','Thái Sơn','Thai Son','Xã Thái Sơn','Thai Son Commune','thai_son','08',4),
('02419','Thái Hòa','Thai Hoa','Xã Thái Hòa','Thai Hoa Commune','thai_hoa','08',4),
('02425','Hùng Đức','Hung Duc','Xã Hùng Đức','Hung Duc Commune','hung_duc','08',4),
('02434','Lực Hành','Luc Hanh','Xã Lực Hành','Luc Hanh Commune','luc_hanh','08',4),
('02437','Kiến Thiết','Kien Thiet','Xã Kiến Thiết','Kien Thiet Commune','kien_thiet','08',4),
('02449','Xuân Vân','Xuan Van','Xã Xuân Vân','Xuan Van Commune','xuan_van','08',4),
('02455','Hùng Lợi','Hung Loi','Xã Hùng Lợi','Hung Loi Commune','hung_loi','08',4),
('02458','Trung Sơn','Trung Son','Xã Trung Sơn','Trung Son Commune','trung_son','08',4),
('02470','Tân Long','Tan Long','Xã Tân Long','Tan Long Commune','tan_long','08',4),
('02473','Yên Sơn','Yen Son','Xã Yên Sơn','Yen Son Commune','yen_son','08',4),
('02494','Thái Bình','Thai Binh','Xã Thái Bình','Thai Binh Commune','thai_binh','08',4),
('02509','Mỹ Lâm','My Lam','Phường Mỹ Lâm','My Lam Ward','my_lam','08',3),
('02512','An Tường','An Tuong','Phường An Tường','An Tuong Ward','an_tuong','08',3),
('02524','Bình Thuận','Binh Thuan','Phường Bình Thuận','Binh Thuan Ward','binh_thuan','08',3),
('02530','Nhữ Khê','Nhu Khe','Xã Nhữ Khê','Nhu Khe Commune','nhu_khe','08',4),
('02536','Sơn Dương','Son Duong','Xã Sơn Dương','Son Duong Commune','son_duong','08',4),
('02545','Tân Trào','Tan Trao','Xã Tân Trào','Tan Trao Commune','tan_trao','08',4),
('02548','Bình Ca','Binh Ca','Xã Bình Ca','Binh Ca Commune','binh_ca','08',4),
('02554','Minh Thanh','Minh Thanh','Xã Minh Thanh','Minh Thanh Commune','minh_thanh','08',4),
('02572','Đông Thọ','Dong Tho','Xã Đông Thọ','Dong Tho Commune','dong_tho','08',4),
('02578','Tân Thanh','Tan Thanh','Xã Tân Thanh','Tan Thanh Commune','tan_thanh','08',4),
('02608','Hồng Sơn','Hong Son','Xã Hồng Sơn','Hong Son Commune','hong_son','08',4),
('02611','Phú Lương','Phu Luong','Xã Phú Lương','Phu Luong Commune','phu_luong','08',4),
('02620','Sơn Thủy','Son Thuy','Xã Sơn Thủy','Son Thuy Commune','son_thuy','08',4),
('02623','Trường Sinh','Truong Sinh','Xã Trường Sinh','Truong Sinh Commune','truong_sinh','08',4),
('02647','Lào Cai','Lao Cai','Phường Lào Cai','Lao Cai Ward','lao_cai','15',3),
('02671','Cam Đường','Cam Duong','Phường Cam Đường','Cam Duong Ward','cam_duong','15',3),
('02680','Hợp Thành','Hop Thanh','Xã Hợp Thành','Hop Thanh Commune','hop_thanh','15',4),
('02683','Bát Xát','Bat Xat','Xã Bát Xát','Bat Xat Commune','bat_xat','15',4),
('02686','A Mú Sung','A Mu Sung','Xã A Mú Sung','A Mu Sung Commune','a_mu_sung','15',4),
('02695','Trịnh Tường','Trinh Tuong','Xã Trịnh Tường','Trinh Tuong Commune','trinh_tuong','15',4),
('02701','Y Tý','Y Ty','Xã Y Tý','Y Ty Commune','y_ty','15',4),
('02707','Dền Sáng','Den Sang','Xã Dền Sáng','Den Sang Commune','den_sang','15',4),
('02725','Bản Xèo','Ban Xeo','Xã Bản Xèo','Ban Xeo Commune','ban_xeo','15',4),
('02728','Mường Hum','Muong Hum','Xã Mường Hum','Muong Hum Commune','muong_hum','15',4),
('02746','Cốc San','Coc San','Xã Cốc San','Coc San Commune','coc_san','15',4),
('02752','Pha Long','Pha Long','Xã Pha Long','Pha Long Commune','pha_long','15',4),
('02761','Mường Khương','Muong Khuong','Xã Mường Khương','Muong Khuong Commune','muong_khuong','15',4),
('02782','Cao Sơn','Cao Son','Xã Cao Sơn','Cao Son Commune','cao_son','15',4),
('02788','Bản Lầu','Ban Lau','Xã Bản Lầu','Ban Lau Commune','ban_lau','15',4),
('02809','Si Ma Cai','Si Ma Cai','Xã Si Ma Cai','Si Ma Cai Commune','si_ma_cai','15',4),
('02824','Sín Chéng','Sin Cheng','Xã Sín Chéng','Sin Cheng Commune','sin_cheng','15',4),
('02839','Bắc Hà','Bac Ha','Xã Bắc Hà','Bac Ha Commune','bac_ha','15',4),
('02842','Tả Củ Tỷ','Ta Cu Ty','Xã Tả Củ Tỷ','Ta Cu Ty Commune','ta_cu_ty','15',4),
('02848','Lùng Phình','Lung Phinh','Xã Lùng Phình','Lung Phinh Commune','lung_phinh','15',4),
('02869','Bản Liền','Ban Lien','Xã Bản Liền','Ban Lien Commune','ban_lien','15',4),
('02890','Bảo Nhai','Bao Nhai','Xã Bảo Nhai','Bao Nhai Commune','bao_nhai','15',4),
('02896','Cốc Lầu','Coc Lau','Xã Cốc Lầu','Coc Lau Commune','coc_lau','15',4),
('02902','Phong Hải','Phong Hai','Xã Phong Hải','Phong Hai Commune','phong_hai','15',4),
('02905','Bảo Thắng','Bao Thang','Xã Bảo Thắng','Bao Thang Commune','bao_thang','15',4),
('02908','Tằng Loỏng','Tang Loong','Xã Tằng Loỏng','Tang Loong Commune','tang_loong','15',4),
('02923','Gia Phú','Gia Phu','Xã Gia Phú','Gia Phu Commune','gia_phu','15',4),
('02926','Xuân Quang','Xuan Quang','Xã Xuân Quang','Xuan Quang Commune','xuan_quang','15',4),
('02947','Bảo Yên','Bao Yen','Xã Bảo Yên','Bao Yen Commune','bao_yen','15',4),
('02953','Nghĩa Đô','Nghia Do','Xã Nghĩa Đô','Nghia Do Commune','nghia_do','15',4),
('02962','Xuân Hòa','Xuan Hoa','Xã Xuân Hòa','Xuan Hoa Commune','xuan_hoa','15',4),
('02968','Thượng Hà','Thuong Ha','Xã Thượng Hà','Thuong Ha Commune','thuong_ha','15',4),
('02989','Bảo Hà','Bao Ha','Xã Bảo Hà','Bao Ha Commune','bao_ha','15',4),
('02998','Phúc Khánh','Phuc Khanh','Xã Phúc Khánh','Phuc Khanh Commune','phuc_khanh','15',4),
('03004','Ngũ Chỉ Sơn','Ngu Chi Son','Xã Ngũ Chỉ Sơn','Ngu Chi Son Commune','ngu_chi_son','15',4),
('03006','Sa Pa','Sa Pa','Phường Sa Pa','Sa Pa Ward','sa_pa','15',3),
('03013','Tả Phìn','Ta Phin','Xã Tả Phìn','Ta Phin Commune','ta_phin','15',4),
('03037','Tả Van','Ta Van','Xã Tả Van','Ta Van Commune','ta_van','15',4),
('03043','Mường Bo','Muong Bo','Xã Mường Bo','Muong Bo Commune','muong_bo','15',4),
('03046','Bản Hồ','Ban Ho','Xã Bản Hồ','Ban Ho Commune','ban_ho','15',4),
('03061','Võ Lao','Vo Lao','Xã Võ Lao','Vo Lao Commune','vo_lao','15',4),
('03076','Nậm Chày','Nam Chay','Xã Nậm Chày','Nam Chay Commune','nam_chay','15',4),
('03082','Văn Bàn','Van Ban','Xã Văn Bàn','Van Ban Commune','van_ban','15',4),
('03085','Nậm Xé','Nam Xe','Xã Nậm Xé','Nam Xe Commune','nam_xe','15',4),
('03091','Chiềng Ken','Chieng Ken','Xã Chiềng Ken','Chieng Ken Commune','chieng_ken','15',4),
('03103','Khánh Yên','Khanh Yen','Xã Khánh Yên','Khanh Yen Commune','khanh_yen','15',4),
('03106','Dương Quỳ','Duong Quy','Xã Dương Quỳ','Duong Quy Commune','duong_quy','15',4),
('03121','Minh Lương','Minh Luong','Xã Minh Lương','Minh Luong Commune','minh_luong','15',4),
('03127','Điện Biên Phủ','Dien Bien Phu','Phường Điện Biên Phủ','Dien Bien Phu Ward','dien_bien_phu','11',3),
('03151','Mường Lay','Muong Lay','Phường Mường Lay','Muong Lay Ward','muong_lay','11',3),
('03158','Sín Thầu','Sin Thau','Xã Sín Thầu','Sin Thau Commune','sin_thau','11',4),
('03160','Mường Nhé','Muong Nhe','Xã Mường Nhé','Muong Nhe Commune','muong_nhe','11',4),
('03162','Nậm Kè','Nam Ke','Xã Nậm Kè','Nam Ke Commune','nam_ke','11',4),
('03163','Mường Toong','Muong Toong','Xã Mường Toong','Muong Toong Commune','muong_toong','11',4),
('03164','Quảng Lâm','Quang Lam','Xã Quảng Lâm','Quang Lam Commune','quang_lam','11',4),
('03166','Mường Chà','Muong Cha','Xã Mường Chà','Muong Cha Commune','muong_cha','11',4),
('03169','Nà Hỳ','Na Hy','Xã Nà Hỳ','Na Hy Commune','na_hy','11',4),
('03172','Na Sang','Na Sang','Xã Na Sang','Na Sang Commune','na_sang','11',4),
('03175','Chà Tở','Cha To','Xã Chà Tở','Cha To Commune','cha_to','11',4),
('03176','Nà Bủng','Na Bung','Xã Nà Bủng','Na Bung Commune','na_bung','11',4),
('03181','Mường Tùng','Muong Tung','Xã Mường Tùng','Muong Tung Commune','muong_tung','11',4),
('03193','Pa Ham','Pa Ham','Xã Pa Ham','Pa Ham Commune','pa_ham','11',4),
('03194','Nậm Nèn','Nam Nen','Xã Nậm Nèn','Nam Nen Commune','nam_nen','11',4),
('03199','Si Pa Phìn','Si Pa Phin','Xã Si Pa Phìn','Si Pa Phin Commune','si_pa_phin','11',4),
('03202','Mường Pồn','Muong Pon','Xã Mường Pồn','Muong Pon Commune','muong_pon','11',4),
('03203','Na Son','Na Son','Xã Na Son','Na Son Commune','na_son','11',4),
('03208','Xa Dung','Xa Dung','Xã Xa Dung','Xa Dung Commune','xa_dung','11',4),
('03214','Mường Luân','Muong Luan','Xã Mường Luân','Muong Luan Commune','muong_luan','11',4),
('03217','Tủa Chùa','Tua Chua','Xã Tủa Chùa','Tua Chua Commune','tua_chua','11',4),
('03220','Tủa Thàng','Tua Thang','Xã Tủa Thàng','Tua Thang Commune','tua_thang','11',4),
('03226','Sín Chải','Sin Chai','Xã Sín Chải','Sin Chai Commune','sin_chai','11',4),
('03241','Sính Phình','Sinh Phinh','Xã Sính Phình','Sinh Phinh Commune','sinh_phinh','11',4),
('03244','Sáng Nhè','Sang Nhe','Xã Sáng Nhè','Sang Nhe Commune','sang_nhe','11',4),
('03253','Tuần Giáo','Tuan Giao','Xã Tuần Giáo','Tuan Giao Commune','tuan_giao','11',4),
('03256','Mường Ảng','Muong Ang','Xã Mường Ảng','Muong Ang Commune','muong_ang','11',4),
('03260','Pú Nhung','Pu Nhung','Xã Pú Nhung','Pu Nhung Commune','pu_nhung','11',4),
('03268','Mường Mùn','Muong Mun','Xã Mường Mùn','Muong Mun Commune','muong_mun','11',4),
('03283','Chiềng Sinh','Chieng Sinh','Xã Chiềng Sinh','Chieng Sinh Commune','chieng_sinh','11',4),
('03295','Quài Tở','Quai To','Xã Quài Tở','Quai To Commune','quai_to','11',4),
('03301','Búng Lao','Bung Lao','Xã Búng Lao','Bung Lao Commune','bung_lao','11',4),
('03313','Mường Lạn','Muong Lan','Xã Mường Lạn','Muong Lan Commune','muong_lan','11',4),
('03316','Nà Tấu','Na Tau','Xã Nà Tấu','Na Tau Commune','na_tau','11',4),
('03325','Mường Phăng','Muong Phang','Xã Mường Phăng','Muong Phang Commune','muong_phang','11',4),
('03328','Thanh Nưa','Thanh Nua','Xã Thanh Nưa','Thanh Nua Commune','thanh_nua','11',4),
('03334','Mường Thanh','Muong Thanh','Phường Mường Thanh','Muong Thanh Ward','muong_thanh','11',3),
('03349','Thanh Yên','Thanh Yen','Xã Thanh Yên','Thanh Yen Commune','thanh_yen','11',4),
('03352','Thanh An','Thanh An','Xã Thanh An','Thanh An Commune','thanh_an','11',4),
('03356','Sam Mứn','Sam Mun','Xã Sam Mứn','Sam Mun Commune','sam_mun','11',4),
('03358','Núa Ngam','Nua Ngam','Xã Núa Ngam','Nua Ngam Commune','nua_ngam','11',4),
('03368','Mường Nhà','Muong Nha','Xã Mường Nhà','Muong Nha Commune','muong_nha','11',4),
('03370','Pu Nhi','Pu Nhi','Xã Pu Nhi','Pu Nhi Commune','pu_nhi','11',4),
('03382','Phình Giàng','Phinh Giang','Xã Phình Giàng','Phinh Giang Commune','phinh_giang','11',4),
('03385','Tìa Dình','Tia Dinh','Xã Tìa Dình','Tia Dinh Commune','tia_dinh','11',4),
('03388','Đoàn Kết','Doan Ket','Phường Đoàn Kết','Doan Ket Ward','doan_ket','12',3),
('03390','Bình Lư','Binh Lu','Xã Bình Lư','Binh Lu Commune','binh_lu','12',4),
('03394','Sin Suối Hồ','Sin Suoi Ho','Xã Sin Suối Hồ','Sin Suoi Ho Commune','sin_suoi_ho','12',4),
('03405','Tả Lèng','Ta Leng','Xã Tả Lèng','Ta Leng Commune','ta_leng','12',4),
('03408','Tân Phong','Tan Phong','Phường Tân Phong','Tan Phong Ward','tan_phong','12',3),
('03424','Bản Bo','Ban Bo','Xã Bản Bo','Ban Bo Commune','ban_bo','12',4),
('03430','Khun Há','Khun Ha','Xã Khun Há','Khun Ha Commune','khun_ha','12',4),
('03433','Bum Tở','Bum To','Xã Bum Tở','Bum To Commune','bum_to','12',4),
('03434','Nậm Hàng','Nam Hang','Xã Nậm Hàng','Nam Hang Commune','nam_hang','12',4),
('03439','Thu Lũm','Thu Lum','Xã Thu Lũm','Thu Lum Commune','thu_lum','12',4),
('03442','Pa Ủ','Pa U','Xã Pa Ủ','Pa U Commune','pa_u','12',4),
('03445','Mường Tè','Muong Te','Xã Mường Tè','Muong Te Commune','muong_te','12',4),
('03451','Mù Cả','Mu Ca','Xã Mù Cả','Mu Ca Commune','mu_ca','12',4),
('03460','Hua Bum','Hua Bum','Xã Hua Bum','Hua Bum Commune','hua_bum','12',4),
('03463','Tà Tổng','Ta Tong','Xã Tà Tổng','Ta Tong Commune','ta_tong','12',4),
('03466','Bum Nưa','Bum Nua','Xã Bum Nưa','Bum Nua Commune','bum_nua','12',4),
('03472','Mường Mô','Muong Mo','Xã Mường Mô','Muong Mo Commune','muong_mo','12',4),
('03478','Sìn Hồ','Sin Ho','Xã Sìn Hồ','Sin Ho Commune','sin_ho','12',4),
('03487','Lê Lợi','Le Loi','Xã Lê Lợi','Le Loi Commune','le_loi','12',4),
('03503','Pa Tần','Pa Tan','Xã Pa Tần','Pa Tan Commune','pa_tan','12',4),
('03508','Hồng Thu','Hong Thu','Xã Hồng Thu','Hong Thu Commune','hong_thu','12',4),
('03517','Nậm Tăm','Nam Tam','Xã Nậm Tăm','Nam Tam Commune','nam_tam','12',4),
('03529','Tủa Sín Chải','Tua Sin Chai','Xã Tủa Sín Chải','Tua Sin Chai Commune','tua_sin_chai','12',4),
('03532','Pu Sam Cáp','Pu Sam Cap','Xã Pu Sam Cáp','Pu Sam Cap Commune','pu_sam_cap','12',4),
('03538','Nậm Mạ','Nam Ma','Xã Nậm Mạ','Nam Ma Commune','nam_ma','12',4),
('03544','Nậm Cuổi','Nam Cuoi','Xã Nậm Cuổi','Nam Cuoi Commune','nam_cuoi','12',4),
('03549','Phong Thổ','Phong Tho','Xã Phong Thổ','Phong Tho Commune','phong_tho','12',4),
('03562','Sì Lở Lầu','Si Lo Lau','Xã Sì Lở Lầu','Si Lo Lau Commune','si_lo_lau','12',4),
('03571','Dào San','Dao San','Xã Dào San','Dao San Commune','dao_san','12',4),
('03583','Khổng Lào','Khong Lao','Xã Khổng Lào','Khong Lao Commune','khong_lao','12',4),
('03595','Than Uyên','Than Uyen','Xã Than Uyên','Than Uyen Commune','than_uyen','12',4),
('03598','Tân Uyên','Tan Uyen','Xã Tân Uyên','Tan Uyen Commune','tan_uyen','12',4),
('03601','Mường Khoa','Muong Khoa','Xã Mường Khoa','Muong Khoa Commune','muong_khoa','12',4),
('03613','Nậm Sỏ','Nam So','Xã Nậm Sỏ','Nam So Commune','nam_so','12',4),
('03616','Pắc Ta','Pac Ta','Xã Pắc Ta','Pac Ta Commune','pac_ta','12',4),
('03618','Mường Than','Muong Than','Xã Mường Than','Muong Than Commune','muong_than','12',4),
('03637','Mường Kim','Muong Kim','Xã Mường Kim','Muong Kim Commune','muong_kim','12',4),
('03640','Khoen On','Khoen On','Xã Khoen On','Khoen On Commune','khoen_on','12',4),
('03646','Tô Hiệu','To Hieu','Phường Tô Hiệu','To Hieu Ward','to_hieu','14',3),
('03664','Chiềng An','Chieng An','Phường Chiềng An','Chieng An Ward','chieng_an','14',3),
('03670','Chiềng Cơi','Chieng Coi','Phường Chiềng Cơi','Chieng Coi Ward','chieng_coi','14',3),
('03679','Chiềng Sinh','Chieng Sinh','Phường Chiềng Sinh','Chieng Sinh Ward','chieng_sinh','14',3),
('03688','Mường Chiên','Muong Chien','Xã Mường Chiên','Muong Chien Commune','muong_chien','14',4),
('03694','Mường Giôn','Muong Gion','Xã Mường Giôn','Muong Gion Commune','muong_gion','14',4),
('03703','Quỳnh Nhai','Quynh Nhai','Xã Quỳnh Nhai','Quynh Nhai Commune','quynh_nhai','14',4),
('03712','Mường Sại','Muong Sai','Xã Mường Sại','Muong Sai Commune','muong_sai','14',4),
('03721','Thuận Châu','Thuan Chau','Xã Thuận Châu','Thuan Chau Commune','thuan_chau','14',4),
('03724','Bình Thuận','Binh Thuan','Xã Bình Thuận','Binh Thuan Commune','binh_thuan','14',4),
('03727','Mường É','Muong E','Xã Mường É','Muong E Commune','muong_e','14',4),
('03754','Chiềng La','Chieng La','Xã Chiềng La','Chieng La Commune','chieng_la','14',4),
('03757','Mường Khiêng','Muong Khieng','Xã Mường Khiêng','Muong Khieng Commune','muong_khieng','14',4),
('03760','Mường Bám','Muong Bam','Xã Mường Bám','Muong Bam Commune','muong_bam','14',4),
('03763','Long Hẹ','Long He','Xã Long Hẹ','Long He Commune','long_he','14',4),
('03781','Co Mạ','Co Ma','Xã Co Mạ','Co Ma Commune','co_ma','14',4),
('03784','Nậm Lầu','Nam Lau','Xã Nậm Lầu','Nam Lau Commune','nam_lau','14',4),
('03799','Muổi Nọi','Muoi Noi','Xã Muổi Nọi','Muoi Noi Commune','muoi_noi','14',4),
('03808','Mường La','Muong La','Xã Mường La','Muong La Commune','muong_la','14',4),
('03814','Chiềng Lao','Chieng Lao','Xã Chiềng Lao','Chieng Lao Commune','chieng_lao','14',4),
('03820','Ngọc Chiến','Ngoc Chien','Xã Ngọc Chiến','Ngoc Chien Commune','ngoc_chien','14',4),
('03847','Mường Bú','Muong Bu','Xã Mường Bú','Muong Bu Commune','muong_bu','14',4),
('03850','Chiềng Hoa','Chieng Hoa','Xã Chiềng Hoa','Chieng Hoa Commune','chieng_hoa','14',4),
('03856','Bắc Yên','Bac Yen','Xã Bắc Yên','Bac Yen Commune','bac_yen','14',4),
('03862','Xím Vàng','Xim Vang','Xã Xím Vàng','Xim Vang Commune','xim_vang','14',4),
('03868','Tà Xùa','Ta Xua','Xã Tà Xùa','Ta Xua Commune','ta_xua','14',4),
('03871','Pắc Ngà','Pac Nga','Xã Pắc Ngà','Pac Nga Commune','pac_nga','14',4),
('03880','Tạ Khoa','Ta Khoa','Xã Tạ Khoa','Ta Khoa Commune','ta_khoa','14',4),
('03892','Chiềng Sại','Chieng Sai','Xã Chiềng Sại','Chieng Sai Commune','chieng_sai','14',4),
('03901','Suối Tọ','Suoi To','Xã Suối Tọ','Suoi To Commune','suoi_to','14',4),
('03907','Mường Cơi','Muong Coi','Xã Mường Cơi','Muong Coi Commune','muong_coi','14',4),
('03910','Phù Yên','Phu Yen','Xã Phù Yên','Phu Yen Commune','phu_yen','14',4),
('03922','Gia Phù','Gia Phu','Xã Gia Phù','Gia Phu Commune','gia_phu','14',4),
('03943','Mường Bang','Muong Bang','Xã Mường Bang','Muong Bang Commune','muong_bang','14',4),
('03958','Tường Hạ','Tuong Ha','Xã Tường Hạ','Tuong Ha Commune','tuong_ha','14',4),
('03961','Kim Bon','Kim Bon','Xã Kim Bon','Kim Bon Commune','kim_bon','14',4),
('03970','Tân Phong','Tan Phong','Xã Tân Phong','Tan Phong Commune','tan_phong','14',4),
('03979','Mộc Sơn','Moc Son','Phường Mộc Sơn','Moc Son Ward','moc_son','14',3),
('03980','Mộc Châu','Moc Chau','Phường Mộc Châu','Moc Chau Ward','moc_chau','14',3),
('03982','Thảo Nguyên','Thao Nguyen','Phường Thảo Nguyên','Thao Nguyen Ward','thao_nguyen','14',3),
('03985','Chiềng Sơn','Chieng Son','Xã Chiềng Sơn','Chieng Son Commune','chieng_son','14',4),
('03997','Tân Yên','Tan Yen','Xã Tân Yên','Tan Yen Commune','tan_yen','14',4),
('04000','Đoàn Kết','Doan Ket','Xã Đoàn Kết','Doan Ket Commune','doan_ket','14',4),
('04006','Song Khủa','Song Khua','Xã Song Khủa','Song Khua Commune','song_khua','14',4),
('04018','Tô Múa','To Mua','Xã Tô Múa','To Mua Commune','to_mua','14',4),
('04033','Vân Sơn','Van Son','Phường Vân Sơn','Van Son Ward','van_son','14',3),
('04045','Lóng Sập','Long Sap','Xã Lóng Sập','Long Sap Commune','long_sap','14',4),
('04048','Vân Hồ','Van Ho','Xã Vân Hồ','Van Ho Commune','van_ho','14',4),
('04057','Xuân Nha','Xuan Nha','Xã Xuân Nha','Xuan Nha Commune','xuan_nha','14',4),
('04075','Yên Châu','Yen Chau','Xã Yên Châu','Yen Chau Commune','yen_chau','14',4),
('04078','Chiềng Hặc','Chieng Hac','Xã Chiềng Hặc','Chieng Hac Commune','chieng_hac','14',4),
('04087','Yên Sơn','Yen Son','Xã Yên Sơn','Yen Son Commune','yen_son','14',4),
('04096','Lóng Phiêng','Long Phieng','Xã Lóng Phiêng','Long Phieng Commune','long_phieng','14',4),
('04099','Phiêng Khoài','Phieng Khoai','Xã Phiêng Khoài','Phieng Khoai Commune','phieng_khoai','14',4),
('04105','Mai Sơn','Mai Son','Xã Mai Sơn','Mai Son Commune','mai_son','14',4),
('04108','Chiềng Sung','Chieng Sung','Xã Chiềng Sung','Chieng Sung Commune','chieng_sung','14',4),
('04117','Mường Chanh','Muong Chanh','Xã Mường Chanh','Muong Chanh Commune','muong_chanh','14',4),
('04123','Chiềng Mung','Chieng Mung','Xã Chiềng Mung','Chieng Mung Commune','chieng_mung','14',4),
('04132','Chiềng Mai','Chieng Mai','Xã Chiềng Mai','Chieng Mai Commune','chieng_mai','14',4),
('04136','Tà Hộc','Ta Hoc','Xã Tà Hộc','Ta Hoc Commune','ta_hoc','14',4),
('04144','Phiêng Cằm','Phieng Cam','Xã Phiêng Cằm','Phieng Cam Commune','phieng_cam','14',4),
('04159','Phiêng Pằn','Phieng Pan','Xã Phiêng Pằn','Phieng Pan Commune','phieng_pan','14',4),
('04168','Sông Mã','Song Ma','Xã Sông Mã','Song Ma Commune','song_ma','14',4),
('04171','Bó Sinh','Bo Sinh','Xã Bó Sinh','Bo Sinh Commune','bo_sinh','14',4),
('04183','Mường Lầm','Muong Lam','Xã Mường Lầm','Muong Lam Commune','muong_lam','14',4),
('04186','Nậm Ty','Nam Ty','Xã Nậm Ty','Nam Ty Commune','nam_ty','14',4),
('04195','Chiềng Sơ','Chieng So','Xã Chiềng Sơ','Chieng So Commune','chieng_so','14',4),
('04204','Chiềng Khoong','Chieng Khoong','Xã Chiềng Khoong','Chieng Khoong Commune','chieng_khoong','14',4),
('04210','Huổi Một','Huoi Mot','Xã Huổi Một','Huoi Mot Commune','huoi_mot','14',4),
('04219','Mường Hung','Muong Hung','Xã Mường Hung','Muong Hung Commune','muong_hung','14',4),
('04222','Chiềng Khương','Chieng Khuong','Xã Chiềng Khương','Chieng Khuong Commune','chieng_khuong','14',4),
('04228','Púng Bánh','Pung Banh','Xã Púng Bánh','Pung Banh Commune','pung_banh','14',4),
('04231','Sốp Cộp','Sop Cop','Xã Sốp Cộp','Sop Cop Commune','sop_cop','14',4),
('04240','Mường Lèo','Muong Leo','Xã Mường Lèo','Muong Leo Commune','muong_leo','14',4),
('04246','Mường Lạn','Muong Lan','Xã Mường Lạn','Muong Lan Commune','muong_lan','14',4),
('04252','Yên Bái','Yen Bai','Phường Yên Bái','Yen Bai Ward','yen_bai','15',3),
('04273','Nam Cường','Nam Cuong','Phường Nam Cường','Nam Cuong Ward','nam_cuong','15',3),
('04279','Văn Phú','Van Phu','Phường Văn Phú','Van Phu Ward','van_phu','15',3),
('04288','Nghĩa Lộ','Nghia Lo','Phường Nghĩa Lộ','Nghia Lo Ward','nghia_lo','15',3),
('04303','Lục Yên','Luc Yen','Xã Lục Yên','Luc Yen Commune','luc_yen','15',4),
('04309','Lâm Thượng','Lam Thuong','Xã Lâm Thượng','Lam Thuong Commune','lam_thuong','15',4),
('04336','Tân Lĩnh','Tan Linh','Xã Tân Lĩnh','Tan Linh Commune','tan_linh','15',4),
('04342','Khánh Hòa','Khanh Hoa','Xã Khánh Hòa','Khanh Hoa Commune','khanh_hoa','15',4),
('04345','Mường Lai','Muong Lai','Xã Mường Lai','Muong Lai Commune','muong_lai','15',4),
('04363','Phúc Lợi','Phuc Loi','Xã Phúc Lợi','Phuc Loi Commune','phuc_loi','15',4),
('04375','Mậu A','Mau A','Xã Mậu A','Mau A Commune','mau_a','15',4),
('04381','Lâm Giang','Lam Giang','Xã Lâm Giang','Lam Giang Commune','lam_giang','15',4),
('04387','Châu Quế','Chau Que','Xã Châu Quế','Chau Que Commune','chau_que','15',4),
('04399','Đông Cuông','Dong Cuong','Xã Đông Cuông','Dong Cuong Commune','dong_cuong','15',4),
('04402','Phong Dụ Hạ','Phong Du Ha','Xã Phong Dụ Hạ','Phong Du Ha Commune','phong_du_ha','15',4),
('04423','Phong Dụ Thượng','Phong Du Thuong','Xã Phong Dụ Thượng','Phong Du Thuong Commune','phong_du_thuong','15',4),
('04429','Tân Hợp','Tan Hop','Xã Tân Hợp','Tan Hop Commune','tan_hop','15',4),
('04441','Xuân Ái','Xuan Ai','Xã Xuân Ái','Xuan Ai Commune','xuan_ai','15',4),
('04450','Mỏ Vàng','Mo Vang','Xã Mỏ Vàng','Mo Vang Commune','mo_vang','15',4),
('04456','Mù Cang Chải','Mu Cang Chai','Xã Mù Cang Chải','Mu Cang Chai Commune','mu_cang_chai','15',4),
('04462','Nậm Có','Nam Co','Xã Nậm Có','Nam Co Commune','nam_co','15',4),
('04465','Khao Mang','Khao Mang','Xã Khao Mang','Khao Mang Commune','khao_mang','15',4),
('04474','Lao Chải','Lao Chai','Xã Lao Chải','Lao Chai Commune','lao_chai','15',4),
('04489','Chế Tạo','Che Tao','Xã Chế Tạo','Che Tao Commune','che_tao','15',4),
('04492','Púng Luông','Pung Luong','Xã Púng Luông','Pung Luong Commune','pung_luong','15',4),
('04498','Trấn Yên','Tran Yen','Xã Trấn Yên','Tran Yen Commune','tran_yen','15',4),
('04531','Quy Mông','Quy Mong','Xã Quy Mông','Quy Mong Commune','quy_mong','15',4),
('04537','Lương Thịnh','Luong Thinh','Xã Lương Thịnh','Luong Thinh Commune','luong_thinh','15',4),
('04543','Âu Lâu','Au Lau','Phường Âu Lâu','Au Lau Ward','au_lau','15',3),
('04564','Việt Hồng','Viet Hong','Xã Việt Hồng','Viet Hong Commune','viet_hong','15',4),
('04576','Hưng Khánh','Hung Khanh','Xã Hưng Khánh','Hung Khanh Commune','hung_khanh','15',4),
('04585','Hạnh Phúc','Hanh Phuc','Xã Hạnh Phúc','Hanh Phuc Commune','hanh_phuc','15',4),
('04603','Tà Xi Láng','Ta Xi Lang','Xã Tà Xi Láng','Ta Xi Lang Commune','ta_xi_lang','15',4),
('04606','Trạm Tấu','Tram Tau','Xã Trạm Tấu','Tram Tau Commune','tram_tau','15',4),
('04609','Phình Hồ','Phinh Ho','Xã Phình Hồ','Phinh Ho Commune','phinh_ho','15',4),
('04630','Tú Lệ','Tu Le','Xã Tú Lệ','Tu Le Commune','tu_le','15',4),
('04636','Gia Hội','Gia Hoi','Xã Gia Hội','Gia Hoi Commune','gia_hoi','15',4),
('04651','Sơn Lương','Son Luong','Xã Sơn Lương','Son Luong Commune','son_luong','15',4),
('04660','Liên Sơn','Lien Son','Xã Liên Sơn','Lien Son Commune','lien_son','15',4),
('04663','Trung Tâm','Trung Tam','Phường Trung Tâm','Trung Tam Ward','trung_tam','15',3),
('04672','Văn Chấn','Van Chan','Xã Văn Chấn','Van Chan Commune','van_chan','15',4),
('04681','Cầu Thia','Cau Thia','Phường Cầu Thia','Cau Thia Ward','cau_thia','15',3),
('04693','Cát Thịnh','Cat Thinh','Xã Cát Thịnh','Cat Thinh Commune','cat_thinh','15',4),
('04699','Chấn Thịnh','Chan Thinh','Xã Chấn Thịnh','Chan Thinh Commune','chan_thinh','15',4),
('04705','Thượng Bằng La','Thuong Bang La','Xã Thượng Bằng La','Thuong Bang La Commune','thuong_bang_la','15',4),
('04711','Nghĩa Tâm','Nghia Tam','Xã Nghĩa Tâm','Nghia Tam Commune','nghia_tam','15',4),
('04714','Yên Bình','Yen Binh','Xã Yên Bình','Yen Binh Commune','yen_binh','15',4),
('04717','Thác Bà','Thac Ba','Xã Thác Bà','Thac Ba Commune','thac_ba','15',4),
('04726','Cảm Nhân','Cam Nhan','Xã Cảm Nhân','Cam Nhan Commune','cam_nhan','15',4),
('04744','Yên Thành','Yen Thanh','Xã Yên Thành','Yen Thanh Commune','yen_thanh','15',4),
('04750','Bảo Ái','Bao Ai','Xã Bảo Ái','Bao Ai Commune','bao_ai','15',4),
('04792','Tân Hòa','Tan Hoa','Phường Tân Hòa','Tan Hoa Ward','tan_hoa','25',3),
('04795','Hòa Bình','Hoa Binh','Phường Hòa Bình','Hoa Binh Ward','hoa_binh','25',3),
('04828','Thống Nhất','Thong Nhat','Phường Thống Nhất','Thong Nhat Ward','thong_nhat','25',3),
('04831','Đà Bắc','Da Bac','Xã Đà Bắc','Da Bac Commune','da_bac','25',4),
('04846','Đức Nhàn','Duc Nhan','Xã Đức Nhàn','Duc Nhan Commune','duc_nhan','25',4),
('04849','Tân Pheo','Tan Pheo','Xã Tân Pheo','Tan Pheo Commune','tan_pheo','25',4),
('04873','Quy Đức','Quy Duc','Xã Quy Đức','Quy Duc Commune','quy_duc','25',4),
('04876','Cao Sơn','Cao Son','Xã Cao Sơn','Cao Son Commune','cao_son','25',4),
('04891','Tiền Phong','Tien Phong','Xã Tiền Phong','Tien Phong Commune','tien_phong','25',4),
('04894','Kỳ Sơn','Ky Son','Phường Kỳ Sơn','Ky Son Ward','ky_son','25',3),
('04897','Thịnh Minh','Thinh Minh','Xã Thịnh Minh','Thinh Minh Commune','thinh_minh','25',4),
('04924','Lương Sơn','Luong Son','Xã Lương Sơn','Luong Son Commune','luong_son','25',4),
('04930','Yên Xuân','Yen Xuan','Xã Yên Xuân','Yen Xuan Commune','yen_xuan','01',4),
('04960','Liên Sơn','Lien Son','Xã Liên Sơn','Lien Son Commune','lien_son','25',4),
('04978','Kim Bôi','Kim Boi','Xã Kim Bôi','Kim Boi Commune','kim_boi','25',4),
('04990','Nật Sơn','Nat Son','Xã Nật Sơn','Nat Son Commune','nat_son','25',4),
('05014','Mường Động','Muong Dong','Xã Mường Động','Muong Dong Commune','muong_dong','25',4),
('05047','Cao Dương','Cao Duong','Xã Cao Dương','Cao Duong Commune','cao_duong','25',4),
('05068','Hợp Kim','Hop Kim','Xã Hợp Kim','Hop Kim Commune','hop_kim','25',4),
('05086','Dũng Tiến','Dung Tien','Xã Dũng Tiến','Dung Tien Commune','dung_tien','25',4),
('05089','Cao Phong','Cao Phong','Xã Cao Phong','Cao Phong Commune','cao_phong','25',4),
('05092','Thung Nai','Thung Nai','Xã Thung Nai','Thung Nai Commune','thung_nai','25',4),
('05116','Mường Thàng','Muong Thang','Xã Mường Thàng','Muong Thang Commune','muong_thang','25',4),
('05128','Tân Lạc','Tan Lac','Xã Tân Lạc','Tan Lac Commune','tan_lac','25',4),
('05134','Mường Hoa','Muong Hoa','Xã Mường Hoa','Muong Hoa Commune','muong_hoa','25',4),
('05152','Vân Sơn','Van Son','Xã Vân Sơn','Van Son Commune','van_son','25',4),
('05158','Mường Bi','Muong Bi','Xã Mường Bi','Muong Bi Commune','muong_bi','25',4),
('05191','Toàn Thắng','Toan Thang','Xã Toàn Thắng','Toan Thang Commune','toan_thang','25',4),
('05200','Mai Châu','Mai Chau','Xã Mai Châu','Mai Chau Commune','mai_chau','25',4),
('05206','Tân Mai','Tan Mai','Xã Tân Mai','Tan Mai Commune','tan_mai','25',4),
('05212','Pà Cò','Pa Co','Xã Pà Cò','Pa Co Commune','pa_co','25',4),
('05245','Bao La','Bao La','Xã Bao La','Bao La Commune','bao_la','25',4),
('05251','Mai Hạ','Mai Ha','Xã Mai Hạ','Mai Ha Commune','mai_ha','25',4),
('05266','Lạc Sơn','Lac Son','Xã Lạc Sơn','Lac Son Commune','lac_son','25',4),
('05287','Mường Vang','Muong Vang','Xã Mường Vang','Muong Vang Commune','muong_vang','25',4),
('05290','Nhân Nghĩa','Nhan Nghia','Xã Nhân Nghĩa','Nhan Nghia Commune','nhan_nghia','25',4),
('05293','Thượng Cốc','Thuong Coc','Xã Thượng Cốc','Thuong Coc Commune','thuong_coc','25',4),
('05305','Yên Phú','Yen Phu','Xã Yên Phú','Yen Phu Commune','yen_phu','25',4),
('05323','Quyết Thắng','Quyet Thang','Xã Quyết Thắng','Quyet Thang Commune','quyet_thang','25',4),
('05329','Ngọc Sơn','Ngoc Son','Xã Ngọc Sơn','Ngoc Son Commune','ngoc_son','25',4),
('05347','Đại Đồng','Dai Dong','Xã Đại Đồng','Dai Dong Commune','dai_dong','25',4),
('05353','Yên Thủy','Yen Thuy','Xã Yên Thủy','Yen Thuy Commune','yen_thuy','25',4),
('05362','Lạc Lương','Lac Luong','Xã Lạc Lương','Lac Luong Commune','lac_luong','25',4),
('05386','Yên Trị','Yen Tri','Xã Yên Trị','Yen Tri Commune','yen_tri','25',4),
('05392','Lạc Thủy','Lac Thuy','Xã Lạc Thủy','Lac Thuy Commune','lac_thuy','25',4),
('05395','An Nghĩa','An Nghia','Xã An Nghĩa','An Nghia Commune','an_nghia','25',4),
('05425','An Bình','An Binh','Xã An Bình','An Binh Commune','an_binh','25',4),
('05443','Phan Đình Phùng','Phan Dinh Phung','Phường Phan Đình Phùng','Phan Dinh Phung Ward','phan_dinh_phung','19',3),
('05455','Quyết Thắng','Quyet Thang','Phường Quyết Thắng','Quyet Thang Ward','quyet_thang','19',3),
('05467','Gia Sàng','Gia Sang','Phường Gia Sàng','Gia Sang Ward','gia_sang','19',3),
('05482','Quan Triều','Quan Trieu','Phường Quan Triều','Quan Trieu Ward','quan_trieu','19',3),
('05488','Đại Phúc','Dai Phuc','Xã Đại Phúc','Dai Phuc Commune','dai_phuc','19',4),
('05500','Tích Lương','Tich Luong','Phường Tích Lương','Tich Luong Ward','tich_luong','19',3),
('05503','Tân Cương','Tan Cuong','Xã Tân Cương','Tan Cuong Commune','tan_cuong','19',4),
('05518','Sông Công','Song Cong','Phường Sông Công','Song Cong Ward','song_cong','19',3),
('05528','Bách Quang','Bach Quang','Phường Bách Quang','Bach Quang Ward','bach_quang','19',3),
('05533','Bá Xuyên','Ba Xuyen','Phường Bá Xuyên','Ba Xuyen Ward','ba_xuyen','19',3),
('05542','Lam Vỹ','Lam Vy','Xã Lam Vỹ','Lam Vy Commune','lam_vy','19',4),
('05551','Kim Phượng','Kim Phuong','Xã Kim Phượng','Kim Phuong Commune','kim_phuong','19',4),
('05563','Phượng Tiến','Phuong Tien','Xã Phượng Tiến','Phuong Tien Commune','phuong_tien','19',4),
('05569','Định Hóa','Dinh Hoa','Xã Định Hóa','Dinh Hoa Commune','dinh_hoa','19',4),
('05581','Trung Hội','Trung Hoi','Xã Trung Hội','Trung Hoi Commune','trung_hoi','19',4),
('05587','Bình Yên','Binh Yen','Xã Bình Yên','Binh Yen Commune','binh_yen','19',4),
('05602','Phú Đình','Phu Dinh','Xã Phú Đình','Phu Dinh Commune','phu_dinh','19',4),
('05605','Bình Thành','Binh Thanh','Xã Bình Thành','Binh Thanh Commune','binh_thanh','19',4),
('05611','Phú Lương','Phu Luong','Xã Phú Lương','Phu Luong Commune','phu_luong','19',4),
('05620','Yên Trạch','Yen Trach','Xã Yên Trạch','Yen Trach Commune','yen_trach','19',4),
('05632','Hợp Thành','Hop Thanh','Xã Hợp Thành','Hop Thanh Commune','hop_thanh','19',4),
('05641','Vô Tranh','Vo Tranh','Xã Vô Tranh','Vo Tranh Commune','vo_tranh','19',4),
('05662','Trại Cau','Trai Cau','Xã Trại Cau','Trai Cau Commune','trai_cau','19',4),
('05665','Văn Lăng','Van Lang','Xã Văn Lăng','Van Lang Commune','van_lang','19',4),
('05674','Quang Sơn','Quang Son','Xã Quang Sơn','Quang Son Commune','quang_son','19',4),
('05680','Văn Hán','Van Han','Xã Văn Hán','Van Han Commune','van_han','19',4),
('05692','Đồng Hỷ','Dong Hy','Xã Đồng Hỷ','Dong Hy Commune','dong_hy','19',4),
('05707','Nam Hòa','Nam Hoa','Xã Nam Hòa','Nam Hoa Commune','nam_hoa','19',4),
('05710','Linh Sơn','Linh Son','Phường Linh Sơn','Linh Son Ward','linh_son','19',3),
('05716','Võ Nhai','Vo Nhai','Xã Võ Nhai','Vo Nhai Commune','vo_nhai','19',4),
('05719','Sảng Mộc','Sang Moc','Xã Sảng Mộc','Sang Moc Commune','sang_moc','19',4),
('05722','Nghinh Tường','Nghinh Tuong','Xã Nghinh Tường','Nghinh Tuong Commune','nghinh_tuong','19',4),
('05725','Thần Sa','Than Sa','Xã Thần Sa','Than Sa Commune','than_sa','19',4),
('05740','La Hiên','La Hien','Xã La Hiên','La Hien Commune','la_hien','19',4),
('05746','Tràng Xá','Trang Xa','Xã Tràng Xá','Trang Xa Commune','trang_xa','19',4),
('05755','Dân Tiến','Dan Tien','Xã Dân Tiến','Dan Tien Commune','dan_tien','19',4),
('05773','Phú Xuyên','Phu Xuyen','Xã Phú Xuyên','Phu Xuyen Commune','phu_xuyen','19',4),
('05776','Đức Lương','Duc Luong','Xã Đức Lương','Duc Luong Commune','duc_luong','19',4),
('05788','Phú Lạc','Phu Lac','Xã Phú Lạc','Phu Lac Commune','phu_lac','19',4),
('05800','Phú Thịnh','Phu Thinh','Xã Phú Thịnh','Phu Thinh Commune','phu_thinh','19',4),
('05809','An Khánh','An Khanh','Xã An Khánh','An Khanh Commune','an_khanh','19',4),
('05818','La Bằng','La Bang','Xã La Bằng','La Bang Commune','la_bang','19',4),
('05830','Đại Từ','Dai Tu','Xã Đại Từ','Dai Tu Commune','dai_tu','19',4),
('05845','Vạn Phú','Van Phu','Xã Vạn Phú','Van Phu Commune','van_phu','19',4),
('05851','Quân Chu','Quan Chu','Xã Quân Chu','Quan Chu Commune','quan_chu','19',4),
('05857','Phúc Thuận','Phuc Thuan','Phường Phúc Thuận','Phuc Thuan Ward','phuc_thuan','19',3),
('05860','Phổ Yên','Pho Yen','Phường Phổ Yên','Pho Yen Ward','pho_yen','19',3),
('05881','Thành Công','Thanh Cong','Xã Thành Công','Thanh Cong Commune','thanh_cong','19',4),
('05890','Vạn Xuân','Van Xuan','Phường Vạn Xuân','Van Xuan Ward','van_xuan','19',3),
('05899','Trung Thành','Trung Thanh','Phường Trung Thành','Trung Thanh Ward','trung_thanh','19',3),
('05908','Phú Bình','Phu Binh','Xã Phú Bình','Phu Binh Commune','phu_binh','19',4),
('05917','Tân Khánh','Tan Khanh','Xã Tân Khánh','Tan Khanh Commune','tan_khanh','19',4),
('05923','Tân Thành','Tan Thanh','Xã Tân Thành','Tan Thanh Commune','tan_thanh','19',4),
('05941','Điềm Thụy','Diem Thuy','Xã Điềm Thụy','Diem Thuy Commune','diem_thuy','19',4),
('05953','Kha Sơn','Kha Son','Xã Kha Sơn','Kha Son Commune','kha_son','19',4),
('05977','Đông Kinh','Dong Kinh','Phường Đông Kinh','Dong Kinh Ward','dong_kinh','20',3),
('05983','Lương Văn Tri','Luong Van Tri','Phường Lương Văn Tri','Luong Van Tri Ward','luong_van_tri','20',3),
('05986','Tam Thanh','Tam Thanh','Phường Tam Thanh','Tam Thanh Ward','tam_thanh','20',3),
('06001','Đoàn Kết','Doan Ket','Xã Đoàn Kết','Doan Ket Commune','doan_ket','20',4),
('06004','Quốc Khánh','Quoc Khanh','Xã Quốc Khánh','Quoc Khanh Commune','quoc_khanh','20',4),
('06019','Tân Tiến','Tan Tien','Xã Tân Tiến','Tan Tien Commune','tan_tien','20',4),
('06037','Kháng Chiến','Khang Chien','Xã Kháng Chiến','Khang Chien Commune','khang_chien','20',4),
('06040','Thất Khê','That Khe','Xã Thất Khê','That Khe Commune','that_khe','20',4),
('06046','Tràng Định','Trang Dinh','Xã Tràng Định','Trang Dinh Commune','trang_dinh','20',4),
('06058','Quốc Việt','Quoc Viet','Xã Quốc Việt','Quoc Viet Commune','quoc_viet','20',4),
('06073','Hoa Thám','Hoa Tham','Xã Hoa Thám','Hoa Tham Commune','hoa_tham','20',4),
('06076','Quý Hòa','Quy Hoa','Xã Quý Hòa','Quy Hoa Commune','quy_hoa','20',4),
('06079','Hồng Phong','Hong Phong','Xã Hồng Phong','Hong Phong Commune','hong_phong','20',4),
('06085','Thiện Hòa','Thien Hoa','Xã Thiện Hòa','Thien Hoa Commune','thien_hoa','20',4),
('06091','Thiện Thuật','Thien Thuat','Xã Thiện Thuật','Thien Thuat Commune','thien_thuat','20',4),
('06103','Thiện Long','Thien Long','Xã Thiện Long','Thien Long Commune','thien_long','20',4),
('06112','Bình Gia','Binh Gia','Xã Bình Gia','Binh Gia Commune','binh_gia','20',4),
('06115','Tân Văn','Tan Van','Xã Tân Văn','Tan Van Commune','tan_van','20',4),
('06124','Na Sầm','Na Sam','Xã Na Sầm','Na Sam Commune','na_sam','20',4),
('06148','Thụy Hùng','Thuy Hung','Xã Thụy Hùng','Thuy Hung Commune','thuy_hung','20',4),
('06151','Hội Hoan','Hoi Hoan','Xã Hội Hoan','Hoi Hoan Commune','hoi_hoan','20',4),
('06154','Văn Lãng','Van Lang','Xã Văn Lãng','Van Lang Commune','van_lang','20',4),
('06172','Hoàng Văn Thụ','Hoang Van Thu','Xã Hoàng Văn Thụ','Hoang Van Thu Commune','hoang_van_thu','20',4),
('06184','Đồng Đăng','Dong Dang','Xã Đồng Đăng','Dong Dang Commune','dong_dang','20',4),
('06187','Kỳ Lừa','Ky Lua','Phường Kỳ Lừa','Ky Lua Ward','ky_lua','20',3),
('06196','Ba Sơn','Ba Son','Xã Ba Sơn','Ba Son Commune','ba_son','20',4),
('06211','Cao Lộc','Cao Loc','Xã Cao Lộc','Cao Loc Commune','cao_loc','20',4),
('06220','Công Sơn','Cong Son','Xã Công Sơn','Cong Son Commune','cong_son','20',4),
('06253','Văn Quan','Van Quan','Xã Văn Quan','Van Quan Commune','van_quan','20',4),
('06280','Điềm He','Diem He','Xã Điềm He','Diem He Commune','diem_he','20',4),
('06286','Khánh Khê','Khanh Khe','Xã Khánh Khê','Khanh Khe Commune','khanh_khe','20',4),
('06298','Yên Phúc','Yen Phuc','Xã Yên Phúc','Yen Phuc Commune','yen_phuc','20',4),
('06313','Tri Lễ','Tri Le','Xã Tri Lễ','Tri Le Commune','tri_le','20',4),
('06316','Tân Đoàn','Tan Doan','Xã Tân Đoàn','Tan Doan Commune','tan_doan','20',4),
('06325','Bắc Sơn','Bac Son','Xã Bắc Sơn','Bac Son Commune','bac_son','20',4),
('06337','Tân Tri','Tan Tri','Xã Tân Tri','Tan Tri Commune','tan_tri','20',4),
('06349','Hưng Vũ','Hung Vu','Xã Hưng Vũ','Hung Vu Commune','hung_vu','20',4),
('06364','Vũ Lễ','Vu Le','Xã Vũ Lễ','Vu Le Commune','vu_le','20',4),
('06367','Vũ Lăng','Vu Lang','Xã Vũ Lăng','Vu Lang Commune','vu_lang','20',4),
('06376','Nhất Hòa','Nhat Hoa','Xã Nhất Hòa','Nhat Hoa Commune','nhat_hoa','20',4),
('06385','Hữu Lũng','Huu Lung','Xã Hữu Lũng','Huu Lung Commune','huu_lung','20',4),
('06391','Yên Bình','Yen Binh','Xã Yên Bình','Yen Binh Commune','yen_binh','20',4),
('06400','Hữu Liên','Huu Lien','Xã Hữu Liên','Huu Lien Commune','huu_lien','20',4),
('06415','Vân Nham','Van Nham','Xã Vân Nham','Van Nham Commune','van_nham','20',4),
('06427','Cai Kinh','Cai Kinh','Xã Cai Kinh','Cai Kinh Commune','cai_kinh','20',4),
('06436','Thiện Tân','Thien Tan','Xã Thiện Tân','Thien Tan Commune','thien_tan','20',4),
('06445','Tân Thành','Tan Thanh','Xã Tân Thành','Tan Thanh Commune','tan_thanh','20',4),
('06457','Tuấn Sơn','Tuan Son','Xã Tuấn Sơn','Tuan Son Commune','tuan_son','20',4),
('06463','Chi Lăng','Chi Lang','Xã Chi Lăng','Chi Lang Commune','chi_lang','20',4),
('06475','Bằng Mạc','Bang Mac','Xã Bằng Mạc','Bang Mac Commune','bang_mac','20',4),
('06481','Chiến Thắng','Chien Thang','Xã Chiến Thắng','Chien Thang Commune','chien_thang','20',4),
('06496','Nhân Lý','Nhan Ly','Xã Nhân Lý','Nhan Ly Commune','nhan_ly','20',4),
('06505','Vạn Linh','Van Linh','Xã Vạn Linh','Van Linh Commune','van_linh','20',4),
('06517','Quan Sơn','Quan Son','Xã Quan Sơn','Quan Son Commune','quan_son','20',4),
('06526','Na Dương','Na Duong','Xã Na Dương','Na Duong Commune','na_duong','20',4),
('06529','Lộc Bình','Loc Binh','Xã Lộc Bình','Loc Binh Commune','loc_binh','20',4),
('06541','Mẫu Sơn','Mau Son','Xã Mẫu Sơn','Mau Son Commune','mau_son','20',4),
('06565','Khuất Xá','Khuat Xa','Xã Khuất Xá','Khuat Xa Commune','khuat_xa','20',4),
('06577','Thống Nhất','Thong Nhat','Xã Thống Nhất','Thong Nhat Commune','thong_nhat','20',4),
('06601','Lợi Bác','Loi Bac','Xã Lợi Bác','Loi Bac Commune','loi_bac','20',4),
('06607','Xuân Dương','Xuan Duong','Xã Xuân Dương','Xuan Duong Commune','xuan_duong','20',4),
('06613','Đình Lập','Dinh Lap','Xã Đình Lập','Dinh Lap Commune','dinh_lap','20',4),
('06616','Thái Bình','Thai Binh','Xã Thái Bình','Thai Binh Commune','thai_binh','20',4),
('06625','Kiên Mộc','Kien Moc','Xã Kiên Mộc','Kien Moc Commune','kien_moc','20',4),
('06637','Châu Sơn','Chau Son','Xã Châu Sơn','Chau Son Commune','chau_son','20',4),
('06652','Hà Tu','Ha Tu','Phường Hà Tu','Ha Tu Ward','ha_tu','22',3),
('06658','Cao Xanh','Cao Xanh','Phường Cao Xanh','Cao Xanh Ward','cao_xanh','22',3),
('06661','Việt Hưng','Viet Hung','Phường Việt Hưng','Viet Hung Ward','viet_hung','22',3),
('06673','Bãi Cháy','Bai Chay','Phường Bãi Cháy','Bai Chay Ward','bai_chay','22',3),
('06676','Hà Lầm','Ha Lam','Phường Hà Lầm','Ha Lam Ward','ha_lam','22',3),
('06685','Hồng Gai','Hong Gai','Phường Hồng Gai','Hong Gai Ward','hong_gai','22',3),
('06688','Hạ Long','Ha Long','Phường Hạ Long','Ha Long Ward','ha_long','22',3),
('06706','Tuần Châu','Tuan Chau','Phường Tuần Châu','Tuan Chau Ward','tuan_chau','22',3),
('06709','Móng Cái 2','Mong Cai 2','Phường Móng Cái 2','Mong Cai 2 Ward','mong_cai_2','22',3),
('06712','Móng Cái 1','Mong Cai 1','Phường Móng Cái 1','Mong Cai 1 Ward','mong_cai_1','22',3),
('06724','Hải Sơn','Hai Son','Xã Hải Sơn','Hai Son Commune','hai_son','22',4),
('06733','Hải Ninh','Hai Ninh','Xã Hải Ninh','Hai Ninh Commune','hai_ninh','22',4),
('06736','Móng Cái 3','Mong Cai 3','Phường Móng Cái 3','Mong Cai 3 Ward','mong_cai_3','22',3),
('06757','Vĩnh Thực','Vinh Thuc','Xã Vĩnh Thực','Vinh Thuc Commune','vinh_thuc','22',4),
('06760','Mông Dương','Mong Duong','Phường Mông Dương','Mong Duong Ward','mong_duong','22',3),
('06778','Quang Hanh','Quang Hanh','Phường Quang Hanh','Quang Hanh Ward','quang_hanh','22',3),
('06781','Cửa Ông','Cua Ong','Phường Cửa Ông','Cua Ong Ward','cua_ong','22',3),
('06793','Cẩm Phả','Cam Pha','Phường Cẩm Phả','Cam Pha Ward','cam_pha','22',3),
('06799','Hải Hòa','Hai Hoa','Xã Hải Hòa','Hai Hoa Commune','hai_hoa','22',4),
('06811','Uông Bí','Uong Bi','Phường Uông Bí','Uong Bi Ward','uong_bi','22',3),
('06820','Vàng Danh','Vang Danh','Phường Vàng Danh','Vang Danh Ward','vang_danh','22',3),
('06832','Yên Tử','Yen Tu','Phường Yên Tử','Yen Tu Ward','yen_tu','22',3),
('06838','Bình Liêu','Binh Lieu','Xã Bình Liêu','Binh Lieu Commune','binh_lieu','22',4),
('06841','Hoành Mô','Hoanh Mo','Xã Hoành Mô','Hoanh Mo Commune','hoanh_mo','22',4),
('06856','Lục Hồn','Luc Hon','Xã Lục Hồn','Luc Hon Commune','luc_hon','22',4),
('06862','Tiên Yên','Tien Yen','Xã Tiên Yên','Tien Yen Commune','tien_yen','22',4),
('06874','Điền Xá','Dien Xa','Xã Điền Xá','Dien Xa Commune','dien_xa','22',4),
('06877','Đông Ngũ','Dong Ngu','Xã Đông Ngũ','Dong Ngu Commune','dong_ngu','22',4),
('06886','Hải Lạng','Hai Lang','Xã Hải Lạng','Hai Lang Commune','hai_lang','22',4),
('06895','Đầm Hà','Dam Ha','Xã Đầm Hà','Dam Ha Commune','dam_ha','22',4),
('06913','Quảng Tân','Quang Tan','Xã Quảng Tân','Quang Tan Commune','quang_tan','22',4),
('06922','Quảng Hà','Quang Ha','Xã Quảng Hà','Quang Ha Commune','quang_ha','22',4),
('06931','Quảng Đức','Quang Duc','Xã Quảng Đức','Quang Duc Commune','quang_duc','22',4),
('06946','Đường Hoa','Duong Hoa','Xã Đường Hoa','Duong Hoa Commune','duong_hoa','22',4),
('06967','Cái Chiên','Cai Chien','Xã Cái Chiên','Cai Chien Commune','cai_chien','22',4),
('06978','Ba Chẽ','Ba Che','Xã Ba Chẽ','Ba Che Commune','ba_che','22',4),
('06979','Kỳ Thượng','Ky Thuong','Xã Kỳ Thượng','Ky Thuong Commune','ky_thuong','22',4),
('06985','Lương Minh','Luong Minh','Xã Lương Minh','Luong Minh Commune','luong_minh','22',4),
('06994','Vân Đồn','Van Don','Đặc khu Vân Đồn','Van Don Special administrative region','van_don','22',5),
('07030','Hoành Bồ','Hoanh Bo','Phường Hoành Bồ','Hoanh Bo Ward','hoanh_bo','22',3),
('07054','Quảng La','Quang La','Xã Quảng La','Quang La Commune','quang_la','22',4),
('07060','Thống Nhất','Thong Nhat','Xã Thống Nhất','Thong Nhat Commune','thong_nhat','22',4),
('07069','Mạo Khê','Mao Khe','Phường Mạo Khê','Mao Khe Ward','mao_khe','22',3),
('07081','Bình Khê','Binh Khe','Phường Bình Khê','Binh Khe Ward','binh_khe','22',3),
('07090','An Sinh','An Sinh','Phường An Sinh','An Sinh Ward','an_sinh','22',3),
('07093','Đông Triều','Dong Trieu','Phường Đông Triều','Dong Trieu Ward','dong_trieu','22',3),
('07114','Hoàng Quế','Hoang Que','Phường Hoàng Quế','Hoang Que Ward','hoang_que','22',3),
('07132','Quảng Yên','Quang Yen','Phường Quảng Yên','Quang Yen Ward','quang_yen','22',3),
('07135','Đông Mai','Dong Mai','Phường Đông Mai','Dong Mai Ward','dong_mai','22',3),
('07147','Hiệp Hòa','Hiep Hoa','Phường Hiệp Hòa','Hiep Hoa Ward','hiep_hoa','22',3),
('07168','Hà An','Ha An','Phường Hà An','Ha An Ward','ha_an','22',3),
('07180','Liên Hòa','Lien Hoa','Phường Liên Hòa','Lien Hoa Ward','lien_hoa','22',3),
('07183','Phong Cốc','Phong Coc','Phường Phong Cốc','Phong Coc Ward','phong_coc','22',3),
('07192','Cô Tô','Co To','Đặc khu Cô Tô','Co To Special administrative region','co_to','22',5),
('07210','Bắc Giang','Bac Giang','Phường Bắc Giang','Bac Giang Ward','bac_giang','24',3),
('07228','Đa Mai','Da Mai','Phường Đa Mai','Da Mai Ward','da_mai','24',3),
('07246','Xuân Lương','Xuan Luong','Xã Xuân Lương','Xuan Luong Commune','xuan_luong','24',4),
('07264','Tam Tiến','Tam Tien','Xã Tam Tiến','Tam Tien Commune','tam_tien','24',4),
('07282','Đồng Kỳ','Dong Ky','Xã Đồng Kỳ','Dong Ky Commune','dong_ky','24',4),
('07288','Yên Thế','Yen The','Xã Yên Thế','Yen The Commune','yen_the','24',4),
('07294','Bố Hạ','Bo Ha','Xã Bố Hạ','Bo Ha Commune','bo_ha','24',4),
('07306','Nhã Nam','Nha Nam','Xã Nhã Nam','Nha Nam Commune','nha_nam','24',4),
('07330','Phúc Hòa','Phuc Hoa','Xã Phúc Hòa','Phuc Hoa Commune','phuc_hoa','24',4),
('07333','Quang Trung','Quang Trung','Xã Quang Trung','Quang Trung Commune','quang_trung','24',4),
('07339','Tân Yên','Tan Yen','Xã Tân Yên','Tan Yen Commune','tan_yen','24',4),
('07351','Ngọc Thiện','Ngoc Thien','Xã Ngọc Thiện','Ngoc Thien Commune','ngoc_thien','24',4),
('07375','Lạng Giang','Lang Giang','Xã Lạng Giang','Lang Giang Commune','lang_giang','24',4),
('07381','Tiên Lục','Tien Luc','Xã Tiên Lục','Tien Luc Commune','tien_luc','24',4),
('07399','Kép','Kep','Xã Kép','Kep Commune','kep','24',4),
('07420','Mỹ Thái','My Thai','Xã Mỹ Thái','My Thai Commune','my_thai','24',4),
('07432','Tân Dĩnh','Tan Dinh','Xã Tân Dĩnh','Tan Dinh Commune','tan_dinh','24',4),
('07444','Lục Nam','Luc Nam','Xã Lục Nam','Luc Nam Commune','luc_nam','24',4),
('07450','Đông Phú','Dong Phu','Xã Đông Phú','Dong Phu Commune','dong_phu','24',4),
('07462','Bảo Đài','Bao Dai','Xã Bảo Đài','Bao Dai Commune','bao_dai','24',4),
('07486','Nghĩa Phương','Nghia Phuong','Xã Nghĩa Phương','Nghia Phuong Commune','nghia_phuong','24',4),
('07489','Trường Sơn','Truong Son','Xã Trường Sơn','Truong Son Commune','truong_son','24',4),
('07492','Lục Sơn','Luc Son','Xã Lục Sơn','Luc Son Commune','luc_son','24',4),
('07498','Bắc Lũng','Bac Lung','Xã Bắc Lũng','Bac Lung Commune','bac_lung','24',4),
('07519','Cẩm Lý','Cam Ly','Xã Cẩm Lý','Cam Ly Commune','cam_ly','24',4),
('07525','Chũ','Chu','Phường Chũ','Chu Ward','chu','24',3),
('07531','Tân Sơn','Tan Son','Xã Tân Sơn','Tan Son Commune','tan_son','24',4),
('07534','Sa Lý','Sa Ly','Xã Sa Lý','Sa Ly Commune','sa_ly','24',4),
('07537','Biên Sơn','Bien Son','Xã Biên Sơn','Bien Son Commune','bien_son','24',4),
('07543','Sơn Hải','Son Hai','Xã Sơn Hải','Son Hai Commune','son_hai','24',4),
('07552','Kiên Lao','Kien Lao','Xã Kiên Lao','Kien Lao Commune','kien_lao','24',4),
('07573','Biển Động','Bien Dong','Xã Biển Động','Bien Dong Commune','bien_dong','24',4),
('07582','Lục Ngạn','Luc Ngan','Xã Lục Ngạn','Luc Ngan Commune','luc_ngan','24',4),
('07594','Đèo Gia','Deo Gia','Xã Đèo Gia','Deo Gia Commune','deo_gia','24',4),
('07603','Nam Dương','Nam Duong','Xã Nam Dương','Nam Duong Commune','nam_duong','24',4),
('07612','Phượng Sơn','Phuong Son','Phường Phượng Sơn','Phuong Son Ward','phuong_son','24',3),
('07615','Sơn Động','Son Dong','Xã Sơn Động','Son Dong Commune','son_dong','24',4),
('07616','Tây Yên Tử','Tay Yen Tu','Xã Tây Yên Tử','Tay Yen Tu Commune','tay_yen_tu','24',4),
('07621','Vân Sơn','Van Son','Xã Vân Sơn','Van Son Commune','van_son','24',4),
('07627','Đại Sơn','Dai Son','Xã Đại Sơn','Dai Son Commune','dai_son','24',4),
('07642','Yên Định','Yen Dinh','Xã Yên Định','Yen Dinh Commune','yen_dinh','24',4),
('07654','An Lạc','An Lac','Xã An Lạc','An Lac Commune','an_lac','24',4),
('07663','Tuấn Đạo','Tuan Dao','Xã Tuấn Đạo','Tuan Dao Commune','tuan_dao','24',4),
('07672','Dương Hưu','Duong Huu','Xã Dương Hưu','Duong Huu Commune','duong_huu','24',4),
('07681','Yên Dũng','Yen Dung','Phường Yên Dũng','Yen Dung Ward','yen_dung','24',3),
('07682','Tân An','Tan An','Phường Tân An','Tan An Ward','tan_an','24',3),
('07696','Tiền Phong','Tien Phong','Phường Tiền Phong','Tien Phong Ward','tien_phong','24',3),
('07699','Tân Tiến','Tan Tien','Phường Tân Tiến','Tan Tien Ward','tan_tien','24',3),
('07735','Đồng Việt','Dong Viet','Xã Đồng Việt','Dong Viet Commune','dong_viet','24',4),
('07738','Cảnh Thụy','Canh Thuy','Phường Cảnh Thụy','Canh Thuy Ward','canh_thuy','24',3),
('07774','Tự Lạn','Tu Lan','Phường Tự Lạn','Tu Lan Ward','tu_lan','24',3),
('07777','Việt Yên','Viet Yen','Phường Việt Yên','Viet Yen Ward','viet_yen','24',3),
('07795','Nếnh','Nenh','Phường Nếnh','Nenh Ward','nenh','24',3),
('07798','Vân Hà','Van Ha','Phường Vân Hà','Van Ha Ward','van_ha','24',3),
('07822','Hoàng Vân','Hoang Van','Xã Hoàng Vân','Hoang Van Commune','hoang_van','24',4),
('07840','Hiệp Hòa','Hiep Hoa','Xã Hiệp Hòa','Hiep Hoa Commune','hiep_hoa','24',4),
('07864','Hợp Thịnh','Hop Thinh','Xã Hợp Thịnh','Hop Thinh Commune','hop_thinh','24',4),
('07870','Xuân Cẩm','Xuan Cam','Xã Xuân Cẩm','Xuan Cam Commune','xuan_cam','24',4),
('07894','Nông Trang','Nong Trang','Phường Nông Trang','Nong Trang Ward','nong_trang','25',3),
('07900','Việt Trì','Viet Tri','Phường Việt Trì','Viet Tri Ward','viet_tri','25',3),
('07909','Thanh Miếu','Thanh Mieu','Phường Thanh Miếu','Thanh Mieu Ward','thanh_mieu','25',3),
('07918','Vân Phú','Van Phu','Phường Vân Phú','Van Phu Ward','van_phu','25',3),
('07942','Phú Thọ','Phu Tho','Phường Phú Thọ','Phu Tho Ward','phu_tho','25',3),
('07948','Âu Cơ','Au Co','Phường Âu Cơ','Au Co Ward','au_co','25',3),
('07954','Phong Châu','Phong Chau','Phường Phong Châu','Phong Chau Ward','phong_chau','25',3),
('07969','Đoan Hùng','Doan Hung','Xã Đoan Hùng','Doan Hung Commune','doan_hung','25',4),
('07996','Bằng Luân','Bang Luan','Xã Bằng Luân','Bang Luan Commune','bang_luan','25',4),
('07999','Chí Đám','Chi Dam','Xã Chí Đám','Chi Dam Commune','chi_dam','25',4),
('08023','Tây Cốc','Tay Coc','Xã Tây Cốc','Tay Coc Commune','tay_coc','25',4),
('08038','Chân Mộng','Chan Mong','Xã Chân Mộng','Chan Mong Commune','chan_mong','25',4),
('08053','Hạ Hòa','Ha Hoa','Xã Hạ Hòa','Ha Hoa Commune','ha_hoa','25',4),
('08071','Đan Thượng','Dan Thuong','Xã Đan Thượng','Dan Thuong Commune','dan_thuong','25',4),
('08110','Hiền Lương','Hien Luong','Xã Hiền Lương','Hien Luong Commune','hien_luong','25',4),
('08113','Yên Kỳ','Yen Ky','Xã Yên Kỳ','Yen Ky Commune','yen_ky','25',4),
('08134','Văn Lang','Van Lang','Xã Văn Lang','Van Lang Commune','van_lang','25',4),
('08143','Vĩnh Chân','Vinh Chan','Xã Vĩnh Chân','Vinh Chan Commune','vinh_chan','25',4),
('08152','Thanh Ba','Thanh Ba','Xã Thanh Ba','Thanh Ba Commune','thanh_ba','25',4),
('08173','Quảng Yên','Quang Yen','Xã Quảng Yên','Quang Yen Commune','quang_yen','25',4),
('08203','Hoàng Cương','Hoang Cuong','Xã Hoàng Cương','Hoang Cuong Commune','hoang_cuong','25',4),
('08209','Đông Thành','Dong Thanh','Xã Đông Thành','Dong Thanh Commune','dong_thanh','25',4),
('08218','Chí Tiên','Chi Tien','Xã Chí Tiên','Chi Tien Commune','chi_tien','25',4),
('08227','Liên Minh','Lien Minh','Xã Liên Minh','Lien Minh Commune','lien_minh','25',4),
('08230','Phù Ninh','Phu Ninh','Xã Phù Ninh','Phu Ninh Commune','phu_ninh','25',4),
('08236','Phú Mỹ','Phu My','Xã Phú Mỹ','Phu My Commune','phu_my','25',4),
('08245','Trạm Thản','Tram Than','Xã Trạm Thản','Tram Than Commune','tram_than','25',4),
('08254','Dân Chủ','Dan Chu','Xã Dân Chủ','Dan Chu Commune','dan_chu','25',4),
('08275','Bình Phú','Binh Phu','Xã Bình Phú','Binh Phu Commune','binh_phu','25',4),
('08290','Yên Lập','Yen Lap','Xã Yên Lập','Yen Lap Commune','yen_lap','25',4),
('08296','Sơn Lương','Son Luong','Xã Sơn Lương','Son Luong Commune','son_luong','25',4),
('08305','Xuân Viên','Xuan Vien','Xã Xuân Viên','Xuan Vien Commune','xuan_vien','25',4),
('08311','Trung Sơn','Trung Son','Xã Trung Sơn','Trung Son Commune','trung_son','25',4),
('08323','Thượng Long','Thuong Long','Xã Thượng Long','Thuong Long Commune','thuong_long','25',4),
('08338','Minh Hòa','Minh Hoa','Xã Minh Hòa','Minh Hoa Commune','minh_hoa','25',4),
('08341','Cẩm Khê','Cam Khe','Xã Cẩm Khê','Cam Khe Commune','cam_khe','25',4),
('08344','Tiên Lương','Tien Luong','Xã Tiên Lương','Tien Luong Commune','tien_luong','25',4),
('08377','Vân Bán','Van Ban','Xã Vân Bán','Van Ban Commune','van_ban','25',4),
('08398','Phú Khê','Phu Khe','Xã Phú Khê','Phu Khe Commune','phu_khe','25',4),
('08416','Hùng Việt','Hung Viet','Xã Hùng Việt','Hung Viet Commune','hung_viet','25',4),
('08431','Đồng Lương','Dong Luong','Xã Đồng Lương','Dong Luong Commune','dong_luong','25',4),
('08434','Tam Nông','Tam Nong','Xã Tam Nông','Tam Nong Commune','tam_nong','25',4),
('08443','Hiền Quan','Hien Quan','Xã Hiền Quan','Hien Quan Commune','hien_quan','25',4),
('08467','Vạn Xuân','Van Xuan','Xã Vạn Xuân','Van Xuan Commune','van_xuan','25',4),
('08479','Thọ Văn','Tho Van','Xã Thọ Văn','Tho Van Commune','tho_van','25',4),
('08494','Lâm Thao','Lam Thao','Xã Lâm Thao','Lam Thao Commune','lam_thao','25',4),
('08500','Xuân Lũng','Xuan Lung','Xã Xuân Lũng','Xuan Lung Commune','xuan_lung','25',4),
('08515','Hy Cương','Hy Cuong','Xã Hy Cương','Hy Cuong Commune','hy_cuong','25',4),
('08521','Phùng Nguyên','Phung Nguyen','Xã Phùng Nguyên','Phung Nguyen Commune','phung_nguyen','25',4),
('08527','Bản Nguyên','Ban Nguyen','Xã Bản Nguyên','Ban Nguyen Commune','ban_nguyen','25',4),
('08542','Thanh Sơn','Thanh Son','Xã Thanh Sơn','Thanh Son Commune','thanh_son','25',4),
('08545','Thu Cúc','Thu Cuc','Xã Thu Cúc','Thu Cuc Commune','thu_cuc','25',4),
('08560','Lai Đồng','Lai Dong','Xã Lai Đồng','Lai Dong Commune','lai_dong','25',4),
('08566','Tân Sơn','Tan Son','Xã Tân Sơn','Tan Son Commune','tan_son','25',4),
('08584','Võ Miếu','Vo Mieu','Xã Võ Miếu','Vo Mieu Commune','vo_mieu','25',4),
('08590','Xuân Đài','Xuan Dai','Xã Xuân Đài','Xuan Dai Commune','xuan_dai','25',4),
('08593','Minh Đài','Minh Dai','Xã Minh Đài','Minh Dai Commune','minh_dai','25',4),
('08611','Văn Miếu','Van Mieu','Xã Văn Miếu','Van Mieu Commune','van_mieu','25',4),
('08614','Cự Đồng','Cu Dong','Xã Cự Đồng','Cu Dong Commune','cu_dong','25',4),
('08620','Long Cốc','Long Coc','Xã Long Cốc','Long Coc Commune','long_coc','25',4),
('08632','Hương Cần','Huong Can','Xã Hương Cần','Huong Can Commune','huong_can','25',4),
('08635','Khả Cửu','Kha Cuu','Xã Khả Cửu','Kha Cuu Commune','kha_cuu','25',4),
('08656','Yên Sơn','Yen Son','Xã Yên Sơn','Yen Son Commune','yen_son','25',4),
('08662','Đào Xá','Dao Xa','Xã Đào Xá','Dao Xa Commune','dao_xa','25',4),
('08674','Thanh Thủy','Thanh Thuy','Xã Thanh Thủy','Thanh Thuy Commune','thanh_thuy','25',4),
('08686','Tu Vũ','Tu Vu','Xã Tu Vũ','Tu Vu Commune','tu_vu','25',4),
('08707','Vĩnh Yên','Vinh Yen','Phường Vĩnh Yên','Vinh Yen Ward','vinh_yen','25',3),
('08716','Vĩnh Phúc','Vinh Phuc','Phường Vĩnh Phúc','Vinh Phuc Ward','vinh_phuc','25',3),
('08740','Phúc Yên','Phuc Yen','Phường Phúc Yên','Phuc Yen Ward','phuc_yen','25',3),
('08746','Xuân Hòa','Xuan Hoa','Phường Xuân Hòa','Xuan Hoa Ward','xuan_hoa','25',3),
('08761','Lập Thạch','Lap Thach','Xã Lập Thạch','Lap Thach Commune','lap_thach','25',4),
('08770','Hợp Lý','Hop Ly','Xã Hợp Lý','Hop Ly Commune','hop_ly','25',4),
('08773','Yên Lãng','Yen Lang','Xã Yên Lãng','Yen Lang Commune','yen_lang','25',4),
('08782','Hải Lựu','Hai Luu','Xã Hải Lựu','Hai Luu Commune','hai_luu','25',4),
('08788','Thái Hòa','Thai Hoa','Xã Thái Hòa','Thai Hoa Commune','thai_hoa','25',4),
('08812','Liên Hòa','Lien Hoa','Xã Liên Hòa','Lien Hoa Commune','lien_hoa','25',4),
('08824','Tam Sơn','Tam Son','Xã Tam Sơn','Tam Son Commune','tam_son','25',4),
('08842','Tiên Lữ','Tien Lu','Xã Tiên Lữ','Tien Lu Commune','tien_lu','25',4),
('08848','Sông Lô','Song Lo','Xã Sông Lô','Song Lo Commune','song_lo','25',4),
('08866','Sơn Đông','Son Dong','Xã Sơn Đông','Son Dong Commune','son_dong','25',4),
('08869','Tam Dương','Tam Duong','Xã Tam Dương','Tam Duong Commune','tam_duong','25',4),
('08872','Tam Dương Bắc','Tam Duong Bac','Xã Tam Dương Bắc','Tam Duong Bac Commune','tam_duong_bac','25',4),
('08896','Hoàng An','Hoang An','Xã Hoàng An','Hoang An Commune','hoang_an','25',4),
('08905','Hội Thịnh','Hoi Thinh','Xã Hội Thịnh','Hoi Thinh Commune','hoi_thinh','25',4),
('08911','Tam Đảo','Tam Dao','Xã Tam Đảo','Tam Dao Commune','tam_dao','25',4),
('08914','Đạo Trù','Dao Tru','Xã Đạo Trù','Dao Tru Commune','dao_tru','25',4),
('08923','Đại Đình','Dai Dinh','Xã Đại Đình','Dai Dinh Commune','dai_dinh','25',4),
('08935','Bình Nguyên','Binh Nguyen','Xã Bình Nguyên','Binh Nguyen Commune','binh_nguyen','25',4),
('08944','Bình Tuyền','Binh Tuyen','Xã Bình Tuyền','Binh Tuyen Commune','binh_tuyen','25',4),
('08950','Bình Xuyên','Binh Xuyen','Xã Bình Xuyên','Binh Xuyen Commune','binh_xuyen','25',4),
('08971','Xuân Lãng','Xuan Lang','Xã Xuân Lãng','Xuan Lang Commune','xuan_lang','25',4),
('08974','Quang Minh','Quang Minh','Xã Quang Minh','Quang Minh Commune','quang_minh','01',4),
('08980','Yên Lãng','Yen Lang','Xã Yên Lãng','Yen Lang Commune','yen_lang','01',4),
('08995','Tiến Thắng','Tien Thang','Xã Tiến Thắng','Tien Thang Commune','tien_thang','01',4),
('09022','Mê Linh','Me Linh','Xã Mê Linh','Me Linh Commune','me_linh','01',4),
('09025','Yên Lạc','Yen Lac','Xã Yên Lạc','Yen Lac Commune','yen_lac','25',4),
('09040','Tề Lỗ','Te Lo','Xã Tề Lỗ','Te Lo Commune','te_lo','25',4),
('09043','Tam Hồng','Tam Hong','Xã Tam Hồng','Tam Hong Commune','tam_hong','25',4),
('09052','Nguyệt Đức','Nguyet Duc','Xã Nguyệt Đức','Nguyet Duc Commune','nguyet_duc','25',4),
('09064','Liên Châu','Lien Chau','Xã Liên Châu','Lien Chau Commune','lien_chau','25',4),
('09076','Vĩnh Tường','Vinh Tuong','Xã Vĩnh Tường','Vinh Tuong Commune','vinh_tuong','25',4),
('09079','Vĩnh An','Vinh An','Xã Vĩnh An','Vinh An Commune','vinh_an','25',4),
('09100','Vĩnh Hưng','Vinh Hung','Xã Vĩnh Hưng','Vinh Hung Commune','vinh_hung','25',4),
('09106','Vĩnh Thành','Vinh Thanh','Xã Vĩnh Thành','Vinh Thanh Commune','vinh_thanh','25',4),
('09112','Thổ Tang','Tho Tang','Xã Thổ Tang','Tho Tang Commune','tho_tang','25',4),
('09154','Vĩnh Phú','Vinh Phu','Xã Vĩnh Phú','Vinh Phu Commune','vinh_phu','25',4),
('09169','Vũ Ninh','Vu Ninh','Phường Vũ Ninh','Vu Ninh Ward','vu_ninh','24',3),
('09187','Kinh Bắc','Kinh Bac','Phường Kinh Bắc','Kinh Bac Ward','kinh_bac','24',3),
('09190','Võ Cường','Vo Cuong','Phường Võ Cường','Vo Cuong Ward','vo_cuong','24',3),
('09193','Yên Phong','Yen Phong','Xã Yên Phong','Yen Phong Commune','yen_phong','24',4),
('09202','Tam Giang','Tam Giang','Xã Tam Giang','Tam Giang Commune','tam_giang','24',4),
('09205','Yên Trung','Yen Trung','Xã Yên Trung','Yen Trung Commune','yen_trung','24',4),
('09208','Tam Đa','Tam Da','Xã Tam Đa','Tam Da Commune','tam_da','24',4),
('09238','Văn Môn','Van Mon','Xã Văn Môn','Van Mon Commune','van_mon','24',4),
('09247','Quế Võ','Que Vo','Phường Quế Võ','Que Vo Ward','que_vo','24',3),
('09253','Nhân Hòa','Nhan Hoa','Phường Nhân Hòa','Nhan Hoa Ward','nhan_hoa','24',3),
('09265','Phương Liễu','Phuong Lieu','Phường Phương Liễu','Phuong Lieu Ward','phuong_lieu','24',3),
('09286','Nam Sơn','Nam Son','Phường Nam Sơn','Nam Son Ward','nam_son','24',3),
('09292','Phù Lãng','Phu Lang','Xã Phù Lãng','Phu Lang Commune','phu_lang','24',4),
('09295','Bồng Lai','Bong Lai','Phường Bồng Lai','Bong Lai Ward','bong_lai','24',3),
('09301','Đào Viên','Dao Vien','Phường Đào Viên','Dao Vien Ward','dao_vien','24',3),
('09313','Chi Lăng','Chi Lang','Xã Chi Lăng','Chi Lang Commune','chi_lang','24',4),
('09319','Tiên Du','Tien Du','Xã Tiên Du','Tien Du Commune','tien_du','24',4),
('09325','Hạp Lĩnh','Hap Linh','Phường Hạp Lĩnh','Hap Linh Ward','hap_linh','24',3),
('09334','Liên Bão','Lien Bao','Xã Liên Bão','Lien Bao Commune','lien_bao','24',4),
('09340','Đại Đồng','Dai Dong','Xã Đại Đồng','Dai Dong Commune','dai_dong','24',4),
('09343','Tân Chi','Tan Chi','Xã Tân Chi','Tan Chi Commune','tan_chi','24',4),
('09349','Phật Tích','Phat Tich','Xã Phật Tích','Phat Tich Commune','phat_tich','24',4),
('09367','Từ Sơn','Tu Son','Phường Từ Sơn','Tu Son Ward','tu_son','24',3),
('09370','Tam Sơn','Tam Son','Phường Tam Sơn','Tam Son Ward','tam_son','24',3),
('09379','Phù Khê','Phu Khe','Phường Phù Khê','Phu Khe Ward','phu_khe','24',3),
('09385','Đồng Nguyên','Dong Nguyen','Phường Đồng Nguyên','Dong Nguyen Ward','dong_nguyen','24',3),
('09400','Thuận Thành','Thuan Thanh','Phường Thuận Thành','Thuan Thanh Ward','thuan_thanh','24',3),
('09409','Mão Điền','Mao Dien','Phường Mão Điền','Mao Dien Ward','mao_dien','24',3),
('09427','Trí Quả','Tri Qua','Phường Trí Quả','Tri Qua Ward','tri_qua','24',3),
('09430','Trạm Lộ','Tram Lo','Phường Trạm Lộ','Tram Lo Ward','tram_lo','24',3),
('09433','Song Liễu','Song Lieu','Phường Song Liễu','Song Lieu Ward','song_lieu','24',3),
('09445','Ninh Xá','Ninh Xa','Phường Ninh Xá','Ninh Xa Ward','ninh_xa','24',3),
('09454','Gia Bình','Gia Binh','Xã Gia Bình','Gia Binh Commune','gia_binh','24',4),
('09466','Cao Đức','Cao Duc','Xã Cao Đức','Cao Duc Commune','cao_duc','24',4),
('09469','Đại Lai','Dai Lai','Xã Đại Lai','Dai Lai Commune','dai_lai','24',4),
('09475','Nhân Thắng','Nhan Thang','Xã Nhân Thắng','Nhan Thang Commune','nhan_thang','24',4),
('09487','Đông Cứu','Dong Cuu','Xã Đông Cứu','Dong Cuu Commune','dong_cuu','24',4),
('09496','Lương Tài','Luong Tai','Xã Lương Tài','Luong Tai Commune','luong_tai','24',4),
('09499','Trung Kênh','Trung Kenh','Xã Trung Kênh','Trung Kenh Commune','trung_kenh','24',4),
('09523','Trung Chính','Trung Chinh','Xã Trung Chính','Trung Chinh Commune','trung_chinh','24',4),
('09529','Lâm Thao','Lam Thao','Xã Lâm Thao','Lam Thao Commune','lam_thao','24',4),
('09552','Kiến Hưng','Kien Hung','Phường Kiến Hưng','Kien Hung Ward','kien_hung','01',3),
('09556','Hà Đông','Ha Dong','Phường Hà Đông','Ha Dong Ward','ha_dong','01',3),
('09562','Yên Nghĩa','Yen Nghia','Phường Yên Nghĩa','Yen Nghia Ward','yen_nghia','01',3),
('09568','Phú Lương','Phu Luong','Phường Phú Lương','Phu Luong Ward','phu_luong','01',3),
('09574','Sơn Tây','Son Tay','Phường Sơn Tây','Son Tay Ward','son_tay','01',3),
('09604','Tùng Thiện','Tung Thien','Phường Tùng Thiện','Tung Thien Ward','tung_thien','01',3),
('09616','Đoài Phương','Doai Phuong','Xã Đoài Phương','Doai Phuong Commune','doai_phuong','01',4),
('09619','Quảng Oai','Quang Oai','Xã Quảng Oai','Quang Oai Commune','quang_oai','01',4),
('09634','Cổ Đô','Co Do','Xã Cổ Đô','Co Do Commune','co_do','01',4),
('09661','Minh Châu','Minh Chau','Xã Minh Châu','Minh Chau Commune','minh_chau','01',4),
('09664','Vật Lại','Vat Lai','Xã Vật Lại','Vat Lai Commune','vat_lai','01',4),
('09676','Bất Bạt','Bat Bat','Xã Bất Bạt','Bat Bat Commune','bat_bat','01',4),
('09694','Suối Hai','Suoi Hai','Xã Suối Hai','Suoi Hai Commune','suoi_hai','01',4),
('09700','Ba Vì','Ba Vi','Xã Ba Vì','Ba Vi Commune','ba_vi','01',4),
('09706','Yên Bài','Yen Bai','Xã Yên Bài','Yen Bai Commune','yen_bai','01',4),
('09715','Phúc Thọ','Phuc Tho','Xã Phúc Thọ','Phuc Tho Commune','phuc_tho','01',4),
('09739','Phúc Lộc','Phuc Loc','Xã Phúc Lộc','Phuc Loc Commune','phuc_loc','01',4),
('09772','Hát Môn','Hat Mon','Xã Hát Môn','Hat Mon Commune','hat_mon','01',4),
('09784','Đan Phượng','Dan Phuong','Xã Đan Phượng','Dan Phuong Commune','dan_phuong','01',4),
('09787','Liên Minh','Lien Minh','Xã Liên Minh','Lien Minh Commune','lien_minh','01',4),
('09817','Ô Diên','O Dien','Xã Ô Diên','O Dien Commune','o_dien','01',4),
('09832','Hoài Đức','Hoai Duc','Xã Hoài Đức','Hoai Duc Commune','hoai_duc','01',4),
('09856','Dương Hòa','Duong Hoa','Xã Dương Hòa','Duong Hoa Commune','duong_hoa','01',4),
('09871','Sơn Đồng','Son Dong','Xã Sơn Đồng','Son Dong Commune','son_dong','01',4),
('09877','An Khánh','An Khanh','Xã An Khánh','An Khanh Commune','an_khanh','01',4),
('09886','Dương Nội','Duong Noi','Phường Dương Nội','Duong Noi Ward','duong_noi','01',3),
('09895','Quốc Oai','Quoc Oai','Xã Quốc Oai','Quoc Oai Commune','quoc_oai','01',4),
('09910','Kiều Phú','Kieu Phu','Xã Kiều Phú','Kieu Phu Commune','kieu_phu','01',4),
('09931','Hưng Đạo','Hung Dao','Xã Hưng Đạo','Hung Dao Commune','hung_dao','01',4),
('09952','Phú Cát','Phu Cat','Xã Phú Cát','Phu Cat Commune','phu_cat','01',4),
('09955','Thạch Thất','Thach That','Xã Thạch Thất','Thach That Commune','thach_that','01',4),
('09982','Hạ Bằng','Ha Bang','Xã Hạ Bằng','Ha Bang Commune','ha_bang','01',4),
('09988','Hòa Lạc','Hoa Lac','Xã Hòa Lạc','Hoa Lac Commune','hoa_lac','01',4),
('10003','Tây Phương','Tay Phuong','Xã Tây Phương','Tay Phuong Commune','tay_phuong','01',4),
('10015','Chương Mỹ','Chuong My','Phường Chương Mỹ','Chuong My Ward','chuong_my','01',3),
('10030','Phú Nghĩa','Phu Nghia','Xã Phú Nghĩa','Phu Nghia Commune','phu_nghia','01',4),
('10045','Xuân Mai','Xuan Mai','Xã Xuân Mai','Xuan Mai Commune','xuan_mai','01',4),
('10072','Quảng Bị','Quang Bi','Xã Quảng Bị','Quang Bi Commune','quang_bi','01',4),
('10081','Trần Phú','Tran Phu','Xã Trần Phú','Tran Phu Commune','tran_phu','01',4),
('10096','Hòa Phú','Hoa Phu','Xã Hòa Phú','Hoa Phu Commune','hoa_phu','01',4),
('10114','Thanh Oai','Thanh Oai','Xã Thanh Oai','Thanh Oai Commune','thanh_oai','01',4),
('10126','Bình Minh','Binh Minh','Xã Bình Minh','Binh Minh Commune','binh_minh','01',4),
('10144','Tam Hưng','Tam Hung','Xã Tam Hưng','Tam Hung Commune','tam_hung','01',4),
('10180','Dân Hòa','Dan Hoa','Xã Dân Hòa','Dan Hoa Commune','dan_hoa','01',4),
('10183','Thường Tín','Thuong Tin','Xã Thường Tín','Thuong Tin Commune','thuong_tin','01',4),
('10210','Hồng Vân','Hong Van','Xã Hồng Vân','Hong Van Commune','hong_van','01',4),
('10231','Thượng Phúc','Thuong Phuc','Xã Thượng Phúc','Thuong Phuc Commune','thuong_phuc','01',4),
('10237','Chương Dương','Chuong Duong','Xã Chương Dương','Chuong Duong Commune','chuong_duong','01',4),
('10273','Phú Xuyên','Phu Xuyen','Xã Phú Xuyên','Phu Xuyen Commune','phu_xuyen','01',4),
('10279','Phượng Dực','Phuong Duc','Xã Phượng Dực','Phuong Duc Commune','phuong_duc','01',4),
('10330','Chuyên Mỹ','Chuyen My','Xã Chuyên Mỹ','Chuyen My Commune','chuyen_my','01',4),
('10342','Đại Xuyên','Dai Xuyen','Xã Đại Xuyên','Dai Xuyen Commune','dai_xuyen','01',4),
('10354','Vân Đình','Van Dinh','Xã Vân Đình','Van Dinh Commune','van_dinh','01',4),
('10369','Ứng Thiên','Ung Thien','Xã Ứng Thiên','Ung Thien Commune','ung_thien','01',4),
('10402','Ứng Hòa','Ung Hoa','Xã Ứng Hòa','Ung Hoa Commune','ung_hoa','01',4),
('10417','Hòa Xá','Hoa Xa','Xã Hòa Xá','Hoa Xa Commune','hoa_xa','01',4),
('10441','Mỹ Đức','My Duc','Xã Mỹ Đức','My Duc Commune','my_duc','01',4),
('10459','Phúc Sơn','Phuc Son','Xã Phúc Sơn','Phuc Son Commune','phuc_son','01',4),
('10465','Hồng Sơn','Hong Son','Xã Hồng Sơn','Hong Son Commune','hong_son','01',4),
('10489','Hương Sơn','Huong Son','Xã Hương Sơn','Huong Son Commune','huong_son','01',4),
('10507','Thành Đông','Thanh Dong','Phường Thành Đông','Thanh Dong Ward','thanh_dong','31',3),
('10525','Hải Dương','Hai Duong','Phường Hải Dương','Hai Duong Ward','hai_duong','31',3),
('10532','Lê Thanh Nghị','Le Thanh Nghi','Phường Lê Thanh Nghị','Le Thanh Nghi Ward','le_thanh_nghi','31',3),
('10537','Tân Hưng','Tan Hung','Phường Tân Hưng','Tan Hung Ward','tan_hung','31',3),
('10543','Việt Hòa','Viet Hoa','Phường Việt Hòa','Viet Hoa Ward','viet_hoa','31',3),
('10546','Chí Linh','Chi Linh','Phường Chí Linh','Chi Linh Ward','chi_linh','31',3),
('10549','Chu Văn An','Chu Van An','Phường Chu Văn An','Chu Van An Ward','chu_van_an','31',3),
('10552','Nguyễn Trãi','Nguyen Trai','Phường Nguyễn Trãi','Nguyen Trai Ward','nguyen_trai','31',3),
('10570','Trần Hưng Đạo','Tran Hung Dao','Phường Trần Hưng Đạo','Tran Hung Dao Ward','tran_hung_dao','31',3),
('10573','Trần Nhân Tông','Tran Nhan Tong','Phường Trần Nhân Tông','Tran Nhan Tong Ward','tran_nhan_tong','31',3),
('10603','Lê Đại Hành','Le Dai Hanh','Phường Lê Đại Hành','Le Dai Hanh Ward','le_dai_hanh','31',3),
('10606','Nam Sách','Nam Sach','Xã Nam Sách','Nam Sach Commune','nam_sach','31',4),
('10615','Hợp Tiến','Hop Tien','Xã Hợp Tiến','Hop Tien Commune','hop_tien','31',4),
('10633','Trần Phú','Tran Phu','Xã Trần Phú','Tran Phu Commune','tran_phu','31',4),
('10642','Thái Tân','Thai Tan','Xã Thái Tân','Thai Tan Commune','thai_tan','31',4),
('10645','An Phú','An Phu','Xã An Phú','An Phu Commune','an_phu','31',4),
('10660','Ái Quốc','Ai Quoc','Phường Ái Quốc','Ai Quoc Ward','ai_quoc','31',3),
('10675','Kinh Môn','Kinh Mon','Phường Kinh Môn','Kinh Mon Ward','kinh_mon','31',3),
('10678','Bắc An Phụ','Bac An Phu','Phường Bắc An Phụ','Bac An Phu Ward','bac_an_phu','31',3),
('10705','Nam An Phụ','Nam An Phu','Xã Nam An Phụ','Nam An Phu Commune','nam_an_phu','31',4),
('10714','Nhị Chiểu','Nhi Chieu','Phường Nhị Chiểu','Nhi Chieu Ward','nhi_chieu','31',3),
('10726','Phạm Sư Mạnh','Pham Su Manh','Phường Phạm Sư Mạnh','Pham Su Manh Ward','pham_su_manh','31',3),
('10729','Trần Liễu','Tran Lieu','Phường Trần Liễu','Tran Lieu Ward','tran_lieu','31',3),
('10744','Nguyễn Đại Năng','Nguyen Dai Nang','Phường Nguyễn Đại Năng','Nguyen Dai Nang Ward','nguyen_dai_nang','31',3),
('10750','Phú Thái','Phu Thai','Xã Phú Thái','Phu Thai Commune','phu_thai','31',4),
('10756','Lai Khê','Lai Khe','Xã Lai Khê','Lai Khe Commune','lai_khe','31',4),
('10792','An Thành','An Thanh','Xã An Thành','An Thanh Commune','an_thanh','31',4),
('10804','Kim Thành','Kim Thanh','Xã Kim Thành','Kim Thanh Commune','kim_thanh','31',4),
('10813','Thanh Hà','Thanh Ha','Xã Thanh Hà','Thanh Ha Commune','thanh_ha','31',4),
('10816','Hà Bắc','Ha Bac','Xã Hà Bắc','Ha Bac Commune','ha_bac','31',4),
('10837','Nam Đồng','Nam Dong','Phường Nam Đồng','Nam Dong Ward','nam_dong','31',3),
('10843','Hà Nam','Ha Nam','Xã Hà Nam','Ha Nam Commune','ha_nam','31',4),
('10846','Hà Tây','Ha Tay','Xã Hà Tây','Ha Tay Commune','ha_tay','31',4),
('10882','Hà Đông','Ha Dong','Xã Hà Đông','Ha Dong Commune','ha_dong','31',4),
('10888','Cẩm Giang','Cam Giang','Xã Cẩm Giang','Cam Giang Commune','cam_giang','31',4),
('10891','Tứ Minh','Tu Minh','Phường Tứ Minh','Tu Minh Ward','tu_minh','31',3),
('10903','Cẩm Giàng','Cam Giang','Xã Cẩm Giàng','Cam Giang Commune','cam_giang','31',4),
('10909','Tuệ Tĩnh','Tue Tinh','Xã Tuệ Tĩnh','Tue Tinh Commune','tue_tinh','31',4),
('10930','Mao Điền','Mao Dien','Xã Mao Điền','Mao Dien Commune','mao_dien','31',4),
('10945','Kẻ Sặt','Ke Sat','Xã Kẻ Sặt','Ke Sat Commune','ke_sat','31',4),
('10966','Bình Giang','Binh Giang','Xã Bình Giang','Binh Giang Commune','binh_giang','31',4),
('10972','Đường An','Duong An','Xã Đường An','Duong An Commune','duong_an','31',4),
('10993','Thượng Hồng','Thuong Hong','Xã Thượng Hồng','Thuong Hong Commune','thuong_hong','31',4),
('10999','Gia Lộc','Gia Loc','Xã Gia Lộc','Gia Loc Commune','gia_loc','31',4),
('11002','Thạch Khôi','Thach Khoi','Phường Thạch Khôi','Thach Khoi Ward','thach_khoi','31',3),
('11020','Yết Kiêu','Yet Kieu','Xã Yết Kiêu','Yet Kieu Commune','yet_kieu','31',4),
('11050','Gia Phúc','Gia Phuc','Xã Gia Phúc','Gia Phuc Commune','gia_phuc','31',4),
('11065','Trường Tân','Truong Tan','Xã Trường Tân','Truong Tan Commune','truong_tan','31',4),
('11074','Tứ Kỳ','Tu Ky','Xã Tứ Kỳ','Tu Ky Commune','tu_ky','31',4),
('11086','Đại Sơn','Dai Son','Xã Đại Sơn','Dai Son Commune','dai_son','31',4),
('11113','Tân Kỳ','Tan Ky','Xã Tân Kỳ','Tan Ky Commune','tan_ky','31',4),
('11131','Chí Minh','Chi Minh','Xã Chí Minh','Chi Minh Commune','chi_minh','31',4),
('11140','Lạc Phượng','Lac Phuong','Xã Lạc Phượng','Lac Phuong Commune','lac_phuong','31',4),
('11146','Nguyên Giáp','Nguyen Giap','Xã Nguyên Giáp','Nguyen Giap Commune','nguyen_giap','31',4),
('11164','Vĩnh Lại','Vinh Lai','Xã Vĩnh Lại','Vinh Lai Commune','vinh_lai','31',4),
('11167','Tân An','Tan An','Xã Tân An','Tan An Commune','tan_an','31',4),
('11203','Ninh Giang','Ninh Giang','Xã Ninh Giang','Ninh Giang Commune','ninh_giang','31',4),
('11218','Hồng Châu','Hong Chau','Xã Hồng Châu','Hong Chau Commune','hong_chau','31',4),
('11224','Khúc Thừa Dụ','Khuc Thua Du','Xã Khúc Thừa Dụ','Khuc Thua Du Commune','khuc_thua_du','31',4),
('11239','Thanh Miện','Thanh Mien','Xã Thanh Miện','Thanh Mien Commune','thanh_mien','31',4),
('11242','Nguyễn Lương Bằng','Nguyen Luong Bang','Xã Nguyễn Lương Bằng','Nguyen Luong Bang Commune','nguyen_luong_bang','31',4),
('11254','Bắc Thanh Miện','Bac Thanh Mien','Xã Bắc Thanh Miện','Bac Thanh Mien Commune','bac_thanh_mien','31',4),
('11257','Hải Hưng','Hai Hung','Xã Hải Hưng','Hai Hung Commune','hai_hung','31',4),
('11284','Nam Thanh Miện','Nam Thanh Mien','Xã Nam Thanh Miện','Nam Thanh Mien Commune','nam_thanh_mien','31',4),
('11311','Hồng Bàng','Hong Bang','Phường Hồng Bàng','Hong Bang Ward','hong_bang','31',3),
('11329','Ngô Quyền','Ngo Quyen','Phường Ngô Quyền','Ngo Quyen Ward','ngo_quyen','31',3),
('11359','Gia Viên','Gia Vien','Phường Gia Viên','Gia Vien Ward','gia_vien','31',3),
('11383','Lê Chân','Le Chan','Phường Lê Chân','Le Chan Ward','le_chan','31',3),
('11407','An Biên','An Bien','Phường An Biên','An Bien Ward','an_bien','31',3),
('11411','Đông Hải','Dong Hai','Phường Đông Hải','Dong Hai Ward','dong_hai','31',3),
('11413','Hải An','Hai An','Phường Hải An','Hai An Ward','hai_an','31',3),
('11443','Kiến An','Kien An','Phường Kiến An','Kien An Ward','kien_an','31',3),
('11446','Phù Liễn','Phu Lien','Phường Phù Liễn','Phu Lien Ward','phu_lien','31',3),
('11455','Đồ Sơn','Do Son','Phường Đồ Sơn','Do Son Ward','do_son','31',3),
('11473','Bạch Đằng','Bach Dang','Phường Bạch Đằng','Bach Dang Ward','bach_dang','31',3),
('11488','Lưu Kiếm','Luu Kiem','Phường Lưu Kiếm','Luu Kiem Ward','luu_kiem','31',3),
('11503','Việt Khê','Viet Khe','Xã Việt Khê','Viet Khe Commune','viet_khe','31',4),
('11506','Lê Ích Mộc','Le Ich Moc','Phường Lê Ích Mộc','Le Ich Moc Ward','le_ich_moc','31',3),
('11533','Hòa Bình','Hoa Binh','Phường Hòa Bình','Hoa Binh Ward','hoa_binh','31',3),
('11542','Nam Triệu','Nam Trieu','Phường Nam Triệu','Nam Trieu Ward','nam_trieu','31',3),
('11557','Thiên Hương','Thien Huong','Phường Thiên Hương','Thien Huong Ward','thien_huong','31',3),
('11560','Thủy Nguyên','Thuy Nguyen','Phường Thủy Nguyên','Thuy Nguyen Ward','thuy_nguyen','31',3),
('11581','An Dương','An Duong','Phường An Dương','An Duong Ward','an_duong','31',3),
('11593','An Phong','An Phong','Phường An Phong','An Phong Ward','an_phong','31',3),
('11602','Hồng An','Hong An','Phường Hồng An','Hong An Ward','hong_an','31',3),
('11617','An Hải','An Hai','Phường An Hải','An Hai Ward','an_hai','31',3),
('11629','An Lão','An Lao','Xã An Lão','An Lao Commune','an_lao','31',4),
('11635','An Trường','An Truong','Xã An Trường','An Truong Commune','an_truong','31',4),
('11647','An Quang','An Quang','Xã An Quang','An Quang Commune','an_quang','31',4),
('11668','An Khánh','An Khanh','Xã An Khánh','An Khanh Commune','an_khanh','31',4),
('11674','An Hưng','An Hung','Xã An Hưng','An Hung Commune','an_hung','31',4),
('11680','Kiến Thụy','Kien Thuy','Xã Kiến Thụy','Kien Thuy Commune','kien_thuy','31',4),
('11689','Hưng Đạo','Hung Dao','Phường Hưng Đạo','Hung Dao Ward','hung_dao','31',3),
('11692','Dương Kinh','Duong Kinh','Phường Dương Kinh','Duong Kinh Ward','duong_kinh','31',3),
('11713','Nghi Dương','Nghi Duong','Xã Nghi Dương','Nghi Duong Commune','nghi_duong','31',4),
('11725','Kiến Minh','Kien Minh','Xã Kiến Minh','Kien Minh Commune','kien_minh','31',4),
('11728','Kiến Hưng','Kien Hung','Xã Kiến Hưng','Kien Hung Commune','kien_hung','31',4),
('11737','Nam Đồ Sơn','Nam Do Son','Phường Nam Đồ Sơn','Nam Do Son Ward','nam_do_son','31',3),
('11749','Kiến Hải','Kien Hai','Xã Kiến Hải','Kien Hai Commune','kien_hai','31',4),
('11755','Tiên Lãng','Tien Lang','Xã Tiên Lãng','Tien Lang Commune','tien_lang','31',4),
('11761','Quyết Thắng','Quyet Thang','Xã Quyết Thắng','Quyet Thang Commune','quyet_thang','31',4),
('11779','Tân Minh','Tan Minh','Xã Tân Minh','Tan Minh Commune','tan_minh','31',4),
('11791','Tiên Minh','Tien Minh','Xã Tiên Minh','Tien Minh Commune','tien_minh','31',4),
('11806','Chấn Hưng','Chan Hung','Xã Chấn Hưng','Chan Hung Commune','chan_hung','31',4),
('11809','Hùng Thắng','Hung Thang','Xã Hùng Thắng','Hung Thang Commune','hung_thang','31',4),
('11824','Vĩnh Bảo','Vinh Bao','Xã Vĩnh Bảo','Vinh Bao Commune','vinh_bao','31',4),
('11836','Vĩnh Thịnh','Vinh Thinh','Xã Vĩnh Thịnh','Vinh Thinh Commune','vinh_thinh','31',4),
('11842','Vĩnh Thuận','Vinh Thuan','Xã Vĩnh Thuận','Vinh Thuan Commune','vinh_thuan','31',4),
('11848','Vĩnh Hòa','Vinh Hoa','Xã Vĩnh Hòa','Vinh Hoa Commune','vinh_hoa','31',4),
('11875','Vĩnh Hải','Vinh Hai','Xã Vĩnh Hải','Vinh Hai Commune','vinh_hai','31',4),
('11887','Vĩnh Am','Vinh Am','Xã Vĩnh Am','Vinh Am Commune','vinh_am','31',4),
('11911','Nguyễn Bỉnh Khiêm','Nguyen Binh Khiem','Xã Nguyễn Bỉnh Khiêm','Nguyen Binh Khiem Commune','nguyen_binh_khiem','31',4),
('11914','Cát Hải','Cat Hai','Đặc khu Cát Hải','Cat Hai Special administrative region','cat_hai','31',5),
('11948','Bạch Long Vĩ','Bach Long Vi','Đặc khu Bạch Long Vĩ','Bach Long Vi Special administrative region','bach_long_vi','31',5),
('11953','Phố Hiến','Pho Hien','Phường Phố Hiến','Pho Hien Ward','pho_hien','33',3),
('11977','Tân Hưng','Tan Hung','Xã Tân Hưng','Tan Hung Commune','tan_hung','33',4),
('11980','Hồng Châu','Hong Chau','Phường Hồng Châu','Hong Chau Ward','hong_chau','33',3),
('11983','Sơn Nam','Son Nam','Phường Sơn Nam','Son Nam Ward','son_nam','33',3),
('11992','Lạc Đạo','Lac Dao','Xã Lạc Đạo','Lac Dao Commune','lac_dao','33',4),
('11995','Đại Đồng','Dai Dong','Xã Đại Đồng','Dai Dong Commune','dai_dong','33',4),
('12004','Như Quỳnh','Nhu Quynh','Xã Như Quỳnh','Nhu Quynh Commune','nhu_quynh','33',4),
('12019','Văn Giang','Van Giang','Xã Văn Giang','Van Giang Commune','van_giang','33',4),
('12025','Phụng Công','Phung Cong','Xã Phụng Công','Phung Cong Commune','phung_cong','33',4),
('12031','Nghĩa Trụ','Nghia Tru','Xã Nghĩa Trụ','Nghia Tru Commune','nghia_tru','33',4),
('12049','Mễ Sở','Me So','Xã Mễ Sở','Me So Commune','me_so','33',4),
('12064','Nguyễn Văn Linh','Nguyen Van Linh','Xã Nguyễn Văn Linh','Nguyen Van Linh Commune','nguyen_van_linh','33',4),
('12070','Hoàn Long','Hoan Long','Xã Hoàn Long','Hoan Long Commune','hoan_long','33',4),
('12073','Yên Mỹ','Yen My','Xã Yên Mỹ','Yen My Commune','yen_my','33',4),
('12091','Việt Yên','Viet Yen','Xã Việt Yên','Viet Yen Commune','viet_yen','33',4),
('12103','Mỹ Hào','My Hao','Phường Mỹ Hào','My Hao Ward','my_hao','33',3),
('12127','Thượng Hồng','Thuong Hong','Phường Thượng Hồng','Thuong Hong Ward','thuong_hong','33',3),
('12133','Đường Hào','Duong Hao','Phường Đường Hào','Duong Hao Ward','duong_hao','33',3),
('12142','Ân Thi','An Thi','Xã Ân Thi','An Thi Commune','an_thi','33',4),
('12148','Phạm Ngũ Lão','Pham Ngu Lao','Xã Phạm Ngũ Lão','Pham Ngu Lao Commune','pham_ngu_lao','33',4),
('12166','Xuân Trúc','Xuan Truc','Xã Xuân Trúc','Xuan Truc Commune','xuan_truc','33',4),
('12184','Nguyễn Trãi','Nguyen Trai','Xã Nguyễn Trãi','Nguyen Trai Commune','nguyen_trai','33',4),
('12196','Hồng Quang','Hong Quang','Xã Hồng Quang','Hong Quang Commune','hong_quang','33',4),
('12205','Khoái Châu','Khoai Chau','Xã Khoái Châu','Khoai Chau Commune','khoai_chau','33',4),
('12223','Triệu Việt Vương','Trieu Viet Vuong','Xã Triệu Việt Vương','Trieu Viet Vuong Commune','trieu_viet_vuong','33',4),
('12238','Việt Tiến','Viet Tien','Xã Việt Tiến','Viet Tien Commune','viet_tien','33',4),
('12247','Châu Ninh','Chau Ninh','Xã Châu Ninh','Chau Ninh Commune','chau_ninh','33',4),
('12271','Chí Minh','Chi Minh','Xã Chí Minh','Chi Minh Commune','chi_minh','33',4),
('12280','Lương Bằng','Luong Bang','Xã Lương Bằng','Luong Bang Commune','luong_bang','33',4),
('12286','Nghĩa Dân','Nghia Dan','Xã Nghĩa Dân','Nghia Dan Commune','nghia_dan','33',4),
('12313','Đức Hợp','Duc Hop','Xã Đức Hợp','Duc Hop Commune','duc_hop','33',4),
('12322','Hiệp Cường','Hiep Cuong','Xã Hiệp Cường','Hiep Cuong Commune','hiep_cuong','33',4),
('12337','Hoàng Hoa Thám','Hoang Hoa Tham','Xã Hoàng Hoa Thám','Hoang Hoa Tham Commune','hoang_hoa_tham','33',4),
('12361','Tiên Hoa','Tien Hoa','Xã Tiên Hoa','Tien Hoa Commune','tien_hoa','33',4),
('12364','Tiên Lữ','Tien Lu','Xã Tiên Lữ','Tien Lu Commune','tien_lu','33',4),
('12391','Quang Hưng','Quang Hung','Xã Quang Hưng','Quang Hung Commune','quang_hung','33',4),
('12406','Đoàn Đào','Doan Dao','Xã Đoàn Đào','Doan Dao Commune','doan_dao','33',4),
('12424','Tiên Tiến','Tien Tien','Xã Tiên Tiến','Tien Tien Commune','tien_tien','33',4),
('12427','Tống Trân','Tong Tran','Xã Tống Trân','Tong Tran Commune','tong_tran','33',4),
('12452','Trần Hưng Đạo','Tran Hung Dao','Phường Trần Hưng Đạo','Tran Hung Dao Ward','tran_hung_dao','33',3),
('12454','Trần Lãm','Tran Lam','Phường Trần Lãm','Tran Lam Ward','tran_lam','33',3),
('12466','Vũ Phúc','Vu Phuc','Phường Vũ Phúc','Vu Phuc Ward','vu_phuc','33',3),
('12472','Quỳnh Phụ','Quynh Phu','Xã Quỳnh Phụ','Quynh Phu Commune','quynh_phu','33',4),
('12499','A Sào','A Sao','Xã A Sào','A Sao Commune','a_sao','33',4),
('12511','Minh Thọ','Minh Tho','Xã Minh Thọ','Minh Tho Commune','minh_tho','33',4),
('12517','Ngọc Lâm','Ngoc Lam','Xã Ngọc Lâm','Ngoc Lam Commune','ngoc_lam','33',4),
('12523','Phụ Dực','Phu Duc','Xã Phụ Dực','Phu Duc Commune','phu_duc','33',4),
('12526','Đồng Bằng','Dong Bang','Xã Đồng Bằng','Dong Bang Commune','dong_bang','33',4),
('12532','Nguyễn Du','Nguyen Du','Xã Nguyễn Du','Nguyen Du Commune','nguyen_du','33',4),
('12577','Quỳnh An','Quynh An','Xã Quỳnh An','Quynh An Commune','quynh_an','33',4),
('12583','Tân Tiến','Tan Tien','Xã Tân Tiến','Tan Tien Commune','tan_tien','33',4),
('12586','Hưng Hà','Hung Ha','Xã Hưng Hà','Hung Ha Commune','hung_ha','33',4),
('12595','Ngự Thiên','Ngu Thien','Xã Ngự Thiên','Ngu Thien Commune','ngu_thien','33',4),
('12613','Long Hưng','Long Hung','Xã Long Hưng','Long Hung Commune','long_hung','33',4),
('12619','Diên Hà','Dien Ha','Xã Diên Hà','Dien Ha Commune','dien_ha','33',4),
('12631','Thần Khê','Than Khe','Xã Thần Khê','Than Khe Commune','than_khe','33',4),
('12634','Tiên La','Tien La','Xã Tiên La','Tien La Commune','tien_la','33',4),
('12676','Lê Quý Đôn','Le Quy Don','Xã Lê Quý Đôn','Le Quy Don Commune','le_quy_don','33',4),
('12685','Hồng Minh','Hong Minh','Xã Hồng Minh','Hong Minh Commune','hong_minh','33',4),
('12688','Đông Hưng','Dong Hung','Xã Đông Hưng','Dong Hung Commune','dong_hung','33',4),
('12694','Bắc Đông Hưng','Bac Dong Hung','Xã Bắc Đông Hưng','Bac Dong Hung Commune','bac_dong_hung','33',4),
('12700','Bắc Tiên Hưng','Bac Tien Hung','Xã Bắc Tiên Hưng','Bac Tien Hung Commune','bac_tien_hung','33',4),
('12736','Đông Tiên Hưng','Dong Tien Hung','Xã Đông Tiên Hưng','Dong Tien Hung Commune','dong_tien_hung','33',4),
('12745','Bắc Đông Quan','Bac Dong Quan','Xã Bắc Đông Quan','Bac Dong Quan Commune','bac_dong_quan','33',4),
('12754','Tiên Hưng','Tien Hung','Xã Tiên Hưng','Tien Hung Commune','tien_hung','33',4),
('12763','Nam Tiên Hưng','Nam Tien Hung','Xã Nam Tiên Hưng','Nam Tien Hung Commune','nam_tien_hung','33',4),
('12775','Nam Đông Hưng','Nam Dong Hung','Xã Nam Đông Hưng','Nam Dong Hung Commune','nam_dong_hung','33',4),
('12793','Đông Quan','Dong Quan','Xã Đông Quan','Dong Quan Commune','dong_quan','33',4),
('12817','Trà Lý','Tra Ly','Phường Trà Lý','Tra Ly Ward','tra_ly','33',3),
('12826','Thái Thụy','Thai Thuy','Xã Thái Thụy','Thai Thuy Commune','thai_thuy','33',4),
('12850','Tây Thụy Anh','Tay Thuy Anh','Xã Tây Thụy Anh','Tay Thuy Anh Commune','tay_thuy_anh','33',4),
('12859','Bắc Thụy Anh','Bac Thuy Anh','Xã Bắc Thụy Anh','Bac Thuy Anh Commune','bac_thuy_anh','33',4),
('12862','Đông Thụy Anh','Dong Thuy Anh','Xã Đông Thụy Anh','Dong Thuy Anh Commune','dong_thuy_anh','33',4),
('12865','Thụy Anh','Thuy Anh','Xã Thụy Anh','Thuy Anh Commune','thuy_anh','33',4),
('12904','Nam Thụy Anh','Nam Thuy Anh','Xã Nam Thụy Anh','Nam Thuy Anh Commune','nam_thuy_anh','33',4),
('12916','Bắc Thái Ninh','Bac Thai Ninh','Xã Bắc Thái Ninh','Bac Thai Ninh Commune','bac_thai_ninh','33',4),
('12919','Tây Thái Ninh','Tay Thai Ninh','Xã Tây Thái Ninh','Tay Thai Ninh Commune','tay_thai_ninh','33',4),
('12922','Thái Ninh','Thai Ninh','Xã Thái Ninh','Thai Ninh Commune','thai_ninh','33',4),
('12943','Đông Thái Ninh','Dong Thai Ninh','Xã Đông Thái Ninh','Dong Thai Ninh Commune','dong_thai_ninh','33',4),
('12961','Nam Thái Ninh','Nam Thai Ninh','Xã Nam Thái Ninh','Nam Thai Ninh Commune','nam_thai_ninh','33',4),
('12970','Tiền Hải','Tien Hai','Xã Tiền Hải','Tien Hai Commune','tien_hai','33',4),
('12988','Đông Tiền Hải','Dong Tien Hai','Xã Đông Tiền Hải','Dong Tien Hai Commune','dong_tien_hai','33',4),
('13003','Đồng Châu','Dong Chau','Xã Đồng Châu','Dong Chau Commune','dong_chau','33',4),
('13021','Ái Quốc','Ai Quoc','Xã Ái Quốc','Ai Quoc Commune','ai_quoc','33',4),
('13039','Tây Tiền Hải','Tay Tien Hai','Xã Tây Tiền Hải','Tay Tien Hai Commune','tay_tien_hai','33',4),
('13057','Nam Cường','Nam Cuong','Xã Nam Cường','Nam Cuong Commune','nam_cuong','33',4),
('13063','Nam Tiền Hải','Nam Tien Hai','Xã Nam Tiền Hải','Nam Tien Hai Commune','nam_tien_hai','33',4),
('13066','Hưng Phú','Hung Phu','Xã Hưng Phú','Hung Phu Commune','hung_phu','33',4),
('13075','Kiến Xương','Kien Xuong','Xã Kiến Xương','Kien Xuong Commune','kien_xuong','33',4),
('13093','Trà Giang','Tra Giang','Xã Trà Giang','Tra Giang Commune','tra_giang','33',4),
('13096','Bình Nguyên','Binh Nguyen','Xã Bình Nguyên','Binh Nguyen Commune','binh_nguyen','33',4),
('13120','Lê Lợi','Le Loi','Xã Lê Lợi','Le Loi Commune','le_loi','33',4),
('13132','Quang Lịch','Quang Lich','Xã Quang Lịch','Quang Lich Commune','quang_lich','33',4),
('13141','Vũ Quý','Vu Quy','Xã Vũ Quý','Vu Quy Commune','vu_quy','33',4),
('13159','Hồng Vũ','Hong Vu','Xã Hồng Vũ','Hong Vu Commune','hong_vu','33',4),
('13183','Bình Thanh','Binh Thanh','Xã Bình Thanh','Binh Thanh Commune','binh_thanh','33',4),
('13186','Bình Định','Binh Dinh','Xã Bình Định','Binh Dinh Commune','binh_dinh','33',4),
('13192','Vũ Thư','Vu Thu','Xã Vũ Thư','Vu Thu Commune','vu_thu','33',4),
('13219','Vạn Xuân','Van Xuan','Xã Vạn Xuân','Van Xuan Commune','van_xuan','33',4),
('13222','Thư Trì','Thu Tri','Xã Thư Trì','Thu Tri Commune','thu_tri','33',4),
('13225','Thái Bình','Thai Binh','Phường Thái Bình','Thai Binh Ward','thai_binh','33',3),
('13246','Tân Thuận','Tan Thuan','Xã Tân Thuận','Tan Thuan Commune','tan_thuan','33',4),
('13264','Thư Vũ','Thu Vu','Xã Thư Vũ','Thu Vu Commune','thu_vu','33',4),
('13279','Vũ Tiên','Vu Tien','Xã Vũ Tiên','Vu Tien Commune','vu_tien','33',4),
('13285','Phủ Lý','Phu Ly','Phường Phủ Lý','Phu Ly Ward','phu_ly','37',3),
('13291','Phù Vân','Phu Van','Phường Phù Vân','Phu Van Ward','phu_van','37',3),
('13318','Châu Sơn','Chau Son','Phường Châu Sơn','Chau Son Ward','chau_son','37',3),
('13324','Duy Tiên','Duy Tien','Phường Duy Tiên','Duy Tien Ward','duy_tien','37',3),
('13330','Duy Tân','Duy Tan','Phường Duy Tân','Duy Tan Ward','duy_tan','37',3),
('13336','Duy Hà','Duy Ha','Phường Duy Hà','Duy Ha Ward','duy_ha','37',3),
('13348','Đồng Văn','Dong Van','Phường Đồng Văn','Dong Van Ward','dong_van','37',3),
('13363','Tiên Sơn','Tien Son','Phường Tiên Sơn','Tien Son Ward','tien_son','37',3),
('13366','Hà Nam','Ha Nam','Phường Hà Nam','Ha Nam Ward','ha_nam','37',3),
('13384','Kim Bảng','Kim Bang','Phường Kim Bảng','Kim Bang Ward','kim_bang','37',3),
('13393','Lê Hồ','Le Ho','Phường Lê Hồ','Le Ho Ward','le_ho','37',3),
('13396','Nguyễn Úy','Nguyen Uy','Phường Nguyễn Úy','Nguyen Uy Ward','nguyen_uy','37',3),
('13402','Kim Thanh','Kim Thanh','Phường Kim Thanh','Kim Thanh Ward','kim_thanh','37',3),
('13420','Tam Chúc','Tam Chuc','Phường Tam Chúc','Tam Chuc Ward','tam_chuc','37',3),
('13435','Lý Thường Kiệt','Ly Thuong Kiet','Phường Lý Thường Kiệt','Ly Thuong Kiet Ward','ly_thuong_kiet','37',3),
('13444','Liêm Tuyền','Liem Tuyen','Phường Liêm Tuyền','Liem Tuyen Ward','liem_tuyen','37',3),
('13456','Liêm Hà','Liem Ha','Xã Liêm Hà','Liem Ha Commune','liem_ha','37',4),
('13474','Tân Thanh','Tan Thanh','Xã Tân Thanh','Tan Thanh Commune','tan_thanh','37',4),
('13483','Thanh Bình','Thanh Binh','Xã Thanh Bình','Thanh Binh Commune','thanh_binh','37',4),
('13489','Thanh Lâm','Thanh Lam','Xã Thanh Lâm','Thanh Lam Commune','thanh_lam','37',4),
('13495','Thanh Liêm','Thanh Liem','Xã Thanh Liêm','Thanh Liem Commune','thanh_liem','37',4),
('13501','Bình Mỹ','Binh My','Xã Bình Mỹ','Binh My Commune','binh_my','37',4),
('13504','Bình Lục','Binh Luc','Xã Bình Lục','Binh Luc Commune','binh_luc','37',4),
('13531','Bình Giang','Binh Giang','Xã Bình Giang','Binh Giang Commune','binh_giang','37',4),
('13540','Bình An','Binh An','Xã Bình An','Binh An Commune','binh_an','37',4),
('13558','Bình Sơn','Binh Son','Xã Bình Sơn','Binh Son Commune','binh_son','37',4),
('13573','Lý Nhân','Ly Nhan','Xã Lý Nhân','Ly Nhan Commune','ly_nhan','37',4),
('13579','Bắc Lý','Bac Ly','Xã Bắc Lý','Bac Ly Commune','bac_ly','37',4),
('13591','Nam Xang','Nam Xang','Xã Nam Xang','Nam Xang Commune','nam_xang','37',4),
('13594','Trần Thương','Tran Thuong','Xã Trần Thương','Tran Thuong Commune','tran_thuong','37',4),
('13597','Vĩnh Trụ','Vinh Tru','Xã Vĩnh Trụ','Vinh Tru Commune','vinh_tru','37',4),
('13609','Nhân Hà','Nhan Ha','Xã Nhân Hà','Nhan Ha Commune','nhan_ha','37',4),
('13627','Nam Lý','Nam Ly','Xã Nam Lý','Nam Ly Commune','nam_ly','37',4),
('13669','Nam Định','Nam Dinh','Phường Nam Định','Nam Dinh Ward','nam_dinh','37',3),
('13684','Thiên Trường','Thien Truong','Phường Thiên Trường','Thien Truong Ward','thien_truong','37',3),
('13693','Đông A','Dong A','Phường Đông A','Dong A Ward','dong_a','37',3),
('13699','Thành Nam','Thanh Nam','Phường Thành Nam','Thanh Nam Ward','thanh_nam','37',3),
('13708','Mỹ Lộc','My Loc','Phường Mỹ Lộc','My Loc Ward','my_loc','37',3),
('13741','Vụ Bản','Vu Ban','Xã Vụ Bản','Vu Ban Commune','vu_ban','37',4),
('13750','Minh Tân','Minh Tan','Xã Minh Tân','Minh Tan Commune','minh_tan','37',4),
('13753','Hiển Khánh','Hien Khanh','Xã Hiển Khánh','Hien Khanh Commune','hien_khanh','37',4),
('13777','Trường Thi','Truong Thi','Phường Trường Thi','Truong Thi Ward','truong_thi','37',3),
('13786','Liên Minh','Lien Minh','Xã Liên Minh','Lien Minh Commune','lien_minh','37',4),
('13795','Ý Yên','Y Yen','Xã Ý Yên','Y Yen Commune','y_yen','37',4),
('13807','Tân Minh','Tan Minh','Xã Tân Minh','Tan Minh Commune','tan_minh','37',4),
('13822','Phong Doanh','Phong Doanh','Xã Phong Doanh','Phong Doanh Commune','phong_doanh','37',4),
('13834','Vũ Dương','Vu Duong','Xã Vũ Dương','Vu Duong Commune','vu_duong','37',4),
('13864','Vạn Thắng','Van Thang','Xã Vạn Thắng','Van Thang Commune','van_thang','37',4),
('13870','Yên Cường','Yen Cuong','Xã Yên Cường','Yen Cuong Commune','yen_cuong','37',4),
('13879','Yên Đồng','Yen Dong','Xã Yên Đồng','Yen Dong Commune','yen_dong','37',4),
('13891','Nghĩa Hưng','Nghia Hung','Xã Nghĩa Hưng','Nghia Hung Commune','nghia_hung','37',4),
('13894','Rạng Đông','Rang Dong','Xã Rạng Đông','Rang Dong Commune','rang_dong','37',4),
('13900','Đồng Thịnh','Dong Thinh','Xã Đồng Thịnh','Dong Thinh Commune','dong_thinh','37',4),
('13918','Nghĩa Sơn','Nghia Son','Xã Nghĩa Sơn','Nghia Son Commune','nghia_son','37',4),
('13927','Hồng Phong','Hong Phong','Xã Hồng Phong','Hong Phong Commune','hong_phong','37',4),
('13939','Quỹ Nhất','Quy Nhat','Xã Quỹ Nhất','Quy Nhat Commune','quy_nhat','37',4),
('13957','Nghĩa Lâm','Nghia Lam','Xã Nghĩa Lâm','Nghia Lam Commune','nghia_lam','37',4),
('13966','Nam Trực','Nam Truc','Xã Nam Trực','Nam Truc Commune','nam_truc','37',4),
('13972','Vị Khê','Vi Khe','Phường Vị Khê','Vi Khe Ward','vi_khe','37',3),
('13984','Hồng Quang','Hong Quang','Phường Hồng Quang','Hong Quang Ward','hong_quang','37',3),
('13987','Nam Hồng','Nam Hong','Xã Nam Hồng','Nam Hong Commune','nam_hong','37',4),
('14005','Nam Ninh','Nam Ninh','Xã Nam Ninh','Nam Ninh Commune','nam_ninh','37',4),
('14011','Nam Minh','Nam Minh','Xã Nam Minh','Nam Minh Commune','nam_minh','37',4),
('14014','Nam Đồng','Nam Dong','Xã Nam Đồng','Nam Dong Commune','nam_dong','37',4),
('14026','Cổ Lễ','Co Le','Xã Cổ Lễ','Co Le Commune','co_le','37',4),
('14038','Ninh Giang','Ninh Giang','Xã Ninh Giang','Ninh Giang Commune','ninh_giang','37',4),
('14053','Trực Ninh','Truc Ninh','Xã Trực Ninh','Truc Ninh Commune','truc_ninh','37',4),
('14056','Cát Thành','Cat Thanh','Xã Cát Thành','Cat Thanh Commune','cat_thanh','37',4),
('14062','Quang Hưng','Quang Hung','Xã Quang Hưng','Quang Hung Commune','quang_hung','37',4),
('14071','Minh Thái','Minh Thai','Xã Minh Thái','Minh Thai Commune','minh_thai','37',4),
('14077','Ninh Cường','Ninh Cuong','Xã Ninh Cường','Ninh Cuong Commune','ninh_cuong','37',4),
('14089','Xuân Trường','Xuan Truong','Xã Xuân Trường','Xuan Truong Commune','xuan_truong','37',4),
('14095','Xuân Hồng','Xuan Hong','Xã Xuân Hồng','Xuan Hong Commune','xuan_hong','37',4),
('14104','Xuân Giang','Xuan Giang','Xã Xuân Giang','Xuan Giang Commune','xuan_giang','37',4),
('14122','Xuân Hưng','Xuan Hung','Xã Xuân Hưng','Xuan Hung Commune','xuan_hung','37',4),
('14161','Giao Minh','Giao Minh','Xã Giao Minh','Giao Minh Commune','giao_minh','37',4),
('14167','Giao Thủy','Giao Thuy','Xã Giao Thủy','Giao Thuy Commune','giao_thuy','37',4),
('14179','Giao Hưng','Giao Hung','Xã Giao Hưng','Giao Hung Commune','giao_hung','37',4),
('14182','Giao Hòa','Giao Hoa','Xã Giao Hòa','Giao Hoa Commune','giao_hoa','37',4),
('14194','Giao Bình','Giao Binh','Xã Giao Bình','Giao Binh Commune','giao_binh','37',4),
('14203','Giao Phúc','Giao Phuc','Xã Giao Phúc','Giao Phuc Commune','giao_phuc','37',4),
('14212','Giao Ninh','Giao Ninh','Xã Giao Ninh','Giao Ninh Commune','giao_ninh','37',4),
('14215','Hải Hậu','Hai Hau','Xã Hải Hậu','Hai Hau Commune','hai_hau','37',4),
('14218','Hải Tiến','Hai Tien','Xã Hải Tiến','Hai Tien Commune','hai_tien','37',4),
('14221','Hải Thịnh','Hai Thinh','Xã Hải Thịnh','Hai Thinh Commune','hai_thinh','37',4),
('14236','Hải Anh','Hai Anh','Xã Hải Anh','Hai Anh Commune','hai_anh','37',4),
('14248','Hải Hưng','Hai Hung','Xã Hải Hưng','Hai Hung Commune','hai_hung','37',4),
('14281','Hải An','Hai An','Xã Hải An','Hai An Commune','hai_an','37',4),
('14287','Hải Quang','Hai Quang','Xã Hải Quang','Hai Quang Commune','hai_quang','37',4),
('14308','Hải Xuân','Hai Xuan','Xã Hải Xuân','Hai Xuan Commune','hai_xuan','37',4),
('14329','Hoa Lư','Hoa Lu','Phường Hoa Lư','Hoa Lu Ward','hoa_lu','37',3),
('14359','Nam Hoa Lư','Nam Hoa Lu','Phường Nam Hoa Lư','Nam Hoa Lu Ward','nam_hoa_lu','37',3),
('14362','Tam Điệp','Tam Diep','Phường Tam Điệp','Tam Diep Ward','tam_diep','37',3),
('14365','Trung Sơn','Trung Son','Phường Trung Sơn','Trung Son Ward','trung_son','37',3),
('14371','Yên Sơn','Yen Son','Phường Yên Sơn','Yen Son Ward','yen_son','37',3),
('14389','Gia Lâm','Gia Lam','Xã Gia Lâm','Gia Lam Commune','gia_lam','37',4),
('14401','Gia Tường','Gia Tuong','Xã Gia Tường','Gia Tuong Commune','gia_tuong','37',4),
('14404','Cúc Phương','Cuc Phuong','Xã Cúc Phương','Cuc Phuong Commune','cuc_phuong','37',4),
('14407','Phú Sơn','Phu Son','Xã Phú Sơn','Phu Son Commune','phu_son','37',4),
('14428','Nho Quan','Nho Quan','Xã Nho Quan','Nho Quan Commune','nho_quan','37',4),
('14434','Thanh Sơn','Thanh Son','Xã Thanh Sơn','Thanh Son Commune','thanh_son','37',4),
('14452','Quỳnh Lưu','Quynh Luu','Xã Quỳnh Lưu','Quynh Luu Commune','quynh_luu','37',4),
('14458','Phú Long','Phu Long','Xã Phú Long','Phu Long Commune','phu_long','37',4),
('14464','Gia Viễn','Gia Vien','Xã Gia Viễn','Gia Vien Commune','gia_vien','37',4),
('14482','Gia Hưng','Gia Hung','Xã Gia Hưng','Gia Hung Commune','gia_hung','37',4),
('14488','Gia Vân','Gia Van','Xã Gia Vân','Gia Van Commune','gia_van','37',4),
('14494','Gia Trấn','Gia Tran','Xã Gia Trấn','Gia Tran Commune','gia_tran','37',4),
('14500','Đại Hoàng','Dai Hoang','Xã Đại Hoàng','Dai Hoang Commune','dai_hoang','37',4),
('14524','Gia Phong','Gia Phong','Xã Gia Phong','Gia Phong Commune','gia_phong','37',4),
('14533','Tây Hoa Lư','Tay Hoa Lu','Phường Tây Hoa Lư','Tay Hoa Lu Ward','tay_hoa_lu','37',3),
('14560','Yên Khánh','Yen Khanh','Xã Yên Khánh','Yen Khanh Commune','yen_khanh','37',4),
('14563','Khánh Thiện','Khanh Thien','Xã Khánh Thiện','Khanh Thien Commune','khanh_thien','37',4),
('14566','Đông Hoa Lư','Dong Hoa Lu','Phường Đông Hoa Lư','Dong Hoa Lu Ward','dong_hoa_lu','37',3),
('14608','Khánh Trung','Khanh Trung','Xã Khánh Trung','Khanh Trung Commune','khanh_trung','37',4),
('14611','Khánh Nhạc','Khanh Nhac','Xã Khánh Nhạc','Khanh Nhac Commune','khanh_nhac','37',4),
('14614','Khánh Hội','Khanh Hoi','Xã Khánh Hội','Khanh Hoi Commune','khanh_hoi','37',4),
('14620','Phát Diệm','Phat Diem','Xã Phát Diệm','Phat Diem Commune','phat_diem','37',4),
('14623','Bình Minh','Binh Minh','Xã Bình Minh','Binh Minh Commune','binh_minh','37',4),
('14638','Kim Sơn','Kim Son','Xã Kim Sơn','Kim Son Commune','kim_son','37',4),
('14647','Quang Thiện','Quang Thien','Xã Quang Thiện','Quang Thien Commune','quang_thien','37',4),
('14653','Chất Bình','Chat Binh','Xã Chất Bình','Chat Binh Commune','chat_binh','37',4),
('14674','Lai Thành','Lai Thanh','Xã Lai Thành','Lai Thanh Commune','lai_thanh','37',4),
('14677','Định Hóa','Dinh Hoa','Xã Định Hóa','Dinh Hoa Commune','dinh_hoa','37',4),
('14698','Kim Đông','Kim Dong','Xã Kim Đông','Kim Dong Commune','kim_dong','37',4),
('14701','Yên Mô','Yen Mo','Xã Yên Mô','Yen Mo Commune','yen_mo','37',4),
('14725','Yên Thắng','Yen Thang','Phường Yên Thắng','Yen Thang Ward','yen_thang','37',3),
('14728','Yên Từ','Yen Tu','Xã Yên Từ','Yen Tu Commune','yen_tu','37',4),
('14743','Yên Mạc','Yen Mac','Xã Yên Mạc','Yen Mac Commune','yen_mac','37',4),
('14746','Đồng Thái','Dong Thai','Xã Đồng Thái','Dong Thai Commune','dong_thai','37',4),
('14758','Hàm Rồng','Ham Rong','Phường Hàm Rồng','Ham Rong Ward','ham_rong','38',3),
('14797','Hạc Thành','Hac Thanh','Phường Hạc Thành','Hac Thanh Ward','hac_thanh','38',3),
('14812','Bỉm Sơn','Bim Son','Phường Bỉm Sơn','Bim Son Ward','bim_son','38',3),
('14818','Quang Trung','Quang Trung','Phường Quang Trung','Quang Trung Ward','quang_trung','38',3),
('14845','Mường Lát','Muong Lat','Xã Mường Lát','Muong Lat Commune','muong_lat','38',4),
('14848','Tam Chung','Tam Chung','Xã Tam Chung','Tam Chung Commune','tam_chung','38',4),
('14854','Mường Lý','Muong Ly','Xã Mường Lý','Muong Ly Commune','muong_ly','38',4),
('14857','Trung Lý','Trung Ly','Xã Trung Lý','Trung Ly Commune','trung_ly','38',4),
('14860','Quang Chiểu','Quang Chieu','Xã Quang Chiểu','Quang Chieu Commune','quang_chieu','38',4),
('14863','Pù Nhi','Pu Nhi','Xã Pù Nhi','Pu Nhi Commune','pu_nhi','38',4),
('14864','Nhi Sơn','Nhi Son','Xã Nhi Sơn','Nhi Son Commune','nhi_son','38',4),
('14866','Mường Chanh','Muong Chanh','Xã Mường Chanh','Muong Chanh Commune','muong_chanh','38',4),
('14869','Hồi Xuân','Hoi Xuan','Xã Hồi Xuân','Hoi Xuan Commune','hoi_xuan','38',4),
('14872','Trung Thành','Trung Thanh','Xã Trung Thành','Trung Thanh Commune','trung_thanh','38',4),
('14875','Trung Sơn','Trung Son','Xã Trung Sơn','Trung Son Commune','trung_son','38',4),
('14878','Phú Lệ','Phu Le','Xã Phú Lệ','Phu Le Commune','phu_le','38',4),
('14890','Phú Xuân','Phu Xuan','Xã Phú Xuân','Phu Xuan Commune','phu_xuan','38',4),
('14896','Hiền Kiệt','Hien Kiet','Xã Hiền Kiệt','Hien Kiet Commune','hien_kiet','38',4),
('14902','Nam Xuân','Nam Xuan','Xã Nam Xuân','Nam Xuan Commune','nam_xuan','38',4),
('14908','Thiên Phủ','Thien Phu','Xã Thiên Phủ','Thien Phu Commune','thien_phu','38',4),
('14923','Bá Thước','Ba Thuoc','Xã Bá Thước','Ba Thuoc Commune','ba_thuoc','38',4),
('14932','Điền Quang','Dien Quang','Xã Điền Quang','Dien Quang Commune','dien_quang','38',4),
('14950','Điền Lư','Dien Lu','Xã Điền Lư','Dien Lu Commune','dien_lu','38',4),
('14953','Quý Lương','Quy Luong','Xã Quý Lương','Quy Luong Commune','quy_luong','38',4),
('14956','Pù Luông','Pu Luong','Xã Pù Luông','Pu Luong Commune','pu_luong','38',4),
('14959','Cổ Lũng','Co Lung','Xã Cổ Lũng','Co Lung Commune','co_lung','38',4),
('14974','Văn Nho','Van Nho','Xã Văn Nho','Van Nho Commune','van_nho','38',4),
('14980','Thiết Ống','Thiet Ong','Xã Thiết Ống','Thiet Ong Commune','thiet_ong','38',4),
('15001','Trung Hạ','Trung Ha','Xã Trung Hạ','Trung Ha Commune','trung_ha','38',4),
('15007','Tam Thanh','Tam Thanh','Xã Tam Thanh','Tam Thanh Commune','tam_thanh','38',4),
('15010','Sơn Thủy','Son Thuy','Xã Sơn Thủy','Son Thuy Commune','son_thuy','38',4),
('15013','Na Mèo','Na Meo','Xã Na Mèo','Na Meo Commune','na_meo','38',4),
('15016','Quan Sơn','Quan Son','Xã Quan Sơn','Quan Son Commune','quan_son','38',4),
('15019','Tam Lư','Tam Lu','Xã Tam Lư','Tam Lu Commune','tam_lu','38',4),
('15022','Sơn Điện','Son Dien','Xã Sơn Điện','Son Dien Commune','son_dien','38',4),
('15025','Mường Mìn','Muong Min','Xã Mường Mìn','Muong Min Commune','muong_min','38',4),
('15031','Yên Khương','Yen Khuong','Xã Yên Khương','Yen Khuong Commune','yen_khuong','38',4),
('15034','Yên Thắng','Yen Thang','Xã Yên Thắng','Yen Thang Commune','yen_thang','38',4),
('15043','Giao An','Giao An','Xã Giao An','Giao An Commune','giao_an','38',4),
('15049','Văn Phú','Van Phu','Xã Văn Phú','Van Phu Commune','van_phu','38',4),
('15055','Linh Sơn','Linh Son','Xã Linh Sơn','Linh Son Commune','linh_son','38',4),
('15058','Đồng Lương','Dong Luong','Xã Đồng Lương','Dong Luong Commune','dong_luong','38',4),
('15061','Ngọc Lặc','Ngoc Lac','Xã Ngọc Lặc','Ngoc Lac Commune','ngoc_lac','38',4),
('15085','Thạch Lập','Thach Lap','Xã Thạch Lập','Thach Lap Commune','thach_lap','38',4),
('15091','Ngọc Liên','Ngoc Lien','Xã Ngọc Liên','Ngoc Lien Commune','ngoc_lien','38',4),
('15106','Nguyệt Ấn','Nguyet An','Xã Nguyệt Ấn','Nguyet An Commune','nguyet_an','38',4),
('15112','Kiên Thọ','Kien Tho','Xã Kiên Thọ','Kien Tho Commune','kien_tho','38',4),
('15124','Minh Sơn','Minh Son','Xã Minh Sơn','Minh Son Commune','minh_son','38',4),
('15127','Cẩm Thủy','Cam Thuy','Xã Cẩm Thủy','Cam Thuy Commune','cam_thuy','38',4),
('15142','Cẩm Thạch','Cam Thach','Xã Cẩm Thạch','Cam Thach Commune','cam_thach','38',4),
('15148','Cẩm Tú','Cam Tu','Xã Cẩm Tú','Cam Tu Commune','cam_tu','38',4),
('15163','Cẩm Vân','Cam Van','Xã Cẩm Vân','Cam Van Commune','cam_van','38',4),
('15178','Cẩm Tân','Cam Tan','Xã Cẩm Tân','Cam Tan Commune','cam_tan','38',4),
('15187','Kim Tân','Kim Tan','Xã Kim Tân','Kim Tan Commune','kim_tan','38',4),
('15190','Vân Du','Van Du','Xã Vân Du','Van Du Commune','van_du','38',4),
('15199','Thạch Quảng','Thach Quang','Xã Thạch Quảng','Thach Quang Commune','thach_quang','38',4),
('15211','Thạch Bình','Thach Binh','Xã Thạch Bình','Thach Binh Commune','thach_binh','38',4),
('15229','Thành Vinh','Thanh Vinh','Xã Thành Vinh','Thanh Vinh Commune','thanh_vinh','38',4),
('15250','Ngọc Trạo','Ngoc Trao','Xã Ngọc Trạo','Ngoc Trao Commune','ngoc_trao','38',4),
('15271','Hà Trung','Ha Trung','Xã Hà Trung','Ha Trung Commune','ha_trung','38',4),
('15274','Hà Long','Ha Long','Xã Hà Long','Ha Long Commune','ha_long','38',4),
('15286','Hoạt Giang','Hoat Giang','Xã Hoạt Giang','Hoat Giang Commune','hoat_giang','38',4),
('15298','Lĩnh Toại','Linh Toai','Xã Lĩnh Toại','Linh Toai Commune','linh_toai','38',4),
('15316','Tống Sơn','Tong Son','Xã Tống Sơn','Tong Son Commune','tong_son','38',4),
('15349','Vĩnh Lộc','Vinh Loc','Xã Vĩnh Lộc','Vinh Loc Commune','vinh_loc','38',4),
('15361','Tây Đô','Tay Do','Xã Tây Đô','Tay Do Commune','tay_do','38',4),
('15382','Biện Thượng','Bien Thuong','Xã Biện Thượng','Bien Thuong Commune','bien_thuong','38',4),
('15409','Yên Phú','Yen Phu','Xã Yên Phú','Yen Phu Commune','yen_phu','38',4),
('15412','Quý Lộc','Quy Loc','Xã Quý Lộc','Quy Loc Commune','quy_loc','38',4),
('15421','Yên Trường','Yen Truong','Xã Yên Trường','Yen Truong Commune','yen_truong','38',4),
('15442','Yên Ninh','Yen Ninh','Xã Yên Ninh','Yen Ninh Commune','yen_ninh','38',4),
('15448','Định Hòa','Dinh Hoa','Xã Định Hòa','Dinh Hoa Commune','dinh_hoa','38',4),
('15457','Định Tân','Dinh Tan','Xã Định Tân','Dinh Tan Commune','dinh_tan','38',4),
('15469','Yên Định','Yen Dinh','Xã Yên Định','Yen Dinh Commune','yen_dinh','38',4),
('15499','Thọ Xuân','Tho Xuan','Xã Thọ Xuân','Tho Xuan Commune','tho_xuan','38',4),
('15505','Thọ Long','Tho Long','Xã Thọ Long','Tho Long Commune','tho_long','38',4),
('15520','Xuân Hòa','Xuan Hoa','Xã Xuân Hòa','Xuan Hoa Commune','xuan_hoa','38',4),
('15544','Lam Sơn','Lam Son','Xã Lam Sơn','Lam Son Commune','lam_son','38',4),
('15553','Sao Vàng','Sao Vang','Xã Sao Vàng','Sao Vang Commune','sao_vang','38',4),
('15568','Thọ Lập','Tho Lap','Xã Thọ Lập','Tho Lap Commune','tho_lap','38',4),
('15574','Xuân Tín','Xuan Tin','Xã Xuân Tín','Xuan Tin Commune','xuan_tin','38',4),
('15592','Xuân Lập','Xuan Lap','Xã Xuân Lập','Xuan Lap Commune','xuan_lap','38',4),
('15607','Bát Mọt','Bat Mot','Xã Bát Mọt','Bat Mot Commune','bat_mot','38',4),
('15610','Yên Nhân','Yen Nhan','Xã Yên Nhân','Yen Nhan Commune','yen_nhan','38',4),
('15622','Vạn Xuân','Van Xuan','Xã Vạn Xuân','Van Xuan Commune','van_xuan','38',4),
('15628','Lương Sơn','Luong Son','Xã Lương Sơn','Luong Son Commune','luong_son','38',4),
('15634','Luận Thành','Luan Thanh','Xã Luận Thành','Luan Thanh Commune','luan_thanh','38',4),
('15643','Thắng Lộc','Thang Loc','Xã Thắng Lộc','Thang Loc Commune','thang_loc','38',4),
('15646','Thường Xuân','Thuong Xuan','Xã Thường Xuân','Thuong Xuan Commune','thuong_xuan','38',4),
('15658','Xuân Chinh','Xuan Chinh','Xã Xuân Chinh','Xuan Chinh Commune','xuan_chinh','38',4),
('15661','Tân Thành','Tan Thanh','Xã Tân Thành','Tan Thanh Commune','tan_thanh','38',4),
('15664','Triệu Sơn','Trieu Son','Xã Triệu Sơn','Trieu Son Commune','trieu_son','38',4),
('15667','Thọ Bình','Tho Binh','Xã Thọ Bình','Tho Binh Commune','tho_binh','38',4),
('15682','Hợp Tiến','Hop Tien','Xã Hợp Tiến','Hop Tien Commune','hop_tien','38',4),
('15715','Tân Ninh','Tan Ninh','Xã Tân Ninh','Tan Ninh Commune','tan_ninh','38',4),
('15724','Đồng Tiến','Dong Tien','Xã Đồng Tiến','Dong Tien Commune','dong_tien','38',4),
('15754','Thọ Ngọc','Tho Ngoc','Xã Thọ Ngọc','Tho Ngoc Commune','tho_ngoc','38',4),
('15763','Thọ Phú','Tho Phu','Xã Thọ Phú','Tho Phu Commune','tho_phu','38',4),
('15766','An Nông','An Nong','Xã An Nông','An Nong Commune','an_nong','38',4),
('15772','Thiệu Hóa','Thieu Hoa','Xã Thiệu Hóa','Thieu Hoa Commune','thieu_hoa','38',4),
('15778','Thiệu Tiến','Thieu Tien','Xã Thiệu Tiến','Thieu Tien Commune','thieu_tien','38',4),
('15796','Thiệu Quang','Thieu Quang','Xã Thiệu Quang','Thieu Quang Commune','thieu_quang','38',4),
('15820','Thiệu Toán','Thieu Toan','Xã Thiệu Toán','Thieu Toan Commune','thieu_toan','38',4),
('15835','Thiệu Trung','Thieu Trung','Xã Thiệu Trung','Thieu Trung Commune','thieu_trung','38',4),
('15853','Đông Tiến','Dong Tien','Phường Đông Tiến','Dong Tien Ward','dong_tien','38',3),
('15865','Hoằng Hóa','Hoang Hoa','Xã Hoằng Hóa','Hoang Hoa Commune','hoang_hoa','38',4),
('15880','Hoằng Giang','Hoang Giang','Xã Hoằng Giang','Hoang Giang Commune','hoang_giang','38',4),
('15889','Hoằng Phú','Hoang Phu','Xã Hoằng Phú','Hoang Phu Commune','hoang_phu','38',4),
('15910','Hoằng Sơn','Hoang Son','Xã Hoằng Sơn','Hoang Son Commune','hoang_son','38',4),
('15925','Nguyệt Viên','Nguyet Vien','Phường Nguyệt Viên','Nguyet Vien Ward','nguyet_vien','38',3),
('15961','Hoằng Lộc','Hoang Loc','Xã Hoằng Lộc','Hoang Loc Commune','hoang_loc','38',4),
('15976','Hoằng Châu','Hoang Chau','Xã Hoằng Châu','Hoang Chau Commune','hoang_chau','38',4),
('15991','Hoằng Tiến','Hoang Tien','Xã Hoằng Tiến','Hoang Tien Commune','hoang_tien','38',4),
('16000','Hoằng Thanh','Hoang Thanh','Xã Hoằng Thanh','Hoang Thanh Commune','hoang_thanh','38',4),
('16012','Hậu Lộc','Hau Loc','Xã Hậu Lộc','Hau Loc Commune','hau_loc','38',4),
('16021','Triệu Lộc','Trieu Loc','Xã Triệu Lộc','Trieu Loc Commune','trieu_loc','38',4),
('16033','Đông Thành','Dong Thanh','Xã Đông Thành','Dong Thanh Commune','dong_thanh','38',4),
('16072','Hoa Lộc','Hoa Loc','Xã Hoa Lộc','Hoa Loc Commune','hoa_loc','38',4),
('16078','Vạn Lộc','Van Loc','Xã Vạn Lộc','Van Loc Commune','van_loc','38',4),
('16093','Nga Sơn','Nga Son','Xã Nga Sơn','Nga Son Commune','nga_son','38',4),
('16108','Tân Tiến','Tan Tien','Xã Tân Tiến','Tan Tien Commune','tan_tien','38',4),
('16114','Nga Thắng','Nga Thang','Xã Nga Thắng','Nga Thang Commune','nga_thang','38',4),
('16138','Hồ Vương','Ho Vuong','Xã Hồ Vương','Ho Vuong Commune','ho_vuong','38',4),
('16144','Nga An','Nga An','Xã Nga An','Nga An Commune','nga_an','38',4),
('16171','Ba Đình','Ba Dinh','Xã Ba Đình','Ba Dinh Commune','ba_dinh','38',4),
('16174','Như Xuân','Nhu Xuan','Xã Như Xuân','Nhu Xuan Commune','nhu_xuan','38',4),
('16177','Xuân Bình','Xuan Binh','Xã Xuân Bình','Xuan Binh Commune','xuan_binh','38',4),
('16186','Hóa Quỳ','Hoa Quy','Xã Hóa Quỳ','Hoa Quy Commune','hoa_quy','38',4),
('16213','Thanh Phong','Thanh Phong','Xã Thanh Phong','Thanh Phong Commune','thanh_phong','38',4),
('16222','Thanh Quân','Thanh Quan','Xã Thanh Quân','Thanh Quan Commune','thanh_quan','38',4),
('16225','Thượng Ninh','Thuong Ninh','Xã Thượng Ninh','Thuong Ninh Commune','thuong_ninh','38',4),
('16228','Như Thanh','Nhu Thanh','Xã Như Thanh','Nhu Thanh Commune','nhu_thanh','38',4),
('16234','Xuân Du','Xuan Du','Xã Xuân Du','Xuan Du Commune','xuan_du','38',4),
('16249','Mậu Lâm','Mau Lam','Xã Mậu Lâm','Mau Lam Commune','mau_lam','38',4),
('16258','Xuân Thái','Xuan Thai','Xã Xuân Thái','Xuan Thai Commune','xuan_thai','38',4),
('16264','Yên Thọ','Yen Tho','Xã Yên Thọ','Yen Tho Commune','yen_tho','38',4),
('16273','Thanh Kỳ','Thanh Ky','Xã Thanh Kỳ','Thanh Ky Commune','thanh_ky','38',4),
('16279','Nông Cống','Nong Cong','Xã Nông Cống','Nong Cong Commune','nong_cong','38',4),
('16297','Trung Chính','Trung Chinh','Xã Trung Chính','Trung Chinh Commune','trung_chinh','38',4),
('16309','Thắng Lợi','Thang Loi','Xã Thắng Lợi','Thang Loi Commune','thang_loi','38',4),
('16342','Thăng Bình','Thang Binh','Xã Thăng Bình','Thang Binh Commune','thang_binh','38',4),
('16348','Trường Văn','Truong Van','Xã Trường Văn','Truong Van Commune','truong_van','38',4),
('16363','Tượng Lĩnh','Tuong Linh','Xã Tượng Lĩnh','Tuong Linh Commune','tuong_linh','38',4),
('16369','Công Chính','Cong Chinh','Xã Công Chính','Cong Chinh Commune','cong_chinh','38',4),
('16378','Đông Sơn','Dong Son','Phường Đông Sơn','Dong Son Ward','dong_son','38',3),
('16417','Đông Quang','Dong Quang','Phường Đông Quang','Dong Quang Ward','dong_quang','38',3),
('16438','Lưu Vệ','Luu Ve','Xã Lưu Vệ','Luu Ve Commune','luu_ve','38',4),
('16480','Quảng Yên','Quang Yen','Xã Quảng Yên','Quang Yen Commune','quang_yen','38',4),
('16489','Quảng Chính','Quang Chinh','Xã Quảng Chính','Quang Chinh Commune','quang_chinh','38',4),
('16498','Quảng Ngọc','Quang Ngoc','Xã Quảng Ngọc','Quang Ngoc Commune','quang_ngoc','38',4),
('16516','Nam Sầm Sơn','Nam Sam Son','Phường Nam Sầm Sơn','Nam Sam Son Ward','nam_sam_son','38',3),
('16522','Quảng Phú','Quang Phu','Phường Quảng Phú','Quang Phu Ward','quang_phu','38',3),
('16531','Sầm Sơn','Sam Son','Phường Sầm Sơn','Sam Son Ward','sam_son','38',3),
('16540','Quảng Ninh','Quang Ninh','Xã Quảng Ninh','Quang Ninh Commune','quang_ninh','38',4),
('16543','Quảng Bình','Quang Binh','Xã Quảng Bình','Quang Binh Commune','quang_binh','38',4),
('16549','Tiên Trang','Tien Trang','Xã Tiên Trang','Tien Trang Commune','tien_trang','38',4),
('16561','Tĩnh Gia','Tinh Gia','Phường Tĩnh Gia','Tinh Gia Ward','tinh_gia','38',3),
('16576','Ngọc Sơn','Ngoc Son','Phường Ngọc Sơn','Ngoc Son Ward','ngoc_son','38',3),
('16591','Các Sơn','Cac Son','Xã Các Sơn','Cac Son Commune','cac_son','38',4),
('16594','Tân Dân','Tan Dan','Phường Tân Dân','Tan Dan Ward','tan_dan','38',3),
('16597','Hải Lĩnh','Hai Linh','Phường Hải Lĩnh','Hai Linh Ward','hai_linh','38',3),
('16609','Đào Duy Từ','Dao Duy Tu','Phường Đào Duy Từ','Dao Duy Tu Ward','dao_duy_tu','38',3),
('16624','Trúc Lâm','Truc Lam','Phường Trúc Lâm','Truc Lam Ward','truc_lam','38',3),
('16636','Trường Lâm','Truong Lam','Xã Trường Lâm','Truong Lam Commune','truong_lam','38',4),
('16645','Hải Bình','Hai Binh','Phường Hải Bình','Hai Binh Ward','hai_binh','38',3),
('16654','Nghi Sơn','Nghi Son','Phường Nghi Sơn','Nghi Son Ward','nghi_son','38',3),
('16681','Thành Vinh','Thanh Vinh','Phường Thành Vinh','Thanh Vinh Ward','thanh_vinh','40',3),
('16690','Trường Vinh','Truong Vinh','Phường Trường Vinh','Truong Vinh Ward','truong_vinh','40',3),
('16702','Vinh Phú','Vinh Phu','Phường Vinh Phú','Vinh Phu Ward','vinh_phu','40',3),
('16708','Vinh Lộc','Vinh Loc','Phường Vinh Lộc','Vinh Loc Ward','vinh_loc','40',3),
('16732','Cửa Lò','Cua Lo','Phường Cửa Lò','Cua Lo Ward','cua_lo','40',3),
('16738','Quế Phong','Que Phong','Xã Quế Phong','Que Phong Commune','que_phong','40',4),
('16744','Thông Thụ','Thong Thu','Xã Thông Thụ','Thong Thu Commune','thong_thu','40',4),
('16750','Tiền Phong','Tien Phong','Xã Tiền Phong','Tien Phong Commune','tien_phong','40',4),
('16756','Tri Lễ','Tri Le','Xã Tri Lễ','Tri Le Commune','tri_le','40',4),
('16774','Mường Quàng','Muong Quang','Xã Mường Quàng','Muong Quang Commune','muong_quang','40',4),
('16777','Quỳ Châu','Quy Chau','Xã Quỳ Châu','Quy Chau Commune','quy_chau','40',4),
('16792','Châu Tiến','Chau Tien','Xã Châu Tiến','Chau Tien Commune','chau_tien','40',4),
('16801','Hùng Chân','Hung Chan','Xã Hùng Chân','Hung Chan Commune','hung_chan','40',4),
('16804','Châu Bình','Chau Binh','Xã Châu Bình','Chau Binh Commune','chau_binh','40',4),
('16813','Mường Xén','Muong Xen','Xã Mường Xén','Muong Xen Commune','muong_xen','40',4),
('16816','Mỹ Lý','My Ly','Xã Mỹ Lý','My Ly Commune','my_ly','40',4),
('16819','Bắc Lý','Bac Ly','Xã Bắc Lý','Bac Ly Commune','bac_ly','40',4),
('16822','Keng Đu','Keng Du','Xã Keng Đu','Keng Du Commune','keng_du','40',4),
('16828','Huồi Tụ','Huoi Tu','Xã Huồi Tụ','Huoi Tu Commune','huoi_tu','40',4),
('16831','Mường Lống','Muong Long','Xã Mường Lống','Muong Long Commune','muong_long','40',4),
('16834','Na Loi','Na Loi','Xã Na Loi','Na Loi Commune','na_loi','40',4),
('16837','Nậm Cắn','Nam Can','Xã Nậm Cắn','Nam Can Commune','nam_can','40',4),
('16849','Hữu Kiệm','Huu Kiem','Xã Hữu Kiệm','Huu Kiem Commune','huu_kiem','40',4),
('16855','Chiêu Lưu','Chieu Luu','Xã Chiêu Lưu','Chieu Luu Commune','chieu_luu','40',4),
('16858','Mường Típ','Muong Tip','Xã Mường Típ','Muong Tip Commune','muong_tip','40',4),
('16870','Na Ngoi','Na Ngoi','Xã Na Ngoi','Na Ngoi Commune','na_ngoi','40',4),
('16876','Tương Dương','Tuong Duong','Xã Tương Dương','Tuong Duong Commune','tuong_duong','40',4),
('16882','Nhôn Mai','Nhon Mai','Xã Nhôn Mai','Nhon Mai Commune','nhon_mai','40',4),
('16885','Hữu Khuông','Huu Khuong','Xã Hữu Khuông','Huu Khuong Commune','huu_khuong','40',4),
('16903','Nga My','Nga My','Xã Nga My','Nga My Commune','nga_my','40',4),
('16906','Lượng Minh','Luong Minh','Xã Lượng Minh','Luong Minh Commune','luong_minh','40',4),
('16909','Yên Hòa','Yen Hoa','Xã Yên Hòa','Yen Hoa Commune','yen_hoa','40',4),
('16912','Yên Na','Yen Na','Xã Yên Na','Yen Na Commune','yen_na','40',4),
('16933','Tam Quang','Tam Quang','Xã Tam Quang','Tam Quang Commune','tam_quang','40',4),
('16936','Tam Thái','Tam Thai','Xã Tam Thái','Tam Thai Commune','tam_thai','40',4),
('16939','Thái Hòa','Thai Hoa','Phường Thái Hòa','Thai Hoa Ward','thai_hoa','40',3),
('16941','Nghĩa Đàn','Nghia Dan','Xã Nghĩa Đàn','Nghia Dan Commune','nghia_dan','40',4),
('16951','Nghĩa Lâm','Nghia Lam','Xã Nghĩa Lâm','Nghia Lam Commune','nghia_lam','40',4),
('16969','Nghĩa Thọ','Nghia Tho','Xã Nghĩa Thọ','Nghia Tho Commune','nghia_tho','40',4),
('16972','Nghĩa Hưng','Nghia Hung','Xã Nghĩa Hưng','Nghia Hung Commune','nghia_hung','40',4),
('16975','Nghĩa Mai','Nghia Mai','Xã Nghĩa Mai','Nghia Mai Commune','nghia_mai','40',4),
('17011','Tây Hiếu','Tay Hieu','Phường Tây Hiếu','Tay Hieu Ward','tay_hieu','40',3),
('17017','Đông Hiếu','Dong Hieu','Xã Đông Hiếu','Dong Hieu Commune','dong_hieu','40',4),
('17029','Nghĩa Lộc','Nghia Loc','Xã Nghĩa Lộc','Nghia Loc Commune','nghia_loc','40',4),
('17032','Nghĩa Khánh','Nghia Khanh','Xã Nghĩa Khánh','Nghia Khanh Commune','nghia_khanh','40',4),
('17035','Quỳ Hợp','Quy Hop','Xã Quỳ Hợp','Quy Hop Commune','quy_hop','40',4),
('17044','Châu Hồng','Chau Hong','Xã Châu Hồng','Chau Hong Commune','chau_hong','40',4),
('17056','Châu Lộc','Chau Loc','Xã Châu Lộc','Chau Loc Commune','chau_loc','40',4),
('17059','Tam Hợp','Tam Hop','Xã Tam Hợp','Tam Hop Commune','tam_hop','40',4),
('17071','Minh Hợp','Minh Hop','Xã Minh Hợp','Minh Hop Commune','minh_hop','40',4),
('17077','Mường Ham','Muong Ham','Xã Mường Ham','Muong Ham Commune','muong_ham','40',4),
('17089','Mường Chọng','Muong Chong','Xã Mường Chọng','Muong Chong Commune','muong_chong','40',4),
('17110','Hoàng Mai','Hoang Mai','Phường Hoàng Mai','Hoang Mai Ward','hoang_mai','40',3),
('17125','Quỳnh Mai','Quynh Mai','Phường Quỳnh Mai','Quynh Mai Ward','quynh_mai','40',3),
('17128','Tân Mai','Tan Mai','Phường Tân Mai','Tan Mai Ward','tan_mai','40',3),
('17143','Quỳnh Văn','Quynh Van','Xã Quỳnh Văn','Quynh Van Commune','quynh_van','40',4),
('17149','Quỳnh Tam','Quynh Tam','Xã Quỳnh Tam','Quynh Tam Commune','quynh_tam','40',4),
('17170','Quỳnh Sơn','Quynh Son','Xã Quỳnh Sơn','Quynh Son Commune','quynh_son','40',4),
('17176','Quỳnh Anh','Quynh Anh','Xã Quỳnh Anh','Quynh Anh Commune','quynh_anh','40',4),
('17179','Quỳnh Lưu','Quynh Luu','Xã Quỳnh Lưu','Quynh Luu Commune','quynh_luu','40',4),
('17212','Quỳnh Phú','Quynh Phu','Xã Quỳnh Phú','Quynh Phu Commune','quynh_phu','40',4),
('17224','Quỳnh Thắng','Quynh Thang','Xã Quỳnh Thắng','Quynh Thang Commune','quynh_thang','40',4),
('17230','Bình Chuẩn','Binh Chuan','Xã Bình Chuẩn','Binh Chuan Commune','binh_chuan','40',4),
('17239','Mậu Thạch','Mau Thach','Xã Mậu Thạch','Mau Thach Commune','mau_thach','40',4),
('17242','Cam Phục','Cam Phuc','Xã Cam Phục','Cam Phuc Commune','cam_phuc','40',4),
('17248','Châu Khê','Chau Khe','Xã Châu Khê','Chau Khe Commune','chau_khe','40',4),
('17254','Con Cuông','Con Cuong','Xã Con Cuông','Con Cuong Commune','con_cuong','40',4),
('17263','Môn Sơn','Mon Son','Xã Môn Sơn','Mon Son Commune','mon_son','40',4),
('17266','Tân Kỳ','Tan Ky','Xã Tân Kỳ','Tan Ky Commune','tan_ky','40',4),
('17272','Tân Phú','Tan Phu','Xã Tân Phú','Tan Phu Commune','tan_phu','40',4),
('17278','Giai Xuân','Giai Xuan','Xã Giai Xuân','Giai Xuan Commune','giai_xuan','40',4),
('17284','Nghĩa Đồng','Nghia Dong','Xã Nghĩa Đồng','Nghia Dong Commune','nghia_dong','40',4),
('17287','Tiên Đồng','Tien Dong','Xã Tiên Đồng','Tien Dong Commune','tien_dong','40',4),
('17305','Tân An','Tan An','Xã Tân An','Tan An Commune','tan_an','40',4),
('17326','Nghĩa Hành','Nghia Hanh','Xã Nghĩa Hành','Nghia Hanh Commune','nghia_hanh','40',4),
('17329','Anh Sơn','Anh Son','Xã Anh Sơn','Anh Son Commune','anh_son','40',4),
('17335','Thành Bình Thọ','Thanh Binh Tho','Xã Thành Bình Thọ','Thanh Binh Tho Commune','thanh_binh_tho','40',4),
('17344','Nhân Hòa','Nhan Hoa','Xã Nhân Hòa','Nhan Hoa Commune','nhan_hoa','40',4),
('17357','Vĩnh Tường','Vinh Tuong','Xã Vĩnh Tường','Vinh Tuong Commune','vinh_tuong','40',4),
('17365','Anh Sơn Đông','Anh Son Dong','Xã Anh Sơn Đông','Anh Son Dong Commune','anh_son_dong','40',4),
('17380','Yên Xuân','Yen Xuan','Xã Yên Xuân','Yen Xuan Commune','yen_xuan','40',4),
('17395','Hùng Châu','Hung Chau','Xã Hùng Châu','Hung Chau Commune','hung_chau','40',4),
('17416','Đức Châu','Duc Chau','Xã Đức Châu','Duc Chau Commune','duc_chau','40',4),
('17419','Hải Châu','Hai Chau','Xã Hải Châu','Hai Chau Commune','hai_chau','40',4),
('17443','Quảng Châu','Quang Chau','Xã Quảng Châu','Quang Chau Commune','quang_chau','40',4),
('17464','Diễn Châu','Dien Chau','Xã Diễn Châu','Dien Chau Commune','dien_chau','40',4),
('17476','Minh Châu','Minh Chau','Xã Minh Châu','Minh Chau Commune','minh_chau','40',4),
('17479','An Châu','An Chau','Xã An Châu','An Chau Commune','an_chau','40',4),
('17488','Tân Châu','Tan Chau','Xã Tân Châu','Tan Chau Commune','tan_chau','40',4),
('17506','Yên Thành','Yen Thanh','Xã Yên Thành','Yen Thanh Commune','yen_thanh','40',4),
('17515','Bình Minh','Binh Minh','Xã Bình Minh','Binh Minh Commune','binh_minh','40',4),
('17521','Quang Đồng','Quang Dong','Xã Quang Đồng','Quang Dong Commune','quang_dong','40',4),
('17524','Giai Lạc','Giai Lac','Xã Giai Lạc','Giai Lac Commune','giai_lac','40',4),
('17530','Đông Thành','Dong Thanh','Xã Đông Thành','Dong Thanh Commune','dong_thanh','40',4),
('17560','Vân Du','Van Du','Xã Vân Du','Van Du Commune','van_du','40',4),
('17569','Quan Thành','Quan Thanh','Xã Quan Thành','Quan Thanh Commune','quan_thanh','40',4),
('17605','Hợp Minh','Hop Minh','Xã Hợp Minh','Hop Minh Commune','hop_minh','40',4),
('17611','Vân Tụ','Van Tu','Xã Vân Tụ','Van Tu Commune','van_tu','40',4),
('17623','Bạch Ngọc','Bach Ngoc','Xã Bạch Ngọc','Bach Ngoc Commune','bach_ngoc','40',4),
('17641','Lương Sơn','Luong Son','Xã Lương Sơn','Luong Son Commune','luong_son','40',4),
('17662','Đô Lương','Do Luong','Xã Đô Lương','Do Luong Commune','do_luong','40',4),
('17677','Văn Hiến','Van Hien','Xã Văn Hiến','Van Hien Commune','van_hien','40',4),
('17689','Thuần Trung','Thuan Trung','Xã Thuần Trung','Thuan Trung Commune','thuan_trung','40',4),
('17707','Bạch Hà','Bach Ha','Xã Bạch Hà','Bach Ha Commune','bach_ha','40',4),
('17713','Đại Đồng','Dai Dong','Xã Đại Đồng','Dai Dong Commune','dai_dong','40',4),
('17722','Hạnh Lâm','Hanh Lam','Xã Hạnh Lâm','Hanh Lam Commune','hanh_lam','40',4),
('17728','Cát Ngạn','Cat Ngan','Xã Cát Ngạn','Cat Ngan Commune','cat_ngan','40',4),
('17743','Tam Đồng','Tam Dong','Xã Tam Đồng','Tam Dong Commune','tam_dong','40',4),
('17759','Sơn Lâm','Son Lam','Xã Sơn Lâm','Son Lam Commune','son_lam','40',4),
('17770','Hoa Quân','Hoa Quan','Xã Hoa Quân','Hoa Quan Commune','hoa_quan','40',4),
('17779','Xuân Lâm','Xuan Lam','Xã Xuân Lâm','Xuan Lam Commune','xuan_lam','40',4),
('17791','Kim Bảng','Kim Bang','Xã Kim Bảng','Kim Bang Commune','kim_bang','40',4),
('17818','Bích Hào','Bich Hao','Xã Bích Hào','Bich Hao Commune','bich_hao','40',4),
('17827','Nghi Lộc','Nghi Loc','Xã Nghi Lộc','Nghi Loc Commune','nghi_loc','40',4),
('17833','Hải Lộc','Hai Loc','Xã Hải Lộc','Hai Loc Commune','hai_loc','40',4),
('17842','Thần Lĩnh','Than Linh','Xã Thần Lĩnh','Than Linh Commune','than_linh','40',4),
('17854','Văn Kiều','Van Kieu','Xã Văn Kiều','Van Kieu Commune','van_kieu','40',4),
('17857','Phúc Lộc','Phuc Loc','Xã Phúc Lộc','Phuc Loc Commune','phuc_loc','40',4),
('17866','Trung Lộc','Trung Loc','Xã Trung Lộc','Trung Loc Commune','trung_loc','40',4),
('17878','Đông Lộc','Dong Loc','Xã Đông Lộc','Dong Loc Commune','dong_loc','40',4),
('17920','Vinh Hưng','Vinh Hung','Phường Vinh Hưng','Vinh Hung Ward','vinh_hung','40',3),
('17935','Nam Đàn','Nam Dan','Xã Nam Đàn','Nam Dan Commune','nam_dan','40',4),
('17944','Đại Huệ','Dai Hue','Xã Đại Huệ','Dai Hue Commune','dai_hue','40',4),
('17950','Vạn An','Van An','Xã Vạn An','Van An Commune','van_an','40',4),
('17971','Kim Liên','Kim Lien','Xã Kim Liên','Kim Lien Commune','kim_lien','40',4),
('17989','Thiên Nhẫn','Thien Nhan','Xã Thiên Nhẫn','Thien Nhan Commune','thien_nhan','40',4),
('18001','Hưng Nguyên','Hung Nguyen','Xã Hưng Nguyên','Hung Nguyen Commune','hung_nguyen','40',4),
('18007','Yên Trung','Yen Trung','Xã Yên Trung','Yen Trung Commune','yen_trung','40',4),
('18028','Hưng Nguyên Nam','Hung Nguyen Nam','Xã Hưng Nguyên Nam','Hung Nguyen Nam Commune','hung_nguyen_nam','40',4),
('18040','Lam Thành','Lam Thanh','Xã Lam Thành','Lam Thanh Commune','lam_thanh','40',4),
('18073','Thành Sen','Thanh Sen','Phường Thành Sen','Thanh Sen Ward','thanh_sen','42',3),
('18100','Trần Phú','Tran Phu','Phường Trần Phú','Tran Phu Ward','tran_phu','42',3),
('18115','Bắc Hồng Lĩnh','Bac Hong Linh','Phường Bắc Hồng Lĩnh','Bac Hong Linh Ward','bac_hong_linh','42',3),
('18118','Nam Hồng Lĩnh','Nam Hong Linh','Phường Nam Hồng Lĩnh','Nam Hong Linh Ward','nam_hong_linh','42',3),
('18133','Hương Sơn','Huong Son','Xã Hương Sơn','Huong Son Commune','huong_son','42',4),
('18160','Sơn Hồng','Son Hong','Xã Sơn Hồng','Son Hong Commune','son_hong','42',4),
('18163','Sơn Tiến','Son Tien','Xã Sơn Tiến','Son Tien Commune','son_tien','42',4),
('18172','Sơn Tây','Son Tay','Xã Sơn Tây','Son Tay Commune','son_tay','42',4),
('18184','Sơn Giang','Son Giang','Xã Sơn Giang','Son Giang Commune','son_giang','42',4),
('18196','Sơn Kim 1','Son Kim 1','Xã Sơn Kim 1','Son Kim 1 Commune','son_kim_1','42',4),
('18199','Sơn Kim 2','Son Kim 2','Xã Sơn Kim 2','Son Kim 2 Commune','son_kim_2','42',4),
('18202','Tứ Mỹ','Tu My','Xã Tứ Mỹ','Tu My Commune','tu_my','42',4),
('18223','Kim Hoa','Kim Hoa','Xã Kim Hoa','Kim Hoa Commune','kim_hoa','42',4),
('18229','Đức Thọ','Duc Tho','Xã Đức Thọ','Duc Tho Commune','duc_tho','42',4),
('18244','Đức Minh','Duc Minh','Xã Đức Minh','Duc Minh Commune','duc_minh','42',4),
('18262','Đức Quang','Duc Quang','Xã Đức Quang','Duc Quang Commune','duc_quang','42',4),
('18277','Đức Thịnh','Duc Thinh','Xã Đức Thịnh','Duc Thinh Commune','duc_thinh','42',4),
('18304','Đức Đồng','Duc Dong','Xã Đức Đồng','Duc Dong Commune','duc_dong','42',4),
('18313','Vũ Quang','Vu Quang','Xã Vũ Quang','Vu Quang Commune','vu_quang','42',4),
('18322','Mai Hoa','Mai Hoa','Xã Mai Hoa','Mai Hoa Commune','mai_hoa','42',4),
('18328','Thượng Đức','Thuong Duc','Xã Thượng Đức','Thuong Duc Commune','thuong_duc','42',4),
('18352','Nghi Xuân','Nghi Xuan','Xã Nghi Xuân','Nghi Xuan Commune','nghi_xuan','42',4),
('18364','Đan Hải','Dan Hai','Xã Đan Hải','Dan Hai Commune','dan_hai','42',4),
('18373','Tiên Điền','Tien Dien','Xã Tiên Điền','Tien Dien Commune','tien_dien','42',4),
('18394','Cổ Đạm','Co Dam','Xã Cổ Đạm','Co Dam Commune','co_dam','42',4),
('18406','Can Lộc','Can Loc','Xã Can Lộc','Can Loc Commune','can_loc','42',4),
('18409','Hồng Lộc','Hong Loc','Xã Hồng Lộc','Hong Loc Commune','hong_loc','42',4),
('18418','Tùng Lộc','Tung Loc','Xã Tùng Lộc','Tung Loc Commune','tung_loc','42',4),
('18436','Trường Lưu','Truong Luu','Xã Trường Lưu','Truong Luu Commune','truong_luu','42',4),
('18466','Gia Hanh','Gia Hanh','Xã Gia Hanh','Gia Hanh Commune','gia_hanh','42',4),
('18481','Xuân Lộc','Xuan Loc','Xã Xuân Lộc','Xuan Loc Commune','xuan_loc','42',4),
('18484','Đồng Lộc','Dong Loc','Xã Đồng Lộc','Dong Loc Commune','dong_loc','42',4),
('18496','Hương Khê','Huong Khe','Xã Hương Khê','Huong Khe Commune','huong_khe','42',4),
('18502','Hà Linh','Ha Linh','Xã Hà Linh','Ha Linh Commune','ha_linh','42',4),
('18523','Hương Bình','Huong Binh','Xã Hương Bình','Huong Binh Commune','huong_binh','42',4),
('18532','Hương Phố','Huong Pho','Xã Hương Phố','Huong Pho Commune','huong_pho','42',4),
('18544','Hương Xuân','Huong Xuan','Xã Hương Xuân','Huong Xuan Commune','huong_xuan','42',4),
('18547','Phúc Trạch','Phuc Trach','Xã Phúc Trạch','Phuc Trach Commune','phuc_trach','42',4),
('18550','Hương Đô','Huong Do','Xã Hương Đô','Huong Do Commune','huong_do','42',4),
('18562','Thạch Hà','Thach Ha','Xã Thạch Hà','Thach Ha Commune','thach_ha','42',4),
('18568','Lộc Hà','Loc Ha','Xã Lộc Hà','Loc Ha Commune','loc_ha','42',4),
('18583','Mai Phụ','Mai Phu','Xã Mai Phụ','Mai Phu Commune','mai_phu','42',4),
('18586','Đông Kinh','Dong Kinh','Xã Đông Kinh','Dong Kinh Commune','dong_kinh','42',4),
('18601','Việt Xuyên','Viet Xuyen','Xã Việt Xuyên','Viet Xuyen Commune','viet_xuyen','42',4),
('18604','Thạch Khê','Thach Khe','Xã Thạch Khê','Thach Khe Commune','thach_khe','42',4),
('18619','Đồng Tiến','Dong Tien','Xã Đồng Tiến','Dong Tien Commune','dong_tien','42',4),
('18628','Thạch Lạc','Thach Lac','Xã Thạch Lạc','Thach Lac Commune','thach_lac','42',4),
('18634','Toàn Lưu','Toan Luu','Xã Toàn Lưu','Toan Luu Commune','toan_luu','42',4),
('18652','Hà Huy Tập','Ha Huy Tap','Phường Hà Huy Tập','Ha Huy Tap Ward','ha_huy_tap','42',3),
('18667','Thạch Xuân','Thach Xuan','Xã Thạch Xuân','Thach Xuan Commune','thach_xuan','42',4),
('18673','Cẩm Xuyên','Cam Xuyen','Xã Cẩm Xuyên','Cam Xuyen Commune','cam_xuyen','42',4),
('18676','Thiên Cầm','Thien Cam','Xã Thiên Cầm','Thien Cam Commune','thien_cam','42',4),
('18682','Yên Hòa','Yen Hoa','Xã Yên Hòa','Yen Hoa Commune','yen_hoa','42',4),
('18685','Cẩm Bình','Cam Binh','Xã Cẩm Bình','Cam Binh Commune','cam_binh','42',4),
('18736','Cẩm Hưng','Cam Hung','Xã Cẩm Hưng','Cam Hung Commune','cam_hung','42',4),
('18739','Cẩm Duệ','Cam Due','Xã Cẩm Duệ','Cam Due Commune','cam_due','42',4),
('18742','Cẩm Trung','Cam Trung','Xã Cẩm Trung','Cam Trung Commune','cam_trung','42',4),
('18748','Cẩm Lạc','Cam Lac','Xã Cẩm Lạc','Cam Lac Commune','cam_lac','42',4),
('18754','Sông Trí','Song Tri','Phường Sông Trí','Song Tri Ward','song_tri','42',3),
('18766','Kỳ Xuân','Ky Xuan','Xã Kỳ Xuân','Ky Xuan Commune','ky_xuan','42',4),
('18775','Kỳ Anh','Ky Anh','Xã Kỳ Anh','Ky Anh Commune','ky_anh','42',4),
('18781','Hải Ninh','Hai Ninh','Phường Hải Ninh','Hai Ninh Ward','hai_ninh','42',3),
('18787','Kỳ Văn','Ky Van','Xã Kỳ Văn','Ky Van Commune','ky_van','42',4),
('18790','Kỳ Khang','Ky Khang','Xã Kỳ Khang','Ky Khang Commune','ky_khang','42',4),
('18814','Kỳ Hoa','Ky Hoa','Xã Kỳ Hoa','Ky Hoa Commune','ky_hoa','42',4),
('18823','Vũng Áng','Vung Ang','Phường Vũng Áng','Vung Ang Ward','vung_ang','42',3),
('18832','Hoành Sơn','Hoanh Son','Phường Hoành Sơn','Hoanh Son Ward','hoanh_son','42',3),
('18838','Kỳ Lạc','Ky Lac','Xã Kỳ Lạc','Ky Lac Commune','ky_lac','42',4),
('18844','Kỳ Thượng','Ky Thuong','Xã Kỳ Thượng','Ky Thuong Commune','ky_thuong','42',4),
('18859','Đồng Thuận','Dong Thuan','Phường Đồng Thuận','Dong Thuan Ward','dong_thuan','44',3),
('18871','Đồng Sơn','Dong Son','Phường Đồng Sơn','Dong Son Ward','dong_son','44',3),
('18880','Đồng Hới','Dong Hoi','Phường Đồng Hới','Dong Hoi Ward','dong_hoi','44',3),
('18901','Minh Hóa','Minh Hoa','Xã Minh Hóa','Minh Hoa Commune','minh_hoa','44',4),
('18904','Dân Hóa','Dan Hoa','Xã Dân Hóa','Dan Hoa Commune','dan_hoa','44',4),
('18919','Tân Thành','Tan Thanh','Xã Tân Thành','Tan Thanh Commune','tan_thanh','44',4),
('18922','Kim Điền','Kim Dien','Xã Kim Điền','Kim Dien Commune','kim_dien','44',4),
('18943','Kim Phú','Kim Phu','Xã Kim Phú','Kim Phu Commune','kim_phu','44',4),
('18949','Đồng Lê','Dong Le','Xã Đồng Lê','Dong Le Commune','dong_le','44',4),
('18952','Tuyên Sơn','Tuyen Son','Xã Tuyên Sơn','Tuyen Son Commune','tuyen_son','44',4),
('18958','Tuyên Lâm','Tuyen Lam','Xã Tuyên Lâm','Tuyen Lam Commune','tuyen_lam','44',4),
('18985','Tuyên Phú','Tuyen Phu','Xã Tuyên Phú','Tuyen Phu Commune','tuyen_phu','44',4),
('18991','Tuyên Bình','Tuyen Binh','Xã Tuyên Bình','Tuyen Binh Commune','tuyen_binh','44',4),
('18997','Tuyên Hóa','Tuyen Hoa','Xã Tuyên Hóa','Tuyen Hoa Commune','tuyen_hoa','44',4),
('19009','Ba Đồn','Ba Don','Phường Ba Đồn','Ba Don Ward','ba_don','44',3),
('19021','Phú Trạch','Phu Trach','Xã Phú Trạch','Phu Trach Commune','phu_trach','44',4),
('19030','Trung Thuần','Trung Thuan','Xã Trung Thuần','Trung Thuan Commune','trung_thuan','44',4),
('19033','Hòa Trạch','Hoa Trach','Xã Hòa Trạch','Hoa Trach Commune','hoa_trach','44',4),
('19051','Tân Gianh','Tan Gianh','Xã Tân Gianh','Tan Gianh Commune','tan_gianh','44',4),
('19057','Quảng Trạch','Quang Trach','Xã Quảng Trạch','Quang Trach Commune','quang_trach','44',4),
('19066','Bắc Gianh','Bac Gianh','Phường Bắc Gianh','Bac Gianh Ward','bac_gianh','44',3),
('19075','Nam Ba Đồn','Nam Ba Don','Xã Nam Ba Đồn','Nam Ba Don Commune','nam_ba_don','44',4),
('19093','Nam Gianh','Nam Gianh','Xã Nam Gianh','Nam Gianh Commune','nam_gianh','44',4),
('19111','Hoàn Lão','Hoan Lao','Xã Hoàn Lão','Hoan Lao Commune','hoan_lao','44',4),
('19126','Bắc Trạch','Bac Trach','Xã Bắc Trạch','Bac Trach Commune','bac_trach','44',4),
('19138','Phong Nha','Phong Nha','Xã Phong Nha','Phong Nha Commune','phong_nha','44',4),
('19141','Bố Trạch','Bo Trach','Xã Bố Trạch','Bo Trach Commune','bo_trach','44',4),
('19147','Thượng Trạch','Thuong Trach','Xã Thượng Trạch','Thuong Trach Commune','thuong_trach','44',4),
('19159','Đông Trạch','Dong Trach','Xã Đông Trạch','Dong Trach Commune','dong_trach','44',4),
('19198','Nam Trạch','Nam Trach','Xã Nam Trạch','Nam Trach Commune','nam_trach','44',4),
('19204','Trường Sơn','Truong Son','Xã Trường Sơn','Truong Son Commune','truong_son','44',4),
('19207','Quảng Ninh','Quang Ninh','Xã Quảng Ninh','Quang Ninh Commune','quang_ninh','44',4),
('19225','Ninh Châu','Ninh Chau','Xã Ninh Châu','Ninh Chau Commune','ninh_chau','44',4),
('19237','Trường Ninh','Truong Ninh','Xã Trường Ninh','Truong Ninh Commune','truong_ninh','44',4),
('19246','Lệ Ninh','Le Ninh','Xã Lệ Ninh','Le Ninh Commune','le_ninh','44',4),
('19249','Lệ Thủy','Le Thuy','Xã Lệ Thủy','Le Thuy Commune','le_thuy','44',4),
('19255','Cam Hồng','Cam Hong','Xã Cam Hồng','Cam Hong Commune','cam_hong','44',4),
('19288','Sen Ngư','Sen Ngu','Xã Sen Ngư','Sen Ngu Commune','sen_ngu','44',4),
('19291','Tân Mỹ','Tan My','Xã Tân Mỹ','Tan My Commune','tan_my','44',4),
('19309','Trường Phú','Truong Phu','Xã Trường Phú','Truong Phu Commune','truong_phu','44',4),
('19318','Kim Ngân','Kim Ngan','Xã Kim Ngân','Kim Ngan Commune','kim_ngan','44',4),
('19333','Đông Hà','Dong Ha','Phường Đông Hà','Dong Ha Ward','dong_ha','44',3),
('19351','Nam Đông Hà','Nam Dong Ha','Phường Nam Đông Hà','Nam Dong Ha Ward','nam_dong_ha','44',3),
('19360','Quảng Trị','Quang Tri','Phường Quảng Trị','Quang Tri Ward','quang_tri','44',3),
('19363','Vĩnh Linh','Vinh Linh','Xã Vĩnh Linh','Vinh Linh Commune','vinh_linh','44',4),
('19366','Bến Quan','Ben Quan','Xã Bến Quan','Ben Quan Commune','ben_quan','44',4),
('19372','Vĩnh Hoàng','Vinh Hoang','Xã Vĩnh Hoàng','Vinh Hoang Commune','vinh_hoang','44',4),
('19405','Vĩnh Thủy','Vinh Thuy','Xã Vĩnh Thủy','Vinh Thuy Commune','vinh_thuy','44',4),
('19414','Cửa Tùng','Cua Tung','Xã Cửa Tùng','Cua Tung Commune','cua_tung','44',4),
('19429','Khe Sanh','Khe Sanh','Xã Khe Sanh','Khe Sanh Commune','khe_sanh','44',4),
('19432','Lao Bảo','Lao Bao','Xã Lao Bảo','Lao Bao Commune','lao_bao','44',4),
('19435','Hướng Lập','Huong Lap','Xã Hướng Lập','Huong Lap Commune','huong_lap','44',4),
('19441','Hướng Phùng','Huong Phung','Xã Hướng Phùng','Huong Phung Commune','huong_phung','44',4),
('19462','Tân Lập','Tan Lap','Xã Tân Lập','Tan Lap Commune','tan_lap','44',4),
('19483','A Dơi','A Doi','Xã A Dơi','A Doi Commune','a_doi','44',4),
('19489','Lìa','Lia','Xã Lìa','Lia Commune','lia','44',4),
('19495','Gio Linh','Gio Linh','Xã Gio Linh','Gio Linh Commune','gio_linh','44',4),
('19496','Cửa Việt','Cua Viet','Xã Cửa Việt','Cua Viet Commune','cua_viet','44',4),
('19501','Bến Hải','Ben Hai','Xã Bến Hải','Ben Hai Commune','ben_hai','44',4),
('19537','Cồn Tiên','Con Tien','Xã Cồn Tiên','Con Tien Commune','con_tien','44',4),
('19555','Hướng Hiệp','Huong Hiep','Xã Hướng Hiệp','Huong Hiep Commune','huong_hiep','44',4),
('19564','Đakrông','Dakrong','Xã Đakrông','Dakrong Commune','dakrong','44',4),
('19567','Ba Lòng','Ba Long','Xã Ba Lòng','Ba Long Commune','ba_long','44',4),
('19588','Tà Rụt','Ta Rut','Xã Tà Rụt','Ta Rut Commune','ta_rut','44',4),
('19594','La Lay','La Lay','Xã La Lay','La Lay Commune','la_lay','44',4),
('19597','Cam Lộ','Cam Lo','Xã Cam Lộ','Cam Lo Commune','cam_lo','44',4),
('19603','Hiếu Giang','Hieu Giang','Xã Hiếu Giang','Hieu Giang Commune','hieu_giang','44',4),
('19624','Triệu Phong','Trieu Phong','Xã Triệu Phong','Trieu Phong Commune','trieu_phong','44',4),
('19639','Nam Cửa Việt','Nam Cua Viet','Xã Nam Cửa Việt','Nam Cua Viet Commune','nam_cua_viet','44',4),
('19645','Triệu Bình','Trieu Binh','Xã Triệu Bình','Trieu Binh Commune','trieu_binh','44',4),
('19654','Triệu Cơ','Trieu Co','Xã Triệu Cơ','Trieu Co Commune','trieu_co','44',4),
('19669','Ái Tử','Ai Tu','Xã Ái Tử','Ai Tu Commune','ai_tu','44',4),
('19681','Diên Sanh','Dien Sanh','Xã Diên Sanh','Dien Sanh Commune','dien_sanh','44',4),
('19699','Vĩnh Định','Vinh Dinh','Xã Vĩnh Định','Vinh Dinh Commune','vinh_dinh','44',4),
('19702','Hải Lăng','Hai Lang','Xã Hải Lăng','Hai Lang Commune','hai_lang','44',4),
('19735','Nam Hải Lăng','Nam Hai Lang','Xã Nam Hải Lăng','Nam Hai Lang Commune','nam_hai_lang','44',4),
('19741','Mỹ Thủy','My Thuy','Xã Mỹ Thủy','My Thuy Commune','my_thuy','44',4),
('19742','Cồn Cỏ','Con Co','Đặc khu Cồn Cỏ','Con Co Special administrative region','con_co','44',5),
('19753','Phú Xuân','Phu Xuan','Phường Phú Xuân','Phu Xuan Ward','phu_xuan','46',3),
('19774','Kim Long','Kim Long','Phường Kim Long','Kim Long Ward','kim_long','46',3),
('19777','Vỹ Dạ','Vy Da','Phường Vỹ Dạ','Vy Da Ward','vy_da','46',3),
('19789','Thuận Hóa','Thuan Hoa','Phường Thuận Hóa','Thuan Hoa Ward','thuan_hoa','46',3),
('19804','Hương An','Huong An','Phường Hương An','Huong An Ward','huong_an','46',3),
('19813','Thủy Xuân','Thuy Xuan','Phường Thủy Xuân','Thuy Xuan Ward','thuy_xuan','46',3),
('19815','An Cựu','An Cuu','Phường An Cựu','An Cuu Ward','an_cuu','46',3),
('19819','Phong Điền','Phong Dien','Phường Phong Điền','Phong Dien Ward','phong_dien','46',3),
('19828','Phong Phú','Phong Phu','Phường Phong Phú','Phong Phu Ward','phong_phu','46',3),
('19831','Phong Dinh','Phong Dinh','Phường Phong Dinh','Phong Dinh Ward','phong_dinh','46',3),
('19858','Phong Thái','Phong Thai','Phường Phong Thái','Phong Thai Ward','phong_thai','46',3),
('19867','Quảng Điền','Quang Dien','Xã Quảng Điền','Quang Dien Commune','quang_dien','46',4),
('19873','Phong Quảng','Phong Quang','Phường Phong Quảng','Phong Quang Ward','phong_quang','46',3),
('19885','Đan Điền','Dan Dien','Xã Đan Điền','Dan Dien Commune','dan_dien','46',4),
('19900','Thuận An','Thuan An','Phường Thuận An','Thuan An Ward','thuan_an','46',3),
('19909','Dương Nỗ','Duong No','Phường Dương Nỗ','Duong No Ward','duong_no','46',3),
('19918','Phú Hồ','Phu Ho','Xã Phú Hồ','Phu Ho Commune','phu_ho','46',4),
('19930','Mỹ Thượng','My Thuong','Phường Mỹ Thượng','My Thuong Ward','my_thuong','46',3),
('19942','Phú Vang','Phu Vang','Xã Phú Vang','Phu Vang Commune','phu_vang','46',4),
('19945','Phú Vinh','Phu Vinh','Xã Phú Vinh','Phu Vinh Commune','phu_vinh','46',4),
('19960','Phú Bài','Phu Bai','Phường Phú Bài','Phu Bai Ward','phu_bai','46',3),
('19969','Thanh Thủy','Thanh Thuy','Phường Thanh Thủy','Thanh Thuy Ward','thanh_thuy','46',3),
('19975','Hương Thủy','Huong Thuy','Phường Hương Thủy','Huong Thuy Ward','huong_thuy','46',3),
('19996','Hương Trà','Huong Tra','Phường Hương Trà','Huong Tra Ward','huong_tra','46',3),
('20014','Hóa Châu','Hoa Chau','Phường Hóa Châu','Hoa Chau Ward','hoa_chau','46',3),
('20017','Kim Trà','Kim Tra','Phường Kim Trà','Kim Tra Ward','kim_tra','46',3),
('20035','Bình Điền','Binh Dien','Xã Bình Điền','Binh Dien Commune','binh_dien','46',4),
('20044','A Lưới 2','A Luoi 2','Xã A Lưới 2','A Luoi 2 Commune','a_luoi_2','46',4),
('20050','A Lưới 5','A Luoi 5','Xã A Lưới 5','A Luoi 5 Commune','a_luoi_5','46',4),
('20056','A Lưới 1','A Luoi 1','Xã A Lưới 1','A Luoi 1 Commune','a_luoi_1','46',4),
('20071','A Lưới 3','A Luoi 3','Xã A Lưới 3','A Luoi 3 Commune','a_luoi_3','46',4),
('20101','A Lưới 4','A Luoi 4','Xã A Lưới 4','A Luoi 4 Commune','a_luoi_4','46',4),
('20107','Phú Lộc','Phu Loc','Xã Phú Lộc','Phu Loc Commune','phu_loc','46',4),
('20122','Vinh Lộc','Vinh Loc','Xã Vinh Lộc','Vinh Loc Commune','vinh_loc','46',4),
('20131','Hưng Lộc','Hung Loc','Xã Hưng Lộc','Hung Loc Commune','hung_loc','46',4),
('20137','Chân Mây - Lăng Cô','Chan May - Lang Co','Xã Chân Mây - Lăng Cô','Chan May - Lang Co Commune','chan_may_lang_co','46',4),
('20140','Lộc An','Loc An','Xã Lộc An','Loc An Commune','loc_an','46',4),
('20161','Khe Tre','Khe Tre','Xã Khe Tre','Khe Tre Commune','khe_tre','46',4),
('20179','Nam Đông','Nam Dong','Xã Nam Đông','Nam Dong Commune','nam_dong','46',4),
('20182','Long Quảng','Long Quang','Xã Long Quảng','Long Quang Commune','long_quang','46',4),
('20194','Hải Vân','Hai Van','Phường Hải Vân','Hai Van Ward','hai_van','48',3),
('20197','Liên Chiểu','Lien Chieu','Phường Liên Chiểu','Lien Chieu Ward','lien_chieu','48',3),
('20200','Hòa Khánh','Hoa Khanh','Phường Hòa Khánh','Hoa Khanh Ward','hoa_khanh','48',3),
('20209','Thanh Khê','Thanh Khe','Phường Thanh Khê','Thanh Khe Ward','thanh_khe','48',3),
('20242','Hải Châu','Hai Chau','Phường Hải Châu','Hai Chau Ward','hai_chau','48',3),
('20257','Hòa Cường','Hoa Cuong','Phường Hòa Cường','Hoa Cuong Ward','hoa_cuong','48',3),
('20260','Cẩm Lệ','Cam Le','Phường Cẩm Lệ','Cam Le Ward','cam_le','48',3),
('20263','Sơn Trà','Son Tra','Phường Sơn Trà','Son Tra Ward','son_tra','48',3),
('20275','An Hải','An Hai','Phường An Hải','An Hai Ward','an_hai','48',3),
('20285','Ngũ Hành Sơn','Ngu Hanh Son','Phường Ngũ Hành Sơn','Ngu Hanh Son Ward','ngu_hanh_son','48',3),
('20305','An Khê','An Khe','Phường An Khê','An Khe Ward','an_khe','48',3),
('20308','Bà Nà','Ba Na','Xã Bà Nà','Ba Na Commune','ba_na','48',4),
('20314','Hòa Xuân','Hoa Xuan','Phường Hòa Xuân','Hoa Xuan Ward','hoa_xuan','48',3),
('20320','Hòa Vang','Hoa Vang','Xã Hòa Vang','Hoa Vang Commune','hoa_vang','48',4),
('20332','Hòa Tiến','Hoa Tien','Xã Hòa Tiến','Hoa Tien Commune','hoa_tien','48',4),
('20333','Hoàng Sa','Hoang Sa','Đặc khu Hoàng Sa','Hoang Sa Special administrative region','hoang_sa','48',5),
('20335','Bàn Thạch','Ban Thach','Phường Bàn Thạch','Ban Thach Ward','ban_thach','48',3),
('20341','Tam Kỳ','Tam Ky','Phường Tam Kỳ','Tam Ky Ward','tam_ky','48',3),
('20350','Hương Trà','Huong Tra','Phường Hương Trà','Huong Tra Ward','huong_tra','48',3),
('20356','Quảng Phú','Quang Phu','Phường Quảng Phú','Quang Phu Ward','quang_phu','48',3),
('20364','Chiên Đàn','Chien Dan','Xã Chiên Đàn','Chien Dan Commune','chien_dan','48',4),
('20380','Tây Hồ','Tay Ho','Xã Tây Hồ','Tay Ho Commune','tay_ho','48',4),
('20392','Phú Ninh','Phu Ninh','Xã Phú Ninh','Phu Ninh Commune','phu_ninh','48',4),
('20401','Hội An Tây','Hoi An Tay','Phường Hội An Tây','Hoi An Tay Ward','hoi_an_tay','48',3),
('20410','Hội An','Hoi An','Phường Hội An','Hoi An Ward','hoi_an','48',3),
('20413','Hội An Đông','Hoi An Dong','Phường Hội An Đông','Hoi An Dong Ward','hoi_an_dong','48',3),
('20434','Tân Hiệp','Tan Hiep','Xã Tân Hiệp','Tan Hiep Commune','tan_hiep','48',4),
('20443','Hùng Sơn','Hung Son','Xã Hùng Sơn','Hung Son Commune','hung_son','48',4),
('20455','Tây Giang','Tay Giang','Xã Tây Giang','Tay Giang Commune','tay_giang','48',4),
('20458','Avương','Avuong','Xã Avương','Avuong Commune','avuong','48',4),
('20467','Đông Giang','Dong Giang','Xã Đông Giang','Dong Giang Commune','dong_giang','48',4),
('20476','Sông Kôn','Song Kon','Xã Sông Kôn','Song Kon Commune','song_kon','48',4),
('20485','Sông Vàng','Song Vang','Xã Sông Vàng','Song Vang Commune','song_vang','48',4),
('20494','Bến Hiên','Ben Hien','Xã Bến Hiên','Ben Hien Commune','ben_hien','48',4),
('20500','Đại Lộc','Dai Loc','Xã Đại Lộc','Dai Loc Commune','dai_loc','48',4),
('20506','Thượng Đức','Thuong Duc','Xã Thượng Đức','Thuong Duc Commune','thuong_duc','48',4),
('20515','Hà Nha','Ha Nha','Xã Hà Nha','Ha Nha Commune','ha_nha','48',4),
('20539','Vu Gia','Vu Gia','Xã Vu Gia','Vu Gia Commune','vu_gia','48',4),
('20542','Phú Thuận','Phu Thuan','Xã Phú Thuận','Phu Thuan Commune','phu_thuan','48',4),
('20551','Điện Bàn','Dien Ban','Phường Điện Bàn','Dien Ban Ward','dien_ban','48',3),
('20557','Điện Bàn Bắc','Dien Ban Bac','Phường Điện Bàn Bắc','Dien Ban Bac Ward','dien_ban_bac','48',3),
('20569','Điện Bàn Tây','Dien Ban Tay','Xã Điện Bàn Tây','Dien Ban Tay Commune','dien_ban_tay','48',4),
('20575','An Thắng','An Thang','Phường An Thắng','An Thang Ward','an_thang','48',3),
('20579','Điện Bàn Đông','Dien Ban Dong','Phường Điện Bàn Đông','Dien Ban Dong Ward','dien_ban_dong','48',3),
('20587','Gò Nổi','Go Noi','Xã Gò Nổi','Go Noi Commune','go_noi','48',4),
('20599','Nam Phước','Nam Phuoc','Xã Nam Phước','Nam Phuoc Commune','nam_phuoc','48',4),
('20611','Thu Bồn','Thu Bon','Xã Thu Bồn','Thu Bon Commune','thu_bon','48',4),
('20623','Duy Xuyên','Duy Xuyen','Xã Duy Xuyên','Duy Xuyen Commune','duy_xuyen','48',4),
('20635','Duy Nghĩa','Duy Nghia','Xã Duy Nghĩa','Duy Nghia Commune','duy_nghia','48',4),
('20641','Quế Sơn','Que Son','Xã Quế Sơn','Que Son Commune','que_son','48',4),
('20650','Xuân Phú','Xuan Phu','Xã Xuân Phú','Xuan Phu Commune','xuan_phu','48',4),
('20656','Nông Sơn','Nong Son','Xã Nông Sơn','Nong Son Commune','nong_son','48',4),
('20662','Quế Sơn Trung','Que Son Trung','Xã Quế Sơn Trung','Que Son Trung Commune','que_son_trung','48',4),
('20669','Quế Phước','Que Phuoc','Xã Quế Phước','Que Phuoc Commune','que_phuoc','48',4),
('20695','Thạnh Mỹ','Thanh My','Xã Thạnh Mỹ','Thanh My Commune','thanh_my','48',4),
('20698','La Êê','La Ee','Xã La Êê','La Ee Commune','la_ee','48',4),
('20704','La Dêê','La Dee','Xã La Dêê','La Dee Commune','la_dee','48',4),
('20707','Nam Giang','Nam Giang','Xã Nam Giang','Nam Giang Commune','nam_giang','48',4),
('20710','Bến Giằng','Ben Giang','Xã Bến Giằng','Ben Giang Commune','ben_giang','48',4),
('20716','Đắc Pring','Dac Pring','Xã Đắc Pring','Dac Pring Commune','dac_pring','48',4),
('20722','Khâm Đức','Kham Duc','Xã Khâm Đức','Kham Duc Commune','kham_duc','48',4),
('20728','Phước Hiệp','Phuoc Hiep','Xã Phước Hiệp','Phuoc Hiep Commune','phuoc_hiep','48',4),
('20734','Phước Năng','Phuoc Nang','Xã Phước Năng','Phuoc Nang Commune','phuoc_nang','48',4),
('20740','Phước Chánh','Phuoc Chanh','Xã Phước Chánh','Phuoc Chanh Commune','phuoc_chanh','48',4),
('20752','Phước Thành','Phuoc Thanh','Xã Phước Thành','Phuoc Thanh Commune','phuoc_thanh','48',4),
('20767','Việt An','Viet An','Xã Việt An','Viet An Commune','viet_an','48',4),
('20770','Phước Trà','Phuoc Tra','Xã Phước Trà','Phuoc Tra Commune','phuoc_tra','48',4),
('20779','Hiệp Đức','Hiep Duc','Xã Hiệp Đức','Hiep Duc Commune','hiep_duc','48',4),
('20791','Thăng Bình','Thang Binh','Xã Thăng Bình','Thang Binh Commune','thang_binh','48',4),
('20794','Thăng An','Thang An','Xã Thăng An','Thang An Commune','thang_an','48',4),
('20818','Đồng Dương','Dong Duong','Xã Đồng Dương','Dong Duong Commune','dong_duong','48',4),
('20827','Thăng Phú','Thang Phu','Xã Thăng Phú','Thang Phu Commune','thang_phu','48',4),
('20836','Thăng Trường','Thang Truong','Xã Thăng Trường','Thang Truong Commune','thang_truong','48',4),
('20848','Thăng Điền','Thang Dien','Xã Thăng Điền','Thang Dien Commune','thang_dien','48',4),
('20854','Tiên Phước','Tien Phuoc','Xã Tiên Phước','Tien Phuoc Commune','tien_phuoc','48',4),
('20857','Sơn Cẩm Hà','Son Cam Ha','Xã Sơn Cẩm Hà','Son Cam Ha Commune','son_cam_ha','48',4),
('20875','Lãnh Ngọc','Lanh Ngoc','Xã Lãnh Ngọc','Lanh Ngoc Commune','lanh_ngoc','48',4),
('20878','Thạnh Bình','Thanh Binh','Xã Thạnh Bình','Thanh Binh Commune','thanh_binh','48',4),
('20900','Trà My','Tra My','Xã Trà My','Tra My Commune','tra_my','48',4),
('20908','Trà Liên','Tra Lien','Xã Trà Liên','Tra Lien Commune','tra_lien','48',4),
('20920','Trà Đốc','Tra Doc','Xã Trà Đốc','Tra Doc Commune','tra_doc','48',4),
('20923','Trà Tân','Tra Tan','Xã Trà Tân','Tra Tan Commune','tra_tan','48',4),
('20929','Trà Giáp','Tra Giap','Xã Trà Giáp','Tra Giap Commune','tra_giap','48',4),
('20938','Trà Leng','Tra Leng','Xã Trà Leng','Tra Leng Commune','tra_leng','48',4),
('20941','Trà Tập','Tra Tap','Xã Trà Tập','Tra Tap Commune','tra_tap','48',4),
('20944','Nam Trà My','Nam Tra My','Xã Nam Trà My','Nam Tra My Commune','nam_tra_my','48',4),
('20950','Trà Linh','Tra Linh','Xã Trà Linh','Tra Linh Commune','tra_linh','48',4),
('20959','Trà Vân','Tra Van','Xã Trà Vân','Tra Van Commune','tra_van','48',4),
('20965','Núi Thành','Nui Thanh','Xã Núi Thành','Nui Thanh Commune','nui_thanh','48',4),
('20971','Tam Xuân','Tam Xuan','Xã Tam Xuân','Tam Xuan Commune','tam_xuan','48',4),
('20977','Đức Phú','Duc Phu','Xã Đức Phú','Duc Phu Commune','duc_phu','48',4),
('20984','Tam Anh','Tam Anh','Xã Tam Anh','Tam Anh Commune','tam_anh','48',4),
('20992','Tam Hải','Tam Hai','Xã Tam Hải','Tam Hai Commune','tam_hai','48',4),
('21004','Tam Mỹ','Tam My','Xã Tam Mỹ','Tam My Commune','tam_my','48',4),
('21025','Cẩm Thành','Cam Thanh','Phường Cẩm Thành','Cam Thanh Ward','cam_thanh','51',3),
('21028','Nghĩa Lộ','Nghia Lo','Phường Nghĩa Lộ','Nghia Lo Ward','nghia_lo','51',3),
('21034','An Phú','An Phu','Xã An Phú','An Phu Commune','an_phu','51',4),
('21040','Bình Sơn','Binh Son','Xã Bình Sơn','Binh Son Commune','binh_son','51',4),
('21061','Vạn Tường','Van Tuong','Xã Vạn Tường','Van Tuong Commune','van_tuong','51',4),
('21085','Bình Minh','Binh Minh','Xã Bình Minh','Binh Minh Commune','binh_minh','51',4),
('21100','Bình Chương','Binh Chuong','Xã Bình Chương','Binh Chuong Commune','binh_chuong','51',4),
('21109','Đông Sơn','Dong Son','Xã Đông Sơn','Dong Son Commune','dong_son','51',4),
('21115','Trà Bồng','Tra Bong','Xã Trà Bồng','Tra Bong Commune','tra_bong','51',4),
('21124','Thanh Bồng','Thanh Bong','Xã Thanh Bồng','Thanh Bong Commune','thanh_bong','51',4),
('21127','Đông Trà Bồng','Dong Tra Bong','Xã Đông Trà Bồng','Dong Tra Bong Commune','dong_tra_bong','51',4),
('21136','Cà Đam','Ca Dam','Xã Cà Đam','Ca Dam Commune','ca_dam','51',4),
('21154','Tây Trà','Tay Tra','Xã Tây Trà','Tay Tra Commune','tay_tra','51',4),
('21157','Tây Trà Bồng','Tay Tra Bong','Xã Tây Trà Bồng','Tay Tra Bong Commune','tay_tra_bong','51',4),
('21172','Trương Quang Trọng','Truong Quang Trong','Phường Trương Quang Trọng','Truong Quang Trong Ward','truong_quang_trong','51',3),
('21181','Thọ Phong','Tho Phong','Xã Thọ Phong','Tho Phong Commune','tho_phong','51',4),
('21196','Trường Giang','Truong Giang','Xã Trường Giang','Truong Giang Commune','truong_giang','51',4),
('21205','Ba Gia','Ba Gia','Xã Ba Gia','Ba Gia Commune','ba_gia','51',4),
('21211','Tịnh Khê','Tinh Khe','Xã Tịnh Khê','Tinh Khe Commune','tinh_khe','51',4),
('21220','Sơn Tịnh','Son Tinh','Xã Sơn Tịnh','Son Tinh Commune','son_tinh','51',4),
('21235','Tư Nghĩa','Tu Nghia','Xã Tư Nghĩa','Tu Nghia Commune','tu_nghia','51',4),
('21238','Vệ Giang','Ve Giang','Xã Vệ Giang','Ve Giang Commune','ve_giang','51',4),
('21244','Trà Giang','Tra Giang','Xã Trà Giang','Tra Giang Commune','tra_giang','51',4),
('21250','Nghĩa Giang','Nghia Giang','Xã Nghĩa Giang','Nghia Giang Commune','nghia_giang','51',4),
('21289','Sơn Hà','Son Ha','Xã Sơn Hà','Son Ha Commune','son_ha','51',4),
('21292','Sơn Hạ','Son Ha','Xã Sơn Hạ','Son Ha Commune','son_ha','51',4),
('21307','Sơn Linh','Son Linh','Xã Sơn Linh','Son Linh Commune','son_linh','51',4),
('21319','Sơn Thủy','Son Thuy','Xã Sơn Thủy','Son Thuy Commune','son_thuy','51',4),
('21325','Sơn Kỳ','Son Ky','Xã Sơn Kỳ','Son Ky Commune','son_ky','51',4),
('21334','Sơn Tây Thượng','Son Tay Thuong','Xã Sơn Tây Thượng','Son Tay Thuong Commune','son_tay_thuong','51',4),
('21340','Sơn Tây','Son Tay','Xã Sơn Tây','Son Tay Commune','son_tay','51',4),
('21343','Sơn Tây Hạ','Son Tay Ha','Xã Sơn Tây Hạ','Son Tay Ha Commune','son_tay_ha','51',4),
('21349','Sơn Mai','Son Mai','Xã Sơn Mai','Son Mai Commune','son_mai','51',4),
('21361','Minh Long','Minh Long','Xã Minh Long','Minh Long Commune','minh_long','51',4),
('21364','Nghĩa Hành','Nghia Hanh','Xã Nghĩa Hành','Nghia Hanh Commune','nghia_hanh','51',4),
('21370','Phước Giang','Phuoc Giang','Xã Phước Giang','Phuoc Giang Commune','phuoc_giang','51',4),
('21385','Đình Cương','Dinh Cuong','Xã Đình Cương','Dinh Cuong Commune','dinh_cuong','51',4),
('21388','Thiện Tín','Thien Tin','Xã Thiện Tín','Thien Tin Commune','thien_tin','51',4),
('21400','Mộ Đức','Mo Duc','Xã Mộ Đức','Mo Duc Commune','mo_duc','51',4),
('21409','Long Phụng','Long Phung','Xã Long Phụng','Long Phung Commune','long_phung','51',4),
('21421','Mỏ Cày','Mo Cay','Xã Mỏ Cày','Mo Cay Commune','mo_cay','51',4),
('21433','Lân Phong','Lan Phong','Xã Lân Phong','Lan Phong Commune','lan_phong','51',4),
('21439','Đức Phổ','Duc Pho','Phường Đức Phổ','Duc Pho Ward','duc_pho','51',3),
('21451','Trà Câu','Tra Cau','Phường Trà Câu','Tra Cau Ward','tra_cau','51',3),
('21457','Nguyễn Nghiêm','Nguyen Nghiem','Xã Nguyễn Nghiêm','Nguyen Nghiem Commune','nguyen_nghiem','51',4),
('21472','Khánh Cường','Khanh Cuong','Xã Khánh Cường','Khanh Cuong Commune','khanh_cuong','51',4),
('21478','Sa Huỳnh','Sa Huynh','Phường Sa Huỳnh','Sa Huynh Ward','sa_huynh','51',3),
('21484','Ba Tơ','Ba To','Xã Ba Tơ','Ba To Commune','ba_to','51',4),
('21490','Ba Vinh','Ba Vinh','Xã Ba Vinh','Ba Vinh Commune','ba_vinh','51',4),
('21496','Ba Động','Ba Dong','Xã Ba Động','Ba Dong Commune','ba_dong','51',4),
('21499','Ba Dinh','Ba Dinh','Xã Ba Dinh','Ba Dinh Commune','ba_dinh','51',4),
('21520','Đặng Thùy Trâm','Dang Thuy Tram','Xã Đặng Thùy Trâm','Dang Thuy Tram Commune','dang_thuy_tram','51',4),
('21523','Ba Tô','Ba To','Xã Ba Tô','Ba To Commune','ba_to','51',4),
('21529','Ba Vì','Ba Vi','Xã Ba Vì','Ba Vi Commune','ba_vi','51',4),
('21538','Ba Xa','Ba Xa','Xã Ba Xa','Ba Xa Commune','ba_xa','51',4),
('21548','Lý Sơn','Ly Son','Đặc khu Lý Sơn','Ly Son Special administrative region','ly_son','51',5),
('21553','Quy Nhơn Bắc','Quy Nhon Bac','Phường Quy Nhơn Bắc','Quy Nhon Bac Ward','quy_nhon_bac','52',3),
('21583','Quy Nhơn','Quy Nhon','Phường Quy Nhơn','Quy Nhon Ward','quy_nhon','52',3),
('21589','Quy Nhơn Tây','Quy Nhon Tay','Phường Quy Nhơn Tây','Quy Nhon Tay Ward','quy_nhon_tay','52',3),
('21592','Quy Nhơn Nam','Quy Nhon Nam','Phường Quy Nhơn Nam','Quy Nhon Nam Ward','quy_nhon_nam','52',3),
('21601','Quy Nhơn Đông','Quy Nhon Dong','Phường Quy Nhơn Đông','Quy Nhon Dong Ward','quy_nhon_dong','52',3),
('21607','Nhơn Châu','Nhon Chau','Xã Nhơn Châu','Nhon Chau Commune','nhon_chau','52',4),
('21609','An Lão','An Lao','Xã An Lão','An Lao Commune','an_lao','52',4),
('21616','An Vinh','An Vinh','Xã An Vinh','An Vinh Commune','an_vinh','52',4),
('21622','An Toàn','An Toan','Xã An Toàn','An Toan Commune','an_toan','52',4),
('21628','An Hòa','An Hoa','Xã An Hòa','An Hoa Commune','an_hoa','52',4),
('21637','Tam Quan','Tam Quan','Phường Tam Quan','Tam Quan Ward','tam_quan','52',3),
('21640','Bồng Sơn','Bong Son','Phường Bồng Sơn','Bong Son Ward','bong_son','52',3),
('21655','Hoài Nhơn Bắc','Hoai Nhon Bac','Phường Hoài Nhơn Bắc','Hoai Nhon Bac Ward','hoai_nhon_bac','52',3),
('21661','Hoài Nhơn Tây','Hoai Nhon Tay','Phường Hoài Nhơn Tây','Hoai Nhon Tay Ward','hoai_nhon_tay','52',3),
('21664','Hoài Nhơn','Hoai Nhon','Phường Hoài Nhơn','Hoai Nhon Ward','hoai_nhon','52',3),
('21670','Hoài Nhơn Đông','Hoai Nhon Dong','Phường Hoài Nhơn Đông','Hoai Nhon Dong Ward','hoai_nhon_dong','52',3),
('21673','Hoài Nhơn Nam','Hoai Nhon Nam','Phường Hoài Nhơn Nam','Hoai Nhon Nam Ward','hoai_nhon_nam','52',3),
('21688','Hoài Ân','Hoai An','Xã Hoài Ân','Hoai An Commune','hoai_an','52',4),
('21697','Ân Hảo','An Hao','Xã Ân Hảo','An Hao Commune','an_hao','52',4),
('21703','Vạn Đức','Van Duc','Xã Vạn Đức','Van Duc Commune','van_duc','52',4),
('21715','Ân Tường','An Tuong','Xã Ân Tường','An Tuong Commune','an_tuong','52',4),
('21727','Kim Sơn','Kim Son','Xã Kim Sơn','Kim Son Commune','kim_son','52',4),
('21730','Phù Mỹ','Phu My','Xã Phù Mỹ','Phu My Commune','phu_my','52',4),
('21733','Bình Dương','Binh Duong','Xã Bình Dương','Binh Duong Commune','binh_duong','52',4),
('21739','Phù Mỹ Bắc','Phu My Bac','Xã Phù Mỹ Bắc','Phu My Bac Commune','phu_my_bac','52',4),
('21751','Phù Mỹ Đông','Phu My Dong','Xã Phù Mỹ Đông','Phu My Dong Commune','phu_my_dong','52',4),
('21757','Phù Mỹ Tây','Phu My Tay','Xã Phù Mỹ Tây','Phu My Tay Commune','phu_my_tay','52',4),
('21769','An Lương','An Luong','Xã An Lương','An Luong Commune','an_luong','52',4),
('21775','Phù Mỹ Nam','Phu My Nam','Xã Phù Mỹ Nam','Phu My Nam Commune','phu_my_nam','52',4),
('21786','Vĩnh Thạnh','Vinh Thanh','Xã Vĩnh Thạnh','Vinh Thanh Commune','vinh_thanh','52',4),
('21787','Vĩnh Sơn','Vinh Son','Xã Vĩnh Sơn','Vinh Son Commune','vinh_son','52',4),
('21796','Vĩnh Thịnh','Vinh Thinh','Xã Vĩnh Thịnh','Vinh Thinh Commune','vinh_thinh','52',4),
('21805','Vĩnh Quang','Vinh Quang','Xã Vĩnh Quang','Vinh Quang Commune','vinh_quang','52',4),
('21808','Tây Sơn','Tay Son','Xã Tây Sơn','Tay Son Commune','tay_son','52',4),
('21817','Bình Hiệp','Binh Hiep','Xã Bình Hiệp','Binh Hiep Commune','binh_hiep','52',4),
('21820','Bình Khê','Binh Khe','Xã Bình Khê','Binh Khe Commune','binh_khe','52',4),
('21829','Bình An','Binh An','Xã Bình An','Binh An Commune','binh_an','52',4),
('21835','Bình Phú','Binh Phu','Xã Bình Phú','Binh Phu Commune','binh_phu','52',4),
('21853','Phù Cát','Phu Cat','Xã Phù Cát','Phu Cat Commune','phu_cat','52',4),
('21859','Đề Gi','De Gi','Xã Đề Gi','De Gi Commune','de_gi','52',4),
('21868','Hội Sơn','Hoi Son','Xã Hội Sơn','Hoi Son Commune','hoi_son','52',4),
('21871','Hòa Hội','Hoa Hoi','Xã Hòa Hội','Hoa Hoi Commune','hoa_hoi','52',4),
('21880','Cát Tiến','Cat Tien','Xã Cát Tiến','Cat Tien Commune','cat_tien','52',4),
('21892','Xuân An','Xuan An','Xã Xuân An','Xuan An Commune','xuan_an','52',4),
('21901','Ngô Mây','Ngo May','Xã Ngô Mây','Ngo May Commune','ngo_may','52',4),
('21907','Bình Định','Binh Dinh','Phường Bình Định','Binh Dinh Ward','binh_dinh','52',3),
('21910','An Nhơn','An Nhon','Phường An Nhơn','An Nhon Ward','an_nhon','52',3),
('21925','An Nhơn Bắc','An Nhon Bac','Phường An Nhơn Bắc','An Nhon Bac Ward','an_nhon_bac','52',3),
('21934','An Nhơn Đông','An Nhon Dong','Phường An Nhơn Đông','An Nhon Dong Ward','an_nhon_dong','52',3),
('21940','An Nhơn Tây','An Nhon Tay','Xã An Nhơn Tây','An Nhon Tay Commune','an_nhon_tay','52',4),
('21943','An Nhơn Nam','An Nhon Nam','Phường An Nhơn Nam','An Nhon Nam Ward','an_nhon_nam','52',3),
('21952','Tuy Phước','Tuy Phuoc','Xã Tuy Phước','Tuy Phuoc Commune','tuy_phuoc','52',4),
('21964','Tuy Phước Bắc','Tuy Phuoc Bac','Xã Tuy Phước Bắc','Tuy Phuoc Bac Commune','tuy_phuoc_bac','52',4),
('21970','Tuy Phước Đông','Tuy Phuoc Dong','Xã Tuy Phước Đông','Tuy Phuoc Dong Commune','tuy_phuoc_dong','52',4),
('21985','Tuy Phước Tây','Tuy Phuoc Tay','Xã Tuy Phước Tây','Tuy Phuoc Tay Commune','tuy_phuoc_tay','52',4),
('21994','Vân Canh','Van Canh','Xã Vân Canh','Van Canh Commune','van_canh','52',4),
('21997','Canh Liên','Canh Lien','Xã Canh Liên','Canh Lien Commune','canh_lien','52',4),
('22006','Canh Vinh','Canh Vinh','Xã Canh Vinh','Canh Vinh Commune','canh_vinh','52',4),
('22015','Tuy Hòa','Tuy Hoa','Phường Tuy Hòa','Tuy Hoa Ward','tuy_hoa','66',3),
('22045','Bình Kiến','Binh Kien','Phường Bình Kiến','Binh Kien Ward','binh_kien','66',3),
('22051','Sông Cầu','Song Cau','Phường Sông Cầu','Song Cau Ward','song_cau','66',3),
('22057','Xuân Lộc','Xuan Loc','Xã Xuân Lộc','Xuan Loc Commune','xuan_loc','66',4),
('22060','Xuân Cảnh','Xuan Canh','Xã Xuân Cảnh','Xuan Canh Commune','xuan_canh','66',4),
('22075','Xuân Thọ','Xuan Tho','Xã Xuân Thọ','Xuan Tho Commune','xuan_tho','66',4),
('22076','Xuân Đài','Xuan Dai','Phường Xuân Đài','Xuan Dai Ward','xuan_dai','66',3),
('22081','Đồng Xuân','Dong Xuan','Xã Đồng Xuân','Dong Xuan Commune','dong_xuan','66',4),
('22090','Xuân Lãnh','Xuan Lanh','Xã Xuân Lãnh','Xuan Lanh Commune','xuan_lanh','66',4),
('22096','Phú Mỡ','Phu Mo','Xã Phú Mỡ','Phu Mo Commune','phu_mo','66',4),
('22111','Xuân Phước','Xuan Phuoc','Xã Xuân Phước','Xuan Phuoc Commune','xuan_phuoc','66',4),
('22114','Tuy An Bắc','Tuy An Bac','Xã Tuy An Bắc','Tuy An Bac Commune','tuy_an_bac','66',4),
('22120','Tuy An Đông','Tuy An Dong','Xã Tuy An Đông','Tuy An Dong Commune','tuy_an_dong','66',4),
('22132','Tuy An Tây','Tuy An Tay','Xã Tuy An Tây','Tuy An Tay Commune','tuy_an_tay','66',4),
('22147','Ô Loan','O Loan','Xã Ô Loan','O Loan Commune','o_loan','66',4),
('22153','Tuy An Nam','Tuy An Nam','Xã Tuy An Nam','Tuy An Nam Commune','tuy_an_nam','66',4),
('22165','Sơn Hòa','Son Hoa','Xã Sơn Hòa','Son Hoa Commune','son_hoa','66',4),
('22171','Tây Sơn','Tay Son','Xã Tây Sơn','Tay Son Commune','tay_son','66',4),
('22177','Vân Hòa','Van Hoa','Xã Vân Hòa','Van Hoa Commune','van_hoa','66',4),
('22192','Suối Trai','Suoi Trai','Xã Suối Trai','Suoi Trai Commune','suoi_trai','66',4),
('22207','Sông Hinh','Song Hinh','Xã Sông Hinh','Song Hinh Commune','song_hinh','66',4),
('22222','Đức Bình','Duc Binh','Xã Đức Bình','Duc Binh Commune','duc_binh','66',4),
('22225','Ea Bá','Ea Ba','Xã Ea Bá','Ea Ba Commune','ea_ba','66',4),
('22237','Ea Ly','Ea Ly','Xã Ea Ly','Ea Ly Commune','ea_ly','66',4),
('22240','Phú Yên','Phu Yen','Phường Phú Yên','Phu Yen Ward','phu_yen','66',3),
('22250','Sơn Thành','Son Thanh','Xã Sơn Thành','Son Thanh Commune','son_thanh','66',4),
('22255','Tây Hòa','Tay Hoa','Xã Tây Hòa','Tay Hoa Commune','tay_hoa','66',4),
('22258','Đông Hòa','Dong Hoa','Phường Đông Hòa','Dong Hoa Ward','dong_hoa','66',3),
('22261','Hòa Hiệp','Hoa Hiep','Phường Hòa Hiệp','Hoa Hiep Ward','hoa_hiep','66',3),
('22276','Hòa Thịnh','Hoa Thinh','Xã Hòa Thịnh','Hoa Thinh Commune','hoa_thinh','66',4),
('22285','Hòa Mỹ','Hoa My','Xã Hòa Mỹ','Hoa My Commune','hoa_my','66',4),
('22291','Hòa Xuân','Hoa Xuan','Xã Hòa Xuân','Hoa Xuan Commune','hoa_xuan','66',4),
('22303','Phú Hòa 2','Phu Hoa 2','Xã Phú Hòa 2','Phu Hoa 2 Commune','phu_hoa_2','66',4),
('22319','Phú Hòa 1','Phu Hoa 1','Xã Phú Hòa 1','Phu Hoa 1 Commune','phu_hoa_1','66',4),
('22333','Bắc Nha Trang','Bac Nha Trang','Phường Bắc Nha Trang','Bac Nha Trang Ward','bac_nha_trang','56',3),
('22366','Nha Trang','Nha Trang','Phường Nha Trang','Nha Trang Ward','nha_trang','56',3),
('22390','Tây Nha Trang','Tay Nha Trang','Phường Tây Nha Trang','Tay Nha Trang Ward','tay_nha_trang','56',3),
('22402','Nam Nha Trang','Nam Nha Trang','Phường Nam Nha Trang','Nam Nha Trang Ward','nam_nha_trang','56',3),
('22411','Bắc Cam Ranh','Bac Cam Ranh','Phường Bắc Cam Ranh','Bac Cam Ranh Ward','bac_cam_ranh','56',3),
('22420','Cam Ranh','Cam Ranh','Phường Cam Ranh','Cam Ranh Ward','cam_ranh','56',3),
('22423','Ba Ngòi','Ba Ngoi','Phường Ba Ngòi','Ba Ngoi Ward','ba_ngoi','56',3),
('22432','Cam Linh','Cam Linh','Phường Cam Linh','Cam Linh Ward','cam_linh','56',3),
('22435','Cam Hiệp','Cam Hiep','Xã Cam Hiệp','Cam Hiep Commune','cam_hiep','56',4),
('22453','Cam Lâm','Cam Lam','Xã Cam Lâm','Cam Lam Commune','cam_lam','56',4),
('22465','Cam An','Cam An','Xã Cam An','Cam An Commune','cam_an','56',4),
('22480','Nam Cam Ranh','Nam Cam Ranh','Xã Nam Cam Ranh','Nam Cam Ranh Commune','nam_cam_ranh','56',4),
('22489','Vạn Ninh','Van Ninh','Xã Vạn Ninh','Van Ninh Commune','van_ninh','56',4),
('22498','Tu Bông','Tu Bong','Xã Tu Bông','Tu Bong Commune','tu_bong','56',4),
('22504','Đại Lãnh','Dai Lanh','Xã Đại Lãnh','Dai Lanh Commune','dai_lanh','56',4),
('22516','Vạn Thắng','Van Thang','Xã Vạn Thắng','Van Thang Commune','van_thang','56',4),
('22525','Vạn Hưng','Van Hung','Xã Vạn Hưng','Van Hung Commune','van_hung','56',4),
('22528','Ninh Hòa','Ninh Hoa','Phường Ninh Hòa','Ninh Hoa Ward','ninh_hoa','56',3),
('22546','Bắc Ninh Hòa','Bac Ninh Hoa','Xã Bắc Ninh Hòa','Bac Ninh Hoa Commune','bac_ninh_hoa','56',4),
('22552','Tây Ninh Hòa','Tay Ninh Hoa','Xã Tây Ninh Hòa','Tay Ninh Hoa Commune','tay_ninh_hoa','56',4),
('22558','Hòa Trí','Hoa Tri','Xã Hòa Trí','Hoa Tri Commune','hoa_tri','56',4),
('22561','Đông Ninh Hòa','Dong Ninh Hoa','Phường Đông Ninh Hòa','Dong Ninh Hoa Ward','dong_ninh_hoa','56',3),
('22576','Tân Định','Tan Dinh','Xã Tân Định','Tan Dinh Commune','tan_dinh','56',4),
('22591','Hòa Thắng','Hoa Thang','Phường Hòa Thắng','Hoa Thang Ward','hoa_thang','56',3),
('22597','Nam Ninh Hòa','Nam Ninh Hoa','Xã Nam Ninh Hòa','Nam Ninh Hoa Commune','nam_ninh_hoa','56',4),
('22609','Khánh Vĩnh','Khanh Vinh','Xã Khánh Vĩnh','Khanh Vinh Commune','khanh_vinh','56',4),
('22612','Trung Khánh Vĩnh','Trung Khanh Vinh','Xã Trung Khánh Vĩnh','Trung Khanh Vinh Commune','trung_khanh_vinh','56',4),
('22615','Bắc Khánh Vĩnh','Bac Khanh Vinh','Xã Bắc Khánh Vĩnh','Bac Khanh Vinh Commune','bac_khanh_vinh','56',4),
('22624','Tây Khánh Vĩnh','Tay Khanh Vinh','Xã Tây Khánh Vĩnh','Tay Khanh Vinh Commune','tay_khanh_vinh','56',4),
('22648','Nam Khánh Vĩnh','Nam Khanh Vinh','Xã Nam Khánh Vĩnh','Nam Khanh Vinh Commune','nam_khanh_vinh','56',4),
('22651','Diên Khánh','Dien Khanh','Xã Diên Khánh','Dien Khanh Commune','dien_khanh','56',4),
('22657','Diên Điền','Dien Dien','Xã Diên Điền','Dien Dien Commune','dien_dien','56',4),
('22660','Diên Lâm','Dien Lam','Xã Diên Lâm','Dien Lam Commune','dien_lam','56',4),
('22672','Diên Thọ','Dien Tho','Xã Diên Thọ','Dien Tho Commune','dien_tho','56',4),
('22678','Diên Lạc','Dien Lac','Xã Diên Lạc','Dien Lac Commune','dien_lac','56',4),
('22702','Suối Hiệp','Suoi Hiep','Xã Suối Hiệp','Suoi Hiep Commune','suoi_hiep','56',4),
('22708','Suối Dầu','Suoi Dau','Xã Suối Dầu','Suoi Dau Commune','suoi_dau','56',4),
('22714','Khánh Sơn','Khanh Son','Xã Khánh Sơn','Khanh Son Commune','khanh_son','56',4),
('22720','Tây Khánh Sơn','Tay Khanh Son','Xã Tây Khánh Sơn','Tay Khanh Son Commune','tay_khanh_son','56',4),
('22732','Đông Khánh Sơn','Dong Khanh Son','Xã Đông Khánh Sơn','Dong Khanh Son Commune','dong_khanh_son','56',4),
('22736','Trường Sa','Truong Sa','Đặc khu Trường Sa','Truong Sa Special administrative region','truong_sa','56',5),
('22738','Đô Vinh','Do Vinh','Phường Đô Vinh','Do Vinh Ward','do_vinh','56',3),
('22741','Bảo An','Bao An','Phường Bảo An','Bao An Ward','bao_an','56',3),
('22759','Phan Rang','Phan Rang','Phường Phan Rang','Phan Rang Ward','phan_rang','56',3),
('22780','Đông Hải','Dong Hai','Phường Đông Hải','Dong Hai Ward','dong_hai','56',3),
('22786','Bác Ái Tây','Bac Ai Tay','Xã Bác Ái Tây','Bac Ai Tay Commune','bac_ai_tay','56',4),
('22795','Bác Ái','Bac Ai','Xã Bác Ái','Bac Ai Commune','bac_ai','56',4),
('22801','Bác Ái Đông','Bac Ai Dong','Xã Bác Ái Đông','Bac Ai Dong Commune','bac_ai_dong','56',4),
('22810','Ninh Sơn','Ninh Son','Xã Ninh Sơn','Ninh Son Commune','ninh_son','56',4),
('22813','Lâm Sơn','Lam Son','Xã Lâm Sơn','Lam Son Commune','lam_son','56',4),
('22822','Mỹ Sơn','My Son','Xã Mỹ Sơn','My Son Commune','my_son','56',4),
('22828','Anh Dũng','Anh Dung','Xã Anh Dũng','Anh Dung Commune','anh_dung','56',4),
('22834','Ninh Chử','Ninh Chu','Phường Ninh Chử','Ninh Chu Ward','ninh_chu','56',3),
('22840','Công Hải','Cong Hai','Xã Công Hải','Cong Hai Commune','cong_hai','56',4),
('22846','Vĩnh Hải','Vinh Hai','Xã Vĩnh Hải','Vinh Hai Commune','vinh_hai','56',4),
('22849','Thuận Bắc','Thuan Bac','Xã Thuận Bắc','Thuan Bac Commune','thuan_bac','56',4),
('22852','Ninh Hải','Ninh Hai','Xã Ninh Hải','Ninh Hai Commune','ninh_hai','56',4),
('22861','Xuân Hải','Xuan Hai','Xã Xuân Hải','Xuan Hai Commune','xuan_hai','56',4),
('22870','Ninh Phước','Ninh Phuoc','Xã Ninh Phước','Ninh Phuoc Commune','ninh_phuoc','56',4),
('22873','Phước Hậu','Phuoc Hau','Xã Phước Hậu','Phuoc Hau Commune','phuoc_hau','56',4),
('22888','Phước Dinh','Phuoc Dinh','Xã Phước Dinh','Phuoc Dinh Commune','phuoc_dinh','56',4),
('22891','Phước Hữu','Phuoc Huu','Xã Phước Hữu','Phuoc Huu Commune','phuoc_huu','56',4),
('22897','Thuận Nam','Thuan Nam','Xã Thuận Nam','Thuan Nam Commune','thuan_nam','56',4),
('22900','Phước Hà','Phuoc Ha','Xã Phước Hà','Phuoc Ha Commune','phuoc_ha','56',4),
('22909','Cà Ná','Ca Na','Xã Cà Ná','Ca Na Commune','ca_na','56',4),
('22918','Mũi Né','Mui Ne','Phường Mũi Né','Mui Ne Ward','mui_ne','68',3),
('22924','Phú Thủy','Phu Thuy','Phường Phú Thủy','Phu Thuy Ward','phu_thuy','68',3),
('22933','Hàm Thắng','Ham Thang','Phường Hàm Thắng','Ham Thang Ward','ham_thang','68',3),
('22945','Phan Thiết','Phan Thiet','Phường Phan Thiết','Phan Thiet Ward','phan_thiet','68',3),
('22954','Tiến Thành','Tien Thanh','Phường Tiến Thành','Tien Thanh Ward','tien_thanh','68',3),
('22960','Bình Thuận','Binh Thuan','Phường Bình Thuận','Binh Thuan Ward','binh_thuan','68',3),
('22963','Tuyên Quang','Tuyen Quang','Xã Tuyên Quang','Tuyen Quang Commune','tuyen_quang','68',4),
('22969','Liên Hương','Lien Huong','Xã Liên Hương','Lien Huong Commune','lien_huong','68',4),
('22972','Phan Rí Cửa','Phan Ri Cua','Xã Phan Rí Cửa','Phan Ri Cua Commune','phan_ri_cua','68',4),
('22978','Tuy Phong','Tuy Phong','Xã Tuy Phong','Tuy Phong Commune','tuy_phong','68',4),
('22981','Vĩnh Hảo','Vinh Hao','Xã Vĩnh Hảo','Vinh Hao Commune','vinh_hao','68',4),
('23005','Bắc Bình','Bac Binh','Xã Bắc Bình','Bac Binh Commune','bac_binh','68',4),
('23008','Phan Sơn','Phan Son','Xã Phan Sơn','Phan Son Commune','phan_son','68',4),
('23020','Hải Ninh','Hai Ninh','Xã Hải Ninh','Hai Ninh Commune','hai_ninh','68',4),
('23023','Sông Lũy','Song Luy','Xã Sông Lũy','Song Luy Commune','song_luy','68',4),
('23032','Lương Sơn','Luong Son','Xã Lương Sơn','Luong Son Commune','luong_son','68',4),
('23041','Hồng Thái','Hong Thai','Xã Hồng Thái','Hong Thai Commune','hong_thai','68',4),
('23053','Hòa Thắng','Hoa Thang','Xã Hòa Thắng','Hoa Thang Commune','hoa_thang','68',4),
('23059','Hàm Thuận','Ham Thuan','Xã Hàm Thuận','Ham Thuan Commune','ham_thuan','68',4),
('23065','La Dạ','La Da','Xã La Dạ','La Da Commune','la_da','68',4),
('23074','Đông Giang','Dong Giang','Xã Đông Giang','Dong Giang Commune','dong_giang','68',4),
('23086','Hồng Sơn','Hong Son','Xã Hồng Sơn','Hong Son Commune','hong_son','68',4),
('23089','Hàm Thuận Bắc','Ham Thuan Bac','Xã Hàm Thuận Bắc','Ham Thuan Bac Commune','ham_thuan_bac','68',4),
('23095','Hàm Liêm','Ham Liem','Xã Hàm Liêm','Ham Liem Commune','ham_liem','68',4),
('23110','Hàm Thuận Nam','Ham Thuan Nam','Xã Hàm Thuận Nam','Ham Thuan Nam Commune','ham_thuan_nam','68',4),
('23122','Hàm Thạnh','Ham Thanh','Xã Hàm Thạnh','Ham Thanh Commune','ham_thanh','68',4),
('23128','Hàm Kiệm','Ham Kiem','Xã Hàm Kiệm','Ham Kiem Commune','ham_kiem','68',4),
('23134','Tân Lập','Tan Lap','Xã Tân Lập','Tan Lap Commune','tan_lap','68',4),
('23143','Tân Thành','Tan Thanh','Xã Tân Thành','Tan Thanh Commune','tan_thanh','68',4),
('23149','Tánh Linh','Tanh Linh','Xã Tánh Linh','Tanh Linh Commune','tanh_linh','68',4),
('23152','Bắc Ruộng','Bac Ruong','Xã Bắc Ruộng','Bac Ruong Commune','bac_ruong','68',4),
('23158','Nghị Đức','Nghi Duc','Xã Nghị Đức','Nghi Duc Commune','nghi_duc','68',4),
('23173','Đồng Kho','Dong Kho','Xã Đồng Kho','Dong Kho Commune','dong_kho','68',4),
('23188','Suối Kiết','Suoi Kiet','Xã Suối Kiết','Suoi Kiet Commune','suoi_kiet','68',4),
('23191','Đức Linh','Duc Linh','Xã Đức Linh','Duc Linh Commune','duc_linh','68',4),
('23194','Hoài Đức','Hoai Duc','Xã Hoài Đức','Hoai Duc Commune','hoai_duc','68',4),
('23200','Nam Thành','Nam Thanh','Xã Nam Thành','Nam Thanh Commune','nam_thanh','68',4),
('23227','Trà Tân','Tra Tan','Xã Trà Tân','Tra Tan Commune','tra_tan','68',4),
('23230','Tân Minh','Tan Minh','Xã Tân Minh','Tan Minh Commune','tan_minh','68',4),
('23231','Phước Hội','Phuoc Hoi','Phường Phước Hội','Phuoc Hoi Ward','phuoc_hoi','68',3),
('23235','La Gi','La Gi','Phường La Gi','La Gi Ward','la_gi','68',3),
('23236','Hàm Tân','Ham Tan','Xã Hàm Tân','Ham Tan Commune','ham_tan','68',4),
('23246','Tân Hải','Tan Hai','Xã Tân Hải','Tan Hai Commune','tan_hai','68',4),
('23266','Sơn Mỹ','Son My','Xã Sơn Mỹ','Son My Commune','son_my','68',4),
('23272','Phú Quý','Phu Quy','Đặc khu Phú Quý','Phu Quy Special administrative region','phu_quy','68',5),
('23284','Đăk Cấm','Dak Cam','Phường Đăk Cấm','Dak Cam Ward','dak_cam','51',3),
('23293','Kon Tum','Kon Tum','Phường Kon Tum','Kon Tum Ward','kon_tum','51',3),
('23302','Đăk Bla','Dak Bla','Phường Đăk Bla','Dak Bla Ward','dak_bla','51',3),
('23317','Ngọk Bay','Ngok Bay','Xã Ngọk Bay','Ngok Bay Commune','ngok_bay','51',4),
('23326','Ia Chim','Ia Chim','Xã Ia Chim','Ia Chim Commune','ia_chim','51',4),
('23332','Đăk Rơ Wa','Dak Ro Wa','Xã Đăk Rơ Wa','Dak Ro Wa Commune','dak_ro_wa','51',4),
('23341','Đăk Pék','Dak Pek','Xã Đăk Pék','Dak Pek Commune','dak_pek','51',4),
('23344','Đăk Plô','Dak Plo','Xã Đăk Plô','Dak Plo Commune','dak_plo','51',4),
('23356','Xốp','Xop','Xã Xốp','Xop Commune','xop','51',4),
('23365','Ngọc Linh','Ngoc Linh','Xã Ngọc Linh','Ngoc Linh Commune','ngoc_linh','51',4),
('23368','Đăk Long','Dak Long','Xã Đăk Long','Dak Long Commune','dak_long','51',4),
('23374','Đăk Môn','Dak Mon','Xã Đăk Môn','Dak Mon Commune','dak_mon','51',4),
('23377','Bờ Y','Bo Y','Xã Bờ Y','Bo Y Commune','bo_y','51',4),
('23383','Dục Nông','Duc Nong','Xã Dục Nông','Duc Nong Commune','duc_nong','51',4),
('23392','Sa Loong','Sa Loong','Xã Sa Loong','Sa Loong Commune','sa_loong','51',4),
('23401','Đăk Tô','Dak To','Xã Đăk Tô','Dak To Commune','dak_to','51',4),
('23416','Đăk Sao','Dak Sao','Xã Đăk Sao','Dak Sao Commune','dak_sao','51',4),
('23419','Đăk Tờ Kan','Dak To Kan','Xã Đăk Tờ Kan','Dak To Kan Commune','dak_to_kan','51',4),
('23425','Tu Mơ Rông','Tu Mo Rong','Xã Tu Mơ Rông','Tu Mo Rong Commune','tu_mo_rong','51',4),
('23428','Ngọk Tụ','Ngok Tu','Xã Ngọk Tụ','Ngok Tu Commune','ngok_tu','51',4),
('23430','Kon Đào','Kon Dao','Xã Kon Đào','Kon Dao Commune','kon_dao','51',4),
('23446','Măng Ri','Mang Ri','Xã Măng Ri','Mang Ri Commune','mang_ri','51',4),
('23455','Măng Bút','Mang But','Xã Măng Bút','Mang But Commune','mang_but','51',4),
('23473','Măng Đen','Mang Den','Xã Măng Đen','Mang Den Commune','mang_den','51',4),
('23476','Kon Plông','Kon Plong','Xã Kon Plông','Kon Plong Commune','kon_plong','51',4),
('23479','Đăk Rve','Dak Rve','Xã Đăk Rve','Dak Rve Commune','dak_rve','51',4),
('23485','Đăk Kôi','Dak Koi','Xã Đăk Kôi','Dak Koi Commune','dak_koi','51',4),
('23497','Kon Braih','Kon Braih','Xã Kon Braih','Kon Braih Commune','kon_braih','51',4),
('23500','Đăk Hà','Dak Ha','Xã Đăk Hà','Dak Ha Commune','dak_ha','51',4),
('23504','Đăk Pxi','Dak Pxi','Xã Đăk Pxi','Dak Pxi Commune','dak_pxi','51',4),
('23510','Đăk Ui','Dak Ui','Xã Đăk Ui','Dak Ui Commune','dak_ui','51',4),
('23512','Đăk Mar','Dak Mar','Xã Đăk Mar','Dak Mar Commune','dak_mar','51',4),
('23515','Ngọk Réo','Ngok Reo','Xã Ngọk Réo','Ngok Reo Commune','ngok_reo','51',4),
('23527','Sa Thầy','Sa Thay','Xã Sa Thầy','Sa Thay Commune','sa_thay','51',4),
('23530','Rờ Kơi','Ro Koi','Xã Rờ Kơi','Ro Koi Commune','ro_koi','51',4),
('23534','Sa Bình','Sa Binh','Xã Sa Bình','Sa Binh Commune','sa_binh','51',4),
('23535','Ia Đal','Ia Dal','Xã Ia Đal','Ia Dal Commune','ia_dal','51',4),
('23536','Mô Rai','Mo Rai','Xã Mô Rai','Mo Rai Commune','mo_rai','51',4),
('23538','Ia Tơi','Ia Toi','Xã Ia Tơi','Ia Toi Commune','ia_toi','51',4),
('23548','Ya Ly','Ya Ly','Xã Ya Ly','Ya Ly Commune','ya_ly','51',4),
('23563','Diên Hồng','Dien Hong','Phường Diên Hồng','Dien Hong Ward','dien_hong','52',3),
('23575','Pleiku','Pleiku','Phường Pleiku','Pleiku Ward','pleiku','52',3),
('23584','Thống Nhất','Thong Nhat','Phường Thống Nhất','Thong Nhat Ward','thong_nhat','52',3),
('23586','Hội Phú','Hoi Phu','Phường Hội Phú','Hoi Phu Ward','hoi_phu','52',3),
('23590','Biển Hồ','Bien Ho','Xã Biển Hồ','Bien Ho Commune','bien_ho','52',4),
('23602','An Phú','An Phu','Phường An Phú','An Phu Ward','an_phu','52',3),
('23611','Gào','Gao','Xã Gào','Gao Commune','gao','52',4),
('23614','An Bình','An Binh','Phường An Bình','An Binh Ward','an_binh','52',3),
('23617','An Khê','An Khe','Phường An Khê','An Khe Ward','an_khe','52',3),
('23629','Cửu An','Cuu An','Xã Cửu An','Cuu An Commune','cuu_an','52',4),
('23638','Kbang','Kbang','Xã Kbang','Kbang Commune','kbang','52',4),
('23644','Đak Rong','Dak Rong','Xã Đak Rong','Dak Rong Commune','dak_rong','52',4),
('23647','Sơn Lang','Son Lang','Xã Sơn Lang','Son Lang Commune','son_lang','52',4),
('23650','Krong','Krong','Xã Krong','Krong Commune','krong','52',4),
('23668','Tơ Tung','To Tung','Xã Tơ Tung','To Tung Commune','to_tung','52',4),
('23674','Kông Bơ La','Kong Bo La','Xã Kông Bơ La','Kong Bo La Commune','kong_bo_la','52',4),
('23677','Đak Đoa','Dak Doa','Xã Đak Đoa','Dak Doa Commune','dak_doa','52',4),
('23683','Đak Sơmei','Dak Somei','Xã Đak Sơmei','Dak Somei Commune','dak_somei','52',4),
('23701','Kon Gang','Kon Gang','Xã Kon Gang','Kon Gang Commune','kon_gang','52',4),
('23710','Ia Băng','Ia Bang','Xã Ia Băng','Ia Bang Commune','ia_bang','52',4),
('23714','KDang','KDang','Xã KDang','KDang Commune','kdang','52',4),
('23722','Chư Păh','Chu Pah','Xã Chư Păh','Chu Pah Commune','chu_pah','52',4),
('23728','Ia Khươl','Ia Khuol','Xã Ia Khươl','Ia Khuol Commune','ia_khuol','52',4),
('23734','Ia Ly','Ia Ly','Xã Ia Ly','Ia Ly Commune','ia_ly','52',4),
('23749','Ia Phí','Ia Phi','Xã Ia Phí','Ia Phi Commune','ia_phi','52',4),
('23764','Ia Grai','Ia Grai','Xã Ia Grai','Ia Grai Commune','ia_grai','52',4),
('23767','Ia Hrung','Ia Hrung','Xã Ia Hrung','Ia Hrung Commune','ia_hrung','52',4),
('23776','Ia Krái','Ia Krai','Xã Ia Krái','Ia Krai Commune','ia_krai','52',4),
('23782','Ia O','Ia O','Xã Ia O','Ia O Commune','ia_o','52',4),
('23788','Ia Chia','Ia Chia','Xã Ia Chia','Ia Chia Commune','ia_chia','52',4),
('23794','Mang Yang','Mang Yang','Xã Mang Yang','Mang Yang Commune','mang_yang','52',4),
('23798','Ayun','Ayun','Xã Ayun','Ayun Commune','ayun','52',4),
('23799','Hra','Hra','Xã Hra','Hra Commune','hra','52',4),
('23812','Lơ Pang','Lo Pang','Xã Lơ Pang','Lo Pang Commune','lo_pang','52',4),
('23818','Kon Chiêng','Kon Chieng','Xã Kon Chiêng','Kon Chieng Commune','kon_chieng','52',4),
('23824','Kông Chro','Kong Chro','Xã Kông Chro','Kong Chro Commune','kong_chro','52',4),
('23830','Chư Krey','Chu Krey','Xã Chư Krey','Chu Krey Commune','chu_krey','52',4),
('23833','Ya Ma','Ya Ma','Xã Ya Ma','Ya Ma Commune','ya_ma','52',4),
('23839','SRó','SRo','Xã SRó','SRo Commune','sro','52',4),
('23842','Đăk Song','Dak Song','Xã Đăk Song','Dak Song Commune','dak_song','52',4),
('23851','Chơ Long','Cho Long','Xã Chơ Long','Cho Long Commune','cho_long','52',4),
('23857','Đức Cơ','Duc Co','Xã Đức Cơ','Duc Co Commune','duc_co','52',4),
('23866','Ia Krêl','Ia Krel','Xã Ia Krêl','Ia Krel Commune','ia_krel','52',4),
('23869','Ia Dơk','Ia Dok','Xã Ia Dơk','Ia Dok Commune','ia_dok','52',4),
('23872','Ia Dom','Ia Dom','Xã Ia Dom','Ia Dom Commune','ia_dom','52',4),
('23881','Ia Pnôn','Ia Pnon','Xã Ia Pnôn','Ia Pnon Commune','ia_pnon','52',4),
('23884','Ia Nan','Ia Nan','Xã Ia Nan','Ia Nan Commune','ia_nan','52',4),
('23887','Chư Prông','Chu Prong','Xã Chư Prông','Chu Prong Commune','chu_prong','52',4),
('23896','Bàu Cạn','Bau Can','Xã Bàu Cạn','Bau Can Commune','bau_can','52',4),
('23908','Ia Tôr','Ia Tor','Xã Ia Tôr','Ia Tor Commune','ia_tor','52',4),
('23911','Ia Boòng','Ia Boong','Xã Ia Boòng','Ia Boong Commune','ia_boong','52',4),
('23917','Ia Púch','Ia Puch','Xã Ia Púch','Ia Puch Commune','ia_puch','52',4),
('23926','Ia Pia','Ia Pia','Xã Ia Pia','Ia Pia Commune','ia_pia','52',4),
('23935','Ia Lâu','Ia Lau','Xã Ia Lâu','Ia Lau Commune','ia_lau','52',4),
('23938','Ia Mơ','Ia Mo','Xã Ia Mơ','Ia Mo Commune','ia_mo','52',4),
('23941','Chư Sê','Chu Se','Xã Chư Sê','Chu Se Commune','chu_se','52',4),
('23942','Chư Pưh','Chu Puh','Xã Chư Pưh','Chu Puh Commune','chu_puh','52',4),
('23947','Bờ Ngoong','Bo Ngoong','Xã Bờ Ngoong','Bo Ngoong Commune','bo_ngoong','52',4),
('23954','Al Bá','Al Ba','Xã Al Bá','Al Ba Commune','al_ba','52',4),
('23971','Ia Hrú','Ia Hru','Xã Ia Hrú','Ia Hru Commune','ia_hru','52',4),
('23977','Ia Ko','Ia Ko','Xã Ia Ko','Ia Ko Commune','ia_ko','52',4),
('23986','Ia Le','Ia Le','Xã Ia Le','Ia Le Commune','ia_le','52',4),
('23995','Đak Pơ','Dak Po','Xã Đak Pơ','Dak Po Commune','dak_po','52',4),
('24007','Ya Hội','Ya Hoi','Xã Ya Hội','Ya Hoi Commune','ya_hoi','52',4),
('24013','Pờ Tó','Po To','Xã Pờ Tó','Po To Commune','po_to','52',4),
('24022','Ia Pa','Ia Pa','Xã Ia Pa','Ia Pa Commune','ia_pa','52',4),
('24028','Ia Tul','Ia Tul','Xã Ia Tul','Ia Tul Commune','ia_tul','52',4),
('24043','Phú Thiện','Phu Thien','Xã Phú Thiện','Phu Thien Commune','phu_thien','52',4),
('24044','Ayun Pa','Ayun Pa','Phường Ayun Pa','Ayun Pa Ward','ayun_pa','52',3),
('24049','Chư A Thai','Chu A Thai','Xã Chư A Thai','Chu A Thai Commune','chu_a_thai','52',4),
('24061','Ia Hiao','Ia Hiao','Xã Ia Hiao','Ia Hiao Commune','ia_hiao','52',4),
('24065','Ia Rbol','Ia Rbol','Xã Ia Rbol','Ia Rbol Commune','ia_rbol','52',4),
('24073','Ia Sao','Ia Sao','Xã Ia Sao','Ia Sao Commune','ia_sao','52',4),
('24076','Phú Túc','Phu Tuc','Xã Phú Túc','Phu Tuc Commune','phu_tuc','52',4),
('24100','Ia Dreh','Ia Dreh','Xã Ia Dreh','Ia Dreh Commune','ia_dreh','52',4),
('24109','Uar','Uar','Xã Uar','Uar Commune','uar','52',4),
('24112','Ia Rsai','Ia Rsai','Xã Ia Rsai','Ia Rsai Commune','ia_rsai','52',4),
('24121','Tân Lập','Tan Lap','Phường Tân Lập','Tan Lap Ward','tan_lap','66',3),
('24133','Buôn Ma Thuột','Buon Ma Thuot','Phường Buôn Ma Thuột','Buon Ma Thuot Ward','buon_ma_thuot','66',3),
('24154','Thành Nhất','Thanh Nhat','Phường Thành Nhất','Thanh Nhat Ward','thanh_nhat','66',3),
('24163','Tân An','Tan An','Phường Tân An','Tan An Ward','tan_an','66',3),
('24169','Ea Kao','Ea Kao','Phường Ea Kao','Ea Kao Ward','ea_kao','66',3),
('24175','Hòa Phú','Hoa Phu','Xã Hòa Phú','Hoa Phu Commune','hoa_phu','66',4),
('24181','Ea Drăng','Ea Drang','Xã Ea Drăng','Ea Drang Commune','ea_drang','66',4),
('24184','Ea H\'Leo','Ea H\'Leo','Xã Ea H\'Leo','Ea H\'Leo Commune','ea_hleo','66',4),
('24187','Ea Hiao','Ea Hiao','Xã Ea Hiao','Ea Hiao Commune','ea_hiao','66',4),
('24193','Ea Wy','Ea Wy','Xã Ea Wy','Ea Wy Commune','ea_wy','66',4),
('24208','Ea Khăl','Ea Khal','Xã Ea Khăl','Ea Khal Commune','ea_khal','66',4),
('24211','Ea Súp','Ea Sup','Xã Ea Súp','Ea Sup Commune','ea_sup','66',4),
('24214','Ia Lốp','Ia Lop','Xã Ia Lốp','Ia Lop Commune','ia_lop','66',4),
('24217','Ea Rốk','Ea Rok','Xã Ea Rốk','Ea Rok Commune','ea_rok','66',4),
('24221','Ia Rvê','Ia Rve','Xã Ia Rvê','Ia Rve Commune','ia_rve','66',4),
('24229','Ea Bung','Ea Bung','Xã Ea Bung','Ea Bung Commune','ea_bung','66',4),
('24235','Buôn Đôn','Buon Don','Xã Buôn Đôn','Buon Don Commune','buon_don','66',4),
('24241','Ea Wer','Ea Wer','Xã Ea Wer','Ea Wer Commune','ea_wer','66',4),
('24250','Ea Nuôl','Ea Nuol','Xã Ea Nuôl','Ea Nuol Commune','ea_nuol','66',4),
('24259','Quảng Phú','Quang Phu','Xã Quảng Phú','Quang Phu Commune','quang_phu','66',4),
('24265','Ea Kiết','Ea Kiet','Xã Ea Kiết','Ea Kiet Commune','ea_kiet','66',4),
('24277','Ea Tul','Ea Tul','Xã Ea Tul','Ea Tul Commune','ea_tul','66',4),
('24280','Cư M\'gar','Cu M\'gar','Xã Cư M\'gar','Cu M\'gar Commune','cu_mgar','66',4),
('24286','Ea M\'Droh','Ea M\'Droh','Xã Ea M\'Droh','Ea M\'Droh Commune','ea_mdroh','66',4),
('24301','Cuôr Đăng','Cuor Dang','Xã Cuôr Đăng','Cuor Dang Commune','cuor_dang','66',4),
('24305','Buôn Hồ','Buon Ho','Phường Buôn Hồ','Buon Ho Ward','buon_ho','66',3),
('24310','Krông Búk','Krong Buk','Xã Krông Búk','Krong Buk Commune','krong_buk','66',4),
('24313','Cư Pơng','Cu Pong','Xã Cư Pơng','Cu Pong Commune','cu_pong','66',4),
('24316','Pơng Drang','Pong Drang','Xã Pơng Drang','Pong Drang Commune','pong_drang','66',4),
('24328','Ea Drông','Ea Drong','Xã Ea Drông','Ea Drong Commune','ea_drong','66',4),
('24340','Cư Bao','Cu Bao','Phường Cư Bao','Cu Bao Ward','cu_bao','66',3),
('24343','Krông Năng','Krong Nang','Xã Krông Năng','Krong Nang Commune','krong_nang','66',4),
('24346','Dliê Ya','Dlie Ya','Xã Dliê Ya','Dlie Ya Commune','dlie_ya','66',4),
('24352','Tam Giang','Tam Giang','Xã Tam Giang','Tam Giang Commune','tam_giang','66',4),
('24364','Phú Xuân','Phu Xuan','Xã Phú Xuân','Phu Xuan Commune','phu_xuan','66',4),
('24373','Ea Kar','Ea Kar','Xã Ea Kar','Ea Kar Commune','ea_kar','66',4),
('24376','Ea Knốp','Ea Knop','Xã Ea Knốp','Ea Knop Commune','ea_knop','66',4),
('24400','Ea Păl','Ea Pal','Xã Ea Păl','Ea Pal Commune','ea_pal','66',4),
('24403','Ea Ô','Ea O','Xã Ea Ô','Ea O Commune','ea_o','66',4),
('24406','Cư Yang','Cu Yang','Xã Cư Yang','Cu Yang Commune','cu_yang','66',4),
('24412','M\'Drắk','M\'Drak','Xã M\'Drắk','M\'Drak Commune','mdrak','66',4),
('24415','Cư Prao','Cu Prao','Xã Cư Prao','Cu Prao Commune','cu_prao','66',4),
('24433','Ea Riêng','Ea Rieng','Xã Ea Riêng','Ea Rieng Commune','ea_rieng','66',4),
('24436','Cư M\'ta','Cu M\'ta','Xã Cư M\'ta','Cu M\'ta Commune','cu_mta','66',4),
('24444','Krông Á','Krong A','Xã Krông Á','Krong A Commune','krong_a','66',4),
('24445','Ea Trang','Ea Trang','Xã Ea Trang','Ea Trang Commune','ea_trang','66',4),
('24448','Krông Bông','Krong Bong','Xã Krông Bông','Krong Bong Commune','krong_bong','66',4),
('24454','Dang Kang','Dang Kang','Xã Dang Kang','Dang Kang Commune','dang_kang','66',4),
('24472','Hòa Sơn','Hoa Son','Xã Hòa Sơn','Hoa Son Commune','hoa_son','66',4),
('24478','Cư Pui','Cu Pui','Xã Cư Pui','Cu Pui Commune','cu_pui','66',4),
('24484','Yang Mao','Yang Mao','Xã Yang Mao','Yang Mao Commune','yang_mao','66',4),
('24490','Krông Pắc','Krong Pac','Xã Krông Pắc','Krong Pac Commune','krong_pac','66',4),
('24496','Ea Kly','Ea Kly','Xã Ea Kly','Ea Kly Commune','ea_kly','66',4),
('24502','Ea Phê','Ea Phe','Xã Ea Phê','Ea Phe Commune','ea_phe','66',4),
('24505','Ea Knuếc','Ea Knuec','Xã Ea Knuếc','Ea Knuec Commune','ea_knuec','66',4),
('24526','Tân Tiến','Tan Tien','Xã Tân Tiến','Tan Tien Commune','tan_tien','66',4),
('24529','Vụ Bổn','Vu Bon','Xã Vụ Bổn','Vu Bon Commune','vu_bon','66',4),
('24538','Krông Ana','Krong Ana','Xã Krông Ana','Krong Ana Commune','krong_ana','66',4),
('24540','Ea Ning','Ea Ning','Xã Ea Ning','Ea Ning Commune','ea_ning','66',4),
('24544','Ea Ktur','Ea Ktur','Xã Ea Ktur','Ea Ktur Commune','ea_ktur','66',4),
('24559','Ea Na','Ea Na','Xã Ea Na','Ea Na Commune','ea_na','66',4),
('24561','Dray Bhăng','Dray Bhang','Xã Dray Bhăng','Dray Bhang Commune','dray_bhang','66',4),
('24568','Dur Kmăl','Dur Kmal','Xã Dur Kmăl','Dur Kmal Commune','dur_kmal','66',4),
('24580','Liên Sơn Lắk','Lien Son Lak','Xã Liên Sơn Lắk','Lien Son Lak Commune','lien_son_lak','66',4),
('24595','Đắk Liêng','Dak Lieng','Xã Đắk Liêng','Dak Lieng Commune','dak_lieng','66',4),
('24598','Đắk Phơi','Dak Phoi','Xã Đắk Phơi','Dak Phoi Commune','dak_phoi','66',4),
('24604','Krông Nô','Krong No','Xã Krông Nô','Krong No Commune','krong_no','66',4),
('24607','Nam Ka','Nam Ka','Xã Nam Ka','Nam Ka Commune','nam_ka','66',4),
('24611','Bắc Gia Nghĩa','Bac Gia Nghia','Phường Bắc Gia Nghĩa','Bac Gia Nghia Ward','bac_gia_nghia','68',3),
('24615','Nam Gia Nghĩa','Nam Gia Nghia','Phường Nam Gia Nghĩa','Nam Gia Nghia Ward','nam_gia_nghia','68',3),
('24616','Quảng Sơn','Quang Son','Xã Quảng Sơn','Quang Son Commune','quang_son','68',4),
('24617','Đông Gia Nghĩa','Dong Gia Nghia','Phường Đông Gia Nghĩa','Dong Gia Nghia Ward','dong_gia_nghia','68',3),
('24620','Quảng Hòa','Quang Hoa','Xã Quảng Hòa','Quang Hoa Commune','quang_hoa','68',4),
('24631','Quảng Khê','Quang Khe','Xã Quảng Khê','Quang Khe Commune','quang_khe','68',4),
('24637','Tà Đùng','Ta Dung','Xã Tà Đùng','Ta Dung Commune','ta_dung','68',4),
('24640','Cư Jút','Cu Jut','Xã Cư Jút','Cu Jut Commune','cu_jut','68',4),
('24646','Đắk Wil','Dak Wil','Xã Đắk Wil','Dak Wil Commune','dak_wil','68',4),
('24649','Nam Dong','Nam Dong','Xã Nam Dong','Nam Dong Commune','nam_dong','68',4),
('24664','Đức Lập','Duc Lap','Xã Đức Lập','Duc Lap Commune','duc_lap','68',4),
('24670','Đắk Mil','Dak Mil','Xã Đắk Mil','Dak Mil Commune','dak_mil','68',4),
('24678','Đắk Sắk','Dak Sak','Xã Đắk Sắk','Dak Sak Commune','dak_sak','68',4),
('24682','Thuận An','Thuan An','Xã Thuận An','Thuan An Commune','thuan_an','68',4),
('24688','Krông Nô','Krong No','Xã Krông Nô','Krong No Commune','krong_no','68',4),
('24697','Nam Đà','Nam Da','Xã Nam Đà','Nam Da Commune','nam_da','68',4),
('24703','Nâm Nung','Nam Nung','Xã Nâm Nung','Nam Nung Commune','nam_nung','68',4),
('24712','Quảng Phú','Quang Phu','Xã Quảng Phú','Quang Phu Commune','quang_phu','68',4),
('24717','Đức An','Duc An','Xã Đức An','Duc An Commune','duc_an','68',4),
('24718','Đắk Song','Dak Song','Xã Đắk Song','Dak Song Commune','dak_song','68',4),
('24722','Thuận Hạnh','Thuan Hanh','Xã Thuận Hạnh','Thuan Hanh Commune','thuan_hanh','68',4),
('24730','Trường Xuân','Truong Xuan','Xã Trường Xuân','Truong Xuan Commune','truong_xuan','68',4),
('24733','Kiến Đức','Kien Duc','Xã Kiến Đức','Kien Duc Commune','kien_duc','68',4),
('24736','Quảng Trực','Quang Truc','Xã Quảng Trực','Quang Truc Commune','quang_truc','68',4),
('24739','Tuy Đức','Tuy Duc','Xã Tuy Đức','Tuy Duc Commune','tuy_duc','68',4),
('24748','Quảng Tân','Quang Tan','Xã Quảng Tân','Quang Tan Commune','quang_tan','68',4),
('24751','Nhân Cơ','Nhan Co','Xã Nhân Cơ','Nhan Co Commune','nhan_co','68',4),
('24760','Quảng Tín','Quang Tin','Xã Quảng Tín','Quang Tin Commune','quang_tin','68',4),
('24778','Lâm Viên - Đà Lạt','Lam Vien - Da Lat','Phường Lâm Viên - Đà Lạt','Lam Vien - Da Lat Ward','lam_vien_da_lat','68',3),
('24781','Xuân Hương - Đà Lạt','Xuan Huong - Da Lat','Phường Xuân Hương - Đà Lạt','Xuan Huong - Da Lat Ward','xuan_huong_da_lat','68',3),
('24787','Cam Ly - Đà Lạt','Cam Ly - Da Lat','Phường Cam Ly - Đà Lạt','Cam Ly - Da Lat Ward','cam_ly_da_lat','68',3),
('24805','Xuân Trường - Đà Lạt','Xuan Truong - Da Lat','Phường Xuân Trường - Đà Lạt','Xuan Truong - Da Lat Ward','xuan_truong_da_lat','68',3),
('24820','2 Bảo Lộc','2 Bao Loc','Phường 2 Bảo Lộc','2 Bao Loc Ward','2_bao_loc','68',3),
('24823','1 Bảo Lộc','1 Bao Loc','Phường 1 Bảo Lộc','1 Bao Loc Ward','1_bao_loc','68',3),
('24829','B\'Lao','B\'Lao','Phường B\'Lao','B\'Lao Ward','blao','68',3),
('24841','3 Bảo Lộc','3 Bao Loc','Phường 3 Bảo Lộc','3 Bao Loc Ward','3_bao_loc','68',3),
('24846','Lang Biang - Đà Lạt','Lang Biang - Da Lat','Phường Lang Biang - Đà Lạt','Lang Biang - Da Lat Ward','lang_biang_da_lat','68',3),
('24848','Lạc Dương','Lac Duong','Xã Lạc Dương','Lac Duong Commune','lac_duong','68',4),
('24853','Đam Rông 4','Dam Rong 4','Xã Đam Rông 4','Dam Rong 4 Commune','dam_rong_4','68',4),
('24868','Nam Ban Lâm Hà','Nam Ban Lam Ha','Xã Nam Ban Lâm Hà','Nam Ban Lam Ha Commune','nam_ban_lam_ha','68',4),
('24871','Đinh Văn Lâm Hà','Dinh Van Lam Ha','Xã Đinh Văn Lâm Hà','Dinh Van Lam Ha Commune','dinh_van_lam_ha','68',4),
('24875','Đam Rông 3','Dam Rong 3','Xã Đam Rông 3','Dam Rong 3 Commune','dam_rong_3','68',4),
('24877','Đam Rông 2','Dam Rong 2','Xã Đam Rông 2','Dam Rong 2 Commune','dam_rong_2','68',4),
('24883','Nam Hà Lâm Hà','Nam Ha Lam Ha','Xã Nam Hà Lâm Hà','Nam Ha Lam Ha Commune','nam_ha_lam_ha','68',4),
('24886','Đam Rông 1','Dam Rong 1','Xã Đam Rông 1','Dam Rong 1 Commune','dam_rong_1','68',4),
('24895','Phú Sơn Lâm Hà','Phu Son Lam Ha','Xã Phú Sơn Lâm Hà','Phu Son Lam Ha Commune','phu_son_lam_ha','68',4),
('24907','Phúc Thọ Lâm Hà','Phuc Tho Lam Ha','Xã Phúc Thọ Lâm Hà','Phuc Tho Lam Ha Commune','phuc_tho_lam_ha','68',4),
('24916','Tân Hà Lâm Hà','Tan Ha Lam Ha','Xã Tân Hà Lâm Hà','Tan Ha Lam Ha Commune','tan_ha_lam_ha','68',4),
('24931','Đơn Dương','Don Duong','Xã Đơn Dương','Don Duong Commune','don_duong','68',4),
('24934','D\'Ran','D\'Ran','Xã D\'Ran','D\'Ran Commune','dran','68',4),
('24943','Ka Đô','Ka Do','Xã Ka Đô','Ka Do Commune','ka_do','68',4),
('24955','Quảng Lập','Quang Lap','Xã Quảng Lập','Quang Lap Commune','quang_lap','68',4),
('24958','Đức Trọng','Duc Trong','Xã Đức Trọng','Duc Trong Commune','duc_trong','68',4),
('24967','Hiệp Thạnh','Hiep Thanh','Xã Hiệp Thạnh','Hiep Thanh Commune','hiep_thanh','68',4),
('24976','Tân Hội','Tan Hoi','Xã Tân Hội','Tan Hoi Commune','tan_hoi','68',4),
('24985','Ninh Gia','Ninh Gia','Xã Ninh Gia','Ninh Gia Commune','ninh_gia','68',4),
('24988','Tà Năng','Ta Nang','Xã Tà Năng','Ta Nang Commune','ta_nang','68',4),
('24991','Tà Hine','Ta Hine','Xã Tà Hine','Ta Hine Commune','ta_hine','68',4),
('25000','Di Linh','Di Linh','Xã Di Linh','Di Linh Commune','di_linh','68',4),
('25007','Đinh Trang Thượng','Dinh Trang Thuong','Xã Đinh Trang Thượng','Dinh Trang Thuong Commune','dinh_trang_thuong','68',4),
('25015','Gia Hiệp','Gia Hiep','Xã Gia Hiệp','Gia Hiep Commune','gia_hiep','68',4),
('25018','Bảo Thuận','Bao Thuan','Xã Bảo Thuận','Bao Thuan Commune','bao_thuan','68',4),
('25036','Hòa Ninh','Hoa Ninh','Xã Hòa Ninh','Hoa Ninh Commune','hoa_ninh','68',4),
('25042','Hòa Bắc','Hoa Bac','Xã Hòa Bắc','Hoa Bac Commune','hoa_bac','68',4),
('25051','Sơn Điền','Son Dien','Xã Sơn Điền','Son Dien Commune','son_dien','68',4),
('25054','Bảo Lâm 1','Bao Lam 1','Xã Bảo Lâm 1','Bao Lam 1 Commune','bao_lam_1','68',4),
('25057','Bảo Lâm 5','Bao Lam 5','Xã Bảo Lâm 5','Bao Lam 5 Commune','bao_lam_5','68',4),
('25063','Bảo Lâm 4','Bao Lam 4','Xã Bảo Lâm 4','Bao Lam 4 Commune','bao_lam_4','68',4),
('25084','Bảo Lâm 2','Bao Lam 2','Xã Bảo Lâm 2','Bao Lam 2 Commune','bao_lam_2','68',4),
('25093','Bảo Lâm 3','Bao Lam 3','Xã Bảo Lâm 3','Bao Lam 3 Commune','bao_lam_3','68',4),
('25099','Đạ Huoai','Da Huoai','Xã Đạ Huoai','Da Huoai Commune','da_huoai','68',4),
('25105','Đạ Huoai 2','Da Huoai 2','Xã Đạ Huoai 2','Da Huoai 2 Commune','da_huoai_2','68',4),
('25114','Đạ Huoai 3','Da Huoai 3','Xã Đạ Huoai 3','Da Huoai 3 Commune','da_huoai_3','68',4),
('25126','Đạ Tẻh','Da Teh','Xã Đạ Tẻh','Da Teh Commune','da_teh','68',4),
('25135','Đạ Tẻh 3','Da Teh 3','Xã Đạ Tẻh 3','Da Teh 3 Commune','da_teh_3','68',4),
('25138','Đạ Tẻh 2','Da Teh 2','Xã Đạ Tẻh 2','Da Teh 2 Commune','da_teh_2','68',4),
('25159','Cát Tiên','Cat Tien','Xã Cát Tiên','Cat Tien Commune','cat_tien','68',4),
('25162','Cát Tiên 3','Cat Tien 3','Xã Cát Tiên 3','Cat Tien 3 Commune','cat_tien_3','68',4),
('25180','Cát Tiên 2','Cat Tien 2','Xã Cát Tiên 2','Cat Tien 2 Commune','cat_tien_2','68',4),
('25195','Bình Phước','Binh Phuoc','Phường Bình Phước','Binh Phuoc Ward','binh_phuoc','75',3),
('25210','Đồng Xoài','Dong Xoai','Phường Đồng Xoài','Dong Xoai Ward','dong_xoai','75',3),
('25217','Phước Long','Phuoc Long','Phường Phước Long','Phuoc Long Ward','phuoc_long','75',3),
('25220','Phước Bình','Phuoc Binh','Phường Phước Bình','Phuoc Binh Ward','phuoc_binh','75',3),
('25222','Bù Gia Mập','Bu Gia Map','Xã Bù Gia Mập','Bu Gia Map Commune','bu_gia_map','75',4),
('25225','Đăk Ơ','Dak O','Xã Đăk Ơ','Dak O Commune','dak_o','75',4),
('25231','Đa Kia','Da Kia','Xã Đa Kia','Da Kia Commune','da_kia','75',4),
('25246','Bình Tân','Binh Tan','Xã Bình Tân','Binh Tan Commune','binh_tan','75',4),
('25252','Phú Riềng','Phu Rieng','Xã Phú Riềng','Phu Rieng Commune','phu_rieng','75',4),
('25255','Long Hà','Long Ha','Xã Long Hà','Long Ha Commune','long_ha','75',4),
('25261','Phú Trung','Phu Trung','Xã Phú Trung','Phu Trung Commune','phu_trung','75',4),
('25267','Phú Nghĩa','Phu Nghia','Xã Phú Nghĩa','Phu Nghia Commune','phu_nghia','75',4),
('25270','Lộc Ninh','Loc Ninh','Xã Lộc Ninh','Loc Ninh Commune','loc_ninh','75',4),
('25279','Lộc Tấn','Loc Tan','Xã Lộc Tấn','Loc Tan Commune','loc_tan','75',4),
('25280','Lộc Thạnh','Loc Thanh','Xã Lộc Thạnh','Loc Thanh Commune','loc_thanh','75',4),
('25292','Lộc Quang','Loc Quang','Xã Lộc Quang','Loc Quang Commune','loc_quang','75',4),
('25294','Lộc Thành','Loc Thanh','Xã Lộc Thành','Loc Thanh Commune','loc_thanh','75',4),
('25303','Lộc Hưng','Loc Hung','Xã Lộc Hưng','Loc Hung Commune','loc_hung','75',4),
('25308','Thiện Hưng','Thien Hung','Xã Thiện Hưng','Thien Hung Commune','thien_hung','75',4),
('25309','Hưng Phước','Hung Phuoc','Xã Hưng Phước','Hung Phuoc Commune','hung_phuoc','75',4),
('25318','Tân Tiến','Tan Tien','Xã Tân Tiến','Tan Tien Commune','tan_tien','75',4),
('25326','Bình Long','Binh Long','Phường Bình Long','Binh Long Ward','binh_long','75',3),
('25333','An Lộc','An Loc','Phường An Lộc','An Loc Ward','an_loc','75',3),
('25345','Tân Hưng','Tan Hung','Xã Tân Hưng','Tan Hung Commune','tan_hung','75',4),
('25349','Minh Đức','Minh Duc','Xã Minh Đức','Minh Duc Commune','minh_duc','75',4),
('25351','Tân Quan','Tan Quan','Xã Tân Quan','Tan Quan Commune','tan_quan','75',4),
('25357','Tân Khai','Tan Khai','Xã Tân Khai','Tan Khai Commune','tan_khai','75',4),
('25363','Đồng Phú','Dong Phu','Xã Đồng Phú','Dong Phu Commune','dong_phu','75',4),
('25378','Tân Lợi','Tan Loi','Xã Tân Lợi','Tan Loi Commune','tan_loi','75',4),
('25387','Thuận Lợi','Thuan Loi','Xã Thuận Lợi','Thuan Loi Commune','thuan_loi','75',4),
('25390','Đồng Tâm','Dong Tam','Xã Đồng Tâm','Dong Tam Commune','dong_tam','75',4),
('25396','Bù Đăng','Bu Dang','Xã Bù Đăng','Bu Dang Commune','bu_dang','75',4),
('25399','Đak Nhau','Dak Nhau','Xã Đak Nhau','Dak Nhau Commune','dak_nhau','75',4),
('25402','Thọ Sơn','Tho Son','Xã Thọ Sơn','Tho Son Commune','tho_son','75',4),
('25405','Bom Bo','Bom Bo','Xã Bom Bo','Bom Bo Commune','bom_bo','75',4),
('25417','Nghĩa Trung','Nghia Trung','Xã Nghĩa Trung','Nghia Trung Commune','nghia_trung','75',4),
('25420','Phước Sơn','Phuoc Son','Xã Phước Sơn','Phuoc Son Commune','phuoc_son','75',4),
('25432','Chơn Thành','Chon Thanh','Phường Chơn Thành','Chon Thanh Ward','chon_thanh','75',3),
('25441','Minh Hưng','Minh Hung','Phường Minh Hưng','Minh Hung Ward','minh_hung','75',3),
('25450','Nha Bích','Nha Bich','Xã Nha Bích','Nha Bich Commune','nha_bich','75',4),
('25459','Tân Ninh','Tan Ninh','Phường Tân Ninh','Tan Ninh Ward','tan_ninh','80',3),
('25480','Bình Minh','Binh Minh','Phường Bình Minh','Binh Minh Ward','binh_minh','80',3),
('25486','Tân Biên','Tan Bien','Xã Tân Biên','Tan Bien Commune','tan_bien','80',4),
('25489','Tân Lập','Tan Lap','Xã Tân Lập','Tan Lap Commune','tan_lap','80',4),
('25498','Thạnh Bình','Thanh Binh','Xã Thạnh Bình','Thanh Binh Commune','thanh_binh','80',4),
('25510','Trà Vong','Tra Vong','Xã Trà Vong','Tra Vong Commune','tra_vong','80',4),
('25516','Tân Châu','Tan Chau','Xã Tân Châu','Tan Chau Commune','tan_chau','80',4),
('25522','Tân Đông','Tan Dong','Xã Tân Đông','Tan Dong Commune','tan_dong','80',4),
('25525','Tân Hội','Tan Hoi','Xã Tân Hội','Tan Hoi Commune','tan_hoi','80',4),
('25531','Tân Hòa','Tan Hoa','Xã Tân Hòa','Tan Hoa Commune','tan_hoa','80',4),
('25534','Tân Thành','Tan Thanh','Xã Tân Thành','Tan Thanh Commune','tan_thanh','80',4),
('25549','Tân Phú','Tan Phu','Xã Tân Phú','Tan Phu Commune','tan_phu','80',4),
('25552','Dương Minh Châu','Duong Minh Chau','Xã Dương Minh Châu','Duong Minh Chau Commune','duong_minh_chau','80',4),
('25567','Ninh Thạnh','Ninh Thanh','Phường Ninh Thạnh','Ninh Thanh Ward','ninh_thanh','80',3),
('25573','Cầu Khởi','Cau Khoi','Xã Cầu Khởi','Cau Khoi Commune','cau_khoi','80',4),
('25579','Lộc Ninh','Loc Ninh','Xã Lộc Ninh','Loc Ninh Commune','loc_ninh','80',4),
('25585','Châu Thành','Chau Thanh','Xã Châu Thành','Chau Thanh Commune','chau_thanh','80',4),
('25588','Hảo Đước','Hao Duoc','Xã Hảo Đước','Hao Duoc Commune','hao_duoc','80',4),
('25591','Phước Vinh','Phuoc Vinh','Xã Phước Vinh','Phuoc Vinh Commune','phuoc_vinh','80',4),
('25606','Hòa Hội','Hoa Hoi','Xã Hòa Hội','Hoa Hoi Commune','hoa_hoi','80',4),
('25621','Ninh Điền','Ninh Dien','Xã Ninh Điền','Ninh Dien Commune','ninh_dien','80',4),
('25630','Long Hoa','Long Hoa','Phường Long Hoa','Long Hoa Ward','long_hoa','80',3),
('25633','Thanh Điền','Thanh Dien','Phường Thanh Điền','Thanh Dien Ward','thanh_dien','80',3),
('25645','Hòa Thành','Hoa Thanh','Phường Hòa Thành','Hoa Thanh Ward','hoa_thanh','80',3),
('25654','Gò Dầu','Go Dau','Phường Gò Dầu','Go Dau Ward','go_dau','80',3),
('25657','Thạnh Đức','Thanh Duc','Xã Thạnh Đức','Thanh Duc Commune','thanh_duc','80',4),
('25663','Phước Thạnh','Phuoc Thanh','Xã Phước Thạnh','Phuoc Thanh Commune','phuoc_thanh','80',4),
('25666','Truông Mít','Truong Mit','Xã Truông Mít','Truong Mit Commune','truong_mit','80',4),
('25672','Gia Lộc','Gia Loc','Phường Gia Lộc','Gia Loc Ward','gia_loc','80',3),
('25681','Bến Cầu','Ben Cau','Xã Bến Cầu','Ben Cau Commune','ben_cau','80',4),
('25684','Long Chữ','Long Chu','Xã Long Chữ','Long Chu Commune','long_chu','80',4),
('25702','Long Thuận','Long Thuan','Xã Long Thuận','Long Thuan Commune','long_thuan','80',4),
('25708','Trảng Bàng','Trang Bang','Phường Trảng Bàng','Trang Bang Ward','trang_bang','80',3),
('25711','Hưng Thuận','Hung Thuan','Xã Hưng Thuận','Hung Thuan Commune','hung_thuan','80',4),
('25729','Phước Chỉ','Phuoc Chi','Xã Phước Chỉ','Phuoc Chi Commune','phuoc_chi','80',4),
('25732','An Tịnh','An Tinh','Phường An Tịnh','An Tinh Ward','an_tinh','80',3),
('25747','Thủ Dầu Một','Thu Dau Mot','Phường Thủ Dầu Một','Thu Dau Mot Ward','thu_dau_mot','79',3),
('25750','Phú Lợi','Phu Loi','Phường Phú Lợi','Phu Loi Ward','phu_loi','79',3),
('25760','Bình Dương','Binh Duong','Phường Bình Dương','Binh Duong Ward','binh_duong','79',3),
('25768','Phú An','Phu An','Phường Phú An','Phu An Ward','phu_an','79',3),
('25771','Chánh Hiệp','Chanh Hiep','Phường Chánh Hiệp','Chanh Hiep Ward','chanh_hiep','79',3),
('25777','Dầu Tiếng','Dau Tieng','Xã Dầu Tiếng','Dau Tieng Commune','dau_tieng','79',4),
('25780','Minh Thạnh','Minh Thanh','Xã Minh Thạnh','Minh Thanh Commune','minh_thanh','79',4),
('25792','Long Hòa','Long Hoa','Xã Long Hòa','Long Hoa Commune','long_hoa','79',4),
('25807','Thanh An','Thanh An','Xã Thanh An','Thanh An Commune','thanh_an','79',4),
('25813','Bến Cát','Ben Cat','Phường Bến Cát','Ben Cat Ward','ben_cat','79',3),
('25819','Trừ Văn Thố','Tru Van Tho','Xã Trừ Văn Thố','Tru Van Tho Commune','tru_van_tho','79',4),
('25822','Bàu Bàng','Bau Bang','Xã Bàu Bàng','Bau Bang Commune','bau_bang','79',4),
('25837','Chánh Phú Hòa','Chanh Phu Hoa','Phường Chánh Phú Hòa','Chanh Phu Hoa Ward','chanh_phu_hoa','79',3),
('25840','Long Nguyên','Long Nguyen','Phường Long Nguyên','Long Nguyen Ward','long_nguyen','79',3),
('25843','Tây Nam','Tay Nam','Phường Tây Nam','Tay Nam Ward','tay_nam','79',3),
('25846','Thới Hòa','Thoi Hoa','Phường Thới Hòa','Thoi Hoa Ward','thoi_hoa','79',3),
('25849','Hòa Lợi','Hoa Loi','Phường Hòa Lợi','Hoa Loi Ward','hoa_loi','79',3),
('25858','Phú Giáo','Phu Giao','Xã Phú Giáo','Phu Giao Commune','phu_giao','79',4),
('25864','Phước Thành','Phuoc Thanh','Xã Phước Thành','Phuoc Thanh Commune','phuoc_thanh','79',4),
('25867','An Long','An Long','Xã An Long','An Long Commune','an_long','79',4),
('25882','Phước Hòa','Phuoc Hoa','Xã Phước Hòa','Phuoc Hoa Commune','phuoc_hoa','79',4),
('25888','Tân Uyên','Tan Uyen','Phường Tân Uyên','Tan Uyen Ward','tan_uyen','79',3),
('25891','Tân Khánh','Tan Khanh','Phường Tân Khánh','Tan Khanh Ward','tan_khanh','79',3),
('25906','Bắc Tân Uyên','Bac Tan Uyen','Xã Bắc Tân Uyên','Bac Tan Uyen Commune','bac_tan_uyen','79',4),
('25909','Thường Tân','Thuong Tan','Xã Thường Tân','Thuong Tan Commune','thuong_tan','79',4),
('25912','Vĩnh Tân','Vinh Tan','Phường Vĩnh Tân','Vinh Tan Ward','vinh_tan','79',3),
('25915','Bình Cơ','Binh Co','Phường Bình Cơ','Binh Co Ward','binh_co','79',3),
('25920','Tân Hiệp','Tan Hiep','Phường Tân Hiệp','Tan Hiep Ward','tan_hiep','79',3),
('25942','Dĩ An','Di An','Phường Dĩ An','Di An Ward','di_an','79',3),
('25945','Tân Đông Hiệp','Tan Dong Hiep','Phường Tân Đông Hiệp','Tan Dong Hiep Ward','tan_dong_hiep','79',3),
('25951','Đông Hòa','Dong Hoa','Phường Đông Hòa','Dong Hoa Ward','dong_hoa','79',3),
('25966','Lái Thiêu','Lai Thieu','Phường Lái Thiêu','Lai Thieu Ward','lai_thieu','79',3),
('25969','Thuận Giao','Thuan Giao','Phường Thuận Giao','Thuan Giao Ward','thuan_giao','79',3),
('25975','An Phú','An Phu','Phường An Phú','An Phu Ward','an_phu','79',3),
('25978','Thuận An','Thuan An','Phường Thuận An','Thuan An Ward','thuan_an','79',3),
('25987','Bình Hòa','Binh Hoa','Phường Bình Hòa','Binh Hoa Ward','binh_hoa','79',3),
('25993','Trảng Dài','Trang Dai','Phường Trảng Dài','Trang Dai Ward','trang_dai','75',3),
('26005','Hố Nai','Ho Nai','Phường Hố Nai','Ho Nai Ward','ho_nai','75',3),
('26017','Tam Hiệp','Tam Hiep','Phường Tam Hiệp','Tam Hiep Ward','tam_hiep','75',3),
('26020','Long Bình','Long Binh','Phường Long Bình','Long Binh Ward','long_binh','75',3),
('26041','Trấn Biên','Tran Bien','Phường Trấn Biên','Tran Bien Ward','tran_bien','75',3),
('26068','Biên Hòa','Bien Hoa','Phường Biên Hòa','Bien Hoa Ward','bien_hoa','75',3),
('26080','Long Khánh','Long Khanh','Phường Long Khánh','Long Khanh Ward','long_khanh','75',3),
('26089','Bình Lộc','Binh Loc','Phường Bình Lộc','Binh Loc Ward','binh_loc','75',3),
('26098','Bảo Vinh','Bao Vinh','Phường Bảo Vinh','Bao Vinh Ward','bao_vinh','75',3),
('26104','Xuân Lập','Xuan Lap','Phường Xuân Lập','Xuan Lap Ward','xuan_lap','75',3),
('26113','Hàng Gòn','Hang Gon','Phường Hàng Gòn','Hang Gon Ward','hang_gon','75',3),
('26116','Tân Phú','Tan Phu','Xã Tân Phú','Tan Phu Commune','tan_phu','75',4),
('26119','Đak Lua','Dak Lua','Xã Đak Lua','Dak Lua Commune','dak_lua','75',4),
('26122','Nam Cát Tiên','Nam Cat Tien','Xã Nam Cát Tiên','Nam Cat Tien Commune','nam_cat_tien','75',4),
('26134','Tà Lài','Ta Lai','Xã Tà Lài','Ta Lai Commune','ta_lai','75',4),
('26158','Phú Lâm','Phu Lam','Xã Phú Lâm','Phu Lam Commune','phu_lam','75',4),
('26170','Trị An','Tri An','Xã Trị An','Tri An Commune','tri_an','75',4),
('26173','Phú Lý','Phu Ly','Xã Phú Lý','Phu Ly Commune','phu_ly','75',4),
('26179','Tân An','Tan An','Xã Tân An','Tan An Commune','tan_an','75',4),
('26188','Tân Triều','Tan Trieu','Phường Tân Triều','Tan Trieu Ward','tan_trieu','75',3),
('26206','Định Quán','Dinh Quan','Xã Định Quán','Dinh Quan Commune','dinh_quan','75',4),
('26209','Thanh Sơn','Thanh Son','Xã Thanh Sơn','Thanh Son Commune','thanh_son','75',4),
('26215','Phú Vinh','Phu Vinh','Xã Phú Vinh','Phu Vinh Commune','phu_vinh','75',4),
('26221','Phú Hòa','Phu Hoa','Xã Phú Hòa','Phu Hoa Commune','phu_hoa','75',4),
('26227','La Ngà','La Nga','Xã La Ngà','La Nga Commune','la_nga','75',4),
('26248','Trảng Bom','Trang Bom','Xã Trảng Bom','Trang Bom Commune','trang_bom','75',4),
('26254','Bàu Hàm','Bau Ham','Xã Bàu Hàm','Bau Ham Commune','bau_ham','75',4),
('26278','Bình Minh','Binh Minh','Xã Bình Minh','Binh Minh Commune','binh_minh','75',4),
('26281','Hưng Thịnh','Hung Thinh','Xã Hưng Thịnh','Hung Thinh Commune','hung_thinh','75',4),
('26296','An Viễn','An Vien','Xã An Viễn','An Vien Commune','an_vien','75',4),
('26299','Thống Nhất','Thong Nhat','Xã Thống Nhất','Thong Nhat Commune','thong_nhat','75',4),
('26311','Gia Kiệm','Gia Kiem','Xã Gia Kiệm','Gia Kiem Commune','gia_kiem','75',4),
('26326','Dầu Giây','Dau Giay','Xã Dầu Giây','Dau Giay Commune','dau_giay','75',4),
('26332','Xuân Quế','Xuan Que','Xã Xuân Quế','Xuan Que Commune','xuan_que','75',4),
('26341','Cẩm Mỹ','Cam My','Xã Cẩm Mỹ','Cam My Commune','cam_my','75',4),
('26347','Xuân Đường','Xuan Duong','Xã Xuân Đường','Xuan Duong Commune','xuan_duong','75',4),
('26359','Xuân Đông','Xuan Dong','Xã Xuân Đông','Xuan Dong Commune','xuan_dong','75',4),
('26362','Sông Ray','Song Ray','Xã Sông Ray','Song Ray Commune','song_ray','75',4),
('26368','Long Thành','Long Thanh','Xã Long Thành','Long Thanh Commune','long_thanh','75',4),
('26374','Tam Phước','Tam Phuoc','Phường Tam Phước','Tam Phuoc Ward','tam_phuoc','75',3),
('26377','Phước Tân','Phuoc Tan','Phường Phước Tân','Phuoc Tan Ward','phuoc_tan','75',3),
('26380','Long Hưng','Long Hung','Phường Long Hưng','Long Hung Ward','long_hung','75',3),
('26383','An Phước','An Phuoc','Xã An Phước','An Phuoc Commune','an_phuoc','75',4),
('26389','Bình An','Binh An','Xã Bình An','Binh An Commune','binh_an','75',4),
('26413','Long Phước','Long Phuoc','Xã Long Phước','Long Phuoc Commune','long_phuoc','75',4),
('26422','Phước Thái','Phuoc Thai','Xã Phước Thái','Phuoc Thai Commune','phuoc_thai','75',4),
('26425','Xuân Lộc','Xuan Loc','Xã Xuân Lộc','Xuan Loc Commune','xuan_loc','75',4),
('26428','Xuân Bắc','Xuan Bac','Xã Xuân Bắc','Xuan Bac Commune','xuan_bac','75',4),
('26434','Xuân Thành','Xuan Thanh','Xã Xuân Thành','Xuan Thanh Commune','xuan_thanh','75',4),
('26446','Xuân Hòa','Xuan Hoa','Xã Xuân Hòa','Xuan Hoa Commune','xuan_hoa','75',4),
('26458','Xuân Phú','Xuan Phu','Xã Xuân Phú','Xuan Phu Commune','xuan_phu','75',4),
('26461','Xuân Định','Xuan Dinh','Xã Xuân Định','Xuan Dinh Commune','xuan_dinh','75',4),
('26485','Nhơn Trạch','Nhon Trach','Xã Nhơn Trạch','Nhon Trach Commune','nhon_trach','75',4),
('26491','Đại Phước','Dai Phuoc','Xã Đại Phước','Dai Phuoc Commune','dai_phuoc','75',4),
('26503','Phước An','Phuoc An','Xã Phước An','Phuoc An Commune','phuoc_an','75',4),
('26506','Vũng Tàu','Vung Tau','Phường Vũng Tàu','Vung Tau Ward','vung_tau','79',3),
('26526','Tam Thắng','Tam Thang','Phường Tam Thắng','Tam Thang Ward','tam_thang','79',3),
('26536','Rạch Dừa','Rach Dua','Phường Rạch Dừa','Rach Dua Ward','rach_dua','79',3),
('26542','Phước Thắng','Phuoc Thang','Phường Phước Thắng','Phuoc Thang Ward','phuoc_thang','79',3),
('26545','Long Sơn','Long Son','Xã Long Sơn','Long Son Commune','long_son','79',4),
('26560','Bà Rịa','Ba Ria','Phường Bà Rịa','Ba Ria Ward','ba_ria','79',3),
('26566','Long Hương','Long Huong','Phường Long Hương','Long Huong Ward','long_huong','79',3),
('26572','Tam Long','Tam Long','Phường Tam Long','Tam Long Ward','tam_long','79',3),
('26575','Ngãi Giao','Ngai Giao','Xã Ngãi Giao','Ngai Giao Commune','ngai_giao','79',4),
('26584','Xuân Sơn','Xuan Son','Xã Xuân Sơn','Xuan Son Commune','xuan_son','79',4),
('26590','Bình Giã','Binh Gia','Xã Bình Giã','Binh Gia Commune','binh_gia','79',4),
('26596','Châu Đức','Chau Duc','Xã Châu Đức','Chau Duc Commune','chau_duc','79',4),
('26608','Kim Long','Kim Long','Xã Kim Long','Kim Long Commune','kim_long','79',4),
('26617','Nghĩa Thành','Nghia Thanh','Xã Nghĩa Thành','Nghia Thanh Commune','nghia_thanh','79',4),
('26620','Hồ Tràm','Ho Tram','Xã Hồ Tràm','Ho Tram Commune','ho_tram','79',4),
('26632','Xuyên Mộc','Xuyen Moc','Xã Xuyên Mộc','Xuyen Moc Commune','xuyen_moc','79',4),
('26638','Bàu Lâm','Bau Lam','Xã Bàu Lâm','Bau Lam Commune','bau_lam','79',4),
('26641','Hòa Hội','Hoa Hoi','Xã Hòa Hội','Hoa Hoi Commune','hoa_hoi','79',4),
('26647','Hòa Hiệp','Hoa Hiep','Xã Hòa Hiệp','Hoa Hiep Commune','hoa_hiep','79',4),
('26656','Bình Châu','Binh Chau','Xã Bình Châu','Binh Chau Commune','binh_chau','79',4),
('26659','Long Điền','Long Dien','Xã Long Điền','Long Dien Commune','long_dien','79',4),
('26662','Long Hải','Long Hai','Xã Long Hải','Long Hai Commune','long_hai','79',4),
('26680','Đất Đỏ','Dat Do','Xã Đất Đỏ','Dat Do Commune','dat_do','79',4),
('26686','Phước Hải','Phuoc Hai','Xã Phước Hải','Phuoc Hai Commune','phuoc_hai','79',4),
('26704','Phú Mỹ','Phu My','Phường Phú Mỹ','Phu My Ward','phu_my','79',3),
('26710','Tân Hải','Tan Hai','Phường Tân Hải','Tan Hai Ward','tan_hai','79',3),
('26713','Tân Phước','Tan Phuoc','Phường Tân Phước','Tan Phuoc Ward','tan_phuoc','79',3),
('26725','Tân Thành','Tan Thanh','Phường Tân Thành','Tan Thanh Ward','tan_thanh','79',3),
('26728','Châu Pha','Chau Pha','Xã Châu Pha','Chau Pha Commune','chau_pha','79',4),
('26732','Côn Đảo','Con Dao','Đặc khu Côn Đảo','Con Dao Special administrative region','con_dao','79',5),
('26737','Tân Định','Tan Dinh','Phường Tân Định','Tan Dinh Ward','tan_dinh','79',3),
('26740','Sài Gòn','Sai Gon','Phường Sài Gòn','Sai Gon Ward','sai_gon','79',3),
('26743','Bến Thành','Ben Thanh','Phường Bến Thành','Ben Thanh Ward','ben_thanh','79',3),
('26758','Cầu Ông Lãnh','Cau Ong Lanh','Phường Cầu Ông Lãnh','Cau Ong Lanh Ward','cau_ong_lanh','79',3),
('26767','An Phú Đông','An Phu Dong','Phường An Phú Đông','An Phu Dong Ward','an_phu_dong','79',3),
('26773','Thới An','Thoi An','Phường Thới An','Thoi An Ward','thoi_an','79',3),
('26782','Tân Thới Hiệp','Tan Thoi Hiep','Phường Tân Thới Hiệp','Tan Thoi Hiep Ward','tan_thoi_hiep','79',3),
('26785','Trung Mỹ Tây','Trung My Tay','Phường Trung Mỹ Tây','Trung My Tay Ward','trung_my_tay','79',3),
('26791','Đông Hưng Thuận','Dong Hung Thuan','Phường Đông Hưng Thuận','Dong Hung Thuan Ward','dong_hung_thuan','79',3),
('26800','Linh Xuân','Linh Xuan','Phường Linh Xuân','Linh Xuan Ward','linh_xuan','79',3),
('26803','Tam Bình','Tam Binh','Phường Tam Bình','Tam Binh Ward','tam_binh','79',3),
('26809','Hiệp Bình','Hiep Binh','Phường Hiệp Bình','Hiep Binh Ward','hiep_binh','79',3),
('26824','Thủ Đức','Thu Duc','Phường Thủ Đức','Thu Duc Ward','thu_duc','79',3),
('26833','Long Bình','Long Binh','Phường Long Bình','Long Binh Ward','long_binh','79',3),
('26842','Tăng Nhơn Phú','Tang Nhon Phu','Phường Tăng Nhơn Phú','Tang Nhon Phu Ward','tang_nhon_phu','79',3),
('26848','Phước Long','Phuoc Long','Phường Phước Long','Phuoc Long Ward','phuoc_long','79',3),
('26857','Long Phước','Long Phuoc','Phường Long Phước','Long Phuoc Ward','long_phuoc','79',3),
('26860','Long Trường','Long Truong','Phường Long Trường','Long Truong Ward','long_truong','79',3),
('26876','An Nhơn','An Nhon','Phường An Nhơn','An Nhon Ward','an_nhon','79',3),
('26878','An Hội Đông','An Hoi Dong','Phường An Hội Đông','An Hoi Dong Ward','an_hoi_dong','79',3),
('26882','An Hội Tây','An Hoi Tay','Phường An Hội Tây','An Hoi Tay Ward','an_hoi_tay','79',3),
('26884','Gò Vấp','Go Vap','Phường Gò Vấp','Go Vap Ward','go_vap','79',3),
('26890','Hạnh Thông','Hanh Thong','Phường Hạnh Thông','Hanh Thong Ward','hanh_thong','79',3),
('26898','Thông Tây Hội','Thong Tay Hoi','Phường Thông Tây Hội','Thong Tay Hoi Ward','thong_tay_hoi','79',3),
('26905','Bình Lợi Trung','Binh Loi Trung','Phường Bình Lợi Trung','Binh Loi Trung Ward','binh_loi_trung','79',3),
('26911','Bình Quới','Binh Quoi','Phường Bình Quới','Binh Quoi Ward','binh_quoi','79',3),
('26929','Bình Thạnh','Binh Thanh','Phường Bình Thạnh','Binh Thanh Ward','binh_thanh','79',3),
('26944','Gia Định','Gia Dinh','Phường Gia Định','Gia Dinh Ward','gia_dinh','79',3),
('26956','Thạnh Mỹ Tây','Thanh My Tay','Phường Thạnh Mỹ Tây','Thanh My Tay Ward','thanh_my_tay','79',3),
('26968','Tân Sơn Nhất','Tan Son Nhat','Phường Tân Sơn Nhất','Tan Son Nhat Ward','tan_son_nhat','79',3),
('26977','Tân Sơn Hòa','Tan Son Hoa','Phường Tân Sơn Hòa','Tan Son Hoa Ward','tan_son_hoa','79',3),
('26983','Bảy Hiền','Bay Hien','Phường Bảy Hiền','Bay Hien Ward','bay_hien','79',3),
('26995','Tân Hòa','Tan Hoa','Phường Tân Hòa','Tan Hoa Ward','tan_hoa','79',3),
('27004','Tân Bình','Tan Binh','Phường Tân Bình','Tan Binh Ward','tan_binh','79',3),
('27007','Tân Sơn','Tan Son','Phường Tân Sơn','Tan Son Ward','tan_son','79',3),
('27013','Tây Thạnh','Tay Thanh','Phường Tây Thạnh','Tay Thanh Ward','tay_thanh','79',3),
('27019','Tân Sơn Nhì','Tan Son Nhi','Phường Tân Sơn Nhì','Tan Son Nhi Ward','tan_son_nhi','79',3),
('27022','Phú Thọ Hòa','Phu Tho Hoa','Phường Phú Thọ Hòa','Phu Tho Hoa Ward','phu_tho_hoa','79',3),
('27028','Phú Thạnh','Phu Thanh','Phường Phú Thạnh','Phu Thanh Ward','phu_thanh','79',3),
('27031','Tân Phú','Tan Phu','Phường Tân Phú','Tan Phu Ward','tan_phu','79',3),
('27043','Đức Nhuận','Duc Nhuan','Phường Đức Nhuận','Duc Nhuan Ward','duc_nhuan','79',3),
('27058','Cầu Kiệu','Cau Kieu','Phường Cầu Kiệu','Cau Kieu Ward','cau_kieu','79',3),
('27073','Phú Nhuận','Phu Nhuan','Phường Phú Nhuận','Phu Nhuan Ward','phu_nhuan','79',3),
('27094','An Khánh','An Khanh','Phường An Khánh','An Khanh Ward','an_khanh','79',3),
('27097','Bình Trưng','Binh Trung','Phường Bình Trưng','Binh Trung Ward','binh_trung','79',3),
('27112','Cát Lái','Cat Lai','Phường Cát Lái','Cat Lai Ward','cat_lai','79',3),
('27139','Xuân Hòa','Xuan Hoa','Phường Xuân Hòa','Xuan Hoa Ward','xuan_hoa','79',3),
('27142','Nhiêu Lộc','Nhieu Loc','Phường Nhiêu Lộc','Nhieu Loc Ward','nhieu_loc','79',3),
('27154','Bàn Cờ','Ban Co','Phường Bàn Cờ','Ban Co Ward','ban_co','79',3),
('27163','Hòa Hưng','Hoa Hung','Phường Hòa Hưng','Hoa Hung Ward','hoa_hung','79',3),
('27169','Diên Hồng','Dien Hong','Phường Diên Hồng','Dien Hong Ward','dien_hong','79',3),
('27190','Vườn Lài','Vuon Lai','Phường Vườn Lài','Vuon Lai Ward','vuon_lai','79',3),
('27211','Hòa Bình','Hoa Binh','Phường Hòa Bình','Hoa Binh Ward','hoa_binh','79',3),
('27226','Phú Thọ','Phu Tho','Phường Phú Thọ','Phu Tho Ward','phu_tho','79',3),
('27232','Bình Thới','Binh Thoi','Phường Bình Thới','Binh Thoi Ward','binh_thoi','79',3),
('27238','Minh Phụng','Minh Phung','Phường Minh Phụng','Minh Phung Ward','minh_phung','79',3),
('27259','Xóm Chiếu','Xom Chieu','Phường Xóm Chiếu','Xom Chieu Ward','xom_chieu','79',3),
('27265','Khánh Hội','Khanh Hoi','Phường Khánh Hội','Khanh Hoi Ward','khanh_hoi','79',3),
('27286','Vĩnh Hội','Vinh Hoi','Phường Vĩnh Hội','Vinh Hoi Ward','vinh_hoi','79',3),
('27301','Chợ Quán','Cho Quan','Phường Chợ Quán','Cho Quan Ward','cho_quan','79',3),
('27316','An Đông','An Dong','Phường An Đông','An Dong Ward','an_dong','79',3),
('27343','Chợ Lớn','Cho Lon','Phường Chợ Lớn','Cho Lon Ward','cho_lon','79',3),
('27349','Phú Lâm','Phu Lam','Phường Phú Lâm','Phu Lam Ward','phu_lam','79',3),
('27364','Bình Phú','Binh Phu','Phường Bình Phú','Binh Phu Ward','binh_phu','79',3),
('27367','Bình Tây','Binh Tay','Phường Bình Tây','Binh Tay Ward','binh_tay','79',3),
('27373','Bình Tiên','Binh Tien','Phường Bình Tiên','Binh Tien Ward','binh_tien','79',3),
('27418','Chánh Hưng','Chanh Hung','Phường Chánh Hưng','Chanh Hung Ward','chanh_hung','79',3),
('27424','Bình Đông','Binh Dong','Phường Bình Đông','Binh Dong Ward','binh_dong','79',3),
('27427','Phú Định','Phu Dinh','Phường Phú Định','Phu Dinh Ward','phu_dinh','79',3),
('27439','Bình Hưng Hòa','Binh Hung Hoa','Phường Bình Hưng Hòa','Binh Hung Hoa Ward','binh_hung_hoa','79',3),
('27442','Bình Tân','Binh Tan','Phường Bình Tân','Binh Tan Ward','binh_tan','79',3),
('27448','Bình Trị Đông','Binh Tri Dong','Phường Bình Trị Đông','Binh Tri Dong Ward','binh_tri_dong','79',3),
('27457','Tân Tạo','Tan Tao','Phường Tân Tạo','Tan Tao Ward','tan_tao','79',3),
('27460','An Lạc','An Lac','Phường An Lạc','An Lac Ward','an_lac','79',3),
('27475','Tân Hưng','Tan Hung','Phường Tân Hưng','Tan Hung Ward','tan_hung','79',3),
('27478','Tân Thuận','Tan Thuan','Phường Tân Thuận','Tan Thuan Ward','tan_thuan','79',3),
('27484','Phú Thuận','Phu Thuan','Phường Phú Thuận','Phu Thuan Ward','phu_thuan','79',3),
('27487','Tân Mỹ','Tan My','Phường Tân Mỹ','Tan My Ward','tan_my','79',3),
('27496','Tân An Hội','Tan An Hoi','Xã Tân An Hội','Tan An Hoi Commune','tan_an_hoi','79',4),
('27508','An Nhơn Tây','An Nhon Tay','Xã An Nhơn Tây','An Nhon Tay Commune','an_nhon_tay','79',4),
('27511','Nhuận Đức','Nhuan Duc','Xã Nhuận Đức','Nhuan Duc Commune','nhuan_duc','79',4),
('27526','Thái Mỹ','Thai My','Xã Thái Mỹ','Thai My Commune','thai_my','79',4),
('27541','Phú Hòa Đông','Phu Hoa Dong','Xã Phú Hòa Đông','Phu Hoa Dong Commune','phu_hoa_dong','79',4),
('27544','Bình Mỹ','Binh My','Xã Bình Mỹ','Binh My Commune','binh_my','79',4),
('27553','Củ Chi','Cu Chi','Xã Củ Chi','Cu Chi Commune','cu_chi','79',4),
('27559','Hóc Môn','Hoc Mon','Xã Hóc Môn','Hoc Mon Commune','hoc_mon','79',4),
('27568','Đông Thạnh','Dong Thanh','Xã Đông Thạnh','Dong Thanh Commune','dong_thanh','79',4),
('27577','Xuân Thới Sơn','Xuan Thoi Son','Xã Xuân Thới Sơn','Xuan Thoi Son Commune','xuan_thoi_son','79',4),
('27592','Bà Điểm','Ba Diem','Xã Bà Điểm','Ba Diem Commune','ba_diem','79',4),
('27595','Tân Nhựt','Tan Nhut','Xã Tân Nhựt','Tan Nhut Commune','tan_nhut','79',4),
('27601','Vĩnh Lộc','Vinh Loc','Xã Vĩnh Lộc','Vinh Loc Commune','vinh_loc','79',4),
('27604','Tân Vĩnh Lộc','Tan Vinh Loc','Xã Tân Vĩnh Lộc','Tan Vinh Loc Commune','tan_vinh_loc','79',4),
('27610','Bình Lợi','Binh Loi','Xã Bình Lợi','Binh Loi Commune','binh_loi','79',4),
('27619','Bình Hưng','Binh Hung','Xã Bình Hưng','Binh Hung Commune','binh_hung','79',4),
('27628','Hưng Long','Hung Long','Xã Hưng Long','Hung Long Commune','hung_long','79',4),
('27637','Bình Chánh','Binh Chanh','Xã Bình Chánh','Binh Chanh Commune','binh_chanh','79',4),
('27655','Nhà Bè','Nha Be','Xã Nhà Bè','Nha Be Commune','nha_be','79',4),
('27658','Hiệp Phước','Hiep Phuoc','Xã Hiệp Phước','Hiep Phuoc Commune','hiep_phuoc','79',4),
('27664','Cần Giờ','Can Gio','Xã Cần Giờ','Can Gio Commune','can_gio','79',4),
('27667','Bình Khánh','Binh Khanh','Xã Bình Khánh','Binh Khanh Commune','binh_khanh','79',4),
('27673','An Thới Đông','An Thoi Dong','Xã An Thới Đông','An Thoi Dong Commune','an_thoi_dong','79',4),
('27676','Thạnh An','Thanh An','Xã Thạnh An','Thanh An Commune','thanh_an','79',4),
('27694','Long An','Long An','Phường Long An','Long An Ward','long_an','80',3),
('27712','Tân An','Tan An','Phường Tân An','Tan An Ward','tan_an','80',3),
('27715','Khánh Hậu','Khanh Hau','Phường Khánh Hậu','Khanh Hau Ward','khanh_hau','80',3),
('27721','Tân Hưng','Tan Hung','Xã Tân Hưng','Tan Hung Commune','tan_hung','80',4),
('27727','Hưng Điền','Hung Dien','Xã Hưng Điền','Hung Dien Commune','hung_dien','80',4),
('27736','Vĩnh Thạnh','Vinh Thanh','Xã Vĩnh Thạnh','Vinh Thanh Commune','vinh_thanh','80',4),
('27748','Vĩnh Châu','Vinh Chau','Xã Vĩnh Châu','Vinh Chau Commune','vinh_chau','80',4),
('27757','Vĩnh Hưng','Vinh Hung','Xã Vĩnh Hưng','Vinh Hung Commune','vinh_hung','80',4),
('27763','Khánh Hưng','Khanh Hung','Xã Khánh Hưng','Khanh Hung Commune','khanh_hung','80',4),
('27775','Tuyên Bình','Tuyen Binh','Xã Tuyên Bình','Tuyen Binh Commune','tuyen_binh','80',4),
('27787','Kiến Tường','Kien Tuong','Phường Kiến Tường','Kien Tuong Ward','kien_tuong','80',3),
('27793','Bình Hiệp','Binh Hiep','Xã Bình Hiệp','Binh Hiep Commune','binh_hiep','80',4),
('27811','Bình Hòa','Binh Hoa','Xã Bình Hòa','Binh Hoa Commune','binh_hoa','80',4),
('27817','Tuyên Thạnh','Tuyen Thanh','Xã Tuyên Thạnh','Tuyen Thanh Commune','tuyen_thanh','80',4),
('27823','Mộc Hóa','Moc Hoa','Xã Mộc Hóa','Moc Hoa Commune','moc_hoa','80',4),
('27826','Tân Thạnh','Tan Thanh','Xã Tân Thạnh','Tan Thanh Commune','tan_thanh','80',4),
('27838','Nhơn Hòa Lập','Nhon Hoa Lap','Xã Nhơn Hòa Lập','Nhon Hoa Lap Commune','nhon_hoa_lap','80',4),
('27841','Hậu Thạnh','Hau Thanh','Xã Hậu Thạnh','Hau Thanh Commune','hau_thanh','80',4),
('27856','Nhơn Ninh','Nhon Ninh','Xã Nhơn Ninh','Nhon Ninh Commune','nhon_ninh','80',4),
('27865','Thạnh Hóa','Thanh Hoa','Xã Thạnh Hóa','Thanh Hoa Commune','thanh_hoa','80',4),
('27868','Bình Thành','Binh Thanh','Xã Bình Thành','Binh Thanh Commune','binh_thanh','80',4),
('27877','Thạnh Phước','Thanh Phuoc','Xã Thạnh Phước','Thanh Phuoc Commune','thanh_phuoc','80',4),
('27889','Tân Tây','Tan Tay','Xã Tân Tây','Tan Tay Commune','tan_tay','80',4),
('27898','Đông Thành','Dong Thanh','Xã Đông Thành','Dong Thanh Commune','dong_thanh','80',4),
('27907','Mỹ Quý','My Quy','Xã Mỹ Quý','My Quy Commune','my_quy','80',4),
('27925','Đức Huệ','Duc Hue','Xã Đức Huệ','Duc Hue Commune','duc_hue','80',4),
('27931','Hậu Nghĩa','Hau Nghia','Xã Hậu Nghĩa','Hau Nghia Commune','hau_nghia','80',4),
('27937','Đức Hòa','Duc Hoa','Xã Đức Hòa','Duc Hoa Commune','duc_hoa','80',4),
('27943','An Ninh','An Ninh','Xã An Ninh','An Ninh Commune','an_ninh','80',4),
('27952','Hiệp Hòa','Hiep Hoa','Xã Hiệp Hòa','Hiep Hoa Commune','hiep_hoa','80',4),
('27964','Đức Lập','Duc Lap','Xã Đức Lập','Duc Lap Commune','duc_lap','80',4),
('27976','Mỹ Hạnh','My Hanh','Xã Mỹ Hạnh','My Hanh Commune','my_hanh','80',4),
('27979','Hòa Khánh','Hoa Khanh','Xã Hòa Khánh','Hoa Khanh Commune','hoa_khanh','80',4),
('27991','Bến Lức','Ben Luc','Xã Bến Lức','Ben Luc Commune','ben_luc','80',4),
('27994','Thạnh Lợi','Thanh Loi','Xã Thạnh Lợi','Thanh Loi Commune','thanh_loi','80',4),
('28003','Lương Hòa','Luong Hoa','Xã Lương Hòa','Luong Hoa Commune','luong_hoa','80',4),
('28015','Bình Đức','Binh Duc','Xã Bình Đức','Binh Duc Commune','binh_duc','80',4),
('28018','Mỹ Yên','My Yen','Xã Mỹ Yên','My Yen Commune','my_yen','80',4),
('28036','Thủ Thừa','Thu Thua','Xã Thủ Thừa','Thu Thua Commune','thu_thua','80',4),
('28051','Mỹ Thạnh','My Thanh','Xã Mỹ Thạnh','My Thanh Commune','my_thanh','80',4),
('28066','Mỹ An','My An','Xã Mỹ An','My An Commune','my_an','80',4),
('28072','Tân Long','Tan Long','Xã Tân Long','Tan Long Commune','tan_long','80',4),
('28075','Tân Trụ','Tan Tru','Xã Tân Trụ','Tan Tru Commune','tan_tru','80',4),
('28087','Nhựt Tảo','Nhut Tao','Xã Nhựt Tảo','Nhut Tao Commune','nhut_tao','80',4),
('28093','Vàm Cỏ','Vam Co','Xã Vàm Cỏ','Vam Co Commune','vam_co','80',4),
('28108','Cần Đước','Can Duoc','Xã Cần Đước','Can Duoc Commune','can_duoc','80',4),
('28114','Rạch Kiến','Rach Kien','Xã Rạch Kiến','Rach Kien Commune','rach_kien','80',4),
('28126','Long Cang','Long Cang','Xã Long Cang','Long Cang Commune','long_cang','80',4),
('28132','Mỹ Lệ','My Le','Xã Mỹ Lệ','My Le Commune','my_le','80',4),
('28138','Tân Lân','Tan Lan','Xã Tân Lân','Tan Lan Commune','tan_lan','80',4),
('28144','Long Hựu','Long Huu','Xã Long Hựu','Long Huu Commune','long_huu','80',4),
('28159','Cần Giuộc','Can Giuoc','Xã Cần Giuộc','Can Giuoc Commune','can_giuoc','80',4),
('28165','Phước Lý','Phuoc Ly','Xã Phước Lý','Phuoc Ly Commune','phuoc_ly','80',4),
('28177','Mỹ Lộc','My Loc','Xã Mỹ Lộc','My Loc Commune','my_loc','80',4),
('28201','Phước Vĩnh Tây','Phuoc Vinh Tay','Xã Phước Vĩnh Tây','Phuoc Vinh Tay Commune','phuoc_vinh_tay','80',4),
('28207','Tân Tập','Tan Tap','Xã Tân Tập','Tan Tap Commune','tan_tap','80',4),
('28210','Tầm Vu','Tam Vu','Xã Tầm Vu','Tam Vu Commune','tam_vu','80',4),
('28222','Vĩnh Công','Vinh Cong','Xã Vĩnh Công','Vinh Cong Commune','vinh_cong','80',4),
('28225','Thuận Mỹ','Thuan My','Xã Thuận Mỹ','Thuan My Commune','thuan_my','80',4),
('28243','An Lục Long','An Luc Long','Xã An Lục Long','An Luc Long Commune','an_luc_long','80',4),
('28249','Đạo Thạnh','Dao Thanh','Phường Đạo Thạnh','Dao Thanh Ward','dao_thanh','82',3),
('28261','Mỹ Tho','My Tho','Phường Mỹ Tho','My Tho Ward','my_tho','82',3),
('28270','Thới Sơn','Thoi Son','Phường Thới Sơn','Thoi Son Ward','thoi_son','82',3),
('28273','Mỹ Phong','My Phong','Phường Mỹ Phong','My Phong Ward','my_phong','82',3),
('28285','Trung An','Trung An','Phường Trung An','Trung An Ward','trung_an','82',3),
('28297','Long Thuận','Long Thuan','Phường Long Thuận','Long Thuan Ward','long_thuan','82',3),
('28306','Gò Công','Go Cong','Phường Gò Công','Go Cong Ward','go_cong','82',3),
('28315','Bình Xuân','Binh Xuan','Phường Bình Xuân','Binh Xuan Ward','binh_xuan','82',3),
('28321','Tân Phước 1','Tan Phuoc 1','Xã Tân Phước 1','Tan Phuoc 1 Commune','tan_phuoc_1','82',4),
('28327','Tân Phước 2','Tan Phuoc 2','Xã Tân Phước 2','Tan Phuoc 2 Commune','tan_phuoc_2','82',4),
('28336','Hưng Thạnh','Hung Thanh','Xã Hưng Thạnh','Hung Thanh Commune','hung_thanh','82',4),
('28345','Tân Phước 3','Tan Phuoc 3','Xã Tân Phước 3','Tan Phuoc 3 Commune','tan_phuoc_3','82',4),
('28360','Cái Bè','Cai Be','Xã Cái Bè','Cai Be Commune','cai_be','82',4),
('28366','Hậu Mỹ','Hau My','Xã Hậu Mỹ','Hau My Commune','hau_my','82',4),
('28378','Mỹ Thiện','My Thien','Xã Mỹ Thiện','My Thien Commune','my_thien','82',4),
('28393','Hội Cư','Hoi Cu','Xã Hội Cư','Hoi Cu Commune','hoi_cu','82',4),
('28405','Mỹ Đức Tây','My Duc Tay','Xã Mỹ Đức Tây','My Duc Tay Commune','my_duc_tay','82',4),
('28414','Mỹ Lợi','My Loi','Xã Mỹ Lợi','My Loi Commune','my_loi','82',4),
('28426','Thanh Hưng','Thanh Hung','Xã Thanh Hưng','Thanh Hung Commune','thanh_hung','82',4),
('28429','An Hữu','An Huu','Xã An Hữu','An Huu Commune','an_huu','82',4),
('28435','Mỹ Phước Tây','My Phuoc Tay','Phường Mỹ Phước Tây','My Phuoc Tay Ward','my_phuoc_tay','82',3),
('28436','Thanh Hòa','Thanh Hoa','Phường Thanh Hòa','Thanh Hoa Ward','thanh_hoa','82',3),
('28439','Cai Lậy','Cai Lay','Phường Cai Lậy','Cai Lay Ward','cai_lay','82',3),
('28444','Thạnh Phú','Thanh Phu','Xã Thạnh Phú','Thanh Phu Commune','thanh_phu','82',4),
('28456','Mỹ Thành','My Thanh','Xã Mỹ Thành','My Thanh Commune','my_thanh','82',4),
('28468','Tân Phú','Tan Phu','Xã Tân Phú','Tan Phu Commune','tan_phu','82',4),
('28471','Bình Phú','Binh Phu','Xã Bình Phú','Binh Phu Commune','binh_phu','82',4),
('28477','Nhị Quý','Nhi Quy','Phường Nhị Quý','Nhi Quy Ward','nhi_quy','82',3),
('28501','Hiệp Đức','Hiep Duc','Xã Hiệp Đức','Hiep Duc Commune','hiep_duc','82',4),
('28504','Long Tiên','Long Tien','Xã Long Tiên','Long Tien Commune','long_tien','82',4),
('28516','Ngũ Hiệp','Ngu Hiep','Xã Ngũ Hiệp','Ngu Hiep Commune','ngu_hiep','82',4),
('28519','Châu Thành','Chau Thanh','Xã Châu Thành','Chau Thanh Commune','chau_thanh','82',4),
('28525','Tân Hương','Tan Huong','Xã Tân Hương','Tan Huong Commune','tan_huong','82',4),
('28537','Long Hưng','Long Hung','Xã Long Hưng','Long Hung Commune','long_hung','82',4),
('28543','Long Định','Long Dinh','Xã Long Định','Long Dinh Commune','long_dinh','82',4),
('28564','Bình Trưng','Binh Trung','Xã Bình Trưng','Binh Trung Commune','binh_trung','82',4),
('28576','Vĩnh Kim','Vinh Kim','Xã Vĩnh Kim','Vinh Kim Commune','vinh_kim','82',4),
('28582','Kim Sơn','Kim Son','Xã Kim Sơn','Kim Son Commune','kim_son','82',4),
('28594','Chợ Gạo','Cho Gao','Xã Chợ Gạo','Cho Gao Commune','cho_gao','82',4),
('28603','Mỹ Tịnh An','My Tinh An','Xã Mỹ Tịnh An','My Tinh An Commune','my_tinh_an','82',4),
('28615','Lương Hòa Lạc','Luong Hoa Lac','Xã Lương Hòa Lạc','Luong Hoa Lac Commune','luong_hoa_lac','82',4),
('28627','Tân Thuận Bình','Tan Thuan Binh','Xã Tân Thuận Bình','Tan Thuan Binh Commune','tan_thuan_binh','82',4),
('28633','An Thạnh Thủy','An Thanh Thuy','Xã An Thạnh Thủy','An Thanh Thuy Commune','an_thanh_thuy','82',4),
('28648','Bình Ninh','Binh Ninh','Xã Bình Ninh','Binh Ninh Commune','binh_ninh','82',4),
('28651','Vĩnh Bình','Vinh Binh','Xã Vĩnh Bình','Vinh Binh Commune','vinh_binh','82',4),
('28660','Đồng Sơn','Dong Son','Xã Đồng Sơn','Dong Son Commune','dong_son','82',4),
('28663','Phú Thành','Phu Thanh','Xã Phú Thành','Phu Thanh Commune','phu_thanh','82',4),
('28678','Vĩnh Hựu','Vinh Huu','Xã Vĩnh Hựu','Vinh Huu Commune','vinh_huu','82',4),
('28687','Long Bình','Long Binh','Xã Long Bình','Long Binh Commune','long_binh','82',4),
('28693','Tân Thới','Tan Thoi','Xã Tân Thới','Tan Thoi Commune','tan_thoi','82',4),
('28696','Tân Phú Đông','Tan Phu Dong','Xã Tân Phú Đông','Tan Phu Dong Commune','tan_phu_dong','82',4),
('28702','Tân Hòa','Tan Hoa','Xã Tân Hòa','Tan Hoa Commune','tan_hoa','82',4),
('28720','Gia Thuận','Gia Thuan','Xã Gia Thuận','Gia Thuan Commune','gia_thuan','82',4),
('28723','Tân Đông','Tan Dong','Xã Tân Đông','Tan Dong Commune','tan_dong','82',4),
('28729','Sơn Qui','Son Qui','Phường Sơn Qui','Son Qui Ward','son_qui','82',3),
('28738','Tân Điền','Tan Dien','Xã Tân Điền','Tan Dien Commune','tan_dien','82',4),
('28747','Gò Công Đông','Go Cong Dong','Xã Gò Công Đông','Go Cong Dong Commune','go_cong_dong','82',4),
('28756','Phú Khương','Phu Khuong','Phường Phú Khương','Phu Khuong Ward','phu_khuong','86',3),
('28777','An Hội','An Hoi','Phường An Hội','An Hoi Ward','an_hoi','86',3),
('28783','Sơn Đông','Son Dong','Phường Sơn Đông','Son Dong Ward','son_dong','86',3),
('28789','Bến Tre','Ben Tre','Phường Bến Tre','Ben Tre Ward','ben_tre','86',3),
('28807','Giao Long','Giao Long','Xã Giao Long','Giao Long Commune','giao_long','86',4),
('28810','Phú Túc','Phu Tuc','Xã Phú Túc','Phu Tuc Commune','phu_tuc','86',4),
('28840','Tân Phú','Tan Phu','Xã Tân Phú','Tan Phu Commune','tan_phu','86',4),
('28858','Phú Tân','Phu Tan','Phường Phú Tân','Phu Tan Ward','phu_tan','86',3),
('28861','Tiên Thủy','Tien Thuy','Xã Tiên Thủy','Tien Thuy Commune','tien_thuy','86',4),
('28870','Chợ Lách','Cho Lach','Xã Chợ Lách','Cho Lach Commune','cho_lach','86',4),
('28879','Phú Phụng','Phu Phung','Xã Phú Phụng','Phu Phung Commune','phu_phung','86',4),
('28894','Vĩnh Thành','Vinh Thanh','Xã Vĩnh Thành','Vinh Thanh Commune','vinh_thanh','86',4),
('28901','Hưng Khánh Trung','Hung Khanh Trung','Xã Hưng Khánh Trung','Hung Khanh Trung Commune','hung_khanh_trung','86',4),
('28903','Mỏ Cày','Mo Cay','Xã Mỏ Cày','Mo Cay Commune','mo_cay','86',4),
('28915','Phước Mỹ Trung','Phuoc My Trung','Xã Phước Mỹ Trung','Phuoc My Trung Commune','phuoc_my_trung','86',4),
('28921','Tân Thành Bình','Tan Thanh Binh','Xã Tân Thành Bình','Tan Thanh Binh Commune','tan_thanh_binh','86',4),
('28945','Đồng Khởi','Dong Khoi','Xã Đồng Khởi','Dong Khoi Commune','dong_khoi','86',4),
('28948','Nhuận Phú Tân','Nhuan Phu Tan','Xã Nhuận Phú Tân','Nhuan Phu Tan Commune','nhuan_phu_tan','86',4),
('28957','An Định','An Dinh','Xã An Định','An Dinh Commune','an_dinh','86',4),
('28969','Thành Thới','Thanh Thoi','Xã Thành Thới','Thanh Thoi Commune','thanh_thoi','86',4),
('28981','Hương Mỹ','Huong My','Xã Hương Mỹ','Huong My Commune','huong_my','86',4),
('28984','Giồng Trôm','Giong Trom','Xã Giồng Trôm','Giong Trom Commune','giong_trom','86',4),
('28987','Lương Hòa','Luong Hoa','Xã Lương Hòa','Luong Hoa Commune','luong_hoa','86',4),
('28993','Lương Phú','Luong Phu','Xã Lương Phú','Luong Phu Commune','luong_phu','86',4),
('28996','Châu Hòa','Chau Hoa','Xã Châu Hòa','Chau Hoa Commune','chau_hoa','86',4),
('29020','Phước Long','Phuoc Long','Xã Phước Long','Phuoc Long Commune','phuoc_long','86',4),
('29029','Tân Hào','Tan Hao','Xã Tân Hào','Tan Hao Commune','tan_hao','86',4),
('29044','Hưng Nhượng','Hung Nhuong','Xã Hưng Nhượng','Hung Nhuong Commune','hung_nhuong','86',4),
('29050','Bình Đại','Binh Dai','Xã Bình Đại','Binh Dai Commune','binh_dai','86',4),
('29062','Phú Thuận','Phu Thuan','Xã Phú Thuận','Phu Thuan Commune','phu_thuan','86',4),
('29077','Lộc Thuận','Loc Thuan','Xã Lộc Thuận','Loc Thuan Commune','loc_thuan','86',4),
('29083','Châu Hưng','Chau Hung','Xã Châu Hưng','Chau Hung Commune','chau_hung','86',4),
('29089','Thạnh Trị','Thanh Tri','Xã Thạnh Trị','Thanh Tri Commune','thanh_tri','86',4),
('29104','Thạnh Phước','Thanh Phuoc','Xã Thạnh Phước','Thanh Phuoc Commune','thanh_phuoc','86',4),
('29107','Thới Thuận','Thoi Thuan','Xã Thới Thuận','Thoi Thuan Commune','thoi_thuan','86',4),
('29110','Ba Tri','Ba Tri','Xã Ba Tri','Ba Tri Commune','ba_tri','86',4),
('29122','Mỹ Chánh Hòa','My Chanh Hoa','Xã Mỹ Chánh Hòa','My Chanh Hoa Commune','my_chanh_hoa','86',4),
('29125','Bảo Thạnh','Bao Thanh','Xã Bảo Thạnh','Bao Thanh Commune','bao_thanh','86',4),
('29137','Tân Xuân','Tan Xuan','Xã Tân Xuân','Tan Xuan Commune','tan_xuan','86',4),
('29143','An Ngãi Trung','An Ngai Trung','Xã An Ngãi Trung','An Ngai Trung Commune','an_ngai_trung','86',4),
('29158','An Hiệp','An Hiep','Xã An Hiệp','An Hiep Commune','an_hiep','86',4),
('29167','Tân Thủy','Tan Thuy','Xã Tân Thủy','Tan Thuy Commune','tan_thuy','86',4),
('29182','Thạnh Phú','Thanh Phu','Xã Thạnh Phú','Thanh Phu Commune','thanh_phu','86',4),
('29191','Quới Điền','Quoi Dien','Xã Quới Điền','Quoi Dien Commune','quoi_dien','86',4),
('29194','Đại Điền','Dai Dien','Xã Đại Điền','Dai Dien Commune','dai_dien','86',4),
('29221','Thạnh Hải','Thanh Hai','Xã Thạnh Hải','Thanh Hai Commune','thanh_hai','86',4),
('29224','An Qui','An Qui','Xã An Qui','An Qui Commune','an_qui','86',4),
('29227','Thạnh Phong','Thanh Phong','Xã Thạnh Phong','Thanh Phong Commune','thanh_phong','86',4),
('29242','Trà Vinh','Tra Vinh','Phường Trà Vinh','Tra Vinh Ward','tra_vinh','86',3),
('29254','Nguyệt Hóa','Nguyet Hoa','Phường Nguyệt Hóa','Nguyet Hoa Ward','nguyet_hoa','86',3),
('29263','Long Đức','Long Duc','Phường Long Đức','Long Duc Ward','long_duc','86',3),
('29266','Càng Long','Cang Long','Xã Càng Long','Cang Long Commune','cang_long','86',4),
('29275','An Trường','An Truong','Xã An Trường','An Truong Commune','an_truong','86',4),
('29278','Tân An','Tan An','Xã Tân An','Tan An Commune','tan_an','86',4),
('29287','Bình Phú','Binh Phu','Xã Bình Phú','Binh Phu Commune','binh_phu','86',4),
('29302','Nhị Long','Nhi Long','Xã Nhị Long','Nhi Long Commune','nhi_long','86',4),
('29308','Cầu Kè','Cau Ke','Xã Cầu Kè','Cau Ke Commune','cau_ke','86',4),
('29317','An Phú Tân','An Phu Tan','Xã An Phú Tân','An Phu Tan Commune','an_phu_tan','86',4),
('29329','Phong Thạnh','Phong Thanh','Xã Phong Thạnh','Phong Thanh Commune','phong_thanh','86',4),
('29335','Tam Ngãi','Tam Ngai','Xã Tam Ngãi','Tam Ngai Commune','tam_ngai','86',4),
('29341','Tiểu Cần','Tieu Can','Xã Tiểu Cần','Tieu Can Commune','tieu_can','86',4),
('29362','Hùng Hòa','Hung Hoa','Xã Hùng Hòa','Hung Hoa Commune','hung_hoa','86',4),
('29365','Tập Ngãi','Tap Ngai','Xã Tập Ngãi','Tap Ngai Commune','tap_ngai','86',4),
('29371','Tân Hòa','Tan Hoa','Xã Tân Hòa','Tan Hoa Commune','tan_hoa','86',4),
('29374','Châu Thành','Chau Thanh','Xã Châu Thành','Chau Thanh Commune','chau_thanh','86',4),
('29386','Song Lộc','Song Loc','Xã Song Lộc','Song Loc Commune','song_loc','86',4),
('29398','Hòa Thuận','Hoa Thuan','Phường Hòa Thuận','Hoa Thuan Ward','hoa_thuan','86',3),
('29407','Hưng Mỹ','Hung My','Xã Hưng Mỹ','Hung My Commune','hung_my','86',4),
('29410','Hòa Minh','Hoa Minh','Xã Hòa Minh','Hoa Minh Commune','hoa_minh','86',4),
('29413','Long Hòa','Long Hoa','Xã Long Hòa','Long Hoa Commune','long_hoa','86',4),
('29416','Cầu Ngang','Cau Ngang','Xã Cầu Ngang','Cau Ngang Commune','cau_ngang','86',4),
('29419','Mỹ Long','My Long','Xã Mỹ Long','My Long Commune','my_long','86',4),
('29431','Vinh Kim','Vinh Kim','Xã Vinh Kim','Vinh Kim Commune','vinh_kim','86',4),
('29446','Nhị Trường','Nhi Truong','Xã Nhị Trường','Nhi Truong Commune','nhi_truong','86',4),
('29455','Hiệp Mỹ','Hiep My','Xã Hiệp Mỹ','Hiep My Commune','hiep_my','86',4),
('29461','Trà Cú','Tra Cu','Xã Trà Cú','Tra Cu Commune','tra_cu','86',4),
('29467','Tập Sơn','Tap Son','Xã Tập Sơn','Tap Son Commune','tap_son','86',4),
('29476','Lưu Nghiệp Anh','Luu Nghiep Anh','Xã Lưu Nghiệp Anh','Luu Nghiep Anh Commune','luu_nghiep_anh','86',4),
('29489','Hàm Giang','Ham Giang','Xã Hàm Giang','Ham Giang Commune','ham_giang','86',4),
('29491','Đại An','Dai An','Xã Đại An','Dai An Commune','dai_an','86',4),
('29497','Đôn Châu','Don Chau','Xã Đôn Châu','Don Chau Commune','don_chau','86',4),
('29506','Long Hiệp','Long Hiep','Xã Long Hiệp','Long Hiep Commune','long_hiep','86',4),
('29512','Duyên Hải','Duyen Hai','Phường Duyên Hải','Duyen Hai Ward','duyen_hai','86',3),
('29513','Long Thành','Long Thanh','Xã Long Thành','Long Thanh Commune','long_thanh','86',4),
('29516','Trường Long Hòa','Truong Long Hoa','Phường Trường Long Hòa','Truong Long Hoa Ward','truong_long_hoa','86',3),
('29518','Long Hữu','Long Huu','Xã Long Hữu','Long Huu Commune','long_huu','86',4),
('29530','Ngũ Lạc','Ngu Lac','Xã Ngũ Lạc','Ngu Lac Commune','ngu_lac','86',4),
('29533','Long Vĩnh','Long Vinh','Xã Long Vĩnh','Long Vinh Commune','long_vinh','86',4),
('29536','Đông Hải','Dong Hai','Xã Đông Hải','Dong Hai Commune','dong_hai','86',4),
('29551','Long Châu','Long Chau','Phường Long Châu','Long Chau Ward','long_chau','86',3),
('29557','Phước Hậu','Phuoc Hau','Phường Phước Hậu','Phuoc Hau Ward','phuoc_hau','86',3),
('29566','Tân Ngãi','Tan Ngai','Phường Tân Ngãi','Tan Ngai Ward','tan_ngai','86',3),
('29584','An Bình','An Binh','Xã An Bình','An Binh Commune','an_binh','86',4),
('29590','Thanh Đức','Thanh Duc','Phường Thanh Đức','Thanh Duc Ward','thanh_duc','86',3),
('29593','Tân Hạnh','Tan Hanh','Phường Tân Hạnh','Tan Hanh Ward','tan_hanh','86',3),
('29602','Long Hồ','Long Ho','Xã Long Hồ','Long Ho Commune','long_ho','86',4),
('29611','Phú Quới','Phu Quoi','Xã Phú Quới','Phu Quoi Commune','phu_quoi','86',4),
('29623','Nhơn Phú','Nhon Phu','Xã Nhơn Phú','Nhon Phu Commune','nhon_phu','86',4),
('29638','Bình Phước','Binh Phuoc','Xã Bình Phước','Binh Phuoc Commune','binh_phuoc','86',4),
('29641','Cái Nhum','Cai Nhum','Xã Cái Nhum','Cai Nhum Commune','cai_nhum','86',4),
('29653','Tân Long Hội','Tan Long Hoi','Xã Tân Long Hội','Tan Long Hoi Commune','tan_long_hoi','86',4),
('29659','Trung Thành','Trung Thanh','Xã Trung Thành','Trung Thanh Commune','trung_thanh','86',4),
('29668','Quới An','Quoi An','Xã Quới An','Quoi An Commune','quoi_an','86',4),
('29677','Quới Thiện','Quoi Thien','Xã Quới Thiện','Quoi Thien Commune','quoi_thien','86',4),
('29683','Trung Hiệp','Trung Hiep','Xã Trung Hiệp','Trung Hiep Commune','trung_hiep','86',4),
('29698','Trung Ngãi','Trung Ngai','Xã Trung Ngãi','Trung Ngai Commune','trung_ngai','86',4),
('29701','Hiếu Phụng','Hieu Phung','Xã Hiếu Phụng','Hieu Phung Commune','hieu_phung','86',4),
('29713','Hiếu Thành','Hieu Thanh','Xã Hiếu Thành','Hieu Thanh Commune','hieu_thanh','86',4),
('29719','Tam Bình','Tam Binh','Xã Tam Bình','Tam Binh Commune','tam_binh','86',4),
('29728','Cái Ngang','Cai Ngang','Xã Cái Ngang','Cai Ngang Commune','cai_ngang','86',4),
('29734','Hòa Hiệp','Hoa Hiep','Xã Hòa Hiệp','Hoa Hiep Commune','hoa_hiep','86',4),
('29740','Song Phú','Song Phu','Xã Song Phú','Song Phu Commune','song_phu','86',4),
('29767','Ngãi Tứ','Ngai Tu','Xã Ngãi Tứ','Ngai Tu Commune','ngai_tu','86',4),
('29770','Cái Vồn','Cai Von','Phường Cái Vồn','Cai Von Ward','cai_von','86',3),
('29771','Bình Minh','Binh Minh','Phường Bình Minh','Binh Minh Ward','binh_minh','86',3),
('29785','Tân Lược','Tan Luoc','Xã Tân Lược','Tan Luoc Commune','tan_luoc','86',4),
('29788','Mỹ Thuận','My Thuan','Xã Mỹ Thuận','My Thuan Commune','my_thuan','86',4),
('29800','Tân Quới','Tan Quoi','Xã Tân Quới','Tan Quoi Commune','tan_quoi','86',4),
('29812','Đông Thành','Dong Thanh','Phường Đông Thành','Dong Thanh Ward','dong_thanh','86',3),
('29821','Trà Ôn','Tra On','Xã Trà Ôn','Tra On Commune','tra_on','86',4),
('29830','Hòa Bình','Hoa Binh','Xã Hòa Bình','Hoa Binh Commune','hoa_binh','86',4),
('29836','Trà Côn','Tra Con','Xã Trà Côn','Tra Con Commune','tra_con','86',4),
('29845','Vĩnh Xuân','Vinh Xuan','Xã Vĩnh Xuân','Vinh Xuan Commune','vinh_xuan','86',4),
('29857','Lục Sĩ Thành','Luc Si Thanh','Xã Lục Sĩ Thành','Luc Si Thanh Commune','luc_si_thanh','86',4),
('29869','Cao Lãnh','Cao Lanh','Phường Cao Lãnh','Cao Lanh Ward','cao_lanh','82',3),
('29884','Mỹ Ngãi','My Ngai','Phường Mỹ Ngãi','My Ngai Ward','my_ngai','82',3),
('29888','Mỹ Trà','My Tra','Phường Mỹ Trà','My Tra Ward','my_tra','82',3),
('29905','Sa Đéc','Sa Dec','Phường Sa Đéc','Sa Dec Ward','sa_dec','82',3),
('29926','Tân Hồng','Tan Hong','Xã Tân Hồng','Tan Hong Commune','tan_hong','82',4),
('29929','Tân Hộ Cơ','Tan Ho Co','Xã Tân Hộ Cơ','Tan Ho Co Commune','tan_ho_co','82',4),
('29938','Tân Thành','Tan Thanh','Xã Tân Thành','Tan Thanh Commune','tan_thanh','82',4),
('29944','An Phước','An Phuoc','Xã An Phước','An Phuoc Commune','an_phuoc','82',4),
('29954','An Bình','An Binh','Phường An Bình','An Binh Ward','an_binh','82',3),
('29955','Hồng Ngự','Hong Ngu','Phường Hồng Ngự','Hong Ngu Ward','hong_ngu','82',3),
('29971','Thường Phước','Thuong Phuoc','Xã Thường Phước','Thuong Phuoc Commune','thuong_phuoc','82',4),
('29978','Thường Lạc','Thuong Lac','Phường Thường Lạc','Thuong Lac Ward','thuong_lac','82',3),
('29983','Long Khánh','Long Khanh','Xã Long Khánh','Long Khanh Commune','long_khanh','82',4),
('29992','Long Phú Thuận','Long Phu Thuan','Xã Long Phú Thuận','Long Phu Thuan Commune','long_phu_thuan','82',4),
('30001','Tràm Chim','Tram Chim','Xã Tràm Chim','Tram Chim Commune','tram_chim','82',4),
('30010','Tam Nông','Tam Nong','Xã Tam Nông','Tam Nong Commune','tam_nong','82',4),
('30019','An Hòa','An Hoa','Xã An Hòa','An Hoa Commune','an_hoa','82',4),
('30025','Phú Cường','Phu Cuong','Xã Phú Cường','Phu Cuong Commune','phu_cuong','82',4),
('30028','An Long','An Long','Xã An Long','An Long Commune','an_long','82',4),
('30034','Phú Thọ','Phu Tho','Xã Phú Thọ','Phu Tho Commune','phu_tho','82',4),
('30037','Tháp Mười','Thap Muoi','Xã Tháp Mười','Thap Muoi Commune','thap_muoi','82',4),
('30043','Phương Thịnh','Phuong Thinh','Xã Phương Thịnh','Phuong Thinh Commune','phuong_thinh','82',4),
('30046','Trường Xuân','Truong Xuan','Xã Trường Xuân','Truong Xuan Commune','truong_xuan','82',4),
('30055','Mỹ Quí','My Qui','Xã Mỹ Quí','My Qui Commune','my_qui','82',4),
('30061','Đốc Binh Kiều','Doc Binh Kieu','Xã Đốc Binh Kiều','Doc Binh Kieu Commune','doc_binh_kieu','82',4),
('30073','Thanh Mỹ','Thanh My','Xã Thanh Mỹ','Thanh My Commune','thanh_my','82',4),
('30076','Mỹ Thọ','My Tho','Xã Mỹ Thọ','My Tho Commune','my_tho','82',4),
('30085','Ba Sao','Ba Sao','Xã Ba Sao','Ba Sao Commune','ba_sao','82',4),
('30088','Phong Mỹ','Phong My','Xã Phong Mỹ','Phong My Commune','phong_my','82',4),
('30112','Mỹ Hiệp','My Hiep','Xã Mỹ Hiệp','My Hiep Commune','my_hiep','82',4),
('30118','Bình Hàng Trung','Binh Hang Trung','Xã Bình Hàng Trung','Binh Hang Trung Commune','binh_hang_trung','82',4),
('30130','Thanh Bình','Thanh Binh','Xã Thanh Bình','Thanh Binh Commune','thanh_binh','82',4),
('30154','Tân Long','Tan Long','Xã Tân Long','Tan Long Commune','tan_long','82',4),
('30157','Tân Thạnh','Tan Thanh','Xã Tân Thạnh','Tan Thanh Commune','tan_thanh','82',4),
('30163','Bình Thành','Binh Thanh','Xã Bình Thành','Binh Thanh Commune','binh_thanh','82',4),
('30169','Lấp Vò','Lap Vo','Xã Lấp Vò','Lap Vo Commune','lap_vo','82',4),
('30178','Mỹ An Hưng','My An Hung','Xã Mỹ An Hưng','My An Hung Commune','my_an_hung','82',4),
('30184','Tân Khánh Trung','Tan Khanh Trung','Xã Tân Khánh Trung','Tan Khanh Trung Commune','tan_khanh_trung','82',4),
('30208','Hòa Long','Hoa Long','Xã Hòa Long','Hoa Long Commune','hoa_long','82',4),
('30214','Tân Dương','Tan Duong','Xã Tân Dương','Tan Duong Commune','tan_duong','82',4),
('30226','Lai Vung','Lai Vung','Xã Lai Vung','Lai Vung Commune','lai_vung','82',4),
('30235','Phong Hòa','Phong Hoa','Xã Phong Hòa','Phong Hoa Commune','phong_hoa','82',4),
('30244','Phú Hựu','Phu Huu','Xã Phú Hựu','Phu Huu Commune','phu_huu','82',4),
('30253','Tân Nhuận Đông','Tan Nhuan Dong','Xã Tân Nhuận Đông','Tan Nhuan Dong Commune','tan_nhuan_dong','82',4),
('30259','Tân Phú Trung','Tan Phu Trung','Xã Tân Phú Trung','Tan Phu Trung Commune','tan_phu_trung','82',4),
('30292','Bình Đức','Binh Duc','Phường Bình Đức','Binh Duc Ward','binh_duc','91',3),
('30301','Mỹ Thới','My Thoi','Phường Mỹ Thới','My Thoi Ward','my_thoi','91',3),
('30307','Long Xuyên','Long Xuyen','Phường Long Xuyên','Long Xuyen Ward','long_xuyen','91',3),
('30313','Mỹ Hòa Hưng','My Hoa Hung','Xã Mỹ Hòa Hưng','My Hoa Hung Commune','my_hoa_hung','91',4),
('30316','Châu Đốc','Chau Doc','Phường Châu Đốc','Chau Doc Ward','chau_doc','91',3),
('30325','Vĩnh Tế','Vinh Te','Phường Vĩnh Tế','Vinh Te Ward','vinh_te','91',3),
('30337','An Phú','An Phu','Xã An Phú','An Phu Commune','an_phu','91',4),
('30341','Khánh Bình','Khanh Binh','Xã Khánh Bình','Khanh Binh Commune','khanh_binh','91',4),
('30346','Nhơn Hội','Nhon Hoi','Xã Nhơn Hội','Nhon Hoi Commune','nhon_hoi','91',4),
('30352','Phú Hữu','Phu Huu','Xã Phú Hữu','Phu Huu Commune','phu_huu','91',4),
('30367','Vĩnh Hậu','Vinh Hau','Xã Vĩnh Hậu','Vinh Hau Commune','vinh_hau','91',4),
('30376','Tân Châu','Tan Chau','Phường Tân Châu','Tan Chau Ward','tan_chau','91',3),
('30377','Long Phú','Long Phu','Phường Long Phú','Long Phu Ward','long_phu','91',3),
('30385','Vĩnh Xương','Vinh Xuong','Xã Vĩnh Xương','Vinh Xuong Commune','vinh_xuong','91',4),
('30388','Tân An','Tan An','Xã Tân An','Tan An Commune','tan_an','91',4),
('30403','Châu Phong','Chau Phong','Xã Châu Phong','Chau Phong Commune','chau_phong','91',4),
('30406','Phú Tân','Phu Tan','Xã Phú Tân','Phu Tan Commune','phu_tan','91',4),
('30409','Chợ Vàm','Cho Vam','Xã Chợ Vàm','Cho Vam Commune','cho_vam','91',4),
('30421','Phú Lâm','Phu Lam','Xã Phú Lâm','Phu Lam Commune','phu_lam','91',4),
('30430','Hòa Lạc','Hoa Lac','Xã Hòa Lạc','Hoa Lac Commune','hoa_lac','91',4),
('30436','Phú An','Phu An','Xã Phú An','Phu An Commune','phu_an','91',4),
('30445','Bình Thạnh Đông','Binh Thanh Dong','Xã Bình Thạnh Đông','Binh Thanh Dong Commune','binh_thanh_dong','91',4),
('30463','Châu Phú','Chau Phu','Xã Châu Phú','Chau Phu Commune','chau_phu','91',4),
('30469','Mỹ Đức','My Duc','Xã Mỹ Đức','My Duc Commune','my_duc','91',4),
('30478','Vĩnh Thạnh Trung','Vinh Thanh Trung','Xã Vĩnh Thạnh Trung','Vinh Thanh Trung Commune','vinh_thanh_trung','91',4),
('30481','Thạnh Mỹ Tây','Thanh My Tay','Xã Thạnh Mỹ Tây','Thanh My Tay Commune','thanh_my_tay','91',4),
('30487','Bình Mỹ','Binh My','Xã Bình Mỹ','Binh My Commune','binh_my','91',4),
('30502','Thới Sơn','Thoi Son','Phường Thới Sơn','Thoi Son Ward','thoi_son','91',3),
('30505','Chi Lăng','Chi Lang','Phường Chi Lăng','Chi Lang Ward','chi_lang','91',3),
('30520','Tịnh Biên','Tinh Bien','Phường Tịnh Biên','Tinh Bien Ward','tinh_bien','91',3),
('30526','An Cư','An Cu','Xã An Cư','An Cu Commune','an_cu','91',4),
('30538','Núi Cấm','Nui Cam','Xã Núi Cấm','Nui Cam Commune','nui_cam','91',4),
('30544','Tri Tôn','Tri Ton','Xã Tri Tôn','Tri Ton Commune','tri_ton','91',4),
('30547','Ba Chúc','Ba Chuc','Xã Ba Chúc','Ba Chuc Commune','ba_chuc','91',4),
('30568','Vĩnh Gia','Vinh Gia','Xã Vĩnh Gia','Vinh Gia Commune','vinh_gia','91',4),
('30577','Ô Lâm','O Lam','Xã Ô Lâm','O Lam Commune','o_lam','91',4),
('30580','Cô Tô','Co To','Xã Cô Tô','Co To Commune','co_to','91',4),
('30589','An Châu','An Chau','Xã An Châu','An Chau Commune','an_chau','91',4),
('30595','Cần Đăng','Can Dang','Xã Cần Đăng','Can Dang Commune','can_dang','91',4),
('30604','Vĩnh An','Vinh An','Xã Vĩnh An','Vinh An Commune','vinh_an','91',4),
('30607','Bình Hòa','Binh Hoa','Xã Bình Hòa','Binh Hoa Commune','binh_hoa','91',4),
('30619','Vĩnh Hanh','Vinh Hanh','Xã Vĩnh Hanh','Vinh Hanh Commune','vinh_hanh','91',4),
('30628','Chợ Mới','Cho Moi','Xã Chợ Mới','Cho Moi Commune','cho_moi','91',4),
('30631','Long Điền','Long Dien','Xã Long Điền','Long Dien Commune','long_dien','91',4),
('30643','Cù Lao Giêng','Cu Lao Gieng','Xã Cù Lao Giêng','Cu Lao Gieng Commune','cu_lao_gieng','91',4),
('30658','Nhơn Mỹ','Nhon My','Xã Nhơn Mỹ','Nhon My Commune','nhon_my','91',4),
('30664','Long Kiến','Long Kien','Xã Long Kiến','Long Kien Commune','long_kien','91',4),
('30673','Hội An','Hoi An','Xã Hội An','Hoi An Commune','hoi_an','91',4),
('30682','Thoại Sơn','Thoai Son','Xã Thoại Sơn','Thoai Son Commune','thoai_son','91',4),
('30685','Phú Hòa','Phu Hoa','Xã Phú Hòa','Phu Hoa Commune','phu_hoa','91',4),
('30688','Óc Eo','Oc Eo','Xã Óc Eo','Oc Eo Commune','oc_eo','91',4),
('30691','Tây Phú','Tay Phu','Xã Tây Phú','Tay Phu Commune','tay_phu','91',4),
('30697','Vĩnh Trạch','Vinh Trach','Xã Vĩnh Trạch','Vinh Trach Commune','vinh_trach','91',4),
('30709','Định Mỹ','Dinh My','Xã Định Mỹ','Dinh My Commune','dinh_my','91',4),
('30742','Rạch Giá','Rach Gia','Phường Rạch Giá','Rach Gia Ward','rach_gia','91',3),
('30760','Vĩnh Thông','Vinh Thong','Phường Vĩnh Thông','Vinh Thong Ward','vinh_thong','91',3),
('30766','Tô Châu','To Chau','Phường Tô Châu','To Chau Ward','to_chau','91',3),
('30769','Hà Tiên','Ha Tien','Phường Hà Tiên','Ha Tien Ward','ha_tien','91',3),
('30781','Tiên Hải','Tien Hai','Xã Tiên Hải','Tien Hai Commune','tien_hai','91',4),
('30787','Kiên Lương','Kien Luong','Xã Kiên Lương','Kien Luong Commune','kien_luong','91',4),
('30790','Hòa Điền','Hoa Dien','Xã Hòa Điền','Hoa Dien Commune','hoa_dien','91',4),
('30793','Vĩnh Điều','Vinh Dieu','Xã Vĩnh Điều','Vinh Dieu Commune','vinh_dieu','91',4),
('30796','Giang Thành','Giang Thanh','Xã Giang Thành','Giang Thanh Commune','giang_thanh','91',4),
('30811','Sơn Hải','Son Hai','Xã Sơn Hải','Son Hai Commune','son_hai','91',4),
('30814','Hòn Nghệ','Hon Nghe','Xã Hòn Nghệ','Hon Nghe Commune','hon_nghe','91',4),
('30817','Hòn Đất','Hon Dat','Xã Hòn Đất','Hon Dat Commune','hon_dat','91',4),
('30823','Bình Sơn','Binh Son','Xã Bình Sơn','Binh Son Commune','binh_son','91',4),
('30826','Bình Giang','Binh Giang','Xã Bình Giang','Binh Giang Commune','binh_giang','91',4),
('30835','Sơn Kiên','Son Kien','Xã Sơn Kiên','Son Kien Commune','son_kien','91',4),
('30838','Mỹ Thuận','My Thuan','Xã Mỹ Thuận','My Thuan Commune','my_thuan','91',4),
('30850','Tân Hiệp','Tan Hiep','Xã Tân Hiệp','Tan Hiep Commune','tan_hiep','91',4),
('30856','Tân Hội','Tan Hoi','Xã Tân Hội','Tan Hoi Commune','tan_hoi','91',4),
('30874','Thạnh Đông','Thanh Dong','Xã Thạnh Đông','Thanh Dong Commune','thanh_dong','91',4),
('30880','Châu Thành','Chau Thanh','Xã Châu Thành','Chau Thanh Commune','chau_thanh','91',4),
('30886','Thạnh Lộc','Thanh Loc','Xã Thạnh Lộc','Thanh Loc Commune','thanh_loc','91',4),
('30898','Bình An','Binh An','Xã Bình An','Binh An Commune','binh_an','91',4),
('30904','Giồng Riềng','Giong Rieng','Xã Giồng Riềng','Giong Rieng Commune','giong_rieng','91',4),
('30910','Thạnh Hưng','Thanh Hung','Xã Thạnh Hưng','Thanh Hung Commune','thanh_hung','91',4),
('30928','Ngọc Chúc','Ngoc Chuc','Xã Ngọc Chúc','Ngoc Chuc Commune','ngoc_chuc','91',4),
('30934','Hòa Hưng','Hoa Hung','Xã Hòa Hưng','Hoa Hung Commune','hoa_hung','91',4),
('30943','Long Thạnh','Long Thanh','Xã Long Thạnh','Long Thanh Commune','long_thanh','91',4),
('30949','Hòa Thuận','Hoa Thuan','Xã Hòa Thuận','Hoa Thuan Commune','hoa_thuan','91',4),
('30952','Gò Quao','Go Quao','Xã Gò Quao','Go Quao Commune','go_quao','91',4),
('30958','Định Hòa','Dinh Hoa','Xã Định Hòa','Dinh Hoa Commune','dinh_hoa','91',4),
('30970','Vĩnh Hòa Hưng','Vinh Hoa Hung','Xã Vĩnh Hòa Hưng','Vinh Hoa Hung Commune','vinh_hoa_hung','91',4),
('30982','Vĩnh Tuy','Vinh Tuy','Xã Vĩnh Tuy','Vinh Tuy Commune','vinh_tuy','91',4),
('30985','An Biên','An Bien','Xã An Biên','An Bien Commune','an_bien','91',4),
('30988','Tây Yên','Tay Yen','Xã Tây Yên','Tay Yen Commune','tay_yen','91',4),
('31006','Đông Thái','Dong Thai','Xã Đông Thái','Dong Thai Commune','dong_thai','91',4),
('31012','Vĩnh Hòa','Vinh Hoa','Xã Vĩnh Hòa','Vinh Hoa Commune','vinh_hoa','91',4),
('31018','An Minh','An Minh','Xã An Minh','An Minh Commune','an_minh','91',4),
('31024','Đông Hòa','Dong Hoa','Xã Đông Hòa','Dong Hoa Commune','dong_hoa','91',4),
('31027','U Minh Thượng','U Minh Thuong','Xã U Minh Thượng','U Minh Thuong Commune','u_minh_thuong','91',4),
('31031','Tân Thạnh','Tan Thanh','Xã Tân Thạnh','Tan Thanh Commune','tan_thanh','91',4),
('31036','Đông Hưng','Dong Hung','Xã Đông Hưng','Dong Hung Commune','dong_hung','91',4),
('31042','Vân Khánh','Van Khanh','Xã Vân Khánh','Van Khanh Commune','van_khanh','91',4),
('31051','Vĩnh Phong','Vinh Phong','Xã Vĩnh Phong','Vinh Phong Commune','vinh_phong','91',4),
('31064','Vĩnh Bình','Vinh Binh','Xã Vĩnh Bình','Vinh Binh Commune','vinh_binh','91',4),
('31069','Vĩnh Thuận','Vinh Thuan','Xã Vĩnh Thuận','Vinh Thuan Commune','vinh_thuan','91',4),
('31078','Phú Quốc','Phu Quoc','Đặc khu Phú Quốc','Phu Quoc Special administrative region','phu_quoc','91',5),
('31105','Thổ Châu','Tho Chau','Đặc khu Thổ Châu','Tho Chau Special administrative region','tho_chau','91',5),
('31108','Kiên Hải','Kien Hai','Đặc khu Kiên Hải','Kien Hai Special administrative region','kien_hai','91',5),
('31120','Cái Khế','Cai Khe','Phường Cái Khế','Cai Khe Ward','cai_khe','92',3),
('31135','Ninh Kiều','Ninh Kieu','Phường Ninh Kiều','Ninh Kieu Ward','ninh_kieu','92',3),
('31147','Tân An','Tan An','Phường Tân An','Tan An Ward','tan_an','92',3),
('31150','An Bình','An Binh','Phường An Bình','An Binh Ward','an_binh','92',3),
('31153','Ô Môn','O Mon','Phường Ô Môn','O Mon Ward','o_mon','92',3),
('31157','Thới Long','Thoi Long','Phường Thới Long','Thoi Long Ward','thoi_long','92',3),
('31162','Phước Thới','Phuoc Thoi','Phường Phước Thới','Phuoc Thoi Ward','phuoc_thoi','92',3),
('31168','Bình Thủy','Binh Thuy','Phường Bình Thủy','Binh Thuy Ward','binh_thuy','92',3),
('31174','Thới An Đông','Thoi An Dong','Phường Thới An Đông','Thoi An Dong Ward','thoi_an_dong','92',3),
('31183','Long Tuyền','Long Tuyen','Phường Long Tuyền','Long Tuyen Ward','long_tuyen','92',3),
('31186','Cái Răng','Cai Rang','Phường Cái Răng','Cai Rang Ward','cai_rang','92',3),
('31201','Hưng Phú','Hung Phu','Phường Hưng Phú','Hung Phu Ward','hung_phu','92',3),
('31207','Thốt Nốt','Thot Not','Phường Thốt Nốt','Thot Not Ward','thot_not','92',3),
('31213','Tân Lộc','Tan Loc','Phường Tân Lộc','Tan Loc Ward','tan_loc','92',3),
('31217','Trung Nhứt','Trung Nhut','Phường Trung Nhứt','Trung Nhut Ward','trung_nhut','92',3),
('31228','Thuận Hưng','Thuan Hung','Phường Thuận Hưng','Thuan Hung Ward','thuan_hung','92',3),
('31231','Thạnh An','Thanh An','Xã Thạnh An','Thanh An Commune','thanh_an','92',4),
('31232','Vĩnh Thạnh','Vinh Thanh','Xã Vĩnh Thạnh','Vinh Thanh Commune','vinh_thanh','92',4),
('31237','Vĩnh Trinh','Vinh Trinh','Xã Vĩnh Trinh','Vinh Trinh Commune','vinh_trinh','92',4),
('31246','Thạnh Quới','Thanh Quoi','Xã Thạnh Quới','Thanh Quoi Commune','thanh_quoi','92',4),
('31249','Thạnh Phú','Thanh Phu','Xã Thạnh Phú','Thanh Phu Commune','thanh_phu','92',4),
('31255','Trung Hưng','Trung Hung','Xã Trung Hưng','Trung Hung Commune','trung_hung','92',4),
('31258','Thới Lai','Thoi Lai','Xã Thới Lai','Thoi Lai Commune','thoi_lai','92',4),
('31261','Cờ Đỏ','Co Do','Xã Cờ Đỏ','Co Do Commune','co_do','92',4),
('31264','Thới Hưng','Thoi Hung','Xã Thới Hưng','Thoi Hung Commune','thoi_hung','92',4),
('31273','Đông Hiệp','Dong Hiep','Xã Đông Hiệp','Dong Hiep Commune','dong_hiep','92',4),
('31282','Đông Thuận','Dong Thuan','Xã Đông Thuận','Dong Thuan Commune','dong_thuan','92',4),
('31288','Trường Thành','Truong Thanh','Xã Trường Thành','Truong Thanh Commune','truong_thanh','92',4),
('31294','Trường Xuân','Truong Xuan','Xã Trường Xuân','Truong Xuan Commune','truong_xuan','92',4),
('31299','Phong Điền','Phong Dien','Xã Phong Điền','Phong Dien Commune','phong_dien','92',4),
('31309','Trường Long','Truong Long','Xã Trường Long','Truong Long Commune','truong_long','92',4),
('31315','Nhơn Ái','Nhon Ai','Xã Nhơn Ái','Nhon Ai Commune','nhon_ai','92',4),
('31321','Vị Thanh','Vi Thanh','Phường Vị Thanh','Vi Thanh Ward','vi_thanh','92',3),
('31333','Vị Tân','Vi Tan','Phường Vị Tân','Vi Tan Ward','vi_tan','92',3),
('31338','Hỏa Lựu','Hoa Luu','Xã Hỏa Lựu','Hoa Luu Commune','hoa_luu','92',4),
('31340','Ngã Bảy','Nga Bay','Phường Ngã Bảy','Nga Bay Ward','nga_bay','92',3),
('31342','Tân Hòa','Tan Hoa','Xã Tân Hòa','Tan Hoa Commune','tan_hoa','92',4),
('31348','Trường Long Tây','Truong Long Tay','Xã Trường Long Tây','Truong Long Tay Commune','truong_long_tay','92',4),
('31360','Thạnh Xuân','Thanh Xuan','Xã Thạnh Xuân','Thanh Xuan Commune','thanh_xuan','92',4),
('31366','Châu Thành','Chau Thanh','Xã Châu Thành','Chau Thanh Commune','chau_thanh','92',4),
('31369','Đông Phước','Dong Phuoc','Xã Đông Phước','Dong Phuoc Commune','dong_phuoc','92',4),
('31378','Phú Hữu','Phu Huu','Xã Phú Hữu','Phu Huu Commune','phu_huu','92',4),
('31393','Hòa An','Hoa An','Xã Hòa An','Hoa An Commune','hoa_an','92',4),
('31396','Hiệp Hưng','Hiep Hung','Xã Hiệp Hưng','Hiep Hung Commune','hiep_hung','92',4),
('31399','Tân Bình','Tan Binh','Xã Tân Bình','Tan Binh Commune','tan_binh','92',4),
('31408','Thạnh Hòa','Thanh Hoa','Xã Thạnh Hòa','Thanh Hoa Commune','thanh_hoa','92',4),
('31411','Đại Thành','Dai Thanh','Phường Đại Thành','Dai Thanh Ward','dai_thanh','92',3),
('31420','Phụng Hiệp','Phung Hiep','Xã Phụng Hiệp','Phung Hiep Commune','phung_hiep','92',4),
('31426','Phương Bình','Phuong Binh','Xã Phương Bình','Phuong Binh Commune','phuong_binh','92',4),
('31432','Tân Phước Hưng','Tan Phuoc Hung','Xã Tân Phước Hưng','Tan Phuoc Hung Commune','tan_phuoc_hung','92',4),
('31441','Vị Thủy','Vi Thuy','Xã Vị Thủy','Vi Thuy Commune','vi_thuy','92',4),
('31453','Vĩnh Thuận Đông','Vinh Thuan Dong','Xã Vĩnh Thuận Đông','Vinh Thuan Dong Commune','vinh_thuan_dong','92',4),
('31459','Vĩnh Tường','Vinh Tuong','Xã Vĩnh Tường','Vinh Tuong Commune','vinh_tuong','92',4),
('31465','Vị Thanh 1','Vi Thanh 1','Xã Vị Thanh 1','Vi Thanh 1 Commune','vi_thanh_1','92',4),
('31471','Long Mỹ','Long My','Phường Long Mỹ','Long My Ward','long_my','92',3),
('31473','Long Bình','Long Binh','Phường Long Bình','Long Binh Ward','long_binh','92',3),
('31480','Long Phú 1','Long Phu 1','Phường Long Phú 1','Long Phu 1 Ward','long_phu_1','92',3),
('31489','Vĩnh Viễn','Vinh Vien','Xã Vĩnh Viễn','Vinh Vien Commune','vinh_vien','92',4),
('31492','Lương Tâm','Luong Tam','Xã Lương Tâm','Luong Tam Commune','luong_tam','92',4),
('31495','Xà Phiên','Xa Phien','Xã Xà Phiên','Xa Phien Commune','xa_phien','92',4),
('31507','Sóc Trăng','Soc Trang','Phường Sóc Trăng','Soc Trang Ward','soc_trang','92',3),
('31510','Phú Lợi','Phu Loi','Phường Phú Lợi','Phu Loi Ward','phu_loi','92',3),
('31528','Kế Sách','Ke Sach','Xã Kế Sách','Ke Sach Commune','ke_sach','92',4),
('31531','An Lạc Thôn','An Lac Thon','Xã An Lạc Thôn','An Lac Thon Commune','an_lac_thon','92',4),
('31537','Phong Nẫm','Phong Nam','Xã Phong Nẫm','Phong Nam Commune','phong_nam','92',4),
('31540','Thới An Hội','Thoi An Hoi','Xã Thới An Hội','Thoi An Hoi Commune','thoi_an_hoi','92',4),
('31552','Nhơn Mỹ','Nhon My','Xã Nhơn Mỹ','Nhon My Commune','nhon_my','92',4),
('31561','Đại Hải','Dai Hai','Xã Đại Hải','Dai Hai Commune','dai_hai','92',4),
('31567','Mỹ Tú','My Tu','Xã Mỹ Tú','My Tu Commune','my_tu','92',4),
('31569','Phú Tâm','Phu Tam','Xã Phú Tâm','Phu Tam Commune','phu_tam','92',4),
('31570','Hồ Đắc Kiện','Ho Dac Kien','Xã Hồ Đắc Kiện','Ho Dac Kien Commune','ho_dac_kien','92',4),
('31579','Long Hưng','Long Hung','Xã Long Hưng','Long Hung Commune','long_hung','92',4),
('31582','Thuận Hòa','Thuan Hoa','Xã Thuận Hòa','Thuan Hoa Commune','thuan_hoa','92',4),
('31591','Mỹ Hương','My Huong','Xã Mỹ Hương','My Huong Commune','my_huong','92',4),
('31594','An Ninh','An Ninh','Xã An Ninh','An Ninh Commune','an_ninh','92',4),
('31603','Mỹ Phước','My Phuoc','Xã Mỹ Phước','My Phuoc Commune','my_phuoc','92',4),
('31615','An Thạnh','An Thanh','Xã An Thạnh','An Thanh Commune','an_thanh','92',4),
('31633','Cù Lao Dung','Cu Lao Dung','Xã Cù Lao Dung','Cu Lao Dung Commune','cu_lao_dung','92',4),
('31639','Long Phú','Long Phu','Xã Long Phú','Long Phu Commune','long_phu','92',4),
('31645','Đại Ngãi','Dai Ngai','Xã Đại Ngãi','Dai Ngai Commune','dai_ngai','92',4),
('31654','Trường Khánh','Truong Khanh','Xã Trường Khánh','Truong Khanh Commune','truong_khanh','92',4),
('31666','Tân Thạnh','Tan Thanh','Xã Tân Thạnh','Tan Thanh Commune','tan_thanh','92',4),
('31673','Trần Đề','Tran De','Xã Trần Đề','Tran De Commune','tran_de','92',4),
('31675','Liêu Tú','Lieu Tu','Xã Liêu Tú','Lieu Tu Commune','lieu_tu','92',4),
('31679','Lịch Hội Thượng','Lich Hoi Thuong','Xã Lịch Hội Thượng','Lich Hoi Thuong Commune','lich_hoi_thuong','92',4),
('31684','Mỹ Xuyên','My Xuyen','Phường Mỹ Xuyên','My Xuyen Ward','my_xuyen','92',3),
('31687','Tài Văn','Tai Van','Xã Tài Văn','Tai Van Commune','tai_van','92',4),
('31699','Thạnh Thới An','Thanh Thoi An','Xã Thạnh Thới An','Thanh Thoi An Commune','thanh_thoi_an','92',4),
('31708','Nhu Gia','Nhu Gia','Xã Nhu Gia','Nhu Gia Commune','nhu_gia','92',4),
('31717','Hòa Tú','Hoa Tu','Xã Hòa Tú','Hoa Tu Commune','hoa_tu','92',4),
('31723','Ngọc Tố','Ngoc To','Xã Ngọc Tố','Ngoc To Commune','ngoc_to','92',4),
('31726','Gia Hòa','Gia Hoa','Xã Gia Hòa','Gia Hoa Commune','gia_hoa','92',4),
('31732','Ngã Năm','Nga Nam','Phường Ngã Năm','Nga Nam Ward','nga_nam','92',3),
('31741','Tân Long','Tan Long','Xã Tân Long','Tan Long Commune','tan_long','92',4),
('31753','Mỹ Quới','My Quoi','Phường Mỹ Quới','My Quoi Ward','my_quoi','92',3),
('31756','Phú Lộc','Phu Loc','Xã Phú Lộc','Phu Loc Commune','phu_loc','92',4),
('31759','Lâm Tân','Lam Tan','Xã Lâm Tân','Lam Tan Commune','lam_tan','92',4),
('31777','Vĩnh Lợi','Vinh Loi','Xã Vĩnh Lợi','Vinh Loi Commune','vinh_loi','92',4),
('31783','Vĩnh Châu','Vinh Chau','Phường Vĩnh Châu','Vinh Chau Ward','vinh_chau','92',3),
('31789','Khánh Hòa','Khanh Hoa','Phường Khánh Hòa','Khanh Hoa Ward','khanh_hoa','92',3),
('31795','Vĩnh Hải','Vinh Hai','Xã Vĩnh Hải','Vinh Hai Commune','vinh_hai','92',4),
('31804','Vĩnh Phước','Vinh Phuoc','Phường Vĩnh Phước','Vinh Phuoc Ward','vinh_phuoc','92',3),
('31810','Lai Hòa','Lai Hoa','Xã Lai Hòa','Lai Hoa Commune','lai_hoa','92',4),
('31825','Bạc Liêu','Bac Lieu','Phường Bạc Liêu','Bac Lieu Ward','bac_lieu','96',3),
('31834','Vĩnh Trạch','Vinh Trach','Phường Vĩnh Trạch','Vinh Trach Ward','vinh_trach','96',3),
('31840','Hiệp Thành','Hiep Thanh','Phường Hiệp Thành','Hiep Thanh Ward','hiep_thanh','96',3),
('31843','Hồng Dân','Hong Dan','Xã Hồng Dân','Hong Dan Commune','hong_dan','96',4),
('31849','Ninh Quới','Ninh Quoi','Xã Ninh Quới','Ninh Quoi Commune','ninh_quoi','96',4),
('31858','Vĩnh Lộc','Vinh Loc','Xã Vĩnh Lộc','Vinh Loc Commune','vinh_loc','96',4),
('31864','Ninh Thạnh Lợi','Ninh Thanh Loi','Xã Ninh Thạnh Lợi','Ninh Thanh Loi Commune','ninh_thanh_loi','96',4),
('31867','Phước Long','Phuoc Long','Xã Phước Long','Phuoc Long Commune','phuoc_long','96',4),
('31876','Vĩnh Phước','Vinh Phuoc','Xã Vĩnh Phước','Vinh Phuoc Commune','vinh_phuoc','96',4),
('31882','Vĩnh Thanh','Vinh Thanh','Xã Vĩnh Thanh','Vinh Thanh Commune','vinh_thanh','96',4),
('31885','Phong Hiệp','Phong Hiep','Xã Phong Hiệp','Phong Hiep Commune','phong_hiep','96',4),
('31891','Hòa Bình','Hoa Binh','Xã Hòa Bình','Hoa Binh Commune','hoa_binh','96',4),
('31894','Châu Thới','Chau Thoi','Xã Châu Thới','Chau Thoi Commune','chau_thoi','96',4),
('31900','Vĩnh Lợi','Vinh Loi','Xã Vĩnh Lợi','Vinh Loi Commune','vinh_loi','96',4),
('31906','Hưng Hội','Hung Hoi','Xã Hưng Hội','Hung Hoi Commune','hung_hoi','96',4),
('31918','Vĩnh Mỹ','Vinh My','Xã Vĩnh Mỹ','Vinh My Commune','vinh_my','96',4),
('31927','Vĩnh Hậu','Vinh Hau','Xã Vĩnh Hậu','Vinh Hau Commune','vinh_hau','96',4),
('31942','Giá Rai','Gia Rai','Phường Giá Rai','Gia Rai Ward','gia_rai','96',3),
('31951','Láng Tròn','Lang Tron','Phường Láng Tròn','Lang Tron Ward','lang_tron','96',3),
('31957','Phong Thạnh','Phong Thanh','Xã Phong Thạnh','Phong Thanh Commune','phong_thanh','96',4),
('31972','Gành Hào','Ganh Hao','Xã Gành Hào','Ganh Hao Commune','ganh_hao','96',4),
('31975','Đông Hải','Dong Hai','Xã Đông Hải','Dong Hai Commune','dong_hai','96',4),
('31985','Long Điền','Long Dien','Xã Long Điền','Long Dien Commune','long_dien','96',4),
('31988','An Trạch','An Trach','Xã An Trạch','An Trach Commune','an_trach','96',4),
('31993','Định Thành','Dinh Thanh','Xã Định Thành','Dinh Thanh Commune','dinh_thanh','96',4),
('32002','An Xuyên','An Xuyen','Phường An Xuyên','An Xuyen Ward','an_xuyen','96',3),
('32014','Lý Văn Lâm','Ly Van Lam','Phường Lý Văn Lâm','Ly Van Lam Ward','ly_van_lam','96',3),
('32025','Tân Thành','Tan Thanh','Phường Tân Thành','Tan Thanh Ward','tan_thanh','96',3),
('32041','Hòa Thành','Hoa Thanh','Phường Hòa Thành','Hoa Thanh Ward','hoa_thanh','96',3),
('32044','Nguyễn Phích','Nguyen Phich','Xã Nguyễn Phích','Nguyen Phich Commune','nguyen_phich','96',4),
('32047','U Minh','U Minh','Xã U Minh','U Minh Commune','u_minh','96',4),
('32059','Khánh An','Khanh An','Xã Khánh An','Khanh An Commune','khanh_an','96',4),
('32062','Khánh Lâm','Khanh Lam','Xã Khánh Lâm','Khanh Lam Commune','khanh_lam','96',4),
('32065','Thới Bình','Thoi Binh','Xã Thới Bình','Thoi Binh Commune','thoi_binh','96',4),
('32069','Biển Bạch','Bien Bach','Xã Biển Bạch','Bien Bach Commune','bien_bach','96',4),
('32071','Trí Phải','Tri Phai','Xã Trí Phải','Tri Phai Commune','tri_phai','96',4),
('32083','Tân Lộc','Tan Loc','Xã Tân Lộc','Tan Loc Commune','tan_loc','96',4),
('32092','Hồ Thị Kỷ','Ho Thi Ky','Xã Hồ Thị Kỷ','Ho Thi Ky Commune','ho_thi_ky','96',4),
('32095','Trần Văn Thời','Tran Van Thoi','Xã Trần Văn Thời','Tran Van Thoi Commune','tran_van_thoi','96',4),
('32098','Sông Đốc','Song Doc','Xã Sông Đốc','Song Doc Commune','song_doc','96',4),
('32104','Đá Bạc','Da Bac','Xã Đá Bạc','Da Bac Commune','da_bac','96',4),
('32110','Khánh Bình','Khanh Binh','Xã Khánh Bình','Khanh Binh Commune','khanh_binh','96',4),
('32119','Khánh Hưng','Khanh Hung','Xã Khánh Hưng','Khanh Hung Commune','khanh_hung','96',4),
('32128','Cái Nước','Cai Nuoc','Xã Cái Nước','Cai Nuoc Commune','cai_nuoc','96',4),
('32134','Lương Thế Trân','Luong The Tran','Xã Lương Thế Trân','Luong The Tran Commune','luong_the_tran','96',4),
('32137','Tân Hưng','Tan Hung','Xã Tân Hưng','Tan Hung Commune','tan_hung','96',4),
('32140','Hưng Mỹ','Hung My','Xã Hưng Mỹ','Hung My Commune','hung_my','96',4),
('32152','Đầm Dơi','Dam Doi','Xã Đầm Dơi','Dam Doi Commune','dam_doi','96',4),
('32155','Tạ An Khương','Ta An Khuong','Xã Tạ An Khương','Ta An Khuong Commune','ta_an_khuong','96',4),
('32161','Trần Phán','Tran Phan','Xã Trần Phán','Tran Phan Commune','tran_phan','96',4),
('32167','Tân Thuận','Tan Thuan','Xã Tân Thuận','Tan Thuan Commune','tan_thuan','96',4),
('32182','Quách Phẩm','Quach Pham','Xã Quách Phẩm','Quach Pham Commune','quach_pham','96',4),
('32185','Thanh Tùng','Thanh Tung','Xã Thanh Tùng','Thanh Tung Commune','thanh_tung','96',4),
('32188','Tân Tiến','Tan Tien','Xã Tân Tiến','Tan Tien Commune','tan_tien','96',4),
('32191','Năm Căn','Nam Can','Xã Năm Căn','Nam Can Commune','nam_can','96',4),
('32201','Đất Mới','Dat Moi','Xã Đất Mới','Dat Moi Commune','dat_moi','96',4),
('32206','Tam Giang','Tam Giang','Xã Tam Giang','Tam Giang Commune','tam_giang','96',4),
('32212','Cái Đôi Vàm','Cai Doi Vam','Xã Cái Đôi Vàm','Cai Doi Vam Commune','cai_doi_vam','96',4),
('32214','Phú Mỹ','Phu My','Xã Phú Mỹ','Phu My Commune','phu_my','96',4),
('32218','Phú Tân','Phu Tan','Xã Phú Tân','Phu Tan Commune','phu_tan','96',4),
('32227','Nguyễn Việt Khái','Nguyen Viet Khai','Xã Nguyễn Việt Khái','Nguyen Viet Khai Commune','nguyen_viet_khai','96',4),
('32236','Tân Ân','Tan An','Xã Tân Ân','Tan An Commune','tan_an','96',4),
('32244','Phan Ngọc Hiển','Phan Ngoc Hien','Xã Phan Ngọc Hiển','Phan Ngoc Hien Commune','phan_ngoc_hien','96',4),
('32248','Đất Mũi','Dat Mui','Xã Đất Mũi','Dat Mui Commune','dat_mui','96',4);
/*!40000 ALTER TABLE `wards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-05-20  1:43:49
